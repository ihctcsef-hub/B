# Demo photographs

These two photographs are bundled locally so the demo canvas does not make external image requests.

- `studio-objects.jpg`: https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85
- `studio-light.jpg`: https://images.unsplash.com/photo-1484154218962-a197022b5858

Source: Unsplash. License: https://unsplash.com/license

These are demonstration reference photographs, not Milanote assets.
