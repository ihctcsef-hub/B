# Local background-removal model

`u2netp.onnx` is the small U²-Net salient-object segmentation model (not a portrait-only model).

- Original implementation and pretrained model: https://github.com/xuebinqin/U-2-Net (Apache-2.0; retained as `U2NET-LICENSE.txt`).
- ONNX conversion distributed by rembg: https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2netp.onnx (rembg MIT notice retained as `REMBG-LICENSE.txt`).
- Official rembg session/checksum definition: https://github.com/danielgatis/rembg/blob/main/rembg/sessions/u2netp.py
- Size: 4,574,861 bytes.
- MD5: `8e83ca70e441ab06c318d82300c84806` (matches upstream rembg definition).
- SHA-256: `309c8469258dda742793dce0ebea8e6dd393174f89934733ecc8b14c76f4ddd8`.

The model runs locally in ONNX Runtime Web using the bundled WASM runtime. No image is sent to a segmentation server. Its foreground predictions are an independent implementation; they have not been proved identical to Milanote's model or boundary matte.
