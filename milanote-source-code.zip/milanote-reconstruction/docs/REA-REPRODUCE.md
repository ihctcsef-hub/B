# Repeating the investigation

The shipped archive contains original reconstruction code and an evidence summary. Captured Milanote program sources are kept separately as research inputs, not redistributed.

Use the official [REA repository](https://github.com/morluto/rea). The investigation used the published CLI `rea-agents@6.7.0`; repository main can advertise newer features. Check each command's `--help` for the installed version. The CLI workflow requires no global MCP registration.

Start a dedicated Chromium profile with a loopback-only debugging endpoint (use your installed executable):

```bash
chromium --remote-debugging-port=9222 --user-data-dir=/tmp/milanote-investigation https://app.milanote.com/
```

```bash
npx --yes --package=rea-agents@6.7.0 -- rea list-browser-targets http://127.0.0.1:9222 --format json
npx --yes --package=rea-agents@6.7.0 -- rea inspect-web-page http://127.0.0.1:9222 TARGET_ID --include-accessibility-text --format json
npx --yes --package=rea-agents@6.7.0 -- rea capture-web-screenshot http://127.0.0.1:9222 TARGET_ID --format json
```

`TARGET_ID` comes from discovery and changes with each browser instance. Scope captures to the intended app origin. Additional script capture/static analysis and any cross-origin scope should be explicitly selected per current REA command help. Preserve complete evidence outside the implementation archive. Public script labels establish shipped vocabulary; they do not prove which editor tools actually ran.

This environment's browser certificate issue was fixed by enabling access to its configured NSS certificate database. TLS verification stayed enabled. On other machines use the normal system trust store and your environment's documented proxy CA setup; do not copy the environment-specific launch workaround blindly.

For full reference comparison, sign in to an empty test workspace and record each tool action with before/after screenshots. Account credentials and session cookies must remain out of source files and archives. No account or login was created during this investigation.
