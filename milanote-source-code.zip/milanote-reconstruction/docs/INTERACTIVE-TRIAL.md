# المعاينة التفاعلية الخاصة

الرابط: https://milanote-tools-trial-nov5.heroicchicory.chatgpt.site

حالة النشر مؤكدة: succeeded. الوصول خاص بمالك الموقع عبر ChatGPT. البيانات المحلية تبقى في متصفح المستخدم.

المصدر المنشور: `/workspace/sites/milanote-trial`؛ هو نسخة ثابتة من البناء الحالي، ولا يغير أصل المشروع. الهوية محفوظة في `.openai/hosting.json` داخل ذلك المجلد؛ أعد استخدامها عند تحديث هذه المعاينة ولا تنشئ موقعًا جديدًا.

Project: `appgprj_6aec36e7eeb481918d10d27cda0dec3c`

Version: `appgprj_6aec36e7eeb481918d10d27cda0dec3c~appgver_d0dc1d267e8c819182e89a05b16320d9`

Deployment: `appgdep_6aec37da29688191902ed3ab87a274e0`

Commit: `c0ce40be15136243f6c2be371e36cb5f575f35d4`

نجح فحص إضافة ملاحظة باللمس، والتحرير والتنسيق الغامق، والحفظ بعد إعادة التحميل عند 1024×768 بالمحاكاة. هذه ليست شهادة تطابق شامل أو اختبار iPad فعلي. خدمات Pexels وجلب معاينات الروابط الخادمية غير منشورة في هذه النسخة الثابتة.
