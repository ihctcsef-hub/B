# Multiple-image drop layout — working source

Observed and verified2026-10-27. These measurements cover explicit image batches and a single image in an owned reference child board. They do not establish every image-import, mixed-file, zoom, crop or iPad workflow, and do not approve a release.

## Reference observations

The reference browser used native browser-protocol filesystem drag events (`isTrusted=true`) with independently generated PNG fixtures. The earlier09:09 attempt encountered stale SPA content and a deleted-board dialog; it produced no images and is not treated as a layout observation. Successful probes first verified the actual owned child DOM, and each empty-board case removed only newly owned images before reloading.

For a multi-image drop on an empty board, positions start at logical16/16 regardless of the drop point. The layout places each next image in the leftmost column with the shortest current bottom. Columns step288px horizontally, and images are separated vertically by18px. The number of columns follows the available canvas width: the measured1440,1024 and2000 viewports produced4,3 and6 columns respectively. An exact1152px canvas fit4 columns. The six large source images produced:

| Source pixels | Display width | Display height | Position with4 columns |
| --- | ---: | ---: | --- |
|800×400|270|134|16,16|
|400×800|270|542|304,16|
|600×600|270|270|592,16|
|1200×400|270|86|880,16|
|400×1200|270|806|880,120|
|960×640|270|182|16,168|

With3 columns, positions were16/16,304/16,592/16,16/168,16/272,592/304. With6 columns, all six images occupied the first row. The fourth and fifth images in a three-column layout share a column because it remains shortest; this differs from fixed-height rows and from cycling through columns.

Small200×100 and100×200 sources displayed at widths158 and78; their DOM heights were78.40625 and156.5625. The independently implemented sizing rule fitting these measurements is an eight-pixel quantized envelope with a two-pixel inset: width=`max(6, round(min(270, sourceWidth*.8)/8)*8-2)`; height scales from `max(6,round(270*aspect/8)*8-2)` at width270. The six large fixtures and two small fixtures support this empirical rule; it is not a claim about private implementation internals or arbitrary extreme aspect ratios. The6px minimum and malformed/extreme-size safeguards are local policies without a reference measurement.

A two-image drop on a nonempty board at client800/700 produced logical positions736/624 and1024/624, preserving the earlier images. A single image on an empty board honored the snapped drop point instead of moving to16/16: client700/450 produced logical640/368. Directly dropped reference images had no filename captions.

Evidence remains outside source in `/workspace/milanote-analysis/image-grid-*.json` and PNG screenshots. `image-grid-created.json` records36 owned element IDs. The owned child and all currently contained probes were moved to recoverable Trash; fresh root navigation at13:24:22 confirmed every recorded own ID absent and the original two tables and original board tile still present. No permanent empty or deletion was used. `image-grid-cleanup.json` records the check.

## Independent implementation

`src/core/imageGrid.ts` implements measured direct-drop sizing and shortest-column layout. It handles the single-image/empty-group distinction and snaps a nonempty drop origin to8px. The integration applies layout inside the latest-board commit after asynchronous reads and any active gesture finish, preserving existing import cancellation and Undo ordering.

A drop into an existing writable column keeps the column insertion path. Mixed file batches retain their previous positioning path. Upload-button files still enter Unsorted with their editable filename captions and existing dimensions; this channel was not measured against the reference in this task and is not claimed to use the new direct-drop rules. The library-photo path is unchanged. The empty-board test excludes Unsorted cards locally; that policy and panned/zoomed empty-board variants are not fully established by reference probes.

## Verification

Seven unit cases cover independently measured dimensions and positions, exact column-width boundaries, small/invalid source sizes, existing-content preservation, single versus batch drops, and column/mixed-file routing. Source inputs remain immutable.

`tests/image-grid-e2e.mjs` passed eight checks in Chromium and eight in WebKit, including the browser-error check:

- The six-image batch has measured positions, hidden captions, preserved bytes/filenames, one Undo/Redo and persistence through reload.
- A narrow canvas uses three columns and avoids tall-image overlap.
- Nonempty/single-image drops preserve the snapped drop point and existing content.
- Small sources render the measured widths and fractional DOM heights.
- Column ownership and insertion order remain intact.
- Upload-button files remain in Unsorted.
- A deliberately delayed real FileReader callback completes after a new note was added, retaining that note and using the latest nonempty-board layout.

Results and local screenshots are in `artifacts/image-grid-chromium/` and `artifacts/image-grid-webkit/`. Chromium uses native browser-protocol filesystem dragging; WebKit uses an explicitly synthetic HTML5 DragEvent/DataTransfer because that browser driver has no equivalent trusted filesystem drag API. The controlled FileReader callback uses actual file bytes and delays delivery explicitly. Neither test mechanism is a physical iPad interaction.

```sh
npx vitest run tests/image-grid.test.ts
TEST_URL=http://127.0.0.1:5304 node tests/image-grid-e2e.mjs
BROWSER_ENGINE=webkit WEBKIT_PATH=/workspace/.cache/webkit-runner.sh PLAYWRIGHT_BROWSERS_PATH=/workspace/.cache/ms-playwright TEST_URL=http://127.0.0.1:5304 node tests/image-grid-e2e.mjs
```
