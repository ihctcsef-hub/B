# Touch workflow verification — working source

These checks use browser touch emulation at 1024×768 and 768×1024. They do not establish physical iPad, native iPadOS Safari, Apple Pencil, pressure/tilt, virtual-keyboard, long-press, three-finger, or pixel parity with Milanote.

`tests/touch-workflows-e2e.mjs` activates UI controls with Playwright touchscreen taps. Text entry uses Playwright editing; it does not simulate the native virtual keyboard. Chromium additionally moves a card with trusted `Input.dispatchTouchEvent` browser-protocol touch events and verifies that Undo restores its position. The Chromium drag/Undo scenario uses a 600ms pause after the completed drag and an 80ms Undo contact; immediate Undo is not asserted. An independent Chromium input trace explains the earlier 100ms-pause failure: the fast CDP drag generated `GestureFlingStart` (velocity 727.9/582.3) even though the TouchActionFilter filtered native scrolling for `touch-action:none`. The following Undo touch at 114ms cancelled that fling; its tap events were `FilterTapSuppression` / `FilteredForFling`, so Chromium omitted the click before React could handle it. The 600ms pause lets this synthetic browser gesture settle. A control run instead held the finger stationary for 180ms before release, retained the original 100ms afterward, and passed with zero fling/tap-suppression events. This isolates release velocity as the cause. This is a test-driver/browser timing constraint, not an application Undo fix or a measured Milanote timing. WebKit's public touchscreen API provides taps, so this suite does not assert WebKit drag or pinch behavior. No script-dispatched PointerEvent is represented as a physical touch action.

The tested workflows are:

- Create a note by tapping the tool, enter Arabic and English content, apply bold through the toolbar, select independent background/top strip colors, reload, and reopen the saved note with two taps.
- Open a child board with two taps, change its title, and return to the parent using the visible breadcrumb or the board list on the narrow layout.
- Edit an image caption, rotate and Save, reopen and rotate then Cancel, and verify that the original source, saved transform, and caption survive reload.
- Keep the color, View, Export, and image editor surfaces inside both tablet viewports.
- In Chromium, drag a note with the browser touch protocol, verify displacement, verify that it remains in read mode, and Undo.

Three implementation corrections arose from these checks. Card opening has a touch double-tap path because relying solely on desktop `dblclick` did not open the board in WebKit touch emulation. It uses the existing card-opening operations, ignores interactive child controls, rejects moved/long/cancelled or multiple-pointer gestures, and guards against a duplicate compatibility double-click. The 350ms/18px double-tap and 450ms press thresholds are independent implementation choices; they were not measured from Milanote. Locked cards retain their editing guard.

The board sidebar now explicitly displays when expanded at narrow widths; the earlier base mobile rule kept it hidden after tapping Show boards. Read-only note content has `touch-action:none`: its own `overflow:auto` container otherwise let Chromium take over a card drag and emit `pointercancel` despite the card/stage ancestor rules. The rich editor uses a separate element and retains its native text interaction.

The2026-10-27 coordinated production build at `http://127.0.0.1:5305` passed all **9 WebKit checks** (four workflows at each size plus the uncaught-error check) and **11 Chromium checks** (five workflows at each size plus the uncaught-error check). Earlier failing development runs are diagnostic evidence, not acceptance results. Preserved production reports are `artifacts/production-current-chromium/touch-production/results.json` and `artifacts/production-current-webkit/touch-production/results.json`. Their run metadata records unchanged build SHA-256 `cf77cf95a6c9225d015e253af69a10526416902280e95c3031782e5819b5f418`; generic `artifacts/touch-*/results.json` may later contain development runs. No release is approved by this document.


To repeat against a running production preview:

```sh
BROWSER_ENGINE=chromium TEST_URL=http://127.0.0.1:5305 node tests/touch-workflows-e2e.mjs
BROWSER_ENGINE=webkit WEBKIT_PATH=/workspace/.cache/webkit-runner.sh TEST_URL=http://127.0.0.1:5305 node tests/touch-workflows-e2e.mjs
```

The explicit WebKit executable path is this environment's browser bootstrap, not a portable application dependency. Use a locally installed Playwright WebKit browser or set `WEBKIT_PATH` as appropriate elsewhere.
