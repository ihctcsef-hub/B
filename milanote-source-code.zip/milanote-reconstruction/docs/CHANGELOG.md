# Changes

## 1.3.0

- Added sanitized rich image/link captions and per-column table widths, interactive headers and relative formula clipboard relocation.

- Reviewed all 67 linked guides and 30 tool articles; retained a coverage map separating documented features, runtime observations and implementation gaps.
- Replaced Markdown-only editing with sanitized TipTap/ProseMirror WYSIWYG notes, native selection formatting, color/highlight/small text and a distinct Callout block. Preserved legacy note migration and rich static exports.
- Added titled document editing, note/document conversion, Markdown download, locally synchronized note copies and unlinking.
- Added non-destructive image crop, rotation, horizontal/vertical flip and markup with stroke selection/movement/deletion, save/cancel and local history. JSON retains original source and operations; visual exports bake edits into portable image data.
- Replaced the input matrix with spreadsheet editing, cell metadata/types, selection/clipboard/context actions and formulas backed by a bounded parser plus FormulaJS. Full reference/Excel compatibility remains unverified.
- Added task indentation, reordering, title controls and local due dates/times; HEX/RGB/HSL swatch editing; link preview/info/media/caption controls; assignable tags, board icons and local saved templates.
- Added independent line start/end arrows, weight/dash controls, free endpoints and draggable endpoints, curve handle and body.
- Added moving selected content between boards, dropping onto board tiles and column-to-board conversion with graph validation.
- Added file renaming, local media Loop/Autoplay preferences, PDF preview where supported, dropped-image link/video previews and formula catalog search.
- Expanded automated editor, image, spreadsheet, task, customization and document regression paths. Actual final run results are retained in `artifacts/` rather than inferred from code presence.
- Retained credentials/session/browser profiles and captured proprietary scripts outside the source distribution. Accounts, sharing and cloud services remain excluded.

## 1.2.0

- Authenticated reference investigation in one dedicated test board, with REA evidence identifiers.
- Neutral reference-inspired layout: 44px navigation, 36px board row, 63px tool rail, contextual dock, 8px grid and compact cards.
- Underline, strike, headings/lists/code/alignment, automatic column shrink and standalone-width restoration.
- Board tiles open by double-click/Enter; board tree toggles from navigation.

## 1.1.0

- Ordered columns, insertion marker, resize reflow, multi-column movement and Unsorted inbox.
- Per-board backgrounds/grid, shared escaped note rendering and additional static exports.
- Improved attachment downloads, collapsed-column bounds, imported viewports, Escape commits, hit testing and pinch zoom.

Older investigation reports describe the state when they were written; their missing features and authentication outcomes are historical and may be superseded by later reports.
