# Guide-driven authenticated tool study

Observed 2026-10-25. This supplements `AUTHENTICATED-INVESTIGATION.md` and the v1.3 runtime observations. The public guide index is a collection of project workflows, not an exhaustive product-control reference. This pass read the [guide index](https://milanote.com/guide), the [moodboard guide](https://milanote.com/guide/create-better-moodboards), the [sitemap guide](https://milanote.com/guide/site-map) and linked help entry points, then exercised post-add controls in the authorized test board.

All edits were confined to the dedicated **Reconstruction tool study** board and newly created elements inside it. An empty child board tile was added and customized without opening it. No invitations, messages, collaboration, purchases or account settings were used. Credentials, browser profile, authenticated storage and original application scripts are excluded from this report and source package.

## Evidence method

Playwright performed the interactions and collected screenshots/DOM observations. REA 6.7.0 passively inspected and captured selected resulting states; REA did not drive these interactions. Raw evidence remains outside the source tree in `/workspace/milanote-analysis/live-guide-*`. These are observed reference states, not a proof of equivalence to the reconstruction.

| Reference state | REA inspect evidence | REA screenshot evidence |
|---|---|---|
| Board letters/numbers icon picker | `ev_2cc92ad8fe34bfcaf32116c255d28131e983c6842193851c61d612d9fab3f8d3` | `ev_4d191b7896f981253f5212ff4e3d3577bc3d7cc727cad4e1322742c024914239` |
| Selected link controls | `ev_ee024fc2a2d42aed604cc794c0577d145ade95ff6375473437d1d21698d7f9f4` | `ev_129434e3d484510b6f4d962fe52cb055138e8fbd2522e145592bd31fb4341068` |
| Labels popup | `ev_e4ee04d9a370ac9c81ab1c675e9c7b79abc7eb655a4c023de03b5c0efd8953d7` | `ev_341e2c26b565064eda14f2f453e2b6bece82e2855734a9cc2e5e7d460d6e9c76` |
| To-do due-date calendar | `ev_bd3bfe4918ab68405b3c4b05552adc712ad15c4c5297d628361603ec65120608` | `ev_0b945c5338e302aa16732bb90d7eef127128aaea5af6e825bfab6fc466b5a426` |
| Image Background/Cut out mode | `ev_3472e5cb650c51d65be25725f3e9d5825df658a2e2b51627095cdd93f688a1ec` | `ev_7026948697f3e91cb8895d180a59a14ed7b03bcdf64d9d6b7500e1e407421ecf` |

Board, link and labels retained REA screenshots are 1440×1000. Calendar and Cut out REA screenshots are 1440×857 after CDP detachment changed the browser viewport. Selected 1440×1000 Playwright screenshots are included in `artifacts/reference-guide/`; their names do not imply REA generated them.

## Link controls after insertion

Actual sequence: drag Link onto the board → enter `https://milanote.com/guide` → Enter → wait for server metadata. The reference fetched a thumbnail, favicon, title and description. The populated card measured 270×286px in that state.

The selected rail exposes **Color, Labels, Reactions, Comment, Preview, Link info, Rename, Caption** and More/Trash. The following operations were exercised:

- **Preview** hides/shows only the preview media; hiding it reduced the initial populated card to 134px high.
- **Caption** hides/shows a separate caption region. The existing description was initially used as caption text. Double-clicking this region entered a Tiptap rich text editor. Editing it to a test sentence persisted after reloading.
- **Rename** focuses an inline title editor. A test title was committed with Enter and survived reloading.
- **Link info** hides the entire metadata region: URL, title and caption. With preview enabled, the card became image-only, 270×150px. Preview, Rename and Caption controls disappeared from the active rail; restoring Link info retained the edited title and caption.
- The Color popup exposes swatches and a custom-color option. Its full palette semantics were not exhaustively exercised.

The reconstruction has local title, URL, description, preview-image URL, display toggles and caption controls in `App.tsx`. Automatic remote metadata retrieval, the precise server-generated preview, the original inline/rich caption editor, exact rail state transitions and all media-provider behavior are separate parity requirements; visible toggles alone do not establish parity. See [link controls screenshot](../artifacts/reference-guide/link-controls.png).

## To-do controls after insertion

The selected rail exposes **Color, Title, Reactions, Due date, Assign, Labels, Comment** and More/Trash.

Actually exercised:

- Enter after the first task created another task.
- Tab on the second task nested it beneath the first. The reference DOM contained a nested task-list `ul`, rather than merely a visual left margin.
- Title enabled an editable heading with the empty placeholder **New To-do List**. An entered test title survived reloading.
- Due date opened a monthly calendar. Selecting October 28 displayed a **Due 28 Oct** chip attached to the first task. The popup also exposed **Add due time…**, **No reminder**, **9 AM the day it's due** and **9 AM the day before**.
- Revisiting the selected-list Due date control removed the visible due chip; activating it again showed an unset date/calendar. The exact distinction between list-level toggling and selected-task date removal was not isolated. This pass therefore does not claim date persistence or reminder behavior equivalence.

The reconstruction implements a separate `TodoEditor.tsx` with local title, task creation, indentation, reordering and due dates/times. Its popup and stored reminder time are local behavior, not a reproduction of the original reminder presets or notification service. Task rich-text formatting, parent/child completion semantics, drag behavior, arbitrary nesting, title toggling with retained text and the exact date-removal behavior still need targeted comparisons. See [calendar screenshot](../artifacts/reference-guide/todo-calendar.png).

## Image controls after insertion

- Caption enabled a caption region; double-click entered the reference rich editor. A test caption persisted after reload.
- **Background** opens the image modal in **Cut out** mode with **Remove background** and **Cancel**. It means subject/background removal, not the card's fill color. Remove background was not executed; backend processing and resulting alpha quality remain unverified and unimplemented.
- Draw on/Edit drawing and crop/rotate/flip were investigated in the previous authenticated v1.3 pass. This pass did not repeat their complete geometry tests.

The moodboard guide also documents selecting an image and typing to add a caption, and double-clicking its resize corner to restore its original size. Those documented shortcuts were not executed in this live pass. Source work added a resize reset; side-by-side original-resolution sizing remains unverified. The reconstruction caption is plain text, while the observed reference caption is rich text. See [Background removal state](../artifacts/reference-guide/image-background-removal.png).

## Board tile and canvas appearance

A new child-board tile was dragged into the authorized test board. Selecting it exposes **Color, Icon, Rename**. The Icon picker has **Search icons…**, **Recommended**, **Letters & numbers**, and **Upload an image**. Letters/numbers contains digits, uppercase Latin letters and several punctuation symbols. Choosing **S** changed the tile immediately and survived reloading; the picker remained open after selection.

The board More menu exposes **Open in New Tab, Create a Shortcut to This Board, Copy a Link to This Board, Convert to Template, Lock Position, Bring to Front, Send to Back**. These entries were observed but not activated. The reconstruction's local icon selection is not the full searchable catalog or uploaded custom-image icon workflow. See [board icon picker](../artifacts/reference-guide/board-icons.png).

Right-clicking empty canvas → **Change Board Background** exposes palette swatches, **Choose Custom Color** and **Show Dot Grid**. After a change, **Revert to Default** appears. The grid was toggled off and back on. The source has board background and grid state; exact menu layout, color catalog and default-reset semantics need comparison.

## Columns and shared element labels

Selecting the existing column exposes **Color, Rename**. More contains **Convert to Board, Lock Position, Bring to Front, Send to Back** and a created/modified attribution line. These entries were observed without converting or moving the column. Existing earlier evidence covers collapse and column card positioning. Column-to-board conversion remains a distinct missing workflow unless separately implemented.

Labels opens a popup with **Enter label name…** and an explanatory empty state. No global workspace label was created in this pass. The reconstruction's comma-separated local tags provide basic labeling, not a verified equivalent of creating/editing colored labels, searching, reuse, filtering, or removal in the original. See [labels popup](../artifacts/reference-guide/labels.png).

## What this pass establishes

It establishes concrete reference control states and persistence for edited link title/caption, image caption, nested task text/title and the board's letter icon. It does not establish full product parity, pixel identity across states, exact formula compatibility, background-removal algorithms, metadata-server behavior, all guide templates, browser extensions, native iPad/Safari/Pencil behavior or cloud collaboration. Features excluded from the original requested scope—accounts, sharing and team services—were not exercised.
