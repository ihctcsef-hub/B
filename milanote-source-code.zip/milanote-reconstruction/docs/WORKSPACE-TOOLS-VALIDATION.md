# Workspace tool integration checks

This is working-code validation, not a claim of complete Milanote parity.

Run `node tests/workspace-tools-e2e.mjs` against a Vite server, optionally setting
`TEST_URL`. The recorded run uses Chromium at 1440 × 1000 and passes nine checks
(eight workflows plus the uncaught-browser-error guard):

- Alt-drag duplicates the selected note exactly once over many pointer moves,
  preserves the original position and global label assignment, and records one
  undo/redo transaction.
- Alt-click without movement creates no duplicate or undo transaction.
- Escape cancels an in-progress Alt duplicate without an undo transaction.
- Pointer cancellation restores the original workspace before mouse-up.
- Copying a local board link uses the actual browser clipboard. Hash navigation
  and reload open the referenced board; pasting the link creates a shortcut to
  that existing board without cloning it.
- Renaming an in-place template updates its library entry and owning tile;
  undo restores the original name.
- Reverting a template preserves its board and content while removing its
  template status; undo restores the library entry.
- Deleting a template removes the owning tile and places its full nested board
  snapshot in recoverable Trash; one undo restores it.

The tests inspect exported workspace JSON through More options → Export board →
Workspace backup, rather than relying solely on rendered card counts. Results
and fixture backups are under `artifacts/workspace-tools-*`.

These checks establish behavior in the independent application. They do not
verify visual equality, complete template-library parity, or behavior on a
physical iPad.
