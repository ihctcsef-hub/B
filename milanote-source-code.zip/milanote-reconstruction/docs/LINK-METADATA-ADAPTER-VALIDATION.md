# Public link metadata adapter — working source

Updated2026-10-27. This report covers the independent metadata adapter and its data rules. It does not certify the complete Milanote link interface or every provider, authenticated page, JavaScript-rendered site, preview image, or browser export.

## Behavior

`server/link-metadata.mjs` mounts `GET /api/links/metadata?url=...` in Vite development and preview. It extracts Open Graph, Twitter and ordinary HTML title/description metadata, decodes HTML entities, and resolves relative image URLs. Only plain text and typed web URLs are returned; page HTML and scripts are never sent to the editor. Declared HTML encodings are decoded, with UTF-8 as the default.

The client API in `src/core/linkMetadata.ts` preserves the user's fragment in the card URL. The server omits that fragment from the network request. A final redirected URL never silently replaces the user's original card URL. HTTP failures, malformed JSON, static-host HTML fallbacks and network failures report preview unavailability instead of invented page details or internal diagnostics.

The optional `linkMetadata` snapshot records previously fetched values. Refresh only replaces an unchanged automatic value: an empty field, a default hostname/URL title, or a field still equal to its previous fetched value. A custom value entered before or during the request remains intact. A partial metadata response retains earlier provenance for omitted fields, so a later refresh can still recognize those retained automatic values. Caption, display switches and other card options are untouched. Import validation and legacy compatibility are covered separately from browser integration.

## Transport and resource limits

Every page and redirect destination must use HTTP or HTTPS on its standard port, without URL credentials. Local names, private/loopback/link-local addresses, multicast, documentation and selected transition ranges are rejected. All DNS answers must be public; a mixed public/private answer fails. The chosen validated address is pinned into the origin connection, retaining the original Host and TLS identity. HTTPS certificate validation remains enabled. When a proxy is configured, CONNECT targets the numeric pinned address; it never falls back to asking the proxy to resolve an unchecked origin hostname. Proxy authentication stays on the proxy hop.

Requests carry no browser cookie or authorization headers. The complete operation shares a10second deadline, allows at most4 redirects, and accepts at most1MiB of identity-encoded HTML. Non-HTML responses and oversized streamed bodies are rejected. There are at most8 concurrent upstream operations and100 cached metadata entries, retained for5minutes. Client disconnects abort upstream work and release listeners/capacity. These limits are independent implementation choices, not measured Milanote internals.

Preview image URLs are checked for a public DNS destination before being returned. The adapter does not fetch/cache/proxy those images, and does not establish the safety or availability of a later browser image redirect, CORS compatibility, image dimensions, or portable export. Static hosting of `dist/` alone does not provide the optional server route; manual link details remain usable without it.

## Verification

The adapter's targeted suite passed21 tests:14 server cases and7 client/provenance cases. Native HTTP fixtures verify Host preservation, absence of origin cookies/authorization, content-type and chunked size limits, legacy text encoding, and numeric proxy CONNECT with isolated proxy credentials. The local fixture endpoints test the transport directly; public-only DNS validation is exercised separately and is always applied by the mounted service.

Other cases cover private and alternate numeric loopback URLs, IPv6, mixed DNS, private/credential/custom-port redirects, loops and hop limits, body/deadline limits, concurrency, disconnect cleanup, route/method handling, caching, safe metadata parsing, URL anchors, partial-response provenance, manual edits and backup validation. The fixture data are explicit test inputs, not claimed as live provider results.

A live read-only call to `getLinkMetadata('https://example.com/')` completed through the configured environment proxy in5085ms and returned `{url:'https://example.com/',title:'Example Domain'}`. This proves one real public fetch through the pinned transport, not every provider or the integrated browser UI. The pre-restart development server still served its old HTML fallback at the new route; browser integration requires restarting that server to load the added Vite middleware.

```sh
npx vitest run tests/link-metadata.test.ts tests/link-metadata-server.test.mjs
npx tsc -b
```

TypeScript passed after adapter integration. Combined browser and production checks, source fingerprints and further UI observations belong to the parent integration report. No release or archive was created.
