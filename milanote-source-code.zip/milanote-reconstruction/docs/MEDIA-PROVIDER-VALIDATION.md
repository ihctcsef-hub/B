# Documented media URL conversions — working source

Updated2026-10-28. This is a bounded improvement to the independent source. It does not certify full provider coverage, player playback, authenticated reference behavior, or visual parity.

The public Milanote [Audio](https://help.milanote.com/en/articles/10684339-audio), [Videos](https://help.milanote.com/en/articles/10478926-videos), and [Links](https://help.milanote.com/en/articles/1722065-links) pages were fetched successfully during this round. Their visible text matches the previously retained guide audit. Audio names Spotify, SoundCloud, YouTube Music, Bandcamp, Mixcloud, Apple Music and Vimeo, and mentions Deezer/Amazon Music. Links additionally names CodePen, Airtable, Slideshare, Prezi, Marvel and image services. A provider appearing in that list establishes documented scope; it does not establish its exact current Milanote iframe parameters.

## Implementation

`src/core/media.ts` performs local, allowlisted URL normalization only. Calling it makes no HTTP, redirect, oEmbed, or player request. It accepts supported HTTP(S) source routes, emits an HTTPS player URL, and discards unsolicited tracking/autoplay parameters. Credentials, nondefault ports, control characters, lookalike domains, oversized sources, and unsupported routes are rejected.

| Documented provider | Supported local routes and behavior |
| --- | --- |
| YouTube / YouTube Music | Watch/share, shorts, live and existing embed links; exactly one11-character video identifier; output uses youtube-nocookie.com. |
| Vimeo | Numeric video/share and player links, channel/group/showcase video paths; preserves the unlisted `h` capability required for a shared unlisted video while removing playback/tracking fields. |
| TED | Existing talk and localized talk routes retained. |
| Spotify | Track/album/playlist/episode/show/artist, existing player paths, localized `intl-xx` shares; strips tracking. |
| SoundCloud | Public track and set routes, including mobile shares; strips query/fragment tracking, rejects profile sections, and keeps player autoplay disabled. |
| Mixcloud | A public two-part show share becomes a widget feed; profile collections remain unsupported. |
| Apple Music | Country-qualified album/song/playlist shares become embed.music.apple.com URLs; the selected album track `i` is retained, affiliate/autoplay fields are removed. |
| Deezer | Numeric track/album/playlist shares become the standard widget route; existing light/dark/auto widget paths normalize to the local dark presentation. |
| CodePen | Pen/full/embed URLs become a result-tab iframe route; profiles and arbitrary HTML remain unsupported. |
| Airtable | Classic public `shr` view identifiers become embed URLs; ordinary app/base/workspace links are not interpreted as public shares. |
| Google Maps | Existing query/place support retained. Search query values are decoded exactly once, fixing literal percent/plus searches; unrelated `/maps-*` paths no longer qualify. |

CodePen's current public [embed documentation](https://blog.codepen.io/documentation/embedded-pens/) explicitly describes replacing `/pen/` with `/embed/`. Mixcloud's [developer widget documentation](https://www.mixcloud.com/developers/widget/) and Airtable's [embedding documentation](https://support.airtable.com/docs/embedding-a-view-or-base) were also fetched successfully. The older Mixcloud help URL returned404; Deezer's developer documentation request was denied by the environment proxy (403), and no bypass was attempted. An Apple help deep-link redirected to its generic user guide and is not counted as detailed embed-schema evidence. The local player URL conversions above are independently implemented and unit-tested, not newly measured inside Milanote.

## Validation and limits

`npx vitest run tests/media.test.ts` passed14 test cases. These cover meaningful input families: unlisted Vimeo identity, SoundCloud set identity, selected Apple album track, provider-localized shares, normalization without tracking, invalid routes, credential/host/port rejection, unresolved shorteners, and map searches containing literal `%` and `+`. `npx tsc -b --pretty false` passed after integration with the current source. No new dependency was added.

The tests assert safe URL conversion; they do not load live embedded players. Regional availability, consent, CSP/X-Frame-Options, provider login/subscriptions, sandbox behavior, and browser playback remain provider-dependent. Existing app integration renders `mediaEmbedUrl` output through the same media toggle; the new provider routes still need targeted browser integration verification before being recorded as browser-tested.

Bandcamp share pages need numeric album/track identifiers or provider resolution; Amazon Music routes/regions and opaque shorteners need separately verified handling. Slideshare, Prezi, Marvel, Instagram, Dribbble/Flickr and modern Airtable share formats also remain unverified. No guessed universal embed or arbitrary HTML fallback was added. Source pages and fetch results are retained outside the source distribution under `/workspace/milanote-analysis/media-provider-public/`.

## Browser integration verification

`tests/media-providers-e2e.mjs` passed11 checks in both Chromium and WebKit on2026-10-28. Nine provider workflows use the actual Media toggle, inspect the iframe's normalized source and sandbox, edit a manual title, reload, then restore the image preview. Unsupported/unresolved sources preserve their sourceURL and image without exposing a player toggle. All external provider requests are aborted; playback, login, availability, consent and service-side embed compatibility remain unverified. SourceURL tracking parameters remain saved in the original link but are omitted from the normalized player where supported.

Initial test drafts used an outdated URL-anchor selector and attempted to select a media card by clicking inside its native iframe. Both were test-input errors; the final test selects the actual visible title and verifies the actual URL anchor, without weakening the source/iframe/reload assertions. Current results are `artifacts/media-providers-chromium/results.json` and `artifacts/media-providers-webkit/results.json`. Their URL identifies the tested source/production origin.
