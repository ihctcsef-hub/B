# تحقق معاينات الملفات — 29 أكتوبر 2026

هذه أدلة تنفيذ محددة وليست شهادة مطابقة شاملة. معيار PDF المقاس مباشرة في المرجع لعينة360×480 هو معاينة270×358 وfooter270×72.375 وبطاقة270×430.375. الملف المرجعي: `/workspace/milanote-analysis/pdf-preview-exact-geometry.json`. إخفاء المعاينة يعيد أيقونة78×111.171875؛ التعليق الفارغ يضيف32px، وإخفاء معلومات الملف يخفيfooter والتعليق معًا. لا يُستبدل القياس بنسبة رياضية مثالية.

## التنفيذ

- يرسمPDF.js أول صفحة فعلية، مع دوران الورقة وعدد الصفحات، داخلCanvas محلي. حُزمت ملفاتworker والخطوط وCMaps وWASM؛ لا تُرفع المرفقات لخدمة تحويل. يبقىDownload/Open مرتبطًا بالأصل.
- تُحسبSHA-256 لبايتات الأصل قبل نقلها إلىworker. تستعمل المعاينة المخبأة فقط بعد التحقق من بصمتها مقابل الأصل الحالي؛ اسم الملف ومعرّف البطاقة لا يكفيان. التطبيق القديم الذي لا يملكpreviewDigest يعيد التصيير. تتطابق بصمةWebCrypto وبصمةالبديل المحزم فيHTTP المحلي غير الآمن.
- يحد القراءة15MiB، ويفرضإلغاء/مهلة20ثانية، ويلغي الطلب السابق عند تغير المصدر أوفك المكوّن. تُلتقطcallbacks لكل طلب كيلا توجه استجابة قديمة إلىوثيقة جديدة. يملكApp حارسworkspace/board/epoch وهوية المصدر للكتابة غير المتزامنة.
- تحمل مرفقات القوالب العامةsourceUrl مستقلًا عنdataUrl؛ تقبل القراءةHTTP(S) عامًا بلاcookies أوreferrer، وتبقى قواعدCORS سارية. تدعم معاينةOffice وغيرها صورة فعلية موجودةpreviewSrc؛ امتداد الملف وحده لا يولدصورة وهمية.
- تدعم البطاقةإظهارالمعاينة/المعلومات/التعليق، تحريرالتعليق الغني، إعادةالتسمية معEnter/Escape، والتحجيماليدوي واستعادةالمقاس بعدإخفاءالمعاينة. شُخّصفرقWebKit فيصندوقسطرالحجم9.6px وعولجبحفظالارتفاعالمقاس9.59375px؛ لم يُضف تسامح للاختبار.

## النتائج القابلة لإعادة التشغيل

| المجموعة | Chromium | WebKit | التقرير |
|---|---:|---:|---|
| المكوّن الحقيقي وPDF.js | 9/9 | 9/9 | `artifacts/file-preview-{chromium,webkit}/results.json` |
| التطبيق الحقيقي والحفظ والتراجع | 6/6 | 6/6 | `artifacts/file-preview-app-{chromium,webkit}/results.json` |
| أولمحرر وأولرفعPDF معcacheفارغ | 4/4 | غيرمطلوب لهذهحالةVite | `artifacts/cold-editor/results.json` |
| وحداتالمصادر والقياسات | 9/9 | — | `tests/file-preview.test.ts` |

تتحقق مجموعاتالمكوّن منبكسل أحمرللصفحةالأولى، بصمةالأصل، أبعادالورقة وعددالصفحات، الارتفاعاتالمحددة، منعوميضRasterقديم عنداستبدالالأصل، قبولcacheصحيح بلاcompletionمكرر، مصدرغيرصالحوAbort، ملكيةcallback، إلغاءطلبمعلقعندالاستبدال/الفك، تحريرالتعليقوالاسم، معاينةOfficeفعلية وروابطالأصل، وعدمإرسالcookies/referrer.

تتحقق مجموعاتApp مناستيرادPDF وبقاءبايتاته، اشتقاقالمعاينة وحفظبصمتها، أبعادالبطاقة، إخفاء/استعادةالمعاينة بمعاملةUndo/Redoواحدة، الحفظوreload، تعطيلCaptionواختفاءRenameعندInfooff، التنسيقالغنيوإلغاءإعادةالتسمية، بقاءالمقاساليدوي، وتنزيلPDFالأصليذيالصفحتين. لا تُجمع اختباراتالمكوّنواختباراتApp كميزاتمرجعيةمستقلة.

```sh
npx vitest run tests/file-preview.test.ts
TEST_URL=http://127.0.0.1:5306 node tests/file-preview-e2e.mjs
TEST_URL=http://127.0.0.1:5306 node tests/file-preview-app-e2e.mjs
BROWSER_ENGINE=webkit WEBKIT_PATH=/workspace/.cache/webkit-runner.sh PLAYWRIGHT_BROWSERS_PATH=/workspace/.cache/ms-playwright TEST_URL=http://127.0.0.1:5306 node tests/file-preview-e2e.mjs
BROWSER_ENGINE=webkit WEBKIT_PATH=/workspace/.cache/webkit-runner.sh PLAYWRIGHT_BROWSERS_PATH=/workspace/.cache/ms-playwright TEST_URL=http://127.0.0.1:5306 node tests/file-preview-app-e2e.mjs
node tests/cold-editor-e2e.mjs
```

اختبارcold-editor يملكVite بذاكرةاعتمادياتفارغة فعلًا وHMR=false، وينفذAddNote ثمAddFile ورفعPDF إلىUnsorted ثمPlaceonboard. لا يُحمّلPDF مسبقًا ولايضيفانتظارإحماء. يفحصبكسلالصفحةوبصمةالأصل وبقاءgenerationواحد لـReact وعدمnavigationإضافي؛ ينظفالخادموالذاكرةبعدالانتهاء.

## فروق لم تُغلق بهذه الأدلة

- لا توجد مقارنةبكسلية شاملة للبطاقة والأيقونة والتحميل والخطأ، ولاسيناريوإنتاج لهذهالإضافة بعد. رسمFileGlyph مستقل وليسإثباتمطابقةشكلAdobe/Office.
- لا تثبتعيناتDOCX/TXT/ZIP أوصورالقوالب معالجةكلملفRAW/PSD/AI/Sketch فيكلحالة. حالاتpreview/icon/processing/errorلكلصيغةتبقىفيصفPRE-FILES حتىقياسها.
- المصدرالعام الذي يمنعCORS قدلايُقرأ فيالمتصفحالمستقل؛ لايستبدلالفشل بادعاءنجاحتصيير.
- بقيةدورةحياةالملف داخلColumn/Unsorted/النسخ/Trash والتصدير والمقارناتالمرجعية تبقىمطلوبةحسبالمصفوفة. النتائجالمحلية لا تغلقصفوفها تلقائيًا.
- لقطاتWebKitليستاختبارSafari/iPadفعلي.

تحتاجدفعةالدمج الكاملة إلى`npm test` و`npm run build` وجولةالانحدار علىمصدرثابت؛ النتائجأعلاه خاصةبالاختباراتالمسماةفقط.
