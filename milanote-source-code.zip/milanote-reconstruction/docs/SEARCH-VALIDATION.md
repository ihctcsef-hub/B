# Search — reference observations and working-code validation

This report concerns the unreleased independent source. It does not certify complete Milanote search ranking, filtering, timing, or pixel parity.

## Observed reference behavior

The public [Search help article](https://help.milanote.com/en/articles/1116205-search) describes cross-board content search, Last viewed as the default, Last modified as an alternative, Ctrl/Cmd+F, and Escape. Authenticated observation on 2026-10-26 used only the authorized Reconstruction tool study board. Queries were limited to its known board title and a known test note; unrelated result boards were not opened.

The current reference differs from the older full-screen search assumption in the reconstruction:

- Search is a top-right popover, 320px wide. At 1440×1000 its measured origin was x1029.203/y47. Its height followed the result content: approximately152.94px for one board-title result and175.31px with the observed nested note hit.
- A native sort select contains Last viewed, Last modified, and Relevance. Last modified remained selected after closing and reopening. Reopening cleared the query. The sort was restored to Last viewed before handoff.
- Empty input shows Recently viewed. Query results are grouped by board, with an ancestor breadcrumb, board icon, board title, content counts, and matching card snippets below. The known board-title query returned one board result, rather than a duplicate hit for its owning tile.
- The exact note phrase returned one board group and one clickable inner hit. Clicking that hit selected the real note while keeping the search popover open. The reference URL gained `filter_query`, `filter_ids`, and `filter_context=search` on the same board ID.
- A unique unmatched query produced `No results found for 'Reconstructi...'`.

The reference also exposes Shared with, an account/collaboration filter outside the user's original scope. It is not represented by an inert control in the independent local application.

Observation scripts and restricted screenshots remain outside the source under `/workspace/milanote-analysis/step-search-*-working.mjs` and `acceptance-search-*-working.png`. The exact board ID was retained when Milanote canonicalized away its descriptive slug; there was no fallback to an unrelated tab. These were Playwright interactions under the session's REA investigation workflow, not actions attributed to a passive REA capture. Search was closed, Last viewed restored, and the original authorized URL reopened before handing the browser to the next investigator. No content was created or edited by this search study.

## Independent implementation

`WorkspaceSearch` replaces the previous generic modal with a 320px grouped popover. It provides recent boards, board-title and card-content matches, highlighted snippets, matched-board counts, native viewed/modified/relevance sorting, query clearing, keyboard selection, Ctrl/Cmd+F/K focus, Escape/outside closing, and tablet containment. Choosing a card selects and reveals the local item while keeping search open. Existing global-label lookup is retained as grouped label hits.

Searchable card text includes note/document titles and visible rich or legacy Markdown text, image/link captions, link URLs/descriptions, task text, table cells and formulas, filenames, swatch values/names, column titles, and label names. Encoded resource bytes are excluded. Live board tiles are excluded from ordinary title matching because the destination board already has its own title result; both label-name queries and explicit label lookup can still find labels assigned to a board tile. A broken shortcut's remaining title is searchable in its containing board. Deleted boards are absent because results use the active workspace boards rather than Trash.

Board lookup checks the registry's own properties. Hashes such as `#board/constructor`, `#board/toString`, and `#board/__proto__` do not resolve inherited JavaScript object properties as boards; a valid saved board whose own ID is `constructor` still opens and reloads. The same distinction applies to shortcut creation/targets, ancestor lookup, and sub-board linear export. This is a local robustness correction, not a measured Milanote URL convention.

An optional `Workspace.boardActivity` index stores viewedAt and modifiedAt per board. Visits are recorded on initial loading/navigation, without undo transactions or content modification stamps. Semantic commits compare board content while excluding viewport; pan/zoom and equivalent cloned data do not change modifiedAt. Live note edits, including synced copies, receive modification times. Undo/redo retain recent visits and stamp reverted content as a new modification. Import preserves provided modification metadata and records only the newly opened root visit. Legacy documents retain unknown modification dates rather than inheriting the workspace's unrelated save timestamp. Stale activity entries may remain for deleted boards so restoration retains their navigation history; those entries alone cannot produce a search result.

The implementation's relevance score, date ordering ties, text normalization, snippet extraction, board counts, and local activity policies are independent engineering choices. Every ranking/coercion case and the reference's server indexing delays were not measured. The reference's automatic preview/filter URL behavior, full date grouping, and all provider-extracted file text remain unverified. The local application uses its own board hash routes and card selection rather than copying Milanote's private IDs or URL protocol.

The October27 review reproduced a local mismatch: NFKC-normalized search found fullwidth letters, ligatures and decomposed accented text, but the old raw-string highlight did not; dotted capital I could shift later offsets. Search, highlight and snippet placement now share NFKC, locale lowercase and whitespace folding. The matching range maps through whole original grapheme boundaries, so compatibility/case expansions, combining marks, Arabic vowel marks and joined emoji are not split by a highlight or snippet edge. A normalized query matching part of a grapheme highlights that entire grapheme. Valid visits at the Unix epoch or before it remain dates; missing activity is distinct and sorts after valid dates. These are independently tested local consistency rules, not new reference parity claims.

## Local verification

Thirteen focused unit cases in `tests/search.test.ts` pass in the 2026-10-27 08:21UTC check. They cover grouped matches, title duplication avoidance, labels, every supported text family versus encoded bytes, independent visit/edit times, pan/zoom, structurally equal clones, sorting and legacy dates, undo metadata, backup round-trips, deleted boards, invalid activity guards, visible formatted text, labeled board tiles, broken shortcut titles, inherited versus own board IDs, normalized original-text ranges, complete-grapheme snippets and epoch-zero/pre-epoch dates. Unicode cases include fullwidth forms, a ligature, dotted capital I, decomposed accents, collapsed whitespace, Arabic vowel marks, joined emoji and Greek contextual lowercase. Six shortcut cases passed in the same targeted run; those are separate from the thirteen search cases.

`tests/search-e2e.mjs` passes eight checks in Chromium and eight in WebKit on the local verification server in the 2026-10-27 recheck:

1. Measured popover width/top, grouped title/content hits, live card selection, and keeping search open.
2. Viewed versus modified order, pan/zoom without fabricated edits, live text edits and actual Undo.
3. Recent visits, persisted sort choice, cleared reopen queries, no-result display, Clear, Escape, outside close, and shortcut focus.
4. Deleting a board and undoing deletion, legacy unknown dates, reload and portable backup/reimport.
5. A phrase spanning legacy Markdown formatting and a rich note with empty derived plaintext both remain findable. Selecting the rich hit selects the rendered card; board-tile labels and a broken prototype-named shortcut remain findable without duplicating a live board title.
6. Fullwidth, ligature, case-expansion, combining and Arabic query matches highlight the original whole text correctly; an epoch-zero visit remains in Recently viewed.
7. A portrait768×1024 viewport keeps the popover and native sort within the page.
8. No uncaught browser errors.

The Labels browser suite was adapted to assert the two actual grouped inner hits rather than the former two flat result buttons. Its workflow still verifies label rename/recolor/search/global usage and backup persistence.

Per-engine reports are `artifacts/search-results.json` and `artifacts/webkit/search-results.json`. Local screenshots are `search-preview.png` in those directories. These browser-engine checks do not establish physical iPad, native Safari/iPadOS, or complete reference acceptance. The combined production build has passed; [working validation](VALIDATION-WORKING.md) records its fingerprint and the separate integration rounds. No release archive was created.
