# Image library and background removal: working-code verification

This file describes the private working code, not a complete Milanote parity release.

## Image library

`server/image-library.mjs` adapts the official Pexels API. Vite mounts it at
`/api/images/search` in both development and preview. The server reads
`PEXELS_API_KEY`; the key never becomes browser configuration or photo metadata.
An independently hosted build needs the same middleware mounted by its host.
With no configured key the route returns HTTP 503, and the image library keeps
the local upload option available. No substitute catalog is presented as Pexels.

The user does not currently have a Pexels API key. Successful requests to the live
provider, the provider's ranking, and live photograph downloads remain
**unverified and blocked on configuration**. Passing fixture tests does not close
that acceptance gap.

Verification performed:

- Vitest checks typed metadata, URL filtering, non-finite dimensions, drag-payload
  decoding, and same-site search endpoints.
- `npx vitest run tests/image-library-server.test.mjs` checks the official upstream
  host, server-side Authorization, normalization, caching, missing-key handling,
  upstream authentication errors, and invalid pagination with explicit fake
  provider responses.
- `node tests/image-library-e2e.mjs` exercises the real local route without a key
  and the isolated library UI. Successful search and pagination use explicitly
  intercepted fixture responses. Click selection, actual HTML5 drag and drop,
  Escape, outside dismissal, and the upload action are exercised in Chromium.
  Results: `artifacts/image-library-e2e-results.json` (five passing checks,
  including the browser error guard).
- A separate Vite preview server also returns the expected HTTP 503 JSON from
  the same unconfigured route. TypeScript compilation passes.

`node tests/image-library-app-e2e.mjs` also exercises the integrated App. Its real
unconfigured API check uploads a local PNG into Unsorted and uses HTML5 drag to
place it on the canvas. Explicit provider fixtures then exercise click-to-Unsorted
and drag-directly-to-board. Workspace backups retain the exact image bytes,
original filename, and provider-based 270 × 237.5 card dimensions. Re-import
preserves the existing global label registry and assignment. All four checks,
including the browser error guard, pass; results are in
`artifacts/image-library-app-e2e-results.json`.

These tests do not establish pixel parity or live provider behavior. The isolated
test harness lives at `tests/fixtures/image-library.html` and is not part of the
Vite production entry point.

## Background removal

The bundled U²-Net small model, its original Apache-2.0 license, the rembg MIT
conversion notice, checksums, and provenance are retained under `public/models`.
The ONNX Runtime license is retained under `public/runtime`.

Existing real Chromium inference evidence is retained in
`artifacts/cutout-result.json` and its PNG previews: a 900 × 603 image processed
locally in approximately 1.72 seconds, producing both transparent and partially
transparent pixels, with no external requests. That recorded run also includes
an unrelated missing-resource 404. It is not evidence that every kind of image
will segment well or that the matte matches Milanote's implementation.

The preprocessing/mask tests pass independently. Exact segmentation boundary
parity with Milanote remains unproved.
