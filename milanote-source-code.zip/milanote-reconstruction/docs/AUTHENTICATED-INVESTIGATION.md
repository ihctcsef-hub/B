# Authenticated Milanote investigation — 2026-10-24

A user-authorized email/password login succeeded. Work continued in one newly created board named “Reconstruction tool study”. Existing user boards were not edited. Account identifiers, credentials, cookies, browser profiles, and captured vendor JavaScript are excluded from the source archive.

## Method and provenance

Playwright was used for initial sign-in and exploratory actions. REA `rea-agents@6.7.0` then ran a declared connected-browser scenario: open the test board, edit its note, fill known test content, select that content, apply bold, and capture the resulting DOM, accessibility tree, screenshot and URL. Every scenario step completed successfully. REA marks the retained scenario completeness as incomplete because no event stream was requested; `missing_sections` is `["events"]` and `equality_eligible` is false. The retained UI artifacts and completed actions establish the observations below, not complete capture equivalence.

| REA operation | Evidence ID | Observation |
|---|---|---|
| `capture_browser_scenario` | `ev_a5e8ea38e2723a6be1a86bf6a1199eba9d92c2d1fbbaaea63b53696eaf348be1` | Authenticated note editing and bold shortcut, with final artifacts |
| `inspect_web_page` | `ev_400b5e971d9d119c23445a558b1fb13413ba3a1e61a7c21012c889fd4c63d8d9` | Authenticated test-board DOM/accessibility after column insertion |
| `capture_web_screenshot` | `ev_9565eadced8d2ac14ea9fbf0e56c84c1badf3cbe911e98a7afafa648a997c9ea` | Authenticated column viewport |

Raw evidence remains in the separate research directory `/workspace/milanote-analysis/evidence/`, outside the source archive. `auth-note-scenario-evidence.json`, `auth-column-inspection.json`, and `auth-column-screenshot.json` are the complete REA records. Additional `auth-editor-*.png` images and DOM measurements are exploratory Playwright observations; they are not presented as separate REA Evidence records.

REA capture connects to an existing browser. Disconnecting CDP can reset externally configured viewport emulation in Chromium, so the viewport was explicitly restored before subsequent measurements. TLS verification remained enabled.

## Directly observed behavior

At a 1440×1000 CSS-pixel viewport:

- The first navigation bar is 44px tall. An opened board adds a 36px title/action row; its canvas begins at y80. The Home view has only the first row.
- The creation rail is 63px wide, flush against the left edge. The gray canvas/rail is approximately `#ebedee`, with an 8px repeating dotted grid. The default workspace does not show a persistent board tree.
- Creation tools appear in the order Note, Link, To-do, Line, Board, Column, Comment, Table, then image/upload/drawing controls. Comment and account/team controls remain outside this reconstruction's requested scope.
- Selecting/editing a note replaces creation tools with a contextual rail. Observed controls include text style, bold, italic, strike, underline, bullets, numbering, alignment and code.
- The inspected note uses Inter with an effective 11.2px font and 16px line height. Paragraphs have an 8px bottom margin. An empty note is approximately 272×56px; content increases its height.
- Nested boards appear as colored icon tiles with title/count below, without a full white card panel. Columns and ordinary cards use flat white surfaces and small corner radii.
- Inserting a note into a column makes it fit the column width and take part in a vertical stack. Two observed children had an approximately 6px gap and approximately 6.4px side insets.
- The test column had a header/collapsed height of approximately 62.2px. With two notes its total height was approximately 230.2px; after detaching the second note it shrank to approximately 166.2px. The detached note restored its standalone width of approximately 272px. These are measurements of this browser state, not recovered universal constants.
- A new board offers a template chooser at its lower-right corner. Existing text, links, tasks, drawings, connections, and Unsorted are rendered as board items.

## Implementation changes derived from the observations

Version 1.2 adds the scoped `reference.css` layout, compact headers and a fixed left rail. The board tree remains accessible through a navigation toggle. Selecting an item switches to contextual controls. The original studio CSS is retained as implementation history, but the default presentation uses the observed neutral layout.

Note tools now include strike/underline, bullets/numbering, heading styles, code, and alignment. The safe shared renderer preserves their supported markup in static exports. The editor uses a plain-text Markdown representation, not the original WYSIWYG implementation. `~~strike~~` and `++underline++` are documented extensions.

New columns fit their content automatically, shrink after detaching a member, and preserve a card's previous standalone width. Explicit user resizing can preserve additional height. Independent layout values approximate the observed viewport and are verified through geometry tests; they are not claims about Milanote's internal data model.

The new presentation preserves local persistence, backups, search, nested boards, line editing, images, attachments, tables, sketches, Unsorted, and the requested exclusion of account/sharing services.

## Verification limits

This investigation verifies the signed-in editor states and actions above. It does not establish complete parity for every tool or hidden state. Image crop/markup, advanced table formulas, fetched link previews, native iPad binaries, Safari hardware behavior and Apple Pencil pressure were not exercised. The reconstruction retains its own geometry, storage format, rendering implementation and documented limits. It does not contain Milanote's recovered source or authentication implementation.
