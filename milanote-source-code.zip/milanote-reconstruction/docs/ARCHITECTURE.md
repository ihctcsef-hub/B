# Architecture — 1.3

This is an independent local implementation of a visual editor. It does not contain recovered Milanote source, account credentials or browser sessions. The reference investigations distinguish documented behavior, authenticated observations and implementation choices.

## Source map

| Area | Files |
|---|---|
| Workspace graph, validation, persistence | `src/core/model.ts`, `storage.ts` |
| Columns, moving between boards, templates | `columns.ts`, `boardActions.ts`, `templates.ts` |
| Rich text, document content and local linked copies | `richText.ts`, `notes.ts`, `components/NoteEditor.tsx` |
| Image transformations and markup | `imageEditing.ts`, `components/ImageEditor.tsx` |
| Spreadsheet evaluation and cell interactions | `spreadsheet.ts`, `components/TableEditor.tsx` |
| Task trees, dates, colors | `todo.ts`, `colors.ts`, `components/TodoEditor.tsx`, `ColorSwatch.tsx` |
| Free/attached line geometry | `lines.ts`, `components/ConnectionLayer.tsx` |
| Known media providers | `media.ts` |
| Visual/text exports | `src/export.ts` |
| Interaction orchestration and presentation | `src/App.tsx`, `style.css`, `reference.css` |

## Document graph

A version-1 `Workspace` contains a root board and a record of `Board` objects. Boards store cards, lines, a viewport, and optional background/grid/icon preferences. The eleven card types remain note, image, link, to-do, column, board, file, swatch, sketch and label. A document is a note with `isDocument` and `title`; it is not an additional incompatible card type.

Cards use world coordinates, dimensions, an ID, a stacking value, and optional color, lock, tags and inbox state. `parentId` represents column membership, while the child cards retain absolute board coordinates. A board tile points to a board through `boardId`; the child records its owner in `parentBoardId`.

Pure graph helpers return new objects. Deletion expands column descendants, removes affected lines and removes boards unreachable from the workspace root or a saved-template root. Duplication remaps IDs and deep-copies nested board subtrees. `copyCardsToBoard` copies a clipboard snapshot into another board or workspace. `moveCardsToBoard` retains IDs, detaches individually moved column members, restores their standalone widths, reparents moved board subtrees and rejects cycles. Lines whose two attached endpoints move together transfer with the group; lines crossing the move boundary are removed. Unrelated free lines remain on the source board.

`convertColumnToBoard` replaces the column with a board tile, moves its contents into a new child board and preserves their IDs and internal lines. Saved templates use independent `isTemplate` board roots and cloned descendants; instantiation creates another independent graph. Note synchronization identifiers are cleared when a template snapshot is saved.

## Editing and history

`App.tsx` holds UI selection, tools, dialogs and interaction focus separately from persisted document content. Its workspace history keeps at most 80 past states. Pointer drags preview intermediate geometry and commit one history entry on release; cancelling restores the original state. A new committed edit clears redo history. `core/history.ts` separately provides reusable immutable history helpers.

Rich notes store canonical HTML in `html` and a plain-text search/preview summary in `text`. Missing HTML invokes legacy escaped Markdown migration. `NoteEditor` initializes TipTap after mount and guards destroyed instances during lazy loading and StrictMode replay. Parent property echoes do not replace a newer editor document or native selection. TipTap handles local undo/redo during editing; the completed session becomes one workspace change.

`richText.ts` parses with parse5 and emits a fixed allowlist for marks, headings, lists, links, alignment, colors/highlights and a distinct Callout node. Pasted HTML and rendered/exported content are sanitized. Imported HTML is validated as a string and treated as untrusted at rendering boundaries; import is not a claim that every string already contains canonical HTML.

`applyNoteContent` propagates text and HTML to notes sharing a `syncedId` in the current workspace. Titles, positions and document/tile presentation remain separate. Removing the identifier isolates a copy. There is no network synchronization or collaborative conflict resolution.

## Geometry and images

The canvas translates by viewport `(x,y)` and scales by `zoom`. Pointer positions convert back to world pixels with `(client - stageOrigin - viewportTranslation) / zoom`. Line editing also uses the inverse SVG screen transform, so handle movement follows the same scaled canvas.

Column layout uses independently implemented constants informed by measured reference states: header 62.2px, side padding 6.4px, bottom padding 6px and gap 6px. New columns have automatic height; explicitly resized legacy columns retain their height floor. `preColumnWidth` restores a card's standalone width after detachment. A collapsed column has a visible height of 62.2px. These constants do not recover the reference algorithm or establish every content state's pixel identity.

Attached lines resolve card-side anchors as cards move. Free endpoints use persisted `start`/`end` points; an optional control point defines a quadratic curve. `connectionGeometry` and curve-extrema bounds are shared by display and export. Endpoint dragging detaches only the endpoint being moved; start and end arrows are independent. Free line body movement translates its endpoints and curve control together.

Image source bytes remain in `src`. `imageEdits` stores quarter-turn rotation, visible-axis flips, a normalized crop rectangle and source-relative markup paths. Stroke points remain in original source coordinates; rendering and editing apply/invert the image transforms. The modal has its own history and Save/Cancel boundary. Selection moves/deletes chosen strokes, while the eraser removes intersected strokes rather than performing pixel erasure. Visual exports bake the operations into an image; editable JSON keeps source and operations. Pressure, velocity and native Pencil equivalence are not established.

## Tables, tasks and colors

Tables store raw cell strings plus optional metadata keyed by `row:column`. Display evaluation does not overwrite formulas. The bounded expression parser supports cell/range references, arithmetic, comparisons, concatenation, lazy conditional/error branches and a registry of FormulaJS functions. It does not pass formulas to JavaScript `eval` or `Function`. Formula length, tokens, depth, ranges and output are bounded. Structural row/column edits rewrite references and shift metadata.

Function presence in the registry is not proof of full compatibility with the reference catalog. Array-spill/matrix results and cross-sheet references are unsupported; date serials, currency and locale behavior may differ. Text exports use evaluated display values, while JSON preserves raw formulas.

Task items retain IDs, completion, optional indentation, due date and reminder time. Tree operations keep descendants with their parent during indentation and reordering; deleting a parent promotes its children. Dates and times are local saved metadata, without email, push or notification scheduling. Swatches store canonical hex values with optional HEX/RGB/HSL display, caption and value visibility; the screen eyedropper depends on browser support.

## Persistence, resources and exports

`storage.ts` saves snapshots to IndexedDB database `visual-workspace`, store `documents`; the save resolves after transaction completion. If primary storage fails, localStorage provides a fallback. Loads compare timestamps and report malformed or unavailable data instead of silently replacing it. Import validates the full graph before replacing the current workspace: finite geometry, IDs, ownership/cycles, references, optional metadata, image operations and persisted resource schemes. Saved-template roots are valid independent roots; ordinary nested boards need consistent owners.

Files and uploaded images are embedded as data URLs, with a 15MB per-file UI limit. HTML/SVG resource preparation embeds available local/external images and attachments. External image retrieval may fail because of network/CORS restrictions. Known YouTube, Vimeo, Spotify, SoundCloud and Google Maps links can produce controlled embeds; arbitrary supplied HTML is not embedded. Local media playback, autoplay and PDF preview depend on browser policies and installed codecs/viewers.

JSON is the editable complete workspace backup. HTML/SVG represent one static board; long documents remain constrained by their visual card rectangle, while Markdown/plain text retain their full content. Portable media exports use a safe link fallback rather than a live embedded service. SVG uses `foreignObject` and is best opened in a browser. PDF output uses the browser print dialog.

## Verification and evidence

`npm test` runs graph, import, rich text, formula, geometry and export tests. Browser suites exercise actual selection, editing, pointer operations, reload and downloads; final run reports and screenshots live in `artifacts/`. The final validation record identifies which build was checked. Code presence and test counts alone are not a claim of complete reference parity.

[GUIDE-COVERAGE.md](GUIDE-COVERAGE.md) maps 67 guides and 30 help articles to source features and remaining gaps; [guide-sources.json](guide-sources.json) records public-page provenance without redistributing the full articles. Authenticated reference observations are separate in [AUTHENTICATED-V13.md](AUTHENTICATED-V13.md) and [LIVE-GUIDE-TOOLS.md](LIVE-GUIDE-TOOLS.md). Chromium touch emulation does not establish behavior on an actual iPad, Safari or Apple Pencil.
