# Thumbnail replacement — working source, unreleased

The current implementation has two distinct image-replacement paths. The reference investigation measured an existing image card held over an existing, visible link preview for about one second: the preview displayed a black border and “Replace image”, and release replaced the preview while consuming the source card. The public Milanote Links guide also describes the one-second hold. This is bounded evidence for internal image-card replacement, not proof that every file drag, empty link, video, touch gesture or media provider behaves identically.

The local external-file path already allowed a single image file up to15MB to replace a link preview or uploaded-video poster. Its asynchronous consistency is now protected: locked targets reject the read, and a completed read checks workspace/import epoch, source identity, target existence and lock state, original preview, and whether a newer drop superseded it. Completion waits until an active card drag or note-edit session ends, so it can commit a separate Undo transaction. Navigating to another board during decoding keeps the mutation on its original board. These are local consistency policies; they are not measurements of Milanote's async timing.

## Browser validation

`tests/thumbnail-drop-e2e.mjs` exercises ten workflows and an uncaught-error guard. The external file fixtures dispatch synthetic HTML5 `DragEvent` events containing real generated PNG `File` objects. Their FileReader delivery is explicitly gated by filename to reproduce late-completion races; this is not claimed as trusted OS input. Internal image-card movement uses native browser mouse input.

The checks cover:

- Link preview and video-poster replacement preserve title, source URL/data and card count; link replacement is independently undoable, and the video poster survives reload.
- Initially locked links and video files reject replacement before a FileReader invocation.
- A late read cannot overwrite a newer manual preview or a changed link URL.
- Locking or deleting a target during a read leaves its live/recoverable preview unchanged and preserves the user's Undo action.
- Importing the same workspace ID invalidates an old read, and a newer drop wins over an earlier read.
- Navigation preserves the original destination board.
- Native card dragging and live note editing defer completion and retain two separate Undo actions.
- Holding an internal image over the existing link preview exposes the ready state and “Replace image”; release consumes the source, while one Undo restores its original position and caption alongside the old preview.
- Early release moves the source without replacement; Escape cancels a ready replacement and restores its position.

Latest targeted source runs:

- chromium: **11/11 passed**, 2026-10-28T06:48:12.010Z, no uncaught page errors.
- webkit: **11/11 passed**, 2026-10-28T06:48:57.722Z, no uncaught page errors.

Per-engine reports and screenshots are in `artifacts/thumbnail-drop-chromium/` and `artifacts/thumbnail-drop-webkit/`. Always inspect the current timestamp/status; intermediate failure images may be retained alongside the latest run. The first Chromium setup attempt used invalid fixture ownership (a child board without its owning tile). The fixture tree was corrected; assertions were not relaxed.

## Limits

No full visual/parity claim or release is made. Physical iPad/Pencil testing remains deferred by the user. Synthetic external drop fixtures do not certify native operating-system file dragging, and the local immediate external replacement policy is distinct from the measured internal one-second hover. Replacement image crop/cutout rendering and exact preview ratios need their own fidelity comparisons. The test suite does not certify every provider's poster behavior, network decoding policy, arbitrary file formats or all multiselection/Alt-drag combinations.

## Measured reference workflow — 2026-10-28

The public Links guide says to drag an image over an existing preview and hold for1second. In the owned child board `1XlWMY1mHxXy8e`, an example.com link had no image and did not activate replacement; that is not evidence that replacement is absent. A second link to the Milanote guide had an existing preview. A native browser mouse drag of an owned200×100 image over that preview showed `can-drop` after the held interval, a dark overlay with “Replace image” and a dark card border. Releasing replaced the preview and consumed the source image; a fresh read confirmed a200×100 preview, unchanged link title/URL and no remaining source image card. The guide's1second threshold is implemented locally; sampling at400ms and2000ms only bounds this particular runtime trial.

REA scenario evidence `ev_0817a3beeb247303f81cf9e59f8fec41889f85cca812c3c612dec4479b375d86` records owned-link selection after readiness; passive follow-up `ev_1913d69a9fff328a6b607468ae00e6c706307ecd94f1bc5cda4b0370ff49c902` records the resulting reference state. Internal drag itself was performed with native Playwright mouse events, not claimed as a REA scenario action. Supporting images/measurements remain outside the source distribution under `/workspace/milanote-analysis/thumbnail-internal-*`. The initial external-file probe used a nonexistent fixture path and establishes nothing; it is retained separately as invalid input. A valid external-file probe added a separate image card; external file replacement in this code remains an independent local convenience, not measured reference equivalence.

Only the newly created child was deleted recoverably. After a fresh root reload and readiness check, the child was absent and the three recorded original table/board IDs remained present; `thumbnail-cleanup.json` records cleanup. An immediate earlier reload sampled stale SPA state and was not accepted as final cleanup proof. Trash was not emptied.

The local internal route is limited to one image and an unlocked link with an existing visible image preview. It preserves crop/rotation/annotations/cutout by baking the displayed source before the guarded commit. Video-poster internal dragging, arbitrary multi-image replacement, exact reference sizing/ratio (the local auto-link preview currently uses16:9), and all pixel-level overlay details are not certified. Async consistency and Undo rules are local policies tested independently of the reference timing.
