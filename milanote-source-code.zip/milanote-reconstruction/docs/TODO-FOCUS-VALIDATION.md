# Task focus race — working source, October 27

This fixes a reproduced local interaction defect. It does not establish Milanote focus timing or physical iPad parity, and it is not a release approval.

## Reproduced failure

The source-frozen combined browser run failed the fifth task workflow: after deleting a parent, clearing the remaining `Other` task and pressing Backspace left two tasks instead of one. The original report and screenshot were preserved before rerunning under `artifacts/todo-oct27-diagnostic/`.

An exact-action diagnostic reproduced the failure in Chromium and retained two rows after another 100ms. Native event capture recorded DOM values, React input props, caret positions and focus:

1. At 1939ms the clear action focused `Other` and selected its text.
2. At 1943.9ms an older animation-frame callback from deleting the parent focused `Child` instead.
3. At 1948ms the clear action's native Delete reached `Child` at its end, so `Other` was still nonempty.
4. The next Backspace refocused `Other` and cleared its selected text rather than removing an already-empty task. Both rows remained.

The state and React props agreed throughout; this was neither a stale text handler nor an assertion running before a pending deletion rendered. The trace is `artifacts/todo-oct27-diagnostic/chromium-exact-1793090392127/trace.json`. The corresponding WebKit diagnostic passed. Temporary instrumentation lives outside source in `/tmp/todo-oct27-exact-diagnostic.mjs`; an earlier diagnostic lost its injected helper after page reload and is not evidence of an application defect.

## Fix

Task and title focus requests now have an identity and cancellation cleanup. A newer request cancels the prior one. A later focus choice or pointer press anywhere in the document cancels the pending automatic focus. The callback clears its request and listeners before focusing, and checks that the target remains connected and the editor remains writable. Read-only transitions and unmounting cancel pending requests. Event listeners exist only while a focus request is pending.

Task deletion, insertion, reordering and date dialogs retain their normal automatic focus behavior. The original empty-task deletion assertion remains immediate and unchanged; no delay or relaxed count was added to hide the failure.

## Verification

`tests/todo-e2e.mjs` passes seven checks in Chromium and seven in WebKit after the fix. These retain the six previous checks for default geometry, caret splitting and indentation, date/title persistence, nested reorder, deleting a parent/empty task, and browser errors.

The seventh check uses an explicit test clock to hold application animation-frame callbacks. It deletes a parent, focuses and edits another task, releases the held callback, and verifies that the newer field, caret and text remain intact. It separately holds focus after Enter, clicks the canvas, then checks that release does not steal focus. Finally it verifies normal Add a task focus, native typing, empty-task deletion and focus of the surviving task. This controlled clock makes the regression deterministic without relying on machine speed or sleeping before the critical assertions; it is not a native frame-timing measurement.

Reports are `artifacts/todo-e2e-results.json` and `artifacts/webkit/todo-e2e-results.json`. TypeScript passed after the source change. A fresh production build has passed after this fix; [working validation](VALIDATION-WORKING.md) records its hash and the distinct integrated source and production rounds.
