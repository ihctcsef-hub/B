# Note and document text format

New rich notes store sanitized HTML in `note.html`; `note.text` is a plain-text summary used for search and previews. The TipTap/ProseMirror editor renders formatting directly and applies commands to native selections. `note.isDocument` changes the card to a document tile that opens a larger editor; `title` stores its name. These are presentation options on the same note data type.

## Supported rich content

Paragraphs, headings 1–6, bold, italic, strikethrough, underline, bullet/ordered lists, line breaks, inline code, code blocks, blockquotes, links, and a distinct callout block are persisted. Paragraph/heading alignment is left/center/right. Fixed text colors, highlights and a 10px small-text style are supported.

The canonical callout representation is `<aside data-note-callout="true">…</aside>`. It is a separate editor node from `<blockquote>` and toggles with Ctrl/⌘ Shift 6. A callout's fixed marker is the only accepted aside attribute apart from supported alignment; arbitrary aside wrappers/attributes are not retained.

`src/core/richText.ts` parses content with parse5 and emits a fixed allowlist. It removes executable/embedded resources, event attributes, unsupported styles and unsafe links. Note links must use HTTP or HTTPS. Colors accept bounded RGB or hex input and are stored as hex. The editor sanitizes pasted HTML before schema parsing; static views and exports sanitize again.

## Legacy notes

When `html` is absent, `noteContentHtml` renders the earlier escaped Markdown subset through `src/core/text.ts`. It includes bold (`**`/`__`), italic (`*`/`_`), strike (`~~`), underline (`++`), headings, lists and inline code. Source HTML in legacy text remains escaped. Editing a legacy note produces canonical rich HTML and updates its plain-text summary; the original markers are no longer the editing surface.

An explicitly present empty `html` means empty rich content and does not fall back to stale text. Parent property echoes are acknowledged without replacing a newer editor document or resetting its selection/history.

## History and synchronized notes

A note editing session previews content continuously and commits a workspace history entry when it finishes. TipTap handles undo/redo while that editor is active. Lazy editors initialize after mount, and callbacks reject destroyed instances, including during StrictMode replay.

Notes with the same nonempty `syncedId` receive content updates across boards in the current workspace. Titles, positions and document/tile presentation are independent. Removing a copy's `syncedId` isolates subsequent edits. This is a local graph operation; no account, network synchronization or collaborative conflict resolution is involved.

## Exports

JSON retains stored HTML, the summary, document properties and synchronization group identifiers. Newly edited content is canonical and sanitized; imported HTML strings are still sanitized at view/editor/export boundaries. HTML/SVG preserve rich markup and supported styling. Markdown is generated from rich HTML, preserving marks, headings, lists, links, code and quotations. Underline uses the project's `++underline++` extension; callouts use a `> [!NOTE]` block. Viewers without those conventions may display them differently. Color, highlight, small-text size and alignment have no equivalent in this Markdown export and are omitted. Plain text removes presentation while keeping text, paragraph breaks and list structure.
