# Formula coverage — working source, incomplete acceptance

The published Milanote catalog contains **365 unique function IDs**. The independent parser now registers all **365**, including reference-aware `SHEET` and `SHEETS`. Registration proves that a name is available; it does **not** prove all arguments, errors, coercion, dates, performance, or results. [formula-catalog.json](formula-catalog.json) retains the public catalog IDs and source-text hash.

The earlier work added `ISBINARY`, scalar `SPLIT`, `COUNTUNIQUE`, `ISFORMULA`, `FORMULATEXT`, `ISREF`, and the statistical aliases `CONFIDENCE`, `POISSON`, `TDIST2T`, `TINV2T`, `WEIBULL`. Milanote's documented SPLIT returns one token at a zero-based index. Selected observed cases remain in [formula-observed-cases.json](formula-observed-cases.json). Formula introspection reads source cells without evaluating their errors or introducing self-reference cycles. Text-type cells retain their raw source.

## Shared worksheet context

`src/core/formulaWorkbook.ts` exports immutable registry snapshots. `createFormulaWorkbook(loadedTables)` assigns compact indices in the page's initial table order. `reconcileFormulaWorkbook(previous, activeTables, {createdTableIds})` preserves all assigned identities and deleted indices for Undo. It registers a previously loaded table once. The first explicitly native-created table reserves one additional transient creation slot; subsequent native creations append one index each. A fresh load or replacement import rebuilds the registry. The registry is transient and does not serialize engine bookkeeping into the user's card content.

This rule is based on native reference measurements, rather than returning a constant table count:

| Measured state | First table index | Second table index | SHEETS() |
| --- | ---: | ---: | ---: |
| Existing single-table board, after hard reload | 1 | — | 1 |
| First new table after that reload | 1 | 3 | 3 |
| Delete / Undo that added table | 1 | 3 when restored | 3 |
| Reload the two saved tables | 1 | 2 | 2 |
| Hard-reloaded empty board, first native table | 2 | — | 2 |
| Second native table in that same document | 2 | 3 | 3 |

The last two observations on 29 October corrected the earlier incomplete inference that *every* creation added two slots. The stricter regression covers the first and second creation. Detailed evidence is retained outside the product in `/workspace/milanote-analysis/formula-backlog-lifecycle-recover.json` and `/workspace/milanote-analysis/formula-runtime-oct29-lifecycle.json`. Native breadcrumb navigation into a parent with two previously unseen tables increased the nested board's shared count from3 to5 without changing its existing indices or performance.timeOrigin. Reloading the nested board rebuilt compact indices1/2 and count2. This confirms a page-global retained registry across the measured board navigation; it does not close every import/export boundary in `FORM-CTX`.

`formulaContextForTable(workbook, tableId, {errorDisplay})` supplies the same snapshot to `evaluateTableCell`, `formatTableCell`, `evaluateTable`, `TableEditor`, presentation, and exports. A shared context that does not contain the requested table yields a reference error rather than silently substituting index1. Standalone evaluation without a shared workbook treats its single table as one independent worksheet.

`SHEET(A1)` and `SHEET(B2:C3)` return the current worksheet index. `SHEETS(A1)` and `SHEETS(B2:C3)` return1. These AST forms do not evaluate referenced content, so an error or the formula's own cell does not introduce an unrelated error/cycle. Explicit `#REF!` arguments retain that error. Native probes measured **Sheet does not exist** for invalid `SHEET` arguments (`#N/A`, confirmed through `ISNA`), **Cell reference expected** for non-reference `SHEETS` arguments, and **Wrong number of arguments** for excess arguments. The division-by-zero diagnostic is **Numbers can't be divided by zero**. Observed blank rendering alone is never evidence of a particular error code.

## Errors and scalar corrections

Raw evaluator APIs retain error codes. `evaluateTableCellDetails` and `evaluateTableDetails` also expose structured error diagnostics. `TableEditor` shows an empty value with a 16×16 orange indicator and a diagnostic tooltip. Quoted formula literals such as `="#VALUE!"` remain text with no indicator. The reference also displays a raw `#REF!` cell as text, while `ISERROR(A1)` on a reference to that raw cell returns true. Direct `ISERROR("#REF!")` returns false. These measured cases require source-aware coercion rather than globally treating all matching strings as either errors or ordinary text. Display consumers can request blank error values without discarding the underlying evaluator error.

Native reference probes on 28 October used a `="v:"&(...)` prefix, which avoids mistaking a retained date format for the scalar result. They established eleven actual FormulaJS discrepancies now corrected in `src/core/formulaCompatibility.ts`: time-only `TIMEVALUE`; two-bound `ERF`; `ATAN2` argument order; uppercase `BASE`; right-tail `CHIDIST`, `CHIINV`, `FDIST`, `FINV`; two-tail `TINV`; cumulative/density `T.DIST`; and numbered `SUBSTITUTE` occurrences starting at offset0. The original captured formulas and precise results are included in [formula-observed-cases.json](formula-observed-cases.json). Additional numerical/domain tests are independent local validation, not claims that all those boundaries were observed in Milanote.

## Validation and remaining acceptance

The targeted unit command is:

```sh
npx vitest run tests/formula-workbook.test.ts tests/formula-compatibility.test.ts tests/spreadsheet.test.ts tests/formula-catalog.test.ts
```

The current targeted result is **61 tests in4 files passed**. `tests/table-formula-context-e2e.mjs` exercises the actual application editor, shared indices, first/subsequent creation, delete/Undo/reload, same-ID replacement import, error indicators/tooltips, HTML export, and the eleven scalar corrections. The Chromium report now passes **7/7** cases with no page errors after integration; failed intermediate reports remain diagnostic evidence rather than acceptance. The same7 cases pass in Playwright WebKit as well. The broader table suite passes12/12 cases in each engine with the measured error tooltip. Reports: `artifacts/formula-context/{chromium,webkit}/results.json`, `artifacts/table-e2e-results.json`, `artifacts/webkit/table-e2e-results.json`.

Known open rows include array constants and spills, cross-table/sheet references, complete locale and formatting masks, all argument/error/coercion cases for every function, source-derived limits, and exhaustive presentation/export agreement. Formula source size, recursion, ranges, output length, and costly constructors remain bounded locally; the reference's exact limits are unmeasured. All365 names being registered does not close those rows or authorize a complete-parity release.

## Measured export differences

Native reference Markdown and plain-text downloads on29October rendered each table as the literal `Table element string placeholder`; they did not emit its values or raw error codes. Those downloads are retained in `/workspace/milanote-analysis/formula-runtime-oct29-errors-export.md` and `.txt`. This known reference defect does not justify removing the independent project's existing useful table-content exports; the difference stays explicit and open.

A native standardPDF download (27938bytes) was rendered and its text extracted. Error cells show blank text with orange indicators. A raw `#REF!` literal remains selectable text. PDF worksheet-count evaluation differs from the current live UI: the first table renders1/1, the second2/2, while live headers are1/2 and2/2. A separate native editor inspection confirmed that the first-table source is still `=SHEETS()`, so this is a measured export-evaluation difference, not a changed formula. This difference keeps the full export-context acceptance open. Files: `/workspace/milanote-analysis/formula-runtime-oct29-errors-export.pdf`, `formula-runtime-oct29-errors-export-rendered.png`, `formula-runtime-oct29-errors-export-pdftext.txt`, `formula-runtime-oct29-postexport-dom.json`.

Native argument probes additionally confirm that errors inside `SHEET(1/0)` and `SHEETS(1/0)` propagate the division-by-zero diagnostic. String arguments `"Sheet1"`, `"Sheet2"`, and `"sheet1"` yielded **Sheet does not exist** in the measured page; no guessed hidden worksheet-name aliases were added.

The added nested reference child was recoverably deleted after the captures. A fresh parent reload confirmed exactly its two original owned tables remained and no new child tile. `/workspace/milanote-analysis/formula-runtime-oct29-cleanup.json` records `confirmed: true`; Trash was not emptied.
