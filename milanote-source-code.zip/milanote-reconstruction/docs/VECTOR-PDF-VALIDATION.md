# Hybrid PDF text validation — working source, unreleased

The PDF exporter now paints supported, non-overlapping text as visible embedded-font PDF text, with rich faces, URI link annotations and logical Unicode attached to those same visible text objects. It does not place hidden OCR over a complete raster page. Six openly licensed static Inter/Noto Sans Arabic font instances are bundled with source provenance and notices. Full embedding avoids a reproduced fontkit Inter-subset outline-loss defect.

A shared glyph/geometry preflight runs before removing text from the raster capture. Overlapping cards, mixed Arabic/Latin bidi, unsupported glyphs/styles, code fonts, and unsupported transforms retain the existing raster text. Connections, illustrations, backgrounds and many other visual elements remain raster. This is a hybrid improvement, not complete vector parity.

Tests in `tests/vector-pdf-e2e.mjs` inspect visible PDF text operators, embedded fonts, URI annotations, exact Arabic ActualText, unsupported/overlapping fallback equality and source-DOM preservation. PDF.js5.4.624 actually renders the generated files and checks visible ink. Long-document regression renders every page and verifies visible last-page content. Unit font tests cover glyph rejection and font selection.

A real missing-space defect between inline rich-text nodes was corrected by collecting browser-visible whitespace nodes as well as letter nodes. Whitespace with no visible geometry remains untouched.

WebKit PDF.js default FontFace/canvas rendering produced inverted oversized glyphs after the first run. The same WebKit-generated PDF rendered correctly in Chromium (retained cross-engine image), so this is not recorded as malformed PDF output. The test renderer now uses PDF.js `disableFontFace:true` to render embedded glyph outlines directly in both engines. This passed all five workflows plus the error guard in WebKit without loosening coverage thresholds. Default WebKit FontFace rendering is not certified. Original failure evidence is in `artifacts/vector-pdf-webkit-renderer-diagnostic/`.

Current per-engine outputs: `artifacts/vector-pdf-chromium/` and `artifacts/vector-pdf-webkit/`. A complete frozen-source regression is recorded separately; per-tool success does not certify full Milanote typography, every script, visual matching, native iPad behavior or full vector export.

## Source-capture ink audit —2026-10-28

A bounded capture audit reproduced an actual custom-source defect: a paragraph with `color:#0000ff;-webkit-text-fill-color:#00aa00` appeared green in the browser/raster control but blue in the hybrid PDF. The collector previously used `color` without checking the effective glyph fill. This concerns the `sourceElement` capture API; the ordinary note editor does not expose arbitrary text-fill CSS. The original before-fix PDFs and images are retained in `artifacts/pdf-quality-audit/explicitfill-*`.

The collector now leaves text raster when its computed text-fill color differs from its ordinary color, or when nonzero text-stroke width requires outlined glyphs. It does not introduce alternate ink rendering or broaden font support. The added regression inherits those styles through a child span, renders actual hybrid/control PDFs, requires identical images, checks visible ink and absence of replacement text objects, and confirms unchanged source DOM and cleaned capture surfaces. Existing vector text, Arabic, overlap, unsupported-script and rich-source checks remain unchanged.

The same audit verified colored underline, highlighting and strikethrough visually; partially clipped text and transparent outlined text remained pixel-identical to raster controls. These bounded checks do not certify arbitrary CSS or every browser PDF viewer. Final per-engine acceptance appears in the current timestamped `artifacts/vector-pdf-*/results.json` reports; the suite now has six workflows plus the uncaught-error guard.

The updated six-workflow suite plus error guard passed7/7 in both Chromium and WebKit on28October; `npx tsc -b` also passed. This is targeted source validation, not a fresh production-build acceptance or complete suite run.
