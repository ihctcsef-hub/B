# Authenticated reference observations — v1.3 pass

Observed 2026-10-25 in the dedicated authorized test board. No other board was opened or edited. Only the reconstruction's bundled `public/assets/studio-objects.jpg` was uploaded. This report records the live reference UI; it does not certify the reconstruction as an exact copy.

## Provenance

Passive observation used official `rea-agents@6.7.0` against the authenticated reference tab. All four retained REA screenshot artifacts below are 1440×1000. Playwright drove the authorized test actions and collected supplemental screenshots/computed layout measurements. Raw evidence remains in `evidence/`; account/session data is excluded from this report.

| State | REA inspect evidence | REA screenshot evidence |
|---|---|---|
| Note Text style menu | `ev_0bf7314b2c3067f8b28d4a6eb98884d95f199d5198c306c75592f914314306ee` | `ev_95fedf9d5b325a5f0d5db108878802b63c73e2b5852db39b85248c80093178bc` |
| Image Edit modal | `ev_1a524145cfd0dd1f62ee3f14b086a66fc677752f7b9a816d8cf28895b9e44836` | `ev_6a3094ff67cd9224564b619c52a241f190acc3636c88e4b03e640b4aa8a7dd8a` |
| Table cell context menu | `ev_242e0f5d1bffd73097437dab95948649ae334f5dcc94e581392a8bbcc1d3604d` | `ev_ab1ed321860324e3150e1f4efd5444ef6bb8b4feb184fd08d9121addd8105f35` |
| Line start/end/dashed controls | `ev_da77fbbf6a21c683c39f6ac8dd1bdb804826f46c78aa2fefc5f26d7033359eb3` | `ev_b651522bd17a12def54eb94fa60c7091e85110badd7459167ceb3a633e3681c6` |

Files follow `auth-v13-{note-styles,image-edit,table-context,line-caps}-rea-{inspect,screenshot}.json`. Screenshot JSON artifacts are also decoded as matching `.png` files. Supplemental screenshots listed below record intermediate interactions.

## Observed note formatting and spacing

Selecting note text replaces the left creation rail with contextual formatting controls. Hover labels, in order: **Bold**, **Italic**, **Strikethrough**, **Underline**, **Bullet list**, **Numbered list**, **Align center**, **Inline code**, **Hyperlink**, **Add comment**. The rail begins with **Text style**.

The Text style popup contains **Large heading**, **Normal heading**, **Normal text**, **Small text**, **Code block**, **Callout**, **“Quote block”**, then **Color** and **Highlight** swatches. Observed shortcuts include Large heading Ctrl+Shift+1, Normal heading Ctrl+Shift+2, Small text Ctrl+Shift+9, Code block Ctrl+>, Callout Ctrl+Shift+6, Quote block Ctrl+". The presence of these commands is observed; every command's complete behavior was not exercised in this pass.

Computed 100% layout for a populated note, outside editing:

| Element | Observed measurement |
|---|---|
| Note editor | Font 11.2px, line-height 16px; padding **19px 15.3px 11px 19.2px** |
| Paragraphs | Margin `0 0 8px`; 16px one-line height, 32px two-line height |
| Standalone one-line card | **270×54px**, outer padding 0; text starts x+19.1875px, y+19px |
| In-column two-paragraph card | 257.21875×98px; outer padding `1px 0`, 1px border; inner editor 255.21875×94px |
| Intermediate editor containers | Padding 0, margin 0 |

The existing two-paragraph note contained `<strong>` text. These measurements therefore include that particular populated content; they do not establish all rich block heights. See `auth-v13-note-styles.png` and `auth-v13-note-selected.png`.

## Observed default To-do

A newly dragged blank To-do is **270×54px**, with no title and one unchecked row. Exact placeholder: **Add a task…**. Editor container padding is `15px 18px 15px 19px`; its inner content is 233×24px. The task row has `4px 0` padding, font 11.2px and line-height 16px; the paragraph has zero margin. The checkbox is 12.796875px square, at card x+19px, y+20.59375px. Text starts at x+39.796875px, y+19px. See `auth-v13-todo-default-blurred.png`.

## Observed image workflow

- **Add image → Upload your own** opens an upload panel. Uploading this bundled image placed it in **Unsorted**; dragging it onto the canvas produced a 270px-wide card.
- The selected-image rail includes **Color**, **Labels**, **Reactions**, **Comment**, **Draw on**, **Edit**, **Background**, **Caption**. After adding markup, **Draw on** becomes **Edit drawing**.
- **Edit** opens a large image over a dimmed canvas. Its controls are **Crop**, **Rotate left**, **Flip horizontal**, **Flip vertical**, **Cancel**, **Save**. The modal also exposes mode labels **Draw on**, **Edit**, **Cut out** and image navigation/download controls.
- Crop toggles an orange rectangle with eight handles and a thirds grid. A corner drag changed the crop freely. **Rotate left** turned the image by a quarter turn. Saving crop+rotation returned the transformed image to the board and changed its aspect ratio. This was an actual saved transformation in the test board.
- **Draw on** opens the same image modal with **Pen**, **Selection tool**, **Eraser**, **Color**, **Line weight**, **Undo**, **Redo**, **Cancel**, **Save**. The weight popup displays four stroke presets, without numeric labels. A pointer stroke enabled Undo/Save; Undo enabled Redo; Redo restored the stroke; Save persisted visible markup on the canvas image.

Screenshots: `auth-v13-image-edit.png`, `auth-v13-image-crop.png`, `auth-v13-image-crop-adjusted.png`, `auth-v13-image-rotated.png`, `auth-v13-image-transform-saved.png`, `auth-v13-image-draw-weight.png`, `auth-v13-image-markup-stroke.png`.

Flip controls were observed but not activated. Cut out/backend processing, alpha export, original-resolution output fidelity, pressure/velocity response, eraser intersection rules and annotation selection geometry remain unverified.

## Observed table workflow

- A new table contains **3 columns × 4 rows**, total **270×94px**. Columns are 90px wide; row heights observed were 23, 24, 24, 23px. Editing displays column labels A–C and row labels 1–4 outside the cells.
- Double-clicking a cell entered editing. Typing **Metric**, Tab, **10**, Enter committed both values and moved selection as expected. The editing rail contains **Text style**, **Cell type**, **Color**, **Formula**, **Alignment**, **Add column**, **Add row**.
- Cell type menu: **Auto**, **Number**, **Currency**, **Percentage**, **Text**, **Date & Time**, **Checkbox**.
- Right-click menu: **Cut**, **Copy**, **Paste**, **Paste Values**, **Add Row Above**, **Add Row Below**, **Add Column Left**, **Add Column Right**, **Clear Cell**, **Delete Row**, **Delete Column**. Add-row/column shortcuts shown are Alt+arrow.
- **Add Row Below** increased the table from 4 to 5 rows. **Add Column Right** increased it from 3 to 4 columns. The table expanded to keep 90px columns.
- Alignment popup has six icon controls: horizontal left/center/right and vertical top/middle/bottom. Default active icons were left and top.
- Clicking **Formula** entered a cell editor containing `=`. Entering `=SUM(B1:B2)` in another cell displayed **10** when B1 was 10 and B2 blank. This verifies that single formula example only.

Screenshots: `auth-v13-table-default.png`, `auth-v13-table-editing.png`, `auth-v13-table-cell-types.png`, `auth-v13-table-context.png`, `auth-v13-table-alignment.png`, `auth-v13-table-formula-result.png`.

Cell-type conversions, dates/timezones, locale currency formatting, arbitrary formula compatibility, clipboard integration, row/column moves, and persistence across reload were not fully tested here.

## Observed line defaults and caps

A dragged **Line** created a diagonal straight line, with **Start off**, **End on**, a dark stroke `rgb(50,59,74)` and default rendered width **1.6px**. The rail is **Color**, **Start**, **End**, **Label**, **Dashed**, **Weight**. Start and End are independent immediate toggles, not cap-selection menus: clicking Start activated it; clicking End deactivated it. Endpoint arrowheads are filled triangles; the inactive endpoint uses a tiny round marker. The default line has two endpoint handles and a center control-point handle.

Weight offers three icon presets. Observed rendered widths are **0.8px**, **1.6px**, **3.2px**. The popup remains open after choosing a weight. Enabling Dashed produced computed dasharray **5px, 5px**, with stroke-linecap **butt**. No other cap options were observed in this workflow. See `auth-v13-line-default.png`, `auth-v13-line-weight.png`, `auth-v13-line-caps-dashed.png` and REA line screenshots.

Attached connector snapping/routing, curve manipulation, label placement, and defaults after user preference changes remain unverified.

## Limits for parity claims

This pass provides concrete runtime evidence for the controls and actions above. It does not prove complete app parity, pixel identity across states, original algorithms, server behavior, collaboration, history equivalence, iPad/touch/Pencil behavior, import/export fidelity, all responsive layouts, or full formula support. The reference exposes Cut out and server-backed services that were not reproduced or exercised. Similar visible controls in the reconstruction must not be described as verified equivalent without corresponding side-by-side behavior checks.
