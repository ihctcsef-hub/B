# File preview coverage — open acceptance

This inventory separates **documented upload support** from **measured preview behavior**. The public file article lists25 groups,132 extension occurrences and131 unique extensions (`eps` occurs in two groups). None is called a thumbnail merely because it can be uploaded. This file does not close the parent PRE-FILES row.

The current reference sample uses only independently generated files in owned child `1XlXUz1caAjVdi`. Existing generic DOCX/TXT/ZIP cases contain valid original content; they displayed compact file icons. This does not establish the behavior of embedded-thumbnails or every sibling Office format.

## PDF states measured

| State | Card geometry | Content |
|---|---|---|
| Preview on, info on, caption off |270×430.375| First-page raster270×358; metadata270×72.375 |
| Preview off |78×111.171875| Compact file icon, filename and size |
| Preview restored |270×430.375| Original detail geometry restored |
| File info off |270×358| Entire metadata hidden; Rename absent, Caption disabled |
| File info restored |270×430.375| Original detail restored |
| Empty caption on |270×462.375| Adds32px to the detail card |
| Caption off |270×430.375| Returns to original detail |

Reference image uses `object-fit:cover`. Footer padding is20.2px19.2px; icon25.59375×31.984375; details margin-left9.6px. Filename editor is12px/16px Inter600; secondary links9.6px/12px, rgb141/146/154. Exact measurements: `/workspace/milanote-analysis/pdf-preview-footer-details.json`. Native-click state sequence: `file-preview-states.json`. All toggles were restored. Earlier incomplete probes selected transient duplicate toolbar trees; those partial observations are not treated as successful state sequences.

## Independent decoder verification

Before integration, real PDF.js rendering passed in Chromium and WebKit for a two-page360×480 PDF: metadata preserved, thumbnail720×960, first-page red pixels retained rather than second-page green, invalid URL rejected and pre-aborted work rejected withAbortError. `artifacts/pdf-preview-audit-{engine}/results.json` and `first-page.png` retain evidence. Cleanup probes additionally inspect actual Worker construction/termination around successful, malformed and aborted documents; they are distinct from UI parity. The PDF renderer uses only bundled worker/font/CMap/WASM assets.

## Per-extension open matrix

| Extension | Documented group(s) | Measured reference mode | Acceptance status |
|---|---|---|---|
| 3ga | Audio | unmeasured | جزئي |
| 7z | Archives | unmeasured | جزئي |
| aec | Adobe After Effects | unmeasured | جزئي |
| aep | Adobe After Effects | unmeasured | جزئي |
| aet | Adobe After Effects | unmeasured | جزئي |
| aetx | Adobe After Effects | unmeasured | جزئي |
| ai | Adobe Illustrator | unmeasured | جزئي |
| ai3 | Adobe Illustrator | unmeasured | جزئي |
| ai4 | Adobe Illustrator | unmeasured | جزئي |
| ai5 | Adobe Illustrator | unmeasured | جزئي |
| ai6 | Adobe Illustrator | unmeasured | جزئي |
| ai7 | Adobe Illustrator | unmeasured | جزئي |
| ai8 | Adobe Illustrator | unmeasured | جزئي |
| amr | Audio | unmeasured | جزئي |
| amx | Adobe After Effects | unmeasured | جزئي |
| avi | Video | unmeasured | جزئي |
| bmp | Standard image formats | unmeasured | جزئي |
| cfa | Adobe Premiere Pro | unmeasured | جزئي |
| cpa | Adobe Premiere Pro | unmeasured | جزئي |
| cr2 | RAW images | unmeasured | جزئي |
| crw | RAW images | unmeasured | جزئي |
| csv | Comma separated | unmeasured | جزئي |
| divx | Video | unmeasured | جزئي |
| dng | RAW images | unmeasured | جزئي |
| doc | Microsoft Word | unmeasured | جزئي |
| docm | Microsoft Word | unmeasured | جزئي |
| docx | Microsoft Word | file-icon | جزئي |
| dw | Dreamweaver | unmeasured | جزئي |
| dwt | Dreamweaver | unmeasured | جزئي |
| eps | RAW images, Adobe Illustrator | unmeasured | جزئي |
| erf | RAW images | unmeasured | جزئي |
| gif | Standard image formats | unmeasured | جزئي |
| gz | Archives | unmeasured | جزئي |
| ico | Standard image formats | unmeasured | جزئي |
| idlk | Adobe InDesign | unmeasured | جزئي |
| ind | Adobe InDesign | unmeasured | جزئي |
| indd | Adobe InDesign | unmeasured | جزئي |
| indt | Adobe InDesign | unmeasured | جزئي |
| jpe | Standard image formats | unmeasured | جزئي |
| jpeg | Standard image formats | unmeasured | جزئي |
| jpg | Standard image formats | unmeasured | جزئي |
| js | Javascript | unmeasured | جزئي |
| jxr | RAW images | unmeasured | جزئي |
| key | Apple Keynote | unmeasured | جزئي |
| lrcat | Adobe Photoshop Lightroom | unmeasured | جزئي |
| lrdata | Adobe Photoshop Lightroom | unmeasured | جزئي |
| lrdb | Adobe Photoshop Lightroom | unmeasured | جزئي |
| lrprev | Adobe Photoshop Lightroom | unmeasured | جزئي |
| lrpreview | Adobe Photoshop Lightroom | unmeasured | جزئي |
| lrtemplate | Adobe Photoshop Lightroom | unmeasured | جزئي |
| m1a | Video | unmeasured | جزئي |
| m2a | Video | unmeasured | جزئي |
| m4a | Audio | unmeasured | جزئي |
| m4b | Video | unmeasured | جزئي |
| m4p | Video | unmeasured | جزئي |
| m4r | Video | unmeasured | جزئي |
| m4v | Video | unmeasured | جزئي |
| md | Plain text | unmeasured | جزئي |
| mid | Audio | unmeasured | جزئي |
| mk3d | Video | unmeasured | جزئي |
| mka | Audio | unmeasured | جزئي |
| mks | Video | unmeasured | جزئي |
| mkv | Video | unmeasured | جزئي |
| mlv | Video | unmeasured | جزئي |
| mov | Video | unmeasured | جزئي |
| mp1 | Video | unmeasured | جزئي |
| mp2 | Video | unmeasured | جزئي |
| mp3 | Audio | unmeasured | جزئي |
| mp4 | Video | unmeasured | جزئي |
| mpa | Audio | unmeasured | جزئي |
| mpeg | Video | unmeasured | جزئي |
| mpg | Video | unmeasured | جزئي |
| mpv | Video | unmeasured | جزئي |
| mrw | RAW images | unmeasured | جزئي |
| nef | RAW images | unmeasured | جزئي |
| numbers | Apple Numbers | unmeasured | جزئي |
| odc | Microsoft Excel | unmeasured | جزئي |
| odp | Microsoft Powerpoint | unmeasured | جزئي |
| ods | Microsoft Excel | unmeasured | جزئي |
| odt | Microsoft Word | unmeasured | جزئي |
| oga | Audio | unmeasured | جزئي |
| ogg | Video | unmeasured | جزئي |
| ogm | Video | unmeasured | جزئي |
| ogv | Video | unmeasured | جزئي |
| ogx | Video | unmeasured | جزئي |
| opus | Audio | unmeasured | جزئي |
| orf | RAW images | unmeasured | جزئي |
| otc | Microsoft Excel | unmeasured | جزئي |
| otp | Microsoft Powerpoint | unmeasured | جزئي |
| ott | Microsoft Word | unmeasured | جزئي |
| pages | Apple Pages | unmeasured | جزئي |
| pbm | Standard image formats | unmeasured | جزئي |
| pdf | Portable document format | first-page-raster | جزئي |
| pgm | Standard image formats | unmeasured | جزئي |
| pkf | Audio | unmeasured | جزئي |
| png | Standard image formats | unmeasured | جزئي |
| ppm | Standard image formats | unmeasured | جزئي |
| ppt | Microsoft Powerpoint | unmeasured | جزئي |
| pptm | Microsoft Powerpoint | unmeasured | جزئي |
| pptx | Microsoft Powerpoint | unmeasured | جزئي |
| prproj | Adobe Premiere Pro | unmeasured | جزئي |
| ps | Adobe Illustrator | unmeasured | جزئي |
| psd | Adobe Photoshop | unmeasured | جزئي |
| psf | Adobe Illustrator | unmeasured | جزئي |
| qt | Video | unmeasured | جزئي |
| raf | RAW images | unmeasured | جزئي |
| rar | Archives | unmeasured | جزئي |
| raw | RAW images | unmeasured | جزئي |
| rp | Axure | unmeasured | جزئي |
| rtf | Plain text | unmeasured | جزئي |
| sketch | Sketch | unmeasured | جزئي |
| spx | Video | unmeasured | جزئي |
| svg | Vector images | image | جزئي |
| tab | Comma separated | unmeasured | جزئي |
| tar | Archives | unmeasured | جزئي |
| tif | Standard image formats | unmeasured | جزئي |
| tiff | Standard image formats | unmeasured | جزئي |
| tsv | Comma separated | unmeasured | جزئي |
| txt | Plain text | file-icon | جزئي |
| wav | Audio | unmeasured | جزئي |
| wave | Audio | unmeasured | جزئي |
| webm | Video | unmeasured | جزئي |
| webp | Standard image formats | unmeasured | جزئي |
| wmv | Video | unmeasured | جزئي |
| x3f | RAW images | unmeasured | جزئي |
| xls | Microsoft Excel | unmeasured | جزئي |
| xlsm | Microsoft Excel | unmeasured | جزئي |
| xlsx | Microsoft Excel | unmeasured | جزئي |
| xmp | RAW images | unmeasured | جزئي |
| xvid | Video | unmeasured | جزئي |
| zip | Archives | file-icon | جزئي |

Every row requires a valid specimen and the applicable states listed in [file-preview-catalog.json](file-preview-catalog.json). Unsupported/deferred platform testing is tracked separately by the parent backlog. No external document conversion service receives local attachments.
