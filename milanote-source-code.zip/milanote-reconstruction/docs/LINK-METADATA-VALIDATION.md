# Link metadata — working source

This report covers the independent link-preview adapter and its integration tests. It does not certify complete Milanote behavior or visual parity, and it does not authorize a release.

## Behavior under test

A newly entered or pasted HTTP(S) link requests page metadata. The source URL, including its fragment, remains the user's URL even if the metadata result comes from a redirected page. The fetched title, description and preview image have a persisted `linkMetadata` snapshot so later refreshes can distinguish automatic values from custom details. Existing custom fields, caption and visibility choices are retained. A title draft actively being edited is retained when another field's metadata arrives.

Each pending request belongs to a workspace, board, card and URL. A newer URL/request, deletion, locking, workspace replacement or import cancels the old request. Importing the same workspace ID also cancels it. A completed request waits for a pointer gesture to finish and applies to the latest document, so metadata and the completed drag retain separate Undo transactions.

Failures keep the existing editable link details and show an unavailable message; no placeholder website content is represented as fetched metadata. Invalid URL input does not initiate a request. Locked links cannot open their editor or begin a refresh.

## Browser verification

`tests/link-metadata-e2e.mjs` uses explicitly routed JSON metadata fixtures and one bundled local photograph. Its results do **not** prove a live public website request; the adapter's separate transport tests and live probes establish that scope independently.

The seven UI workflows plus an uncaught-error guard cover:

1. Entering a new URL, fetched fields/image, preserved source fragment and redirect provenance, reload and an editable JSON backup that embeds the image.
2. Custom fields present before a refresh and a focused dirty title draft entered while its response is held.
3. Cancelling the old response after a URL change, retaining the new fragment and original source URL after a redirect result.
4. Reimporting the same workspace, card ID and URL while a request is in flight, without delayed fields or provenance leaking into the replacement.
5. Native browser mouse drag with a response delivered during the gesture, followed by two independent Undo operations.
6. An explicit503 fixture, invalid URL input without a request, and a locked card that cannot open an editor or request metadata.
7. Locking or deleting a link during a pending request, including untouched recoverable Trash content and Undo restoration.

Asynchronous races use route gates and browser animation frames rather than sleeping before critical assertions. Persistence checks read the matching workspace title and content from IndexedDB. These are desktop browser tests, not physical iPad measurements.

The initial functional-only run passed six workflows plus the error guard in Chromium and WebKit. The added lock/delete cancellation workflow also passed in the subsequent Chromium run. A subsequent screenshot review found a real layout gap: the new card's120px height left the URL/details below its white background. The added bounds assertion reproduced `cardBottom=580` versus `contentBottom=606.859375` in Chromium. The original report and screenshot are retained in `artifacts/link-metadata-layout-diagnostic/`. This failure is not treated as a timing issue or hidden by relaxing the assertion. The layout correction subsequently passed the strict content-bounds assertion. The final WebKit run passed eight workflows plus the error guard, including manual resize persistence, lock/delete cancellation, and separate Undo after a live note edit. The first resize check exposed an actual stale preview at pointer release; release coordinates now determine the committed geometry. The combined frozen-source Chromium run subsequently passed33/33 groups, including all nine link-metadata checks.

Per-engine current outputs are `artifacts/link-metadata-chromium/results.json` and `artifacts/link-metadata-webkit/results.json`; screenshots and the exported backup are in the same directories. Always inspect the timestamp and status rather than assuming that every retained artifact passed.

```sh
TEST_URL=http://127.0.0.1:5304 node tests/link-metadata-e2e.mjs
BROWSER_ENGINE=webkit WEBKIT_PATH=/workspace/.cache/webkit-runner.sh PLAYWRIGHT_BROWSERS_PATH=/workspace/.cache/ms-playwright TEST_URL=http://127.0.0.1:5304 node tests/link-metadata-e2e.mjs
```

## Limits

The metadata endpoint needs the local server middleware; serving `dist/` alone does not provide it. JavaScript-rendered pages, authenticated/private previews, provider-specific cards, all image/CDN policies, and complete reference layouts are outside these fixtures. A remote preview image is displayed by the browser and can still be subject to browser/network rules; this is not a server-side image cache or a claim that every remote image can be embedded into a portable export.

The tested request cancellation, merge and Undo behavior is a local consistency policy. It is not a measurement of Milanote's exact network timing, preview-update history or every manual customization rule.
