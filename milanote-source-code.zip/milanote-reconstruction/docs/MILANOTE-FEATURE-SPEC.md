# Milanote editor: public evidence specification

Research date: 2026-10-24. This document uses official public help material, not an authenticated editor session or extracted proprietary source. These are documentation-backed behaviors. Exact pixels, gesture thresholds, responsive breakpoints, internal models, and undocumented tools remain unverified. REA runtime findings, when available, belong in a separate evidence ledger.

## Editor organization and visual anchors

- A left-side creation toolbar lets users drag content into a freeform board. Selection changes that toolbar to formatting controls.
- The board navigation/breadcrumb is at top left; Unsorted and Export are at top right. Unsorted is a per-board holding panel, with drag in/out.
- Nested boards are represented by board tiles; double-click opens one. Creating a board within another nests it. Dragging a board onto another moves it there. Breadcrumbs show the visited board path.
- An empty board exposes a template picker at bottom right. The original has a large template library; an independently authored subset must be labelled as such.

Sources: [first project](https://help.milanote.com/en/articles/112349-creating-your-first-project), [nesting](https://help.milanote.com/en/articles/9860073-nesting-boards), [unsorted](https://help.milanote.com/en/articles/111399-unsorted-notes).

## Tools and observable contracts

| Tool | Documented behavior to reproduce | Source |
|---|---|---|
| Note | Minimal rich text with headings, normal/small text, inline styling, text/highlight colors, lists, indentation, code/quote blocks, links. Background color or transparent note. | [Text Formatting](https://help.milanote.com/en/articles/4675110-text-formatting) |
| Image | Drop image onto board or upload multiple into Unsorted; drag lower-right resize; optional caption/color strip; double-click editing with crop, rotate, image markup, download; context menu position lock. | [Images](https://help.milanote.com/en/articles/359381-images) |
| Link | Drag link card, paste URL, Enter. Three independently editable/displayable sections: preview media, URL, description. Preview and description originate from URL metadata; thumbnail may be replaced by dropping an image. | [Links](https://help.milanote.com/en/articles/1722065-links) |
| To-do list | Title, checkboxes and task text; Tab/Shift-Tab task indentation; task due date, optional reminder; delete completed item or drag task to trash. Assignment and outbound notifications are service features outside requested scope. | [To-Do Lists](https://help.milanote.com/en/articles/10486983-to-do-lists) |
| Column | Drag from toolbar; title and card count; drop/reorder cards with black insertion indicator. Top region moves column; lower-right resize; small dash collapses. Group selected cards into column through context menu. Columns cannot contain columns, but may contain boards/documents. | [Columns](https://help.milanote.com/en/articles/10478526-columns) |
| Line/arrow | Start at top-right card circle or drag from toolbar; endpoints attach to cards or specific points. Center handle bends line; double-click center restores straight line. Select and type label; change color/weight. Shift constrains endpoint horizontally/vertically. | [Lines](https://help.milanote.com/en/articles/111391-lines) |
| Drawing | Three contexts: board-wide ink; resizable sketch card opened by double-click; image markup via double-click image then Draw. Toolbar at bottom in sketch editing. Mouse/stylus/Apple Pencil. Image markup scales with image. | [Drawing](https://help.milanote.com/en/articles/5537688-drawing) |
| Color swatch | Drag creates swatch; double-click picker; paste HEX; optional HEX/RGB/HSL text; caption toggle; lower-right resize. Original can suggest colors from images and has eyedropper. | [Color swatches](https://help.milanote.com/en/articles/2497222-color-swatches) |
| Table | Editable text/numeric/checkbox cells, typed formatting, formulas. Add/remove/reorder rows/columns. Drag header divider changes column width; row height not adjustable. Table contains no images/board elements. | [Tables](https://help.milanote.com/en/articles/8584584-tables) |
| Label | Apply named colored labels to one/multiple items; create, rename, recolor, remove/delete. Rename is global across local usages. Search finds labelled items. Undo/redo label operations. | [Labels, June 2026](https://help.milanote.com/en/articles/15442078-labels) |
| Media/files/documents | Official inventory lists videos, audio, documents/files, map cards and synced notes in addition to the tools above. Exact editing and embedding behavior needs further examination before parity claims. | [Content inventory](https://help.milanote.com/en/collections/166826-adding-organizing-content) |

## Desktop interaction essentials

- Double-click blank canvas creates note. Space-drag pans. `Z` fits content; Ctrl/Cmd +/- and Ctrl/Cmd wheel zoom. Pinch works on trackpad/iPad.
- Ctrl/Cmd+C/X/V, Ctrl/Cmd+Z, select-all, Escape, arrow nudges and Shift-arrow larger nudges. Alt/Option-drag duplicates. Ctrl/Cmd+Enter adds another selected note/board/column type. Ctrl/Cmd+Shift+Up/Down reorders layers. `/` opens shortcut help.
- Drawing shortcuts: Shift+D enters; D pen; V select; E eraser; X previous color; 1–4 pen sizes; Escape saves.
- Right-click element opens contextual actions. Copy+paste creates new content, board shortcut points at original, synced note edits affect all copies: do not conflate these models.

Sources: [shortcuts](https://help.milanote.com/en/articles/111393-keyboard-shortcuts), [zoom](https://help.milanote.com/en/articles/1721940-zoom-in-out), [duplicate](https://help.milanote.com/en/articles/111397-duplicating-content).

## iPad interaction requirements

Official iPad guide: double-tap canvas for new note; long-press content then drag; long-press blank canvas and drag for multiselection; pinch zoom; double-tap image then Draw for markup. Three-finger swipe left/right gives undo/redo; three-finger pinch inward copies, twice cuts; outward pastes. Context menu uses two-finger tap on an item according to duplication guide.

These describe original application behavior, not proof that an emulated viewport or custom web implementation reproduces iPadOS gesture routing. Real hardware validation remains required. Browser or operating system may intercept some gestures; keyboard and visible toolbar alternatives are appropriate implementation choices.

Sources: [iPad app](https://help.milanote.com/en/articles/6280198-milanote-ipad-app), [duplication/context menu](https://help.milanote.com/en/articles/111397-duplicating-content).

## Export and persistence

Original non-home boards have Export top right with PDF Standard/Large, PNG, Word, Markdown and plain text. PDF/PNG fit into one page; text formats linearize. Asset ZIP generation is server-assisted. Home board has no export in original. Local JSON backup and browser-local autosave are independent implementation choices for this reconstruction, not reverse-engineered Milanote formats or synchronization protocols.

Source: [Exporting your work](https://help.milanote.com/en/articles/111395-exporting-your-work).

## Scope and completion language

- User excludes account services, collaboration, notifications, billing and publishing. It is appropriate to provide functional local equivalents rather than reproducing servers.
- Do not claim pixel-perfect/current full feature parity from these documents alone. Need authenticated editor states, selected tool panels, visual screenshots, actual iPad session, and representative drag/zoom/undo tests.
- Public official pages now document labels and tables; omitting them must be listed as an actual limitation. A generic note/card canvas is not a full reconstruction.
- Suggested architecture (design choice): persisted board graph, stable item IDs, column ownership/order, per-board viewport, geometry-based connectors, command history transactions, and input adapters for mouse/touch/pen.
