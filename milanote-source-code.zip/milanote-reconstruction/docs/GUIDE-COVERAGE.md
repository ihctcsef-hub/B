# مراجعة دليل Milanote وتغطية الأدوات

تاريخ تحديث المصدر: 2026-10-26. القراءة الأصلية للصفحات: 2026-10-25. هذه خريطة تنفيذ وفحص، وليست شهادة تطابق كامل.

فُحص فهرس [Guides](https://milanote.com/guide) وكل الصفحات الـ67 المرتبطة به، إضافة إلى المقالات الـ30 في [Adding & organizing content](https://help.milanote.com/en/collections/166826-adding-organizing-content). نجح جلب الصفحات الـ97 كلها. جُمعت التعليمات المعروضة داخل «How to do this in Milanote / Show me how» وفُصلت عن نصائح العمل الإبداعي. أمثلة «خطّط لرواية» و«أنشئ moodboard» ليست أدوات مستقلة؛ هي تراكيب من اللوحات والملاحظات والصور والأعمدة وغيرها.

القراءة تثبت ما توثّقه Milanote، ولا تثبت تنفيذ كل إجراء في حساب المرجع. أدلة التشغيل الفعلية منفصلة في `AUTHENTICATED-INVESTIGATION.md` وتقرير فحص v1.3. حالات الجدول أدناه محدّثة بقراءة المصدر الجاري في `src/` بعد دمج محررات الجداول والمهام والألوان والخطوط والصيغ والمستندات. نجاح اختبار الوحدة أو وجود زر لا يثبت تطابق السلوك والبكسلات مع الأصل. اختبارات المتصفح والمقارنة المرجعية موثقة في تقاريرها المنفصلة.

معاني الحالة: **موجود** = يوجد مسار تنفيذي محلي؛ **جزئي** = توجد بعض الخطوات مع فروق محددة؛ **ناقص** = لم يوجد المسار في الكود المراجع؛ **خارج النطاق** = خدمات الحساب/المشاركة/الدعوات/الإشعارات التي استبعدها الطلب الأصلي. كل حالة «موجود» تحتاج أيضًا فحص المرجع إن أُريد ادعاء المطابقة.

## جميع عائلات إجراءات Guides

دمجت الصيغ النصية المتكررة للتعليمات في العائلات الآتية. لم تُفسَّر عناوين مثل «اكتب وصف الشخصية» على أنها خصائص منفصلة للمنتج.

| إجراء موثّق في Guides | التغطية في المصدر الجاري | ما يجب إكماله/التحقق منه |
|---|---|---|
| سحب Board وتسميتها وفتحها بالنقر المزدوج | موجود | مراجعة شكل الأيقونة والعداد وحالة التحديد والمقاسات |
| اختيار Template عند فتح لوحة جديدة | جزئي | قوالب محلية ونسخ snapshot لقوالب مخصصة موجودة؛ ليست مكتبة Milanote ولا كل إجراءات إدارتها |
| سحب Note والكتابة وتنسيقها من الجانب | موجود | محرر WYSIWYG مع Callout مستقل؛ بعض اختصارات/تفاصيل التنسيق تحتاج مقارنة |
| سحب Note داخل Column | موجود | اختبارات ارتفاع البطاقة، التفاف النص والتراجع عن الإدخال/الإخراج |
| سحب Column وتسميتها وإضافة العناصر | موجود | الترتيب والانطواء والتحجيم موجودة؛ المقارنة البصرية لكل حالة لازمة |
| رفع ملف/صورة أو إسقاطه من الجهاز | موجود | حد محلي 15MB وتخزين المتصفح يختلفان عن معالجة الأصل وأنواع الملفات |
| مكتبة الصور المدمجة والبحث فيها | جزئي | مكتبة وموصل رسمي لـPexels مع بحث/ترقيم وسحب مضافان؛ اختبارات البيانات الاختبارية منفصلة، والاتصال الحي غير متحقق منه لغياب مفتاح المستخدم. |
| Web Clipper وحفظ صور/نصوص إلى لوحة وUnsorted | خارج النطاق | إضافة متصفح/تكامل خارجي مستقل غير موجود |
| إضافة فيديو/صوت من رابط مشاركة | جزئي | embeds لمزوّدين معروفين عبر `mediaEmbedUrl`؛ ليس كل المزوّدين ولا معالجة الروابط المختصرة |
| إضافة Swatch وتغيير اللون بالنقر المزدوج | موجود محليًا ومشاهد في المرجع | الأبعاد134×142 والمنتقي الأصلي بالنقرتين، مع تعليق غني قابل للتوسيع والإخفاء؛ مقارنة كل حالات المنتقي على iPad غير معتمدة. [تقرير الألوان](IMAGE-COLORS-VALIDATION.md). |
| سحب زاوية الصورة لتغيير الحجم | موجود | الحفاظ على النسبة والفرق بين حجم العنصر/قص المحتوى يلزمان مقارنة |
| نقر زاوية الصورة مرتين لاستعادة الحجم الأصلي | جزئي | مقبض reset موجود ويعود لعرض270 ونسبة المصدر؛ استعادة مقاسات الأصل بعد crop تحتاج مقارنة |
| فتح الصورة ثم Edit لقصها أو تدويرها | موجود | النقر المزدوج يفتح المحرر؛ القص/الدوران/Flip والرسم موجودة، مع فروق بصرية معروفة |
| إضافة caption للصورة بتحديدها ثم الكتابة | جزئي | الكتابة عند تحديد الصورة تفتح تحرير caption، مع محرر غني وحفظ HTML؛ لا يثبت ذلك جميع اختصارات المرجع |
| إضافة To-do ثم Enter لإضافة مهمة | موجود | قائمة افتراضية بسطر واحد ودون عنوان، بما يوافق المشاهدة |
| إضافة عنوان To-do من الشريط الجانبي | موجود | Title يضيف/يحذف العنوان ويحفظه في الوثيقة |
| إنشاء Table وإضافة صيغ وتواريخ وعملات | جزئي | محرر متكامل وصيغ موسعة موجودان؛ توافق الكتالوج الكامل وخيارات التاريخ والصفوف/الأعمدة غير مكتمل |
| إضافة Google Maps من رابط في Link | جزئي | embed لمواقع Google Maps بصيغ q/place؛ روابط المشاركة المختصرة وتطابق كل إيماءات الخريطة غير مكتملين |
| توصيل العناصر بخطوط وأسهم | موجود محليًا | أضيف السحب من مقبض البطاقة وsnapping وإعادة الربط وShift والتثبيت النسبي؛ توقيت التثبيت450ms مستقل وغير مقاس في المرجع. |
| رسم أفكار على كامل اللوحة ثم Save | موجود محليًا | جلسة Save/Cancel مع تحديد/ممحاة/نقل/Undo/Redo، وحفظ واحد للجلسة؛ اختبارات المتصفح منفصلة ولا تثبت كل إيماءات الأصل. |
| سحب مجموعة صور إلى لوحة فارغة لترتيبها Grid | موجود محليًا ومقاس لمسارات محددة | ترتيب shortest-column بأعمدة متكيفة مع عرض اللوحة وخطوة288px وفاصل18px، مع أبعاد رفع مقاسة وإخفاء caption للإسقاط المباشر. فُحصت اللوحة الفارغة والمحتوية وصورة واحدة ومصادر صغيرة؛ يبقى الرفع إلىUnsorted والمجموعات المختلطة وكل حالات التكبير بحاجة مقارنة. [تقرير الصور المتعددة](IMAGE-GRID-VALIDATION.md). |
| التقاط الصور من تطبيق الهاتف ووصولها إلى Unsorted | خارج النطاق | لا تطبيق هاتف أصلي/مزامنة؛ رفع الملفات محليًا متاح |
| تفاعلات emoji على الصورة/الملاحظة | خارج النطاق | موثقة في الأدلة، غير منفذة؛ تعامل كخدمة تعاونية مستبعدة من الطلب الأصلي |
| تعليقات وسلاسل ردود وإشارات @ | خارج النطاق | غير منفذة، ولا تُرسل تعليقات أو تنبيهات من المحاكي |
| دعوة محررين وتحديثات مباشرة | خارج النطاق | لا حسابات أو backend تعاوني |
| رابط قراءة فقط/كلمة مرور/Welcome message/نشر | خارج النطاق | لا استضافة أو مشاركة خارجية |

مصادر تمثيلية تجمع كل الأدوات الفريدة: [Moodboard](https://milanote.com/guide/create-better-moodboards)، [Website planning](https://milanote.com/guide/website-design-project-plan)، [Sitemap](https://milanote.com/guide/site-map)، [Photoshoot](https://milanote.com/guide/photoshoot)، [Contact sheet](https://milanote.com/guide/contact-sheet)، [Film storyboard](https://milanote.com/guide/film-storyboards)، [Campaign plan](https://milanote.com/guide/campaign-plan)، [Logo presentation](https://milanote.com/guide/logo-design-presentation)، [YouTube script](https://milanote.com/guide/video-script-youtube). قائمة الصفحات كاملة في نهاية الملف.

## تفاصيل ما بعد إضافة العنصر

### الملاحظة والمستند

المراجع: [Text Formatting](https://help.milanote.com/en/articles/4675110-text-formatting)، [Documents](https://help.milanote.com/en/articles/10458661-documents)، [Synced notes](https://help.milanote.com/en/articles/5147264-synced-notes).

| الخاصية | الحالة في الكود | الفجوة الدقيقة |
|---|---|---|
| تعديل جزء محدد من النص: bold/italic/strike/underline | موجود في `NoteEditor.tsx` | يلزم فحص نطاق التحديد بعد فتح القوائم، Undo/Redo وإعادة التحميل |
| عناوين، نص عادي/صغير، code/quote، قوائم مرقمة/نقطية | موجود | قائمة Text style بسبعة أنماط وألوان؛ قيس H1=16/24 وH2=12.8/20 والصغير9.6 في المرجع والمحاكي. تبقى اختصارات وحالات لصق غير معتمدة. |
| Callout | موجود | عنصر `aside[data-note-callout=true]` مستقل عن Quote؛ التفصيل البصري لكل حالة يحتاج مقارنة |
| لون النص وHighlight وإزالة التنسيق | موجود | قائمة Color/Highlight بستة خيارات لكل منهما وألوان مقاسة، مع فحص نطاق النص والحفظ. مسح اللون متاح؛ كل اختصارات الأصل غير معتمدة. |
| Tab/Shift-Tab لإزاحة عناصر القائمة | غير متحقق | TipTap StarterKit يوفر سلوك قوائم؛ يحتاج فحصًا أصليًا ومتصفحًا صريحًا |
| Hyperlink للجزء المحدد وتغييره/إزالته | موجود | URL modal مستقل يختلف بصريًا؛ إدخال Enter والاختصارات تحتاج مقارنة |
| خلفية ملونة أو شفافة وشريط علوي | موجود محليًا للملاحظات | قائمة Background/Top strip بألوان12 وشفافية ومخصص؛ الشريط4px مستقل عن الخلفية. فُحصت الملاحظات فعليًا في المرجع ومحليًا. كل أصناف البطاقات/تاريخ الألوان ليست معتمدة. |
| إنشاء Document وتسميته وفتحه في محرر واسع | موجود محليًا | note يحمل `isDocument/title` ويفتح محررًا واسعًا؛ لا يلزم نوع منفصل لتشغيله |
| Convert Note to Document؛ Card View/عرض أيقونة | جزئي | التحويل/العكس موجودان؛ Card View/icon toggle ليس مكتملًا مثل الأصل |
| تصدير مستند بمفرده PDF/Word/MD/TXT | موجود محليًا | PDF متعدد الصفحات وWord قابل للتحرير وMarkdown/Text، واختبار متابعة التحرير بعد التنزيل؛ التخطيط المرجعي الكامل غير معتمد. |
| Create synced copy ومؤشر النسخ وتحديث النص عبر لوحات | موجود محليًا | أضيف فهرس اللوحات ومؤشر17.6px وقائمة160px، مع +16/+16 للنسخة وأمر السياق؛ عدّ النسخ الحية يشملUnsorted ويستبعدTrash. استعادة محتوى المجموعة من النسخة الحية سياسة محلية غير معتمدة في المرجع؛ [التفاصيل](SYNCED-NOTES-VALIDATION.md). |

### الصور والرسم

المراجع: [Images](https://help.milanote.com/en/articles/359381-images)، [Drawing](https://help.milanote.com/en/articles/5537688-drawing)، [Remove backgrounds](https://help.milanote.com/en/articles/16591227-remove-backgrounds-from-images).

| الخاصية | الحالة في الكود | الفجوة الدقيقة |
|---|---|---|
| رفع عدة صور من Add Image إلى Unsorted ثم سحبها | موجود | مقارنة ترتيب الصور وحجمها واسم caption الافتراضي |
| إخفاء/إظهار caption، color strip، فتح في تبويب | جزئي | caption غني قابل للإظهار والتحرير؛ خلفية وشريط4px مستقلان أضيفا مع اختبار حفظ/تراجع. فتح الأصل وتجربة preview وكل أصناف الشريط تحتاج مقارنة. |
| Crop بثمانية مقابض وشبكة thirds وتدوير/Flip | موجود في `ImageEditor` | الأدوات منفذة؛ ليست كل خيارات الأصل قد جُرّبت فعليًا في المرجع |
| Save/Cancel/Reset/history للتحرير غير الهدام | موجود | الأصل محفوظ منفصلًا عن operations؛ يلزم قياس فائدة التصدير عند كل تحويل |
| قلم/ممحاة/لون/عرض stroke/Undo/Redo للرسم على صورة | موجود | تحديد stroke وتحريكه يختلف؛ Eraser محلي يحذف stroke ولا توجد مطابقة قاعدة تقاطع الأصل |
| Selection tool في محرر الرسم | موجود | تحديد ضربة أو عدة ضربات بـShift، وتحريكها وحذفها وUndo/Redo/Cancel؛ اختُبرت محليًا، وقواعد تقاطع المرجع غير مثبتة |
| إزالة خلفية تلقائية Cut out/Remove background مع استرجاع الأصل | جزئي | عزل محلي بنموذجU²Net مضاف، مع حفظ الأصل وتشغيل/إيقاف القناع؛ inference فعلي محلي ناجح، وتطابق القناع مع Milanote غير مثبت. |
| Sketch card بالنقر المزدوج يفتح وضع رسم مع أدوات أسفل | موجود محليًا | محرر Sketch بجلسة Save/Cancel/اختيار/ممحاة وتراجع؛ جرى فحص حفظ/إلغاء وتحرير ضربات محليًا. |
| رسم حر على اللوحة، حفظ، حذف/اختيار strokes | موجود محليًا | جلسة رسم مستقلة وأداة تحديد متعدد وسحب وممحاة، مع حفظ واحد للجلسة. تقاطع الممحاة والضغط لا يزالان بحاجة مقارنة. |
| ضغط/ميل القلم وApple Pencil | غير متحقق | Pointer events ليس إثبات دعم iPad/Pencil الفعلي |

### الروابط والوسائط والخرائط والملفات

المراجع: [Links](https://help.milanote.com/en/articles/1722065-links)، [Videos](https://help.milanote.com/en/articles/10478926-videos)، [Audio](https://help.milanote.com/en/articles/10684339-audio)، [Map Cards](https://help.milanote.com/en/articles/10684375-map-cards)، [Files](https://help.milanote.com/en/articles/1159010-what-kind-of-files-can-i-upload).

| الخاصية | الحالة في الكود | الفجوة الدقيقة |
|---|---|---|
| URL/title/description قابلة للتحرير | موجود محليًا | جلب metadata عامة فعلي عبر موصل محلي، مع تحرير يدوي وحماية المسودات وRefresh وحفظ provenance؛ صفحات JavaScript والحسابات ومطابقة كل مزود غير معتمدة. [التقرير](LINK-METADATA-VALIDATION.md). |
| أقسام مستقلة preview/URL/description مع إظهار/إخفاء | جزئي | preview/media وinfo وcaption قابلة للتبديل؛ URL والوصف ليسا بالضرورة تبديلين مستقلين كما في الأصل |
| إسقاط صورة فوق الرابط لمدة ثم استبدال thumbnail | موجود للحالة المقاسة | سحب بطاقة صورة واحدة فوق معاينة رابط موجودة والانتظار ثانية يفعّل الإطار الداكن وReplace image؛ الإفلات يستهلك المصدر ويستبدل الصورة معUndo. النسبة والأبعاد الدقيقة والفيديو الداخلي ما زالت غير معتمدة. [التقرير](THUMBNAIL-DROP-VALIDATION.md). |
| تحويل رابط YouTube/Vimeo/TED إلى فيديو | موجود محليًا | TED أضيف إلى قائمة مزوّدين مسموحين؛ زر Media/معاينة/حفظ اختُبر محليًا مع حظر اتصال المزود. HTTP العام لـTED نجح، ولا يثبت تشغيل الفيديو أو سلوك Milanote نفسه. |
| تحويل Spotify/SoundCloud وغيرها إلى audio embed | جزئي | أضيف YouTube Music وMixcloud وApple Music وDeezer مع تحسين المسارات الحالية، وفحوصIframe فعلية باتصالات مزودين محظورة. Amazon وBandcamp والروابط القصيرة ومزيد من المزودين ما زالت فجوات. [التقرير](MEDIA-PROVIDER-VALIDATION.md). |
| Google Maps تفاعلي pan/zoom مع سحب البطاقة من الهامش | جزئي | Google Maps iframe لصيغ معروفة موجود؛ روابط مختصرة وإيماءات الخريطة/حواف البطاقة لم تثبت |
| رفع audio/video وتشغيل/إيقاف/seek | موجود عبر file | دعم codec يتبع المتصفح؛ لا معالجة خادم للتحويل |
| Loop/Autoplay للملفات المرفوعة | موجود | خيارات محفوظة وتشغيل عبر عناصر المتصفح؛ التشغيل التلقائي وcodec يخضعان لدعم المتصفح |
| تغيير thumbnail لفيديو بإسقاط صورة | موجود | إسقاط صورة على فيديو يضبط poster؛ إسقاطها على رابط يستبدل previewSrc |
| تنزيل المرفق الأصلي | موجود | source data URL محلي؛ الحجم الأقصى واستهلاك التخزين مختلفان |
| معاينات PDF/Office/RAW/PSD/AI | جزئي | معاينة PDF محلية متاحة بحسب المتصفح؛ لا تحويل أو معاينة Office/RAW/PSD/AI |

### To-do والأعمدة واللوحات

المراجع: [To-do](https://help.milanote.com/en/articles/10486983-to-do-lists)، [Columns](https://help.milanote.com/en/articles/10478526-columns)، [Nesting](https://help.milanote.com/en/articles/9860073-nesting-boards)، [Moving content](https://help.milanote.com/en/articles/491831-moving-content-between-boards)، [Board shortcut](https://help.milanote.com/en/articles/2110465-create-a-shortcut-to-a-board).

| الخاصية | الحالة في الكود | الفجوة الدقيقة |
|---|---|---|
| مهام/إتمام/Enter/حذف مهمة | موجود | drag مهمة بعينها إلى Trash ليس موجودًا |
| عنوان القائمة قابل للإضافة/الإخفاء من Title | موجود | `TodoEditor.toggleTitle` وشريط App متصلان |
| Tab/Shift-Tab لإزاحة مهمة | موجود | `indent` وحفظه وإزاحة المهام الفرعية متاحان |
| Due date، وقت محدد، إزالة الموعد | موجود محليًا | حقول dueDate/dueTime وواجهة اختيار/حذف موعد؛ لا إشعارات خارجية |
| Reminder/assignment/email/push | خارج النطاق | تكاملات حساب وإشعارات؛ لا ترسل شيئًا من المحاكي |
| ترتيب عناصر العمود/المؤشر/نقل المجموعة/طي/تحجيم/عداد | موجود | القياسات الخاصة بكل نوع/ارتفاع تلقائي تحتاج مقارنة مستمرة |
| Group selected into Column | موجود من toolbar | موضع قائمة السياق الأصلي مختلف؛ لا أعمدة متداخلة كما في الأصل |
| لوحات فرعية وتسمية متزامنة مع tile وBreadcrumb | موجود | شكل tile وعدد العناصر ومقاسات الحالة تحتاج فحصًا |
| سحب بطاقة/لوحة فوق board tile لنقلها | موجود | نقل ذري للمجموعة/الأعمدة ومحتوياتها وتحديث ملكية اللوحات الداخلية، مع رفض الدورات وUndo؛ الروابط العابرة بين المجموعة والباقي تُزال |
| hover فوق board/breadcrumb لفتحه ثم الإفلات | موجود محليًا ومشاهد في المرجع | فتح بعد الاحتفاظ نحو ثانية، وpreview مستقل ثم نقل ذري عند الإفلات؛ 13 سير عمل وفحص الأخطاء في كل من Chromium وWebKit. الإلغاء وBack وسجل المشاهدة سياسات محلية مختبرة؛ تفاصيلها المرجعية ونسخ حالة الوسائط الحية غير معتمدة. [تقرير hover](BOARD-HOVER-VALIDATION.md). |
| Shortcut يشير إلى لوحة أصلية، منفصل عن Duplicate | موجود محليًا | isShortcut مرجع غير مالك، وإنشاء/لصق رابط محلي ومرجع مفقود بعد حذف الأصل واستعادة؛ اختبارات مستقلة، واعتماد المرجع الشامل مطلوب. |
| Ctrl/Cmd+Enter لإضافة نفس نوع Note/Column/Board | موجود | إضافة النوع المحدد أسفل البطاقة؛ تفاصيل موضع الأصل غير مثبتة |

### الجداول والصيغ

المراجع: [Tables](https://help.milanote.com/en/articles/8584584-tables)، [Formula catalog](https://help.milanote.com/en/articles/8584809-formulas-functions-for-tables).

| الخاصية | الحالة في الكود | الفجوة الدقيقة |
|---|---|---|
| grid، تحرير خلية/Tab/Enter/تحديد نطاق | موجود في `TableEditor` وApp | الاختبارات المتكاملة في تقاريرها؛ المحاذاة الرأسية والعمودية محفوظة |
| أنواع Auto/Number/Currency/Percentage/Text/Date/Checkbox | موجود محليًا | خيارات رقم/عملة/تاريخ ووقت وتقويم مقاسة ومضافة؛ تختبر محليًا مع الحفظ والتراجع، ولا يعني ذلك تطابق التحويل التلقائي لكل قيمة. |
| Cell color/Bold/Italic ومحاذاة أفقية | موجود | toolbar App متصل بالمكون، وتُحفظ metadata في الوثيقة |
| محاذاة رأسية top/middle/bottom | موجود | `verticalAlign` في النموذج والتحقق والتصيير وشريط الخيارات |
| إضافة/حذف صفوف وأعمدة حول الخلية | موجود | إعادة كتابة المراجع وتغيير metadata موجودان في core |
| Clipboard TSV؛ Paste Values؛ Clear cell | موجود | اختُبرت الحافظة واللصق كقيم؛ النسخ الداخلي يعيد ضبط المراجع النسبية ويحفظ $ والمراجع أثناء Cut. حافظة خارجية لا تحمل موضع المصدر، والتوافق مع كل برامج الجداول غير مثبت |
| عناوين A/B/C و1/2/3 وتحديد صف/عمود | موجود | headers خارج الخلايا، وتحديد صف/عمود كامل؛ اختُبرت محليًا |
| تحريك صف/عمود بالسحب | موجود محليًا | سحب الرأس المحدد إلى حد الإدراج مع الصيغ والعروض وmetadata؛ نُفّذ مثال نقل صف في المرجع وقورنت نتيجة انكماش النطاق المحددة. |
| سحب فاصل header لتغيير عرض عمود واحد | موجود | columnWidths محفوظة، مع معاينة وUndo/Redo/Escape، وإدراج/حذف يحفظ عرض بقية الأعمدة |
| سحب الركن لإضافة صف/عمود | موجود محليًا | مقبض يضيف/يحذف الصفوف والأعمدة الأخيرة بدل تكبير الخلايا؛ اختُبرت المعاينة/التراجع/الإلغاء/الحفظ. |
| Formula picker مع البحث في الصيغ | موجود | زر Formula يبدأ `=`، وBrowse formulas يعرض فهرس الدوال المحلي ويُدرج الدالة المختارة |
| arithmetic، مراجع A1/ranges، SUM/AVERAGE/MIN/MAX/COUNT | موجود | parser إلى AST مع أخطاء ودورات وحدود حجم؛ الصيغ لا تمر إلى eval/Function |
| صيغ موسعة: IF/IFERROR/منطق/نص/تاريخ/إحصاء/تمويل/Lookup | جزئي واسع | FormulaJS4.5.6 يوفّر registry متعدد العائلات خلف parser مقيد؛ اختُبرت عينات ذات معنى. الكتالوج الرسمي **365 ID** لم يُثبت متوافقًا كله. Array spills/cross-sheet refs/array constants غير مدعومة |

### الخطوط والألوان وLabels

المراجع: [Lines](https://help.milanote.com/en/articles/111391-lines)، [Swatches](https://help.milanote.com/en/articles/2497222-color-swatches)، [Labels](https://help.milanote.com/en/articles/15442078-labels).

| الخاصية | الحالة في الكود | الفجوة الدقيقة |
|---|---|---|
| خطوط بين بطاقات، لون/وزن/dashed/label | موجود | الوزن/defaults وdash pattern ليست مطابقة لكل حالات الأصل |
| Start/End سهمان مستقلان | موجود | startArrow/endArrow محفوظان ويُرسمان ويُصدّران؛ default مطابق للمشاهدة من حيث التفعيل |
| خط حر له نهايات على نقاط محددة | موجود | start/end نقطتان مستقلتان مع مقبضين وتحريك الخط الحر |
| سحب مقبض card لبدء خط، وسحب نهاياته لإعادة الربط | موجود محليًا | سحب جديد/ربط/فك وربط جديد، مع تراجع واحد وإلغاء؛ التثبيت داخل البطاقة إحداثيات نسبية. التوقيت وبعض الحواف بحاجة مقارنة. |
| سحب مركز الخط لتقويسه ونقر مزدوج لتسويته | موجود محليًا | المقبض يعدل المنحنى والنقر المزدوج يسويه، مع حفظ/تراجع؛ جرى اختبار محلي. |
| Shift لتقييد الخط أفقيًا/رأسيًا | موجود محليًا | تقييد سحب النهايات إلى محور، مع اختبار متصفح وهندسة. |
| Swatch: picker/HEX/اسم/تحجيم | موجود محليًا | المنتقي الأصلي هو المسار الأساسي؛ حقول HEX/RGB/HSL والأداة المستقلة ضمن Color settings. الاسم التلقائي يتغير مع اللون، والتعليق المخصص الغني محفوظ. الأبعاد الجديدة مقاسة؛ أبعاد المستورد تبقى محفوظة. |
| Swatch: RGB/HSL/إخفاء قيمة اللون/caption toggle | موجود محليًا | colorSpace/showValue/showCaption محفوظة؛ التعليق الغني يتمدد إلى64px لسطرين ويحافظ إخفاؤه/إظهاره على مساحة اللون94px. فُحص Undo وإعادة التحميل وHTML/JSON/Word. |
| Eyedropper واستخراج ألوان الصور وتسمية تلقائية | موجود محليًا مع فجوة مقارنة | native EyeDropper إن توفر، واستخراج palette من الصور بعد تحريرها وأخذ لون بالبكسل دون الاعتماد عليه، وأسماء Name That Color العامة. خوارزمية التقليل وترتيب الألوان مستقلان، والتطابق الكامل مع الأصل غير معتمد. [تفاصيل الاختبار](IMAGE-COLORS-VALIDATION.md). |
| Labels كوسوم تُطبّق على عنصر/عدة عناصر | موجود محليًا | registry عالمي ملون وlabelIds، وتعيين ثلاثي الحالة لمجموعة؛ استُبدل حقل tags القديم مع ترحيل بياناته. |
| إنشاء/تطبيق/حذف/تغيير اسم ولون Label عالميًا | موجود محليًا | تحديث عالمي للمواضع ونسخ بين اللوحات وتراجع؛ popup240px وألوان12 مقاسة. كل الحالات المرجعية ليست معتمدة بعد. |
| البحث باسم Label/عدد الاستعمالات/Undo | موجود محليًا | فهرس البحث وعدّاد الاستخدام عبر اللوحات، مع حذف/تراجع وحفظ وفحوص متصفح. |

### التنظيم والتنقل والتخصيص

المراجع: [Unsorted](https://help.milanote.com/en/articles/111399-unsorted-notes)، [Duplicate](https://help.milanote.com/en/articles/111397-duplicating-content)، [Trash](https://help.milanote.com/en/articles/10583739-the-trash)، [Search](https://help.milanote.com/en/articles/1116205-search)، [Custom templates](https://help.milanote.com/en/articles/1945249-custom-templates)، [Shortcuts](https://help.milanote.com/en/articles/111393-keyboard-shortcuts).

| الخاصية | الحالة في الكود | الفجوة الدقيقة |
|---|---|---|
| Unsorted لكل لوحة، إدخال/إخراج بالسحب، quick note | موجود | إنشاء ملاحظات متتالية بـCtrl/Cmd+Enter مع source غير موجود |
| Duplicate ونسخ/لصق بين اللوحات/Undo/Redo | موجود | Alt-drag وCut العام وcontext paste مضافة؛ اختبار عدم النسخ عند النقر بلا حركة والإلغاء/تراجع واحد. |
| Lock يمنع النقل/الحذف | موجود | زر موجود؛ ينبغي مقارنة قائمة السياق وامتداد الحماية داخل groups |
| Trash قابل للاستعراض والاسترجاع بعد reload | موجود محليًا | سجل محفوظ يشمل اللوحات الداخلية والخطوط، واستعادة بالسحب ونسخ احتياطي مع مرفقات المحذوف؛ retention ثلاثة أشهر تقويمية. |
| Empty trash؛ فرز Deleted by me/others | جزئي/خارج النطاق | دوال إفراغ/حذف دائم موجودة؛ واجهة الإدارة مخفية افتراضيًا لعدم ثبوت ظهورها في الحالة المرصودة. تقسيم الآخرين خدمة تعاونية. |
| بحث عبر اللوحات والمحتوى | موجود محليًا ومشاهد في المرجع | popup بعرض 320px بنتائج مجمعة وRecently viewed وفرز Last viewed/Last modified/Relevance وتواريخ محلية مستقلة للمشاهدة والتعديل. اختُبرت النصوص المنسقة والتسميات والمرجع المفقود والحفظ؛ ترتيب المرجع الكامل وتجميع التواريخ وfilter URL واستخراج نص كل الملفات غير معتمدة. [تقرير البحث](SEARCH-VALIDATION.md). |
| Z fit، Ctrl/Cmd +/- و0، Ctrl/Cmd+F، / help | موجود محليًا | Z/0 للملاءمة وCtrl/Cmd +/- للتكبير وCtrl/Cmd0 للنسبة100% وبحثF/K ومساعدة/. أضيف back/forward/parent؛ أسماء الاختصارات موثقة ومشاهدة في مساعدة المرجع، وخطوة التكبير ومظهر المساعدة ليسا معتمدين. |
| Alt/Option-drag duplicate، layer shortcuts | موجود محليًا | Alt-drag باشتراط الحركة وتراجع واحد وإلغاء؛ Ctrl/Cmd Shift↑/↓ لطبقات المجموعة. لا يثبت ذلك كل حالات الترتيب المرجعية. |
| Pan/zoom/pinch | موجود | الاختبار على Chromium والمحاكاة لا يثبت المطابقة على iPad/Safari |
| إنشاء Custom template/Revert template/فهرس خاص | موجود محليًا | Convert/Revert/Rename/Delete واستعادة كاملة من Trash ونسخ مستقل متاحة باختبارات. فهرس القوالب وتجربة كل حالة في الأصل غير معتمدين. |
| Presentation fullscreen/focus/prevent edit/preferences | موجود جزئيًا | شريط مقاس، عرض محفوظ، تركيز وتفضيلات؛ تحرير ملاحظات ووصف صورة/رابط وإكمال مهمة وفق المشاهدة. تفاصيل كل نوع ومركز التركيز/iPad الفعلي غير معتمدة. |
| board background/grid controls | موجود محليًا | تخصيص مستقل؛ لا يكفي وجوده لإثبات خيارات الأصل ومظهرها |

## الويب والآيباد والتصدير

[دليل iPad](https://help.milanote.com/en/articles/6280198-milanote-ipad-app) يصف: نقرًا مزدوجًا لإنشاء note؛ ضغطًا مطوّلًا ثم سحب العنصر؛ ضغطًا مطوّلًا على الفراغ للتحديد؛ pinch للـzoom؛ إيماءات ثلاث أصابع للنسخ/القص/اللصق/Undo/Redo؛ نقر الصورة مرتين ثم Draw. المصدر يستخدم Pointer Events وpinch، وأضيف مسار نقر مزدوج باللمس لفتح البطاقة مع فصل الحركة والإلغاء. لا يطبّق كامل منطق الضغط المطوّل/التحديد متعدد اللمس/الإيماءات الثلاث. اختبار viewport iPad وحده لا يثبت أداء iPadOS أو Safari أو Apple Pencil.

[Export](https://help.milanote.com/en/articles/111395-exporting-your-work): أضيفت PDF Standard/High quality وPNG وWord وMarkdown وPlain text وZIP مرفقات كتنزيلات فعلية، مع قائمة مقاسة. High quality تخص جودة التصيير ولا تغير ورق PDF. صار PDF الافتراضي بحجم اللوحة وخلفية بيضاء ودون عنوانها وفق الملف المرجعي؛ أضيف نص متجهي حقيقي للحالات المدعومة غير المتداخلة، مع إبقاء العربية المختلطة والخطوط غير المدعومة والتداخل كتصيير نقطي محافظ؛ لا تزال المطابقة المتجهية الكاملة والخطوط والظلال فجوات مقارنة. [تقرير النص المتجهي](VECTOR-PDF-VALIDATION.md). اختبارات الحاويات والتخطيط والمستند الطويل والموارد منفصلة في [EXPORT-VALIDATION-WORKING.md](EXPORT-VALIDATION-WORKING.md). HTML/SVG/JSON إضافات محلية. إرسال ZIP بالبريد خارج النطاق؛ توليد الملف محليًا موجود. لا تثبت هذه الاختبارات مطابقة جميع تفاصيل التصدير الأصلية.

## خطة تحقق لكل عنصر بعد إضافته

لكل نوع من الأنواع السابقة، يجب الاحتفاظ بسجل حالة يتضمن: الإنشاء من rail ومن drag، الحالة الفارغة، التحديد، تحرير المحتوى، فتح كل menu/submenu، تطبيق كل خيار وإزالته، النقل والتحجيم، الإدخال/الإخراج من column وUnsorted، النسخ/التكرار/الحذف، Undo/Redo، إعادة التحميل، ثم JSON وexport. تقارن صورة المرجع وصورة المحاكي عند viewport/zoom متساويين؛ تسجّل الأدلة وما لم يُفحص.

لا تُغلق خانة بمجرد وجود اسم أداة أو زر. أمثلة معايير القبول: bold على كلمة واحدة لا بقية الفقرة؛ crop+rotation يحتفظ بالأصل في JSON ويظهر في HTML؛ حذف صف يضبط references؛ renamed label يتغير في جميع مواضعه؛ إزالة due date لا تحذف المهمة. هذه فروق خصائص قابلة للملاحظة، لا تفاصيل أساسية يمكن تجاهلها.

القائمة التالية سجل أولوية تاريخي قبل تغييرات26أكتوبر؛ تُراجع الحالات المحدثة أعلاه وتقارير الاختبار قبل اعتبار بند غائبًا. أولويات المقارنة المتبقية: إدارة Labels العالمية الملونة/متعددة العناصر؛ row/column headers والتحريك والتحجيم الفردي؛ picker الصيغ والتحقق من توافق عينات الكتالوج؛ drag/snapping للخطوط والنقل بين اللوحات؛ auto-grid للصور ومكتبة البحث؛ metadata/thumbnail/drop للروابط ومزيد من المزوّدين؛ trash وpresentation؛ إكمال تصدير المستندات والقوالب وإدارة synced copies؛ ثم اختبارات iPad الفعلية. خصائص title/indent/due-date والقص/الرسم ومقابض الخطوط أصبحت موجودة؛ لا تُعامل كفجوات غائبة.

## فهرس الصفحات الـ67 التي شملها التدقيق

كل رابط أدناه جُلب بنجاح في هذه المراجعة. لا تعني عبارة «شمله التدقيق» أن كل إجراء فيه نُفّذ على حساب المرجع أو اجتاز المحاكي.

- [How To Conduct a Brand Audit: Step-By-Step Guide & Free Template](https://milanote.com/guide/brand-audit)
- [How to Create a Memorable Brand Name: Step-By-Step Guide](https://milanote.com/guide/brand-naming)
- [How to Develop a Brand Strategy: Step-By-Step Guide](https://milanote.com/guide/brand-strategy)
- [How To Write an Inspiring Campaign Plan: Step-By-Step Guide](https://milanote.com/guide/campaign-plan)
- [How to Create a Character: Step-By-Step Guide](https://milanote.com/guide/characters)
- [How to do a Competitive Landscape Analysis: Step-By-Step Guide](https://milanote.com/guide/competitive-landscape)
- [How to Make a Contact Sheet: Step-By-Step Guide](https://milanote.com/guide/contact-sheet)
- [How to Make a Moodboard: Step-By-Step Guide](https://milanote.com/guide/create-better-moodboards)
- [How To Write an Inspiring Creative Brief: Step-By-Step Guide](https://milanote.com/guide/creative-brief)
- [How To Make a Film Call Sheet: Step-By-Step Guide](https://milanote.com/guide/film-call-sheet)
- [How To Brainstorm Film Ideas: Step-By-Step Guide](https://milanote.com/guide/film-ideas)
- [How to Create a Film Marketing Plan: Step-By-Step Guide](https://milanote.com/guide/film-marketing-plan)
- [How to Make a Film Moodboard: Step-By-Step Guide](https://milanote.com/guide/film-moodboard)
- [How to Plan a Film: Step-By-Step Guide](https://milanote.com/guide/film-preproduction)
- [How To Create a Film Shotlist: Step-By-Step Guide](https://milanote.com/guide/film-shot-list)
- [How To Make a Film Storyboard: Step-By-Step Guide](https://milanote.com/guide/film-storyboards)
- [How to Create Video Game Characters: Step-By-Step Guide](https://milanote.com/guide/game-design-character-profile)
- [How to Create a Game Design Document: Step-by-Step Guide](https://milanote.com/guide/game-design-document)
- [How To Brainstorm Video Game Ideas: Step-By-Step Guide](https://milanote.com/guide/game-design-ideas)
- [How To Design a Game Level: Step-By-Step Guide](https://milanote.com/guide/game-design-level-design)
- [How to Make a Game Design Moodboard: Step-By-Step Guide](https://milanote.com/guide/game-design-moodboard)
- [How To Design a Game World: Step-By-Step Guide](https://milanote.com/guide/game-design-worldbuilding)
- [How To Create a Game Marketing Plan: Step-By-Step Guide](https://milanote.com/guide/game-marketing-plan)
- [How To Start Writing a Book: Step-By-Step Guide](https://milanote.com/guide/how-to-start-a-novel)
- [How To Start a Podcast: Step-By-Step Guide](https://milanote.com/guide/how-to-start-a-podcast)
- [How To Write an Interior Design Brief: Step-By-Step Guide](https://milanote.com/guide/interior-design-brief)
- [How to Plan an Interior Design Project: Step-By-Step Guide](https://milanote.com/guide/interior-design-project-plan)
- [How To Write a Logo Design Brief: Step-By-Step Guide](https://milanote.com/guide/logo-design-brief)
- [How To Brainstorm Logo Ideas: Step-By-Step Guide](https://milanote.com/guide/logo-design-ideas)
- [How To Make A Logo Moodboard: Step-By-Step Guide](https://milanote.com/guide/logo-design-moodboard)
- [How To Present Logo Concepts: Step-By-Step Guide](https://milanote.com/guide/logo-design-presentation)
- [How to Plan a Logo Design Project: Step-By-Step Guide](https://milanote.com/guide/logo-design-project-plan)
- [How To Write an Inspiring Marketing Brief: Step-By-Step Guide](https://milanote.com/guide/marketing-brief)
- [How To Write an Inspiring Marketing Plan: Step-By-Step Guide](https://milanote.com/guide/marketing-plan)
- [How To Brainstorm Motion Design Ideas: Step-By-Step Guide](https://milanote.com/guide/motion-design-ideas)
- [How To Make A Motion Design Moodboard: Step-By-Step Guide](https://milanote.com/guide/motion-design-moodboard)
- [How To Create a Motion Design Storyboard: Step-By-Step Guide](https://milanote.com/guide/motion-design-storyboard)
- [How To Present Motion Design Style Frames: Step-By-Step Guide](https://milanote.com/guide/motion-design-style-frames)
- [How to Write A Motion Graphics Brief: Step-By-Sep Guide](https://milanote.com/guide/motion-graphics-brief)
- [How to Plan a Motion Graphics Project: Step-By-Step Guide](https://milanote.com/guide/motion-graphics-pre-production)
- [How to Create a Novel Marketing Plan: Step-By-Step Guide](https://milanote.com/guide/novel-marketing-plan)
- [How To Make A Novel Moodboard: Step-By-Step Guide](https://milanote.com/guide/novel-moodboard)
- [How to Write a Novel: Step-by-Step Guide](https://milanote.com/guide/novel-plan)
- [How to Organize Novel Research: Step-By-Step Guide](https://milanote.com/guide/novel-research)
- [How To Create a Customer Persona: Step-By-Step Guide](https://milanote.com/guide/persona)
- [How To Make A Photography Moodboard: Step-By-Step Guide](https://milanote.com/guide/photography-moodboard)
- [How to Plan a Photoshoot: Step-By-Step Guide](https://milanote.com/guide/photoshoot)
- [How to Write an Inspiring Photoshoot Brief: Step-By-Step Guide](https://milanote.com/guide/photoshoot-brief)
- [How To Create a Photoshoot Call Sheet: Step-By-Step Guide](https://milanote.com/guide/photoshoot-call-sheet)
- [How To Brainstorm Photoshoot Ideas: Step-By-Step Guide](https://milanote.com/guide/photoshoot-ideas)
- [How To Create a Photography Shot List: Step-By-Step Guide](https://milanote.com/guide/photoshoot-shot-list)
- [How To Make a Podcast Outline: Step-By-Step Guide](https://milanote.com/guide/podcast-outline)
- [How to Plan a Podcast Episode: Step-by-Step Guide](https://milanote.com/guide/podcast-plan)
- [How to Organize Podcast Research: Step-By-Step Guide](https://milanote.com/guide/podcast-research)
- [How to Create a Site Map: Step-By-Step Guide](https://milanote.com/guide/site-map)
- [How To Start a YouTube Channel Step-By-Step Guide](https://milanote.com/guide/start-a-youtube-channel)
- [How To Brainstorm Story Ideas: Step-By-Step Guide](https://milanote.com/guide/story-ideas)
- [How to Outline a Book: Step-By-Step Guide](https://milanote.com/guide/story-outline)
- [How To Plan a YouTube Video: Step-By-Step Guide](https://milanote.com/guide/video-plan-youtube)
- [How To Create a YouTube Script: Step-By-Step Guide](https://milanote.com/guide/video-script-youtube)
- [How to Make a Vision Board: Step-By-Step Guide](https://milanote.com/guide/vision-board)
- [How To Plan Your Website Content: Step-By-Step Guide](https://milanote.com/guide/website-content-plan)
- [How To Write a Website Design Brief: Step-By-Step Guide](https://milanote.com/guide/website-design-brief)
- [How To Make A Website Design Moodboard: Step-By-Step Guide](https://milanote.com/guide/website-design-moodboard)
- [How to Plan a Website: Step-By-Step Guide](https://milanote.com/guide/website-design-project-plan)
- [How to Master Worldbuilding: Step-By-Step Guide](https://milanote.com/guide/worldbuilding)
- [How To Brainstorm YouTube Video Ideas: Step-By-Step Guide](https://milanote.com/guide/youtube-video-brainstorm)

## تحديث الدمج النهائي 1.3

أضيف `CaptionEditor` للتعليقات الغنية على الصور والروابط (تحديد نص، bold/italic/underline/strike/link، HTML آمن، وحفظ/تصدير)، وعناوين الجداول وتحجيم الأعمدة والنسخ النسبي للصيغ. اختبارات الإنتاج المحلية ونتائجها النهائية في `VALIDATION-V13.md`. هذه الإضافات لا تلغي الفروق المسماة في الجداول أو تثبت تنفيذ كل تعليمات الدليل داخل حساب المرجع.

## تحديث معاينات الروابط — 27أكتوبر

أضيف موصل محلي فعلي لعنوان الصفحة ووصفها وصورتها، مع حماية التعديلات اليدوية وإلغاء الاستجابات عند الاستيراد وتغيير الرابط أو قفل البطاقة وحذفها. ارتفاع البطاقة الجديدة يتبع المحتوى حتى تحجيمها يدويًا. نجح طلب عام حقيقي عبر middleware بناء الإنتاج، وتفصل اختبارات الواجهة بياناتها المصطنعة عن الاتصال العام. لا يشمل ذلك كل مزودي المعاينة أو صفحات تسجيل الدخول أو التحويلات المعتمدة علىJavaScript. [الواجهة](LINK-METADATA-VALIDATION.md)، [الموصل](LINK-METADATA-ADAPTER-VALIDATION.md).

## تحديث ما بعد الإضافة — 28أكتوبر

سُجلت تجربة مرجعية محددة لاستبدال معاينة رابط بواسطة بطاقة صورة مع الانتظار، ثم طُبقت مع حفظ التراجع وإلغاء السحب وحماية القراءات المتأخرة. التحويلات الجديدة لمزوّدي الوسائط موثقة ومختبرة محليًا، ولا تثبت تشغيل كل لاعب حيًا. أُصلحPDF لحفظ تعبئة النص الخاصة وحدوده عبر الرجوع الآمن إلى التصيير النقطي حين لا يمكن إنتاج متجه مطابق. هذه تحديثات جزئية لحالات مسماة، وليست اعتماد تطابق شامل.
