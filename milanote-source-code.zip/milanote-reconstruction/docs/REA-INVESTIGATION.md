# Initial public-only investigation (historical)

The access limitations in this initial report were superseded by a successful authenticated investigation. Read [AUTHENTICATED-INVESTIGATION.md](AUTHENTICATED-INVESTIGATION.md) for the current reference findings.

# Milanote reconstruction: REA investigation

Date: 2026-10-24. Tool: official `rea-agents@6.7.0` CLI. Target: `https://milanote.com/` and its web client at `https://app.milanote.com/`.

## Status and access

The browser connection problem was repaired without disabling TLS verification. The inherited NSS certificate database already contained the environment proxy CA. Chromium needed permission to open `/home/agent/.pki/nssdb` for writing during launch; launching it with a read-only home prevented NSS from using the database. A runaway `certutil -N` from the previous attempt was stopped. No account was created and no credentials were entered.

The public web client redirects to `/login`. Its rendered login screen and the redirect are observed. Consequently, editing tools have **not** been exercised inside a signed-in workspace. Publicly delivered JavaScript includes workspace modules; these were passively captured and selected modules analyzed statically.

## Evidence ledger

Raw paths below refer to the separate research workspace `/workspace/milanote-analysis`, not to this source distribution. JSON records and vendor scripts are deliberately excluded from the source archive. Evidence identifiers, hashes, and analysis statistics are retained here; a portable summary is in `docs/rea-evidence-summary.json`.

| Evidence | File | What it establishes |
|---|---|---|
| `ev_d55f15c3c09a1e87c1982ad5917f424157c3ee465557c369310feac5b313923b` | `evidence/app-login-inspection.json` | Rendered public login DOM/accessibility and same-origin scripts |
| `ev_7905a6ace2656e9b77899a5861cb91c3cf2bfc3f67266dff89636163287c50da` | `evidence/app-login-screenshot.json`, decoded `evidence/app-login.png` | Login viewport screenshot |
| `ev_35c1be7be2357d948bce67be8d32dfd9be02bf9ed8885c2cb65292709b49ffff` | `evidence/app-public-scripts.json` | 26 captured scripts from explicitly selected app/static Milanote origins; source hashes retained |
| `ev_2905e99f4637f477b9f455a5eecdefe8408e86b8d04250ad77e01a4e58b36cd5` | `evidence/app-bundle.json` | Static web-bundle examination of six app-origin inline scripts, **not** complete client coverage |
| `ev_309e52180721a15790e5a37b594f1c82b1768bfc365e9f1445a66f11fc9b2688` | `evidence/selected-scripts-analysis.json` | REA static JavaScript application analysis of captured locale/workspace modules: 2 parsed sources, 190481 visited AST nodes, 68 modules, 1155 findings, zero parse failures |
| `ev_971b043e42625b4e2fa4edeaf920b26030a18544728c50e833908b9d80d4ebaf` | `evidence/main-page-inspection.json` | Public marketing page DOM and accessibility |
| `ev_eb85c2d419c67f6f7d8c2e512aaea27be1606b85e2c645ad4e863ea1b9deb804` | `evidence/main-page-screenshot.json`, decoded `evidence/main-page.png` | Public marketing page viewport screenshot |

`evidence/script-index.json` maps captured URLs to source hashes. `captured-scripts/` contains exact retained script text. `locale.js` and `workspace.js` are copies of two selected scripts; hashes are respectively `7be27620b6d19f72456e758b98eb5d04a087a2e793e23b9a57eee9675473abbc` and `2798d606d9706ccc022b2b82631b8f8562f7f51f426fc01aa63f1dd559c5ef30`. `evidence/locale-strings.json` is a supplementary extraction of literal JSON localization data using inert AST parsing; the script was not executed. It is derived from the captured source Evidence, not a new REA Evidence record.

## Confirmed shipped UI vocabulary (static evidence)

The captured English locale defines the following tools. This establishes that their labels ship with this web client; it does not establish feature availability for every account or the precise runtime algorithm.

- Content: note, heading, image, link, to-do, board, folder, column, line, sketch, color swatch, document, file, audio, video, map, table and spreadsheet.
- Rich text: bold, italic, underline, strikethrough, bullet/numbered lists, headings, size, alignment, indentation, inline code, code block, quote block, callout, hyperlink and divider.
- Selected items: connect, align, distribute, color, labels, captions, collapse, rename, position lock, bring to front, send to back, duplicate, copy, cut, paste, remove and grouping into a column.
- Lines: start/end controls, dashed style, label and weight.
- Drawing: pen, eraser, line weight, color, selection, undo and redo; save/cancel/discard.
- Canvas: custom background color, dot grid, paste, select all, undo/redo; unsorted/inbox area.
- Image editing vocabulary: crop/rotate, draw on top, captions and original download; exact transformations were not exercised.
- Tables: add/remove/move rows and columns, alignment, cell colors/types, formula and paste values. No formula semantics inferred.
- Preferences: double-click/tap to create notes, automatic movement of nearby cards during editing, drawing ink effects affected by speed/pressure, undo/redo controls.
- Mobile vocabulary: Add, Done, Back, quick notes, image from photo library/camera, boards, search, text styles and undo/redo.

## Engineering decisions for an independent implementation

Use a board-local coordinate space with an explicit viewport transform. Keep card geometry separate from content. Make columns owners of ordered child IDs; make boards links to separate documents; model edges with endpoint item IDs. Commit history at the end of gestures. Distinguish viewport history from document edit history. These are proposed implementation choices, **not recovered Milanote architecture**.

Capture pointer input separately for item dragging, background panning, resize, lasso and drawing. Handle two-pointer zoom around its midpoint. Use HTML for editable cards and SVG for lines/drawing overlays. Store assets in IndexedDB and use a portable JSON backup with embedded asset data. These are likewise independent engineering choices.

## Limits and recovered failure

An attempt to analyze all 26 scripts with `analyze-web-bundle` exceeded the CLI process's default ~2 GiB V8 heap and terminated. No complete Evidence was produced for that attempt; the empty `app-public-bundle.json` is **not** a successful result. The workaround was selected-source static analysis of locale and workspace modules, which completed successfully. Unselected dependencies and dynamic/server behavior remain unknown.

No signed-in editing behavior, Pencil pressure curve, native iPad bundle, collaboration/backend protocol, exact snapping constants, full gesture semantics or pixel-perfect editor styling has been verified. A reconstruction must identify those as approximations until compared with a live workspace. Do not describe this investigation as recovery of original source or complete Milanote internals. Captured vendor sources are research inputs and should not be incorporated into the independent implementation or its distributable archive.

## Follow-up access attempt

A later user-authorized email/password sign-in was attempted through the browser. Milanote remained on `/login` and displayed “Check your email/password and try again”. No verification-code prompt or authenticated workspace was observed. The input fields were cleared afterwards. This was a browser observation, not a new REA Evidence record. No credentials, session cookies, or account identifiers are included in the source archive. Signed-in reference validation is still pending corrected access.

Version 1.1 improves the independent implementation's columns, Unsorted area, board appearance, note exports, attachment exports, touch capture and double-click behavior. These changes are verified against the reconstruction's tests and documented reference requirements; they are not claims of newly observed authenticated Milanote behavior.
