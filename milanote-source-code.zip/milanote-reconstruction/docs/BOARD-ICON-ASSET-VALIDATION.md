# Board-icon visual assets — 29 October 2026

This is a bounded asset and behavior report, not complete Milanote parity or release acceptance. The known reference inventory contains410 IDs; the backend catalog total remains unproved.

## Sources and representation

The observed icon API returned both SVG visual assets and public48px PNG URLs. The410 SVGs were parsed with an SVG-aware HTML parser and reduced to numeric `viewBox` values, path data and explicit secondary opacity0.4. Captured CSS, HTML, scripts and URLs are never interpreted by the product renderer. The producing command is:

```sh
node scripts/prepare-board-icon-assets.mjs /workspace/milanote-analysis/icon-reference-svg /workspace/milanote-analysis/icon-reference-png
```

`src/data/boardIconReferenceProvenance.json` records each source API/PNG URL, original SVG and PNG SHA-256, byte counts, the canonical artifact digest and the absence of license text in the observed response. No Free license or relicensing is claimed for these reference assets. The separate Font Awesome Free collection has its own upstream license notice and provenance.

The410 public PNG files total267,337 bytes. They are retained as a separate fallback asset branch. Comparing a canonical duotone SVG rendering with these black PNG assets produced410 differences; that report remains in `artifacts/board-icon-catalog/chromium/reference-comparison.json`. It is not a successful comparison of the observed SVG UI.

## Measured SVG rendering

Actual reference DOM measurements found a48×48px picker button containing a21.9375×21.9375px SVG, with primary fill`#5f6672` and secondary opacity0.4. The selected board icon SVG measured28.796875×28.796875px with primary fill`#323b4a` and the same secondary opacity. Source evidence is outside the product at:

- `/workspace/milanote-analysis/icon-popup-geometry-oct29.json`
- `/workspace/milanote-analysis/icon-selected-geometry-oct29.json`

An independent browser comparison renders every captured source SVG and its normalized product SVG at those two measured sizes/palettes in the same58px canvas frame. It compares every RGBA channel, with no threshold or mask. Chromium passed820/820 comparisons, zero differing pixels. This establishes retention of captured asset geometry and the measured palettes; it does not establish complete popup or board-tile screenshot parity. The machine report is `artifacts/board-icon-catalog/chromium/reference-svg-comparison.json`.

```sh
TEST_URL=http://127.0.0.1:5306 ICON_REFERENCE_SVG_DIR=/workspace/milanote-analysis/icon-reference-svg node tests/board-icon-catalog-e2e.mjs
```

## Persistence and asynchronous ownership

Choosing an icon stores a160px PNG backup with a CRC-checked PNG text chunk carrying its catalog ID. The ID survives JSON, IndexedDB, Undo/Redo and reload. Known backups are displayed as normalized vectors through `boardIconDisplaySource` so scaling a raster does not alter the observed fractional-size antialiasing. Arbitrary uploaded images retain their original bytes and dimensions. Pending image/file completions are discarded after their picker lifetime ends.

The unit checks cover all410 asset IDs, canonical artifact integrity, public PNG byte hashes/dimensions/provenance, renderer markup restrictions, distinct popup/selected palettes and durable ID handling. The targeted report is `artifacts/board-icon-assets-unit.json` (11 cases).

## Remaining acceptance

The server's semantic index total, unobserved search rankings, alternate account picker branches, complete popup chrome and board-tile screenshot differences, all per-ID export/lifecycle states and visual behavior of the PNG fallback branch remain open. Neither the410 known IDs nor820 asset comparisons close those broader rows. A frozen combined unit/build/browser run is still required for integration acceptance.
