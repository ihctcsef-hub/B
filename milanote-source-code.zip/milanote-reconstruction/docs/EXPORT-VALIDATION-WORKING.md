# Export verification of the working source

This report describes tested behavior in the private working tree. It does not certify complete Milanote parity or authorize a release. No new distribution archive was created.

The implementation provides real PNG, PDF, DOCX and attachment ZIP downloads, in addition to editable workspace JSON, HTML, SVG, Markdown and text. These APIs are reexported from `src/export.ts` so the large binary libraries can load only when needed:

- `exportBoardPng(board, options?)`:2× content crop with32px margins, white background and no title by default; optional scale/background/title/bounds overrides and `.world` source DOM capture.
- `exportBoardPdf(board, options?)`: board-sized white pages without the board title by default, with a0.75pt/CSSpx drawing scale and observed paper rounding described below. Explicit A4/A3/Letter/Legal sizes retain fitted or tiled output, orientation and 24pt margins. `format: 'large'` increases rendering quality without changing page geometry, even for odd logical dimensions. The independently selected scales 1.5 and 3 have not been measured as Milanote's exact raster resolutions. Custom pages exceeding the PDF limit of 14,400pt are explicitly rejected before rendering; an explicit paper size remains available.
- `exportBoardWord(board, options?)`, `exportBoardMarkdown(board, options?)` and `exportBoardText(board, options?)`: optional `{includeSubBoards, workspace}`. Traversal follows visible board tiles in reading order, includes a target once, and avoids shortcut cycles. Deleted shortcut targets have no content to include.
- `exportBoardAttachmentsZip(board)`: visible images and files on the current board, retaining source bytes and safe, unique leaf filenames.
- `exportDocumentFile(note, 'pdf' | 'word' | 'markdown' | 'text')`: full document content, with PDF pagination and editable Word text.

Image cutouts and stored crop/rotation/annotation operations are flattened for rendered/document exports. JSON retains the original bytes and editable operations; attachment ZIP retains originals. Resource failures reject binary exports instead of silently omitting visible resources. Hidden canvas content is excluded from visual and linear exports.

## Measured reference PDF geometry

The downloaded reference standard and high-quality PDFs have the same custom page size, 1235.03992 × 587.03998pt, rather than A4. Their drawing transforms establish 0.75pt per CSS pixel; the background is white, and extracted text contains the board content without the board title. The current board PDF defaults now follow these observations. Reference files remain outside the source tree in `/workspace/milanote-analysis/acceptance-reference-standard.pdf` and `acceptance-reference-quality.pdf`.

This does **not** establish full PDF parity. The reference retains vector text and font subsets, while the independent implementation still embeds a rendered raster. Three further owned table fixtures established tight content bounds with32px padding, rather than the previous36px padding and origin/minimum-canvas bounds; binary captures now follow that measurement. Image downsampling, fonts, line wrapping, all connection/label extents, and complex shadow clipping are not fully established as reference rules. The reference image sample differs between quality modes (400 × 574 versus 502 × 720); that observation does not establish a general renderer scale or downsampling algorithm. Independent PNG observations now establish2× output, white background and no title for these fixtures; the PNG defaults follow that evidence, rather than being inferred solely from PDF.

### Additional owned PNG/PDF pairs

| Fixture | DOM content extent (CSSpx) | PNG pixels | PDF points |
| --- | --- | --- | --- |
| One table |270×94|668×316|251.04×119.04|
| Two separated tables |958×510|2044×1148|767.04×431.04|
| Two tables after native drag |886×462|1900×1052|713.04×395.04|

Each PNG is2× the content extent plus64px. The farthest-left card in the final fixture starts atx927, so its950px logical output width directly excludes the origin-based rule. The drag altered relative card positions unexpectedly; the measured resulting DOM boxes, rather than an assumed group translation, are used for the bounds comparison.

All three pairs and the earlier root pair fit the empirical paper rule `floor((logicalCssDimension + 1) * 25 / 8) * 0.24`. This records observed paper rounding, not private implementation internals. Drawing remains0.75pt/CSSpx with the extra page area left white; the image is not stretched to fill the rounded page. An independent test checks all four observed dimension pairs.

Reference empty-board PNG/PDF buttons remained enabled but produced no download or explicit error within20seconds. Empty output dimensions are unverified; the existing local empty-canvas fallback is independent. Reference fixtures and measurement reports remain outside source; see `/workspace/milanote-analysis/formula-scope-findings.md`.

## Verification

The current targeted suite has 51 passing unit cases (2026-10-27) (`tests/export.test.ts` and `tests/export-formats.test.ts`). It checks safe markup, reading order, formulas, display options, metadata preservation, binary container contents, nested-board traversal and strict resource handling. One older metadata test now mocks its remote resource failure, so its result does not depend on example.com network access.

`node tests/export-formats-e2e.mjs` passed ten browser workflows on 2026-10-27 in Chromium and Playwright WebKit against the development server. Results are recorded separately in `artifacts/binary-export-results.json` and `artifacts/webkit/binary-export-results.json`:

1. PNG dimensions and sampled pixels cover negative coordinates, board zoom independence and the processed cutout source.
2. Capturing supplied rendered DOM excludes resize controls, removes viewport zoom, retains content colors and supports transparency.
3. A 270×94 table far from the origin exports to the independently measured 668×316 PNG and 251.04×119.04pt PDF. Its corner stays white despite the colored board.
4. Standard/high-quality PDF files parse successfully, share board-sized paper dimensions with a 0.75pt/CSSpx drawing scale and the observed rounding for an odd-sized fixture, use a white background despite a colored board, omit the title strip, and contain different image resolutions/file sizes. Embedded raster bytes, not just metadata, verify the white corner and first card position.
5. Explicit A4 fit and Letter tile settings retain their requested geometry.
6. An SVG image with an HTTP resource renders pixels matching the same resource decoded into a reference canvas, within two channel levels. The original editor resource URL remains unchanged, and the temporary capture surface is removed.
7. A long document produces at least three A4 pages. Every page, including the final page, contains visible text pixels; DOCX contains the final paragraph as editable text.
8. Attachment ZIP retains original image bytes while the board displays a cutout.
9. Word embeds a drawing at its own dimensions, preserving stroke color and transparent corners.
10. Failed image loading rejects a DOM capture and removes its temporary surface.

`node tests/export-app-e2e.mjs` passed three integrated workflows in both Chromium and Playwright WebKit, first against the development server and then against the rebuilt production preview. The latest production results are preserved in `artifacts/production-current-chromium/export-app-production/app-export-results.json` and `artifacts/production-current-webkit/export-app-production/app-export-results.json`; the generic output paths may later contain a development run:

1. The main seven-item Export popup downloads valid PNG, standard PDF, high-quality PDF, Word, attachment ZIP, Markdown and plain text files. Standard/high-quality PDF paper geometry matches. Enabled sub-board inclusion appears in Word, Markdown and plain text.
2. Document PDF/Word downloads use current edits. The editor remains usable, and later changes survive a workspace backup.
3. A JSON backup embeds images in both deleted root cards and deleted nested boards. Reimport, restore and reload preserve original image bytes and editable image operations.

The 2026-10-27 production preview at port5305 passed all four `tests/production-e2e.mjs` checks in both engines: bundled local fonts/images with no external requests, Arabic text persistence, portable HTML/editable JSON, and a 1024×1366 touch viewport without overflow. The same build passed 3 export-app workflows per engine and 11 Chromium/9 WebKit touch checks. The SHA-256 of `dist/index.html` remained `cf77cf95a6c9225d015e253af69a10526416902280e95c3031782e5819b5f418` throughout both production sequences.

Immutable copies of these run outputs, commands, timestamps and hash checks are in `artifacts/production-current-chromium/` and `artifacts/production-current-webkit/`, each with `run-metadata.json`. The earlier `artifacts/production-before-todo-focus-webkit/binary-source/` snapshot separately preserves the 10 source-API binary checks; these are not represented as tests of a production UI. The subsequent source change only corrected task focus and its regression scenario. These copies remain distinct from later development runs that reuse the generic result filenames.

The browser checks exposed and corrected issues that unit tests had missed: a Node-only DOCX packing method, offscreen/logical CSS offsets yielding blank raster output, a swatch selector accidentally styling the outer card, and a WebKit hang while the image library waited for a detached SVG image's load event. Capture images are now validated and embedded before the image library clones the surface. This fixes the hang without mutating the source board. Capture surfaces are hidden from accessibility, omit duplicated card identifiers, and are removed on success, resource failure or renderer timeout. Font readiness and iframe loading also have finite timeouts. The app integration check waits for the displayed save status before reloading, consistent with asynchronous local persistence.

The seven-item reference popup has been observed and measured, and its main actions are integrated and tested locally; the extra JSON/HTML/SVG options remain under More options → Export board. See `PARITY-ACCEPTANCE.md` for observed popup geometry and the remaining acceptance gaps.

The synthetic DOM and sampled-pixel checks verify renderer mechanics and resource preservation. They do not establish screenshot equality with Milanote. Complex media embeds, every board-card customization, exact export typography/layout and physical iPad rendering remain part of the wider acceptance work. Playwright WebKit and a touch viewport do not establish Safari/iPadOS or Apple Pencil parity. The 1.5/3 rendering scales and finite timeout values are independent implementation choices, not measured Milanote behavior. The failed-resource cleanup path is exercised by the browser tests; a deliberately stalled renderer/font/frame timeout has not been injected by this suite.

## Reproduction

Run `npm run test -- tests/export.test.ts tests/export-formats.test.ts` for the targeted unit cases. `TEST_URL=<development URL> node tests/export-formats-e2e.mjs` exercises renderer APIs using Vite's source imports; this suite requires the development server. `TEST_URL=<preview URL> node tests/export-app-e2e.mjs` and `TEST_URL=<preview URL> node tests/production-e2e.mjs` exercise the built application.

Set `BROWSER_ENGINE=webkit` for either browser suite to select Playwright WebKit. This environment additionally uses `PLAYWRIGHT_BROWSERS_PATH=/workspace/.cache/ms-playwright` and `WEBKIT_PATH=/workspace/.cache/webkit-runner.sh`; the latter supplies WebKit's workspace-local shared-library paths. These environment paths are testing infrastructure, not files required by the application or its distribution.
