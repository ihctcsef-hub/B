# Third-party notices

The independent project source retains the root MIT license. The integrated calculation runtime now also contains HyperFormula under GPL-3.0-only. Distribution of the combined application must comply with GPLv3, including its corresponding-source requirements; the original MIT grant does not override that requirement. This work uses the GPLv3 option, not a commercial license. Dependencies retain their own licenses and copyright notices. Exact installed versions are recorded in `package-lock.json`; this file does not relicense those dependencies or the reference product.

The distributed installed production/peer dependency notice texts are retained in [licenses/Runtime-Notices.txt](licenses/Runtime-Notices.txt), with a package/version inventory in [licenses/runtime-inventory.json](licenses/runtime-inventory.json). The updated inventory covers 116 installed production/peer entries, including peer type packages and separately installed versions. README license sections and the separately retained ONNX Runtime notice are identified by source. Two upstream text gaps are recorded below. Individual notices are also retained for the main libraries:

| Dependency | License | Retained notice |
|---|---|---|
| React / React DOM / Scheduler | MIT | [React-MIT.txt](licenses/React-MIT.txt), complete runtime notices |
| TipTap core, React adapter and installed extensions | MIT | [Tiptap-MIT.txt](licenses/Tiptap-MIT.txt) |
| ProseMirror packages | MIT | [ProseMirror-MIT.txt](licenses/ProseMirror-MIT.txt) |
| HyperFormula 3.5.0 | GPL-3.0-only (the GPLv3 option) | [Complete upstream license](licenses/HyperFormula-GPL-3.0.txt), runtime notices; source: https://github.com/handsontable/hyperformula/tree/3.5.0 |
| Chevrotain 6.5.0 / regexp-to-ast 0.4.0 / tiny-emitter 2.1.0 | Apache-2.0 / MIT / MIT | Complete runtime notices and exact installed package sources in package-lock.json |
| FormulaJS | MIT, including its bundled notices | [FormulaJS-MIT.txt](licenses/FormulaJS-MIT.txt) |
| Bessel 1.0.2 | Apache-2.0 | [Apache-2.0.txt](licenses/Apache-2.0.txt), [Bessel-Apache-Notice.txt](licenses/Bessel-Apache-Notice.txt), complete runtime notices |
| jStat | MIT | [jStat-MIT.txt](licenses/jStat-MIT.txt) |
| parse5 | MIT | [Parse5-MIT.txt](licenses/Parse5-MIT.txt) |
| entities | BSD-2-Clause | [Entities-BSD-2-Clause.txt](licenses/Entities-BSD-2-Clause.txt) |
| Lucide icons | ISC | [Lucide-ISC.txt](licenses/Lucide-ISC.txt) |
| Floating UI, linkifyjs, fast-equals, orderedmap, rope-sequence, use-sync-external-store, w3c-keyname and supporting packages | MIT | Complete runtime notices; several individual notices are retained alongside them |
| Inter / DM Sans / Manrope variable fonts | SIL Open Font License 1.1 | The corresponding `*-OFL.txt` files in `licenses/` |
| docx, pdf-lib, html-to-image, fflate and their supporting export packages | MIT and the upstream licenses listed per package in the inventory | Complete distributed runtime notices; pako retains its MIT and Zlib notices, and JSZip retains its dual-license notices (the MIT option is used here) |
| ONNX Runtime Web / Common | MIT | [Bundled upstream license](../public/runtime/ONNXRUNTIME-LICENSE.txt), runtime notices |
| FlatBuffers / Long | Apache-2.0 | Runtime notices |
| Protobuf.js packages | BSD-3-Clause | Runtime notices |

`guid-typescript@1.0.9`, a transitive export dependency, declares ISC in its package metadata but its installed package and upstream repository root contain no license text. The metadata and this unresolved notice gap are retained explicitly in the inventory and runtime notices. No copyright holder or replacement upstream notice has been invented. The upstream notice text remains unavailable.

The local background-removal model is U²-Net small, distributed as the rembg ONNX conversion. Its provenance and checksums are in [public/models/README.md](../public/models/README.md); the original [U²-Net Apache-2.0 license](../public/models/U2NET-LICENSE.txt) and [rembg MIT notice](../public/models/REMBG-LICENSE.txt) are bundled alongside the model. This model is an independent implementation, and its output is not claimed to match Milanote's segmentation boundaries.

Font files are bundled through Fontsource. Demo photographs use the Unsplash license; see [public/assets/README.md](../public/assets/README.md) for their sources. Vite, TypeScript, Vitest and Playwright Core are development dependencies with their respective upstream licenses; installing dependencies retrieves their original packages and notices.

REA was used as a separate investigation tool. It is not an application runtime dependency. The source distribution excludes the REA checkout, captured proprietary scripts, credentials, browser profiles and authenticated session files. Milanote names and URLs identify the reference target and imply no affiliation. Reference screenshots document the authorized test workflows; they are not original project source.


The bundled Name that Color dataset contains1566 HEX/name pairs by Chirag Mehta, licensed under [Creative Commons Attribution2.5](https://creativecommons.org/licenses/by/2.5/). Its [notice and provenance](licenses/NameThatColor-CC-BY-2.5.txt) identify the public source and the extracted JSON adaptation. This data retains its own license, independently of the project's MIT source license and the npm runtime dependency inventory. The TypeScript lookup applies the public weighted RGB/HSL rule; it does not embed Milanote code or establish complete product naming/palette equivalence.

PDF text rendering also bundles static Inter and Noto Sans Arabic TrueType instances under SIL Open Font License1.1. The openly licensed Google Fonts sources, conversion details, full notices and generated-asset checksums are retained in [PDF-Fonts.txt](licenses/PDF-Fonts.txt) and [font provenance](../public/fonts/pdf/provenance.json). These are independent export fonts, not proprietary Milanote assets. `@pdf-lib/fontkit@1.1.1` retains its MIT license and is used for OpenType shaping and full-font embedding; its installed README declaration and metadata are retained in [PDF-Fontkit-MIT.txt](licenses/PDF-Fontkit-MIT.txt). The installed package and inspected fork/original repository roots do not supply a standalone license text; this upstream notice gap is recorded without inventing a copyright holder.
