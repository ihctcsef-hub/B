import {readFile,writeFile} from 'node:fs/promises';
const source=new URL('../docs/parity-backlog.json',import.meta.url),target=new URL('../docs/PARITY-BACKLOG.md',import.meta.url);
const data=JSON.parse(await readFile(source,'utf8')),statuses=['مُثبت','جزئي','ناقص','محجوب'];
const ids=new Set();for(const row of data.rows){if(ids.has(row.id)||!statuses.includes(row.status)||!row.acceptance||!row.evidenceRequired)throw Error(`Invalid backlog row: ${row.id}`);ids.add(row.id);if(row.status==='مُثبت'&&!row.evidence)throw Error(`Missing closure evidence: ${row.id}`);}
const counts=Object.fromEntries(statuses.map(status=>[status,data.rows.filter(row=>row.status===status).length]));
const clean=value=>String(value??'').replaceAll('|','&#124;').replaceAll('\n',' ');
const parts=[`# مصفوفة فجوات المطابقة — سجل العمل الملزم

الجرد الأول:28أكتوبر2026. قُرئت ملفات [القبول](PARITY-ACCEPTANCE.md) و[الدليل](GUIDE-COVERAGE.md) و[الحالة](STATUS.md) وقسم الحدود المعروفة في [README](../README.md) قبل إضافة كود جديد بعد طلب الجرد. هذا سجل عمل، وليس تقريرًا ختاميًا أو اعتماد مطابقة. البيانات والمعرفات الثابتة في [parity-backlog.json](parity-backlog.json). يُعاد توليد هذا الملف بالأمر \`node scripts/render-parity-backlog.mjs\` بعد تحديث الدليل أو الحالة؛ لا تُحذف صفوف لتقليل الفجوات.

## قواعد الإغلاق

- **مُثبت:** استوفى الصف معيار قبوله المحدد بدليل مسمّى؛ لا تعمم العينة على صف آخر.
- **جزئي:** توجد خطوات منفذة أو مشاهدات، لكن معيار القبول الكامل لم يتحقق.
- **ناقص:** السلوك أو البنية المطلوبة غير منفذة.
- **محجوب:** اعتماد خارجي حقيقي غير متاح. نقص البحث أو وقت العمل أو سعة وكلاء التوازي ليس سبب حجب؛ يواصل المنفذ المحلي العمل الممكن.

لا تُخفض معايير القبول ولا تُعدّل الاختبارات لتمرير عيب. أي تصحيح لمعيار خاطئ يفسر أولًا ويسجل أدناه بدليله. كل فرق بكسلي معروف يظل ظاهرًا في التقرير؛ لا يحوّل threshold أو mask حالة غير مطابقة إلى مُثبتة. الصور يجب أن تشترك فيviewport/zoom والخطوط والنصوص والمحتوى وحالة التحديد. المناطق الديناميكية تذكر صراحة ولا يُعد استبعادها قبولًا.

## حدود الجرد وأعداده

يشمل الجرد كل بنود الأدوات داخل النطاق في جداول الدليل، و14 حالة دورة حياة لكل13 نوعًا، وكل365 دالة بصف مستقل، وكل208 صفحة قالب عامة مع عناوين التطبيق المرصودة التي تحتاج توفيقًا، وكل هوية أيقونة مرجعية جُلبت حتى الآن. صف اكتمال الكتالوج نفسه يبقى مفتوحًا حتى تُثبت حدود جرده. أي حالة جديدة تُكتشف تُضاف بمعرف ثابت؛ الأيقونات العامة البديلة لا تستبدل هويات المرجع المطلوبة.

${statuses.map(status=>`${status}: **${counts[status]}**`).join('؛ ')}؛ المجموع **${data.rows.length}**. هذه أعداد صفوف الجرد، وليست أعداد اختبارات أو شهادة مطابقة.

## خط الأساس السابق

277 اختبار وحدة في33 ملفًا،35 مجموعةChromium،40 فحص إنتاجChromium و38WebKit. بصمة المصدر \`${data.baseline.sourceHash}\` والبناء \`${data.baseline.buildHash}\`. لا تعتمد هذه الجولة التغييرات الاستكشافية الحالية. نتائج كل دفعة جديدة يجب أن تسجل بتاريخها وبصمتها.

## ترتيب العمل ونقطة المتابعة

1. GATE-001: اعتماد سلامة دمج الاستكشافات الحالية بالوحدات والبناء ومجموعات المتصفح المتأثرة؛ هذا لا يغلق صفوف المطابقة الأخرى.
2. VIS-001..004: إصلاح الفروق المرئية المقاسة وإعادة المقارنة، مع جرد حالاتMore والتثبيت قبل افتراض ترتيب ثابت.
3. CAT-I وCAT-T: إكمال جرد المرجع وبيانات الأيقونات والقوالب وتنفيذ كل مدخل؛ لا إغلاق بكتالوج أسماء فقط.
4. FORM-CTX وFN-SHEET/FN-SHEETS، ثم بقية صفوف الدوال حسب العائلة؛ السياق موحد بين التحرير والعرض والتصدير.
5. PRE-*، ثم جميع بقية صفوف الأدوات والحالات والتصدير واللمس. بعد إغلاق صف ينتقل العمل مباشرة إلى التالي دون طلب موافقة.

${data.workLog||'عند الجرد: PdfPreview وpdfPreview وpublic/pdfjs موجودة غير معتمدة، وpdfjs-dist نُقل إلىruntime. تغييرات نسبة معاينة الروابط فيCSS/HTML/Presentation غير متحققة. توقفت جولات الوكلاء بسبب حد استخدام الخدمة، لكن التنفيذ المحلي غير محجوب. الأدلة الاستكشافية ومعلومات ملكية لوحات الاختبار محفوظة في /workspace/milanote-analysis.'}

أوامر كل دفعة: \`npm test\` و\`npm run build\` ثم \`TEST_URL=http://127.0.0.1:5306 node tests/<affected-suite>.mjs\`. إعدادWebKit: \`BROWSER_ENGINE=webkit WEBKIT_PATH=/workspace/.cache/webkit-runner.sh PLAYWRIGHT_BROWSERS_PATH=/workspace/.cache/ms-playwright\`. الجولة المجمعة \`npm run test:browser:working\` تتطلب ثبات المصدر طوال التنفيذ. تسجل الأرقام الفعلية فيSTATUS وVALIDATION-WORKING بعد الدفعة.

## تصحيحات المعايير المعلنة

${(data.corrections||[]).map(row=>`- **${row.id}:** ${row.reason}${row.evidence?' الدليل: '+row.evidence:''}`).join('\n')}

`];
for(const family of [...new Set(data.rows.map(row=>row.family))]){
 parts.push(`## ${family}\n\n| المعرف | الأداة/السلوك/الحالة | الحالة | الفرق المحدد | معيار القبول القابل للقياس | الدليل المطلوب والموجود |\n|---|---|---|---|---|---|\n`);
 for(const row of data.rows.filter(row=>row.family===family))parts.push('| '+[row.id,row.case,row.status,row.difference,row.acceptance,`${row.evidenceRequired} ${row.evidence?'**الدليل:** '+row.evidence:'**الإغلاق:** لا يوجد دليل قبول مكتمل بعد.'}`].map(clean).join(' | ')+' |\n');
 parts.push('\n');
}
parts.push('## استثناءات الخدمات في النطاق الأصلي\n\nهذه الاستثناءات سبقت المهمة الحالية؛ لا تستبعد أدوات محلية أو تخصيصًا أو مقارنة بصرية. لا تُضاف استثناءات جديدة لتقليل الفجوات.\n\n');
for(const row of data.originalScopeExclusions)parts.push(`- ${row.case}: ${row.reason}\n`);
parts.push('\n## التسليم والاستمرار\n\nلا تسليم نهائي مع أي صف جزئي أو ناقص. لا يوقف العمل إلا خلو المصفوفة منهما أو بقاء صفوف محجوبة حصرًا. قرب حد السياق، تُحدّث الحالة والأدلة والأوامر وآخر صف وما يلزمه في هذا السجل، ويُستأنف العمل منه في السياق التالي.\n');
await writeFile(target,parts.join(''));console.log(JSON.stringify({rows:data.rows.length,counts}));
