import{readFile,writeFile}from'node:fs/promises';
import{resolve,basename}from'node:path';
import{createHash}from'node:crypto';
const project=resolve(new URL('..',import.meta.url).pathname),sha=bytes=>createHash('sha256').update(bytes).digest('hex'),fold=value=>value.normalize('NFKD').replace(/\p{M}/gu,'').toLocaleLowerCase().trim();
const catalogPath=project+'/src/data/boardIconCatalog.json',catalog=JSON.parse(await readFile(catalogPath)),known=new Map(catalog.entries.map(icon=>[icon.id,icon])),observations=new Map();
for(const file of process.argv.slice(2)){
 const bytes=await readFile(resolve(file)),report=JSON.parse(bytes),rows=Array.isArray(report.results)?report.results.map(row=>({query:row.query,icons:row.icons,path:row.path,status:row.status})):report.apiIds?[{query:report.search,icons:report.apiIds,status:200,path:(()=>{const request=report.requests.findLast(row=>row.origin==='https://app.milanote.com'&&row.path==='/api//icons'&&row.search&&fold(row.search)===fold(report.search));if(!request)throw Error('Missing native search request evidence');return request.path+'?'+new URLSearchParams({search:request.search,count:request.count});})()}]:[];
 if(!rows.length)throw Error('No observed query results: '+file);
 for(const row of rows){
  const url=new URL(row.path,'https://app.milanote.com'),query=fold(row.query);
  if(row.status!==200||url.origin!=='https://app.milanote.com'||url.pathname!=='/api//icons'||url.searchParams.get('search')!==query||![...url.searchParams.keys()].every(key=>['search','count'].includes(key))||url.searchParams.get('count')!=='32'||!Array.isArray(row.icons))throw Error('Invalid query evidence: '+row.query);
  const ids=row.icons.map(icon=>icon.id);if(new Set(ids).size!==ids.length||ids.some(id=>!known.get(id)?.referenceKnown||known.get(id)?.templateOnly))throw Error('Query contains duplicate or unrenderable identity: '+query);
  const existing=observations.get(query);if(existing&&JSON.stringify(existing.ids)!==JSON.stringify(ids))throw Error('Conflicting captured query order: '+query);
  catalog.referenceQueries[query]=ids;observations.set(query,{query,ids,requestedCount:Number(url.searchParams.get('count')),sourcePath:url.pathname+url.search,reportFile:basename(file),reportSha256:sha(bytes)});
 }
}
if(!observations.size)throw Error('Provide at least one captured query report');
const provenancePath=project+'/src/data/boardIconQueryProvenance.json',provenance={updatedAt:new Date().toISOString(),completeInventoryClaimed:false,method:'Exact identity order from captured native32-count icon-search responses. Other request counts cannot establish the picker ordering; complete inventory is not claimed.',queries:[...observations.values()]};
await writeFile(catalogPath,JSON.stringify(catalog)+'\n');await writeFile(provenancePath,JSON.stringify(provenance,null,2)+'\n');
const artPath=project+'/src/data/boardIconProvenance.json',art=JSON.parse(await readFile(artPath));for(const file of ['boardIconCatalog.json','boardIconQueryProvenance.json']){const bytes=await readFile(project+'/src/data/'+file);art.files[file]={bytes:bytes.length,sha256:sha(bytes)};}await writeFile(artPath,JSON.stringify(art,null,2)+'\n');
console.log(JSON.stringify({observedQueries:observations.size,totalStoredQueries:Object.keys(catalog.referenceQueries).length,completeInventoryClaimed:false}));
