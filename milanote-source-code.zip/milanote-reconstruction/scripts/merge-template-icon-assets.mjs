import{readFile,writeFile}from'node:fs/promises';
import{resolve,join}from'node:path';
import{createHash}from'node:crypto';
import{parseFragment}from'parse5';

const project=resolve(new URL('..',import.meta.url).pathname),directory=resolve(process.argv[2]||'/workspace/milanote-analysis/template-extra-icon-assets'),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const manifest=JSON.parse(await readFile(join(directory,'manifest.json'),'utf8'));
const dataPath=join(project,'src/data/boardIconReferenceAssets.json'),catalogPath=join(project,'src/data/boardIconCatalog.json'),provenancePath=join(project,'src/data/boardIconReferenceProvenance.json');
const data=JSON.parse(await readFile(dataPath,'utf8')),catalog=JSON.parse(await readFile(catalogPath,'utf8')),provenance=JSON.parse(await readFile(provenancePath,'utf8'));
const known=new Map(catalog.entries.map(icon=>[icon.id,icon])),records=new Map(provenance.assets.map(asset=>[asset.id,asset]));
const inertStyles=new Set(['',' ','line-height:normal;text-indent:0;text-align:start;text-decoration-line:none;text-decoration-style:solid;text-decoration-color:#000;text-transform:none;block-progression:tb;isolation:auto;mix-blend-mode:normal','text-indent:0;text-align:start;line-height:normal;text-transform:none;block-progression:tb;-inkscape-font-specification:Bitstream Vera Sans']);
function normalizeSvg(bytes,id){
 const fragment=parseFragment(bytes.toString('utf8')),roots=fragment.childNodes.filter(node=>node.nodeName!=='#text'||node.value.trim());
 const meaningful=roots.filter(node=>!(node.nodeName==='#comment'&&/^\?xml\b[^<>]*\?$/.test(node.data)));
 if(meaningful.length!==1||meaningful[0].nodeName!=='svg')throw Error('Expected one visual SVG: '+id);
 const svg=meaningful[0];for(const attribute of svg.attrs){if(attribute.prefix==='xmlns')continue;if(!['viewBox','xmlns','version','enable-background','width','height'].includes(attribute.name))throw Error('Unexpected SVG attribute: '+id+' '+attribute.name);}
 const box=svg.attrs.find(attribute=>attribute.name==='viewBox')?.value.split(/[\s,]+/).map(Number);
 if(box?.length!==4||!box.every(Number.isFinite)||box[2]<=0||box[3]<=0)throw Error('Invalid viewport: '+id);
 const paths=[];
 const paint=value=>value==='none'||/^#[a-f\d]{3}(?:[a-f\d]{3})?$/i.test(value);
 function visit(node,state={fill:undefined,fillRule:undefined,x:0,y:0}){
  if(node.nodeName==='#text'&&!node.value.trim())return;
  if(node.nodeName==='title'){if(node.attrs.length||node.childNodes.some(child=>child.nodeName!=='#text'))throw Error('Unexpected title: '+id);return;}
  if(node.nodeName==='g'){
   if(node.attrs.some(attribute=>!['id','fill','fill-rule','transform','stroke','stroke-width'].includes(attribute.name)))throw Error('Unexpected group: '+id);
   const attributes=Object.fromEntries(node.attrs.map(attribute=>[attribute.name,attribute.value])),next={...state};
   if(attributes.fill!==undefined){if(!paint(attributes.fill))throw Error('Unsupported group paint: '+id);next.fill=attributes.fill;}
   if(attributes['fill-rule']!==undefined){if(!['evenodd','nonzero'].includes(attributes['fill-rule']))throw Error('Unsupported fill rule: '+id);next.fillRule=attributes['fill-rule'];}
   if(attributes.stroke!==undefined&&attributes.stroke!=='none')throw Error('Unsupported stroke: '+id);
   if(attributes['stroke-width']!==undefined&&attributes['stroke-width']!=='1')throw Error('Unsupported stroke width: '+id);
   if(attributes.transform!==undefined){const match=/^translate\(\s*([-+\d.eE]+)[,\s]+([-+\d.eE]+)\s*\)$/.exec(attributes.transform);if(!match||![Number(match[1]),Number(match[2])].every(Number.isFinite))throw Error('Unsupported transform: '+id);next.x+=Number(match[1]);next.y+=Number(match[2]);}
   node.childNodes.forEach(child=>visit(child,next));return;
  }
  if(node.nodeName==='defs'){
   const children=node.childNodes.filter(child=>child.nodeName!=='#text'||child.value.trim());
   if(children.length!==1||children[0].nodeName!=='style'||children[0].attrs.length||children[0].childNodes.map(child=>child.value||'').join('')!=='.fa-secondary{opacity:.4}')throw Error('Unexpected stylesheet: '+id);
   return;
  }
  if(node.nodeName!=='path'||node.childNodes.length)throw Error('Unexpected visual element: '+id+' '+node.nodeName);
  const attributes=Object.fromEntries(node.attrs.map(attribute=>[attribute.name,attribute.value]));
  if(node.attrs.some(attribute=>!['d','class','style','overflow','font-family','font-weight','white-space','enable-background','color','id','opacity'].includes(attribute.name)))throw Error('Unexpected path attribute: '+id);
  if(attributes.style!==undefined&&!inertStyles.has(attributes.style))throw Error('Unexpected inline style: '+id);
  if(!attributes.d||!/^[MmZzLlHhVvCcSsQqTtAa\d\s.,+eE-]+$/.test(attributes.d)||attributes.class&&!['fa-primary','fa-secondary'].includes(attributes.class)&&!(id==='pied-piper'&&attributes.class==='cls-1'&&!bytes.toString('utf8').includes('<style')))throw Error('Invalid path: '+id);
  if(attributes.opacity!==undefined&&Number(attributes.opacity)!==.4)throw Error('Unsupported opacity: '+id);
  const opacity=attributes.class==='fa-secondary'||attributes.opacity!==undefined?.4:undefined;
  paths.push({d:attributes.d,...(opacity===undefined?{}:{opacity}),...(state.fill===undefined?{}:{fill:state.fill}),...(state.fillRule==='evenodd'?{fillRule:'evenodd'}:{}),...(state.x||state.y?{transform:`translate(${state.x} ${state.y})`}:{})});
 }
 svg.childNodes.forEach(node=>visit(node));if(!paths.length)throw Error('Empty glyph: '+id);return{viewBox:box,paths};
}
for(const row of manifest.results){
 if(!/^[a-z0-9-]+$/.test(row.id)||!row.svg||!row.icon||row.icon.id!==row.id)throw Error('Incomplete captured identity: '+row.id);
 const bytes=await readFile(join(directory,row.svg.file));if(sha(bytes)!==row.svg.sha256)throw Error('Changed captured asset: '+row.id);
 data.entries[row.id]=normalizeSvg(bytes,row.id);
 const entry=known.get(row.id)||{id:row.id,name:row.icon.name,terms:[],aliases:[]};
 Object.assign(entry,{referenceKnown:true,artSource:'observed-reference-visual-asset',templateOnly:row.icon.type!=='mn-svg'});known.set(row.id,entry);
 records.set(row.id,{...records.get(row.id),id:row.id,type:'observed-reference-visual-asset',sourceApiUrl:'https://app.milanote.com'+row.path,...(row.icon.png?{sourcePngUrl:row.icon.png}:{}),svg:{bytes:bytes.length,sha256:sha(bytes)},licenseEvidence:'No license text in observed response.',sourceContext:row.icon.type==='mn-svg'?'icon-search':'legacy-template',searchObserved:row.icon.type==='mn-svg'});
}
catalog.entries=[...known.values()];catalog.referenceKnownCount=catalog.entries.filter(icon=>icon.referenceKnown).length;catalog.referenceInventoryComplete=false;
data.rasterFallbackIds=[...records.values()].filter(record=>record.png).map(record=>record.id).sort();
const encoded=Buffer.from(JSON.stringify(data)+'\n');provenance.identityCount=Object.keys(data.entries).length;provenance.canonicalAssetSha256=sha(encoded);provenance.updatedAt=new Date().toISOString();provenance.assets=[...records.values()];provenance.canonicalization='Strict SVG grammar: measured viewBox/path geometry; inert legacy XML/group/text-flow metadata removed; fa-secondary becomes opacity0.4. No captured CSS, script, URL or HTML executes.';
if(catalog.referenceKnownCount!==provenance.identityCount)throw Error('Identity inventory differs from captured assets');
await writeFile(dataPath,encoded);await writeFile(catalogPath,JSON.stringify(catalog)+'\n');await writeFile(provenancePath,JSON.stringify(provenance,null,2)+'\n');
const freePath=join(project,'src/data/boardIconProvenance.json'),free=JSON.parse(await readFile(freePath,'utf8'));free.files['boardIconCatalog.json']={bytes:Buffer.byteLength(JSON.stringify(catalog)+'\n'),sha256:sha(JSON.stringify(catalog)+'\n')};await writeFile(freePath,JSON.stringify(free,null,2)+'\n');
console.log(JSON.stringify({capturedAdditional:manifest.results.length,knownVisualAssets:provenance.identityCount,pickerKnown:catalog.entries.filter(icon=>icon.referenceKnown&&!icon.templateOnly).length,legacyTemplateOnly:catalog.entries.filter(icon=>icon.templateOnly).length,available:catalog.entries.length,retainedNativePngFallbacks:data.rasterFallbackIds.length}));
