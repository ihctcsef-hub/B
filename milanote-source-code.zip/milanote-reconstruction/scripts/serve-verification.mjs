import {createServer} from 'vite';

// Keep an in-progress UI workflow stable while other source work is saved.
// A reload still loads the current source; the suite runner separately records
// whether source files changed during its complete verification interval.
const port=Number(process.argv[2]||5289);
if(!Number.isInteger(port)||port<1024||port>65535)throw Error('Expected a valid verification port.');
const server=await createServer({server:{host:'127.0.0.1',port,strictPort:true,hmr:false},clearScreen:false});
await server.listen();server.printUrls();
async function close(){await server.close();process.exit(0);}
process.once('SIGTERM',close);process.once('SIGINT',close);
