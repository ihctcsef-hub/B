/** Reuse only a completed prefix from this exact source and ordered suite list.
 * Failed outcomes are retained; an active/interrupted suite is never appended. */
export function resumableBrowserResults(previous,sourceHash,suites){
 if(!previous||typeof previous!=='object')return{accepted:false,reason:'missing checkpoint'};
 if(previous.sourceHashAtStart!==sourceHash||previous.sourceHashAtEnd!==sourceHash||previous.sourceChangedDuringRun!==false)return{accepted:false,reason:'source fingerprint changed or was not verified'};
 if(JSON.stringify(previous.expectedSuites)!==JSON.stringify(suites))return{accepted:false,reason:'ordered suite list changed'};
 if(!Array.isArray(previous.results)||previous.results.length>=suites.length)return{accepted:false,reason:'round already complete or results missing'};
 const prefix=previous.results.every((row,index)=>row&&row.suite===suites[index]&&['passed','failed'].includes(row.status)&&Number.isInteger(row.exitCode)&&(row.status==='passed'?row.exitCode===0:row.exitCode!==0));
 if(!prefix)return{accepted:false,reason:'results are not a completed, consistent prefix'};
 return{accepted:true,results:structuredClone(previous.results)};
}
