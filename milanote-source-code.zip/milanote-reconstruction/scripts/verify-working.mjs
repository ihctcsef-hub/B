import {resumableBrowserResults} from './browser-run-checkpoint.mjs';
import { spawn } from 'node:child_process';
import { mkdir,writeFile,readFile,readdir,rename,copyFile } from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const project=fileURLToPath(new URL('../',import.meta.url));
const url=process.env.TEST_URL||'http://127.0.0.1:5289';
const suites=['cold-editor-e2e','e2e','tools-e2e','editor-e2e','note-shortcuts-e2e','canvas-shortcuts-e2e','search-e2e','table-e2e','table-layout-e2e','todo-e2e','customization-e2e','import-feedback-e2e','documents-e2e','synced-notes-e2e','advanced-e2e','board-hover-e2e','lines-e2e','labels-e2e','trash-shortcuts-e2e','workspace-tools-e2e','presentation-drawing-e2e','presentation-editing-e2e','view-text-style-e2e','canvas-view-parity-e2e','note-frame-e2e','board-icons-e2e','card-color-e2e','swatch-ui-e2e','image-colors-e2e','image-library-e2e','image-library-app-e2e','image-grid-e2e','link-metadata-e2e','thumbnail-drop-e2e','media-providers-e2e','file-preview-e2e','file-preview-app-e2e','table-formula-context-e2e','formula-native-e2e','template-catalog-e2e','link-preview-e2e','link-preview-app-e2e','vector-pdf-e2e','export-formats-e2e','export-app-e2e','touch-workflows-e2e'];
async function sourceFingerprint(){
  const files=[];
  async function walk(relative){for(const item of await readdir(path.join(project,relative),{withFileTypes:true})){const file=path.join(relative,item.name);if(item.isDirectory())await walk(file);else if(item.isFile())files.push(file);}}
  for(const folder of ['src','public','server','tests','scripts']){try{await walk(folder);}catch(error){if(error.code!=='ENOENT')throw error;}}
  for(const name of ['package.json','package-lock.json','vite.config.ts','index.html']){try{await readFile(path.join(project,name));files.push(name);}catch(error){if(error.code!=='ENOENT')throw error;}}
  const hash=createHash('sha256');for(const file of files.sort()){hash.update(file);hash.update('\0');hash.update(await readFile(path.join(project,file)));hash.update('\0');}return hash.digest('hex');
}
const sourceHashAtStart=await sourceFingerprint();
let sourceChangedDuringRun=false;
let server,activeChild,activeSuite,stopping=false,infrastructureError;
const results=[];
const reportPath=new URL('../artifacts/working-browser-run.json',import.meta.url);
const runId=`${Date.now()}-${process.pid}`;
let startedAt=new Date().toISOString(),resumeHistory=[];
await mkdir(new URL('../artifacts/working-browser-history/',import.meta.url),{recursive:true});
try{
  const previous=JSON.parse(await readFile(reportPath,'utf8'));
  await copyFile(reportPath,new URL(`../artifacts/working-browser-history/${runId}-previous.json`,import.meta.url));
  if(process.env.BROWSER_RUN_RESUME==='1'){
    const resume=resumableBrowserResults(previous,sourceHashAtStart,suites);
    if(resume.accepted){results.push(...resume.results);startedAt=previous.startedAt;resumeHistory=[...(previous.resumeHistory||[]),{resumedAt:new Date().toISOString(),completedSuites:results.length,interruptedSuite:previous.activeSuite}];console.log(`Resuming after ${results.length} completed suites; recorded failures remain failures.`);}
    else console.log(`Checkpoint cannot be reused (${resume.reason}); starting the complete round.`);
  }
}catch(error){if(error.code!=='ENOENT')throw error;}
function stop(){stopping=true;activeChild?.kill('SIGTERM');}
process.on('SIGINT',stop);process.on('SIGTERM',stop);
async function saveCheckpoint(){
  const sourceHashAtEnd=await sourceFingerprint();sourceChangedDuringRun ||= sourceHashAtStart!==sourceHashAtEnd;
  const value={runId,startedAt,checkedAt:new Date().toISOString(),url,releaseApproved:false,referenceParityClaimed:false,sourceHashAtStart,sourceHashAtEnd,sourceChangedDuringRun,expectedSuites:suites,complete:results.length===suites.length&&!activeSuite&&!stopping,interrupted:stopping,activeSuite,resumeHistory,infrastructureError,results};
  const temporary=new URL(`../artifacts/working-browser-run.${process.pid}.tmp`,import.meta.url);await writeFile(temporary,JSON.stringify(value,null,2));await rename(temporary,reportPath);
}
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function waitForServer(){
  for(let index=0;index<100;index++){
    if(server?.exitCode!==null&&server?.exitCode!==undefined)throw Error('The verification server exited before it was ready.');
    try{if((await fetch(url,{signal:AbortSignal.timeout(1000)})).ok)return;}catch{}
    await pause(150);
  }
  throw Error(`The verification server did not become ready at ${url}.`);
}
try{
  await saveCheckpoint();
  if(!process.env.TEST_URL){server=spawn(process.execPath,['scripts/serve-verification.mjs','5289'],{cwd:project,stdio:'ignore'});}
  await waitForServer();
  for(const suite of suites.slice(results.length)){
    if(stopping||sourceChangedDuringRun)break;
    activeSuite=suite;await saveCheckpoint();
    const started=Date.now();console.log(`Running ${suite}`);
    const child=activeChild=spawn(process.execPath,[`tests/${suite}.mjs`],{cwd:project,env:{...process.env,TEST_URL:url},stdio:'inherit'});
    const timeout=setTimeout(()=>child.kill('SIGTERM'),180000);
    const code=await new Promise(resolve=>{child.on('error',()=>resolve(1));child.on('exit',code=>resolve(code??1));});clearTimeout(timeout);
    activeChild=undefined;
    if(stopping)break;
    results.push({suite,status:code===0?'passed':'failed',exitCode:code,elapsedMs:Date.now()-started});activeSuite=undefined;await saveCheckpoint();
  }
}catch(error){
  infrastructureError=error.message;process.exitCode=1;
}finally{
  server?.kill('SIGTERM');
  await saveCheckpoint();process.off('SIGINT',stop);process.off('SIGTERM',stop);
}
if(stopping||infrastructureError||sourceChangedDuringRun||results.length!==suites.length||results.some(result=>result.status!=='passed'))process.exitCode=1;
