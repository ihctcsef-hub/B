import { defineConfig } from 'vite';
import { createImageLibraryMiddleware } from './server/image-library.mjs';
import { createLinkMetadataMiddleware } from './server/link-metadata.mjs';

export default defineConfig({
  // React's JSX runtimes must share the initial dependency generation with
  // lazy editors. A late optimizer generation otherwise gives the editor a
  // second React dispatcher while HMR is disabled for a verification session.
  resolve: { dedupe: ['react', 'react-dom'] },
  optimizeDeps: { entries: ['index.html'], include: ['react', 'react-dom', 'react-dom/client', 'react/jsx-runtime', 'react/jsx-dev-runtime', 'hash.js', 'pdfjs-dist', 'hyperformula'] },
  plugins: [{
    name: 'local-image-library',
    configureServer(server) {
      server.middlewares.use(createImageLibraryMiddleware());
      server.middlewares.use(createLinkMetadataMiddleware());
    },
    configurePreviewServer(server) {
      server.middlewares.use(createImageLibraryMiddleware());
      server.middlewares.use(createLinkMetadataMiddleware());
    },
  }],
  build: {
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (!id.includes('/node_modules/')) return;
          if (/\/node_modules\/(@formulajs|jstat|bessel|hyperformula|chevrotain|regexp-to-ast|tiny-emitter)\//.test(id)) return 'formulas';
          if (/\/node_modules\/(react|react-dom|scheduler)\//.test(id)) return 'react-runtime';
          if (id.includes('/node_modules/prosemirror-')) return 'prosemirror';
          if (id.includes('/node_modules/@tiptap/')) return 'tiptap';
          if (id.includes('/node_modules/parse5/') || id.includes('/node_modules/entities/')) return 'html-parser';
        },
      },
    },
  },
});
