import { describe, expect, it } from 'vitest';
import type { Card, Workspace } from '../src/core/model';
import { importWorkspace, exportWorkspace } from '../src/core/storage';
import { applyNoteContent } from '../src/core/notes';
import { markBoardViewed, retainBoardActivity, sameBoardContent, searchBoardAncestors, searchMatchRange, searchSnippet, searchWorkspace, stampBoardModifications } from '../src/core/search';
const note=(id:string,text:string):Extract<Card,{type:'note'}>=>({id,type:'note',text,x:10,y:20,width:270,height:54,z:1});
function fixture():Workspace{return {version:1,id:'search',title:'Search',rootBoardId:'root',updatedAt:'2026-10-25T00:00:00Z',labels:[{id:'label',name:'Reviewed',color:'#ad6fff'}],boards:{root:{id:'root',title:'Ideas studio',cards:[note('note','An orchid and a willow'),{id:'tile',type:'board',boardId:'child',title:'Research archive',x:500,y:20,width:160,height:160,z:2}],connections:[],viewport:{x:0,y:0,zoom:1}},child:{id:'child',title:'Research archive',parentBoardId:'root',cards:[{...note('nested','The orchid reference'),labelIds:['label']}],connections:[],viewport:{x:0,y:0,zoom:1}}}};}
describe('workspace search and local board activity',()=>{
 it('groups phrase content matches by board and resolves board titles without duplicate owning-tile hits',()=>{
  const doc=fixture();expect(searchWorkspace(doc,'orchid').map(result=>[result.board.id,result.hits.map(card=>card.id)])).toEqual([['root',['note']],['child',['nested']]]);
  const title=searchWorkspace(doc,'research archive');expect(title).toHaveLength(1);expect(title[0].board.id).toBe('child');expect(title[0].titleMatch).toBe(true);expect(title[0].hits).toEqual([]);
  expect(searchWorkspace(doc,'reviewed').map(result=>result.hits[0].id)).toEqual(['nested']);expect(searchWorkspace(doc,'anything','viewed','label').map(result=>result.board.id)).toEqual(['child']);
 });
 it('searches task text, table cells, URLs, captions, filenames and swatch values without searching resource bytes',()=>{
  const doc=fixture(),base={x:0,y:0,width:270,height:100,z:1};doc.boards.root.cards=[
   {...base,id:'todo',type:'todo',title:'Tasks',items:[{id:'task',text:'Collect sapphire references',done:false}]},
   {...base,id:'table',type:'table',title:'Schedule',rows:[['Sapphire','10']]},
   {...base,id:'link',type:'link',title:'Website',url:'https://example.test/sapphire',description:'Useful source',caption:'Saved reference'},
   {...base,id:'image',type:'image',src:'data:image/png;base64,secretpayload',caption:'Sapphire mood'},
   {...base,id:'file',type:'file',name:'sapphire.pdf',mime:'application/pdf',size:10,dataUrl:'data:application/pdf;base64,secretpayload'},
   {...base,id:'swatch',type:'swatch',label:'Sapphire color',value:'#123456'},
  ];expect(searchWorkspace(doc,'sapphire')[0].hits.map(card=>card.id)).toEqual(['todo','table','link','image','file','swatch']);expect(searchWorkspace(doc,'secretpayload')).toEqual([]);expect(searchWorkspace(doc,'#123456')[0].hits[0].id).toBe('swatch');
  expect(searchSnippet(note('long','Before '.repeat(40)+'sapphire in the final paragraph'),'sapphire')).toMatch(/^….*sapphire/);
 });
 it('records navigation without modifying content, and ignores pan/zoom and structurally identical clones',()=>{
  const original=fixture(),visited=markBoardViewed(original,'child','2026-10-26T10:00:00Z');expect(original.boardActivity).toBeUndefined();expect(visited.boardActivity?.child).toEqual({viewedAt:'2026-10-26T10:00:00.000Z'});expect(searchWorkspace(visited,'').map(result=>result.board.id)).toEqual(['child']);
  const pan=structuredClone(visited);pan.boards.child.viewport={x:900,y:-500,zoom:.4};expect(sameBoardContent(visited.boards.child,pan.boards.child)).toBe(true);expect(stampBoardModifications(visited,pan).boardActivity).toEqual(visited.boardActivity);
  const edit=structuredClone(pan);edit.boards.child.cards[0]={...edit.boards.child.cards[0],x:30};const changed=stampBoardModifications(pan,edit,'2026-10-26T11:00:00Z');expect(changed.boardActivity?.child).toEqual({viewedAt:'2026-10-26T10:00:00.000Z',modifiedAt:'2026-10-26T11:00:00.000Z'});expect(changed.boardActivity?.root).toBeUndefined();
 });
 it('sorts board-level viewed/modified history independently and keeps missing legacy dates unknown',()=>{
  const doc=fixture();doc.boardActivity={root:{viewedAt:'2026-10-26T12:00:00Z',modifiedAt:'2026-10-26T09:00:00Z'},child:{viewedAt:'2026-10-26T10:00:00Z',modifiedAt:'2026-10-26T11:00:00Z'}};
  expect(searchWorkspace(doc,'orchid','viewed').map(result=>result.board.id)).toEqual(['root','child']);expect(searchWorkspace(doc,'orchid','modified').map(result=>result.board.id)).toEqual(['child','root']);
  const legacy=fixture();expect(searchWorkspace(legacy,'')).toEqual([]);expect(searchWorkspace(legacy,'orchid')).toHaveLength(2);expect(legacy.boardActivity).toBeUndefined();
  delete doc.boards.child;doc.boards.root.cards=doc.boards.root.cards.filter(card=>card.type!=='board');expect(searchWorkspace(doc,'orchid').map(result=>result.board.id)).toEqual(['root']);
 });
 it('keeps viewed history through content undo, stamps the reverted edit, and preserves incoming live-edit times',()=>{
  const original=fixture(),changed=structuredClone(original);changed.boards.root.title='Changed title';const edited=stampBoardModifications(original,changed,'2026-10-26T10:00:00Z'),visited=markBoardViewed(edited,'child','2026-10-26T11:00:00Z');
  const undo=stampBoardModifications(visited,retainBoardActivity(original,visited),'2026-10-26T12:00:00Z');expect(undo.boards.root.title).toBe('Ideas studio');expect(undo.boardActivity?.root.modifiedAt).toBe('2026-10-26T12:00:00.000Z');expect(undo.boardActivity?.child.viewedAt).toBe('2026-10-26T11:00:00.000Z');
  expect(stampBoardModifications(original,edited,'2026-10-26T14:00:00Z').boardActivity?.root.modifiedAt).toBe('2026-10-26T10:00:00.000Z');
  const foreign={...original,id:'other'};expect(retainBoardActivity(foreign,visited)).toBe(foreign);
 });
 it('marks each board changed by a synced edit without marking an unrelated visit as an edit',()=>{
  const doc=fixture();for(const board of Object.values(doc.boards))for(const card of board.cards)if(card.type==='note')card.syncedId='shared';
  const visited=markBoardViewed(doc,'root','2026-10-26T09:00:00Z'),edited=stampBoardModifications(visited,applyNoteContent(visited,'root','note',{text:'Synchronized change',html:'<p>Synchronized change</p>'},54),'2026-10-26T10:00:00Z');
  expect(edited.boardActivity?.root.modifiedAt).toBe('2026-10-26T10:00:00.000Z');expect(edited.boardActivity?.child.modifiedAt).toBe('2026-10-26T10:00:00.000Z');expect(edited.boardActivity?.child.viewedAt).toBeUndefined();
 });
 it('round-trips activity in portable backups, accepts legacy files and rejects malformed times',()=>{
  const doc=markBoardViewed(fixture(),'root','2026-10-26T10:00:00Z');expect(importWorkspace(exportWorkspace(doc))).toEqual(doc);expect(importWorkspace(exportWorkspace(fixture())).boardActivity).toBeUndefined();
  for(const activity of [{root:{viewedAt:'not a date'}},{root:{modifiedAt:10}},[],{root:null}])expect(()=>importWorkspace(JSON.stringify({...fixture(),boardActivity:activity}))).toThrow(/invalid board activity/);
  expect(searchBoardAncestors(doc,doc.boards.child)).toEqual(['Home']);
  const unusual={...doc,boardActivity:JSON.parse('{"__proto__":{"viewedAt":"2026-10-26T10:00:00Z"}}')};const retained=retainBoardActivity(doc,unusual);expect(Object.hasOwn(retained.boardActivity!,'__proto__')).toBe(true);expect(Object.getPrototypeOf(retained.boardActivity)).toBe(Object.prototype);
 });
 it('indexes visible formatted note and caption text rather than Markdown markers or stale derived plaintext',()=>{
  const doc=fixture();doc.boards.root.cards=[
   {...note('markdown','Alpha **bravo** charlie')},
   {...note('rich',''),html:'<p>Visible <strong>orchid</strong> text</p>'},
   {id:'photo',type:'image',src:'/photo.png',caption:'Old caption',captionHtml:'<p>Rich <em>caption</em> text</p>',x:0,y:0,width:270,height:100,z:1},
  ];
  expect(searchWorkspace(doc,'Alpha bravo')[0].hits[0].id).toBe('markdown');
  expect(searchWorkspace(doc,'Visible orchid')[0].hits[0].id).toBe('rich');
  expect(searchWorkspace(doc,'Rich caption')[0].hits[0].id).toBe('photo');
  expect(searchWorkspace(doc,'Old caption')).toEqual([]);
  expect(searchSnippet(doc.boards.root.cards[0],'bravo')).toBe('Alpha bravo charlie');
 });
 it('retains tile-label and broken-shortcut matches while deduplicating live board titles',()=>{
  const doc=fixture();doc.boards.child.cards=[];doc.boards.root.cards[1].labelIds=['label'];
  expect(searchWorkspace(doc,'research archive').map(result=>result.board.id)).toEqual(['child']);
  expect(searchWorkspace(doc,'Reviewed').map(result=>[result.board.id,result.hits.map(card=>card.id)])).toEqual([['root',['tile']]]);
  doc.boards.root.cards.push({...doc.boards.root.cards[1],id:'broken',boardId:'toString',isShortcut:true,title:'Lost source'} as Card);
  expect(searchWorkspace(doc,'Lost source')[0].hits[0].id).toBe('broken');
 });
 it('does not record inherited names as visits but accepts a real own constructor board',()=>{
  const doc=fixture();for(const id of ['constructor','toString','__proto__'])expect(markBoardViewed(doc,id)).toBe(doc);
  const own={...doc,boards:{...doc.boards,constructor:{...doc.boards.child,id:'constructor',title:'Own constructor'}}};
  expect(markBoardViewed(own,'constructor','2026-10-26T10:00:00Z').boardActivity?.constructor).toEqual({viewedAt:'2026-10-26T10:00:00.000Z'});
 });
 it('maps normalized matches to original whole graphemes for compatible forms, case expansions and Arabic',()=>{
  for(const [text,query,expected] of [
   ['Ｆｕｌｌｗｉｄｔｈ','fullwidth','Ｆｕｌｌｗｉｄｔｈ'],
   ['oﬃce','ffi','ﬃ'],
   ['İstanbul','stan','stan'],
   ['İstanbul','i','İ'],
   ['Cafe\u0301','CAFÉ','Cafe\u0301'],
   ['  Alpha \t\n bravo  ','alpha   bravo','Alpha \t\n bravo'],
   ['سَلَام بِكُمْ','س','سَ'],
   ['👩‍💻 builds','💻','👩‍💻'],
   ['ΟΣ','ος','ΟΣ'],
  ]){
   const doc=fixture();doc.boards.root.cards=[note('unicode',text)];doc.boards.child.cards=[];
   expect(searchWorkspace(doc,query)[0]?.hits[0]?.id).toBe('unicode');
   const match=searchMatchRange(text,query);expect(match).not.toBeNull();expect(text.slice(match!.start,match!.end)).toBe(expected);
  }
  expect(searchMatchRange('Text','   ')).toBeNull();expect(searchMatchRange('Text','absent')).toBeNull();
 });
 it('keeps a distant match in its snippet without splitting emoji or combining clusters',()=>{
  const ligatures=searchSnippet(note('ligatures','ﬃ'.repeat(80)+' target '+ 'ز'.repeat(200)),'target');
  expect(ligatures).toContain('target');expect(ligatures.startsWith('…')).toBe(true);expect(searchMatchRange(ligatures,'target')).not.toBeNull();
  const combining=searchSnippet(note('combining','e\u0301'.repeat(80)+'needle'+'👩‍💻'.repeat(60)),'needle');
  expect(combining.startsWith('…e\u0301')).toBe(true);expect(combining.endsWith('👩‍💻…')).toBe(true);expect(combining).toContain('needle');
  const long='Ｆ'.repeat(170);expect(searchSnippet(note('long-match',long+' suffix'), 'f'.repeat(170))).toContain(long);
 });
 it('keeps epoch-zero and pre-epoch visits valid and sorts missing dates after them',()=>{
  const doc=fixture();doc.boardActivity={root:{viewedAt:'1970-01-01T00:00:00.000Z'},child:{viewedAt:'1969-12-31T23:59:59.000Z'}};
  expect(searchWorkspace(doc,'').map(result=>result.board.id)).toEqual(['root','child']);
  delete doc.boardActivity.root;expect(searchWorkspace(doc,'orchid','viewed').map(result=>result.board.id)).toEqual(['child','root']);
  expect(searchWorkspace(doc,'').map(result=>result.board.id)).toEqual(['child']);
 });
});
