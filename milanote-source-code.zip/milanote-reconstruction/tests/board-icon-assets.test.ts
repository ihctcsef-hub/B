import {readFileSync,readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {describe,expect,it} from 'vitest';
import {boardIconSvg,getReferenceBoardIcons} from '../src/core/boardIcons';
import assets from '../src/data/boardIconReferenceAssets.json';
import provenance from '../src/data/boardIconReferenceProvenance.json';

const sha=(bytes:Uint8Array|string)=>createHash('sha256').update(bytes).digest('hex');
const root=new URL('../',import.meta.url);
describe('captured board-icon visual assets',()=>{
  it('retains all1910 known asset identities with their exact canonical artifact digest',()=>{
    const ids=getReferenceBoardIcons().map(icon=>icon.id).sort();
    expect(Object.keys(assets.entries).sort()).toEqual(ids);
    expect(provenance.assets.map(asset=>asset.id).sort()).toEqual(ids);
    expect(provenance.identityCount).toBe(1910);
    expect(sha(readFileSync(new URL('src/data/boardIconReferenceAssets.json',root)))).toBe(provenance.canonicalAssetSha256);
    expect(provenance.referenceInventoryComplete).toBe(false);
    expect(provenance.relicensingClaimed).toBe(false);
  });
  it('keeps every original native48px fallback byte intact and does not invent missing legacy PNG resources',()=>{
    expect(readdirSync(new URL('public/board-icons/reference-48/',root)).filter(name=>name.endsWith('.png'))).toHaveLength(410);
    let totalBytes=0;
    expect(assets.rasterFallbackIds).toHaveLength(410);
    expect(provenance.assets.filter(asset=>'png' in asset)).toHaveLength(410);
    for(const asset of provenance.assets){
      if(!asset.png)continue;
      if(typeof asset.sourcePngUrl!=='string')throw new Error('Missing native PNG provenance');
      const bytes=readFileSync(new URL(`public/board-icons/reference-48/${asset.id}.png`,root));
      expect(bytes.length,asset.id).toBe(asset.png.bytes);
      expect(sha(bytes),asset.id).toBe(asset.png.sha256);
      expect([...bytes.subarray(0,8)],asset.id).toEqual([137,80,78,71,13,10,26,10]);
      expect(bytes.readUInt32BE(16),asset.id).toBe(48);expect(bytes.readUInt32BE(20),asset.id).toBe(48);
      const source=new URL(asset.sourceApiUrl),png=new URL(asset.sourcePngUrl);
      expect(source.origin).toBe('https://app.milanote.com');expect(source.pathname).toBe('/api//icons');
      expect([...source.searchParams.keys()].sort()).toEqual(['count','search']);
      expect(png.href).toBe(`https://static.milanote.com/element-icons/png/48x48/${asset.id}.png`);
      expect(asset.licenseEvidence).toBe('No license text in observed response.');
      totalBytes+=bytes.length;
    }
    expect(totalBytes).toBe(267337);
  });
  it('renders only path geometry and the measured secondary opacity, without captured executable markup',()=>{
    for(const [id,asset] of Object.entries(assets.entries)){
      expect(asset.viewBox,id).toHaveLength(4);expect(asset.viewBox.every(Number.isFinite),id).toBe(true);
      expect(asset.viewBox[2],id).toBeGreaterThan(0);expect(asset.viewBox[3],id).toBeGreaterThan(0);
      expect(asset.paths.length,id).toBeGreaterThan(0);
      for(const path of asset.paths){
        expect(path.d,id).toMatch(/^[MmZzLlHhVvCcSsQqTtAa\d\s.,+eE-]+$/);
        const safe=path as {opacity?:number;fill?:string;fillRule?:string;transform?:string};
        expect(Object.keys(path).every(key=>['d','opacity','fill','fillRule','transform'].includes(key)),id).toBe(true);
        if(safe.fill!==undefined)expect(safe.fill,id).toMatch(/^(?:none|#[a-f\d]{3}(?:[a-f\d]{3})?)$/i);
        if(safe.fillRule!==undefined)expect(safe.fillRule,id).toBe('evenodd');
        if(safe.transform!==undefined)expect(safe.transform,id).toMatch(/^translate\([-+\d.eE]+ [-+\d.eE]+\)$/);
        const opacity=safe.opacity;expect(opacity===undefined||opacity===.4,id).toBe(true);
      }
      const rendered=boardIconSvg(id)!;
      expect((rendered.match(/<path /g)||[]).length,id).toBe(asset.paths.length);
      expect(rendered,id).not.toMatch(/<defs|<style|<script|<image|<foreignObject|\bon\w+=|(?:href|src)=/);
    }
  });
  it('keeps popup and selected-board palettes separate and rejects markup in rendering options',()=>{
    expect(boardIconSvg('camera')).toContain('fill="#5f6672"');
    expect(boardIconSvg('camera',{color:'#323b4a',size:160})).toContain('fill="#323b4a"');
    expect(()=>boardIconSvg('camera',{color:'red" onload="bad'})).toThrow('Invalid board icon rendering options');
    expect(()=>boardIconSvg('camera',{size:Infinity})).toThrow();expect(()=>boardIconSvg('camera',{size:0})).toThrow();
  });
});
