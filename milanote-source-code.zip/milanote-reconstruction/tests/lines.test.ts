import { describe, expect, it } from "vitest";
import { attachConnectionHandle, connectionAnchorAt, connectionTargetAt, constrainConnectionPoint, straightenConnection, connectionBounds, connectionGeometry, moveConnectionHandle, pointOnConnection, quadraticControlForMidpoint } from "../src/core/lines";
import type { EditableConnection } from "../src/core/lines";
import { createCard } from "../src/core/model";
const free = (extra: Partial<EditableConnection> = {}): EditableConnection => ({ id: "line", from: "", to: "", start: { x: 10, y: 20 }, end: { x: 110, y: 20 }, color: "#323b4a", style: "solid", ...extra });

describe("line geometry", () => {
  it("renders a free line straight and retains negative endpoints", () => {
    const geometry = connectionGeometry(free(), []);
    expect(geometry?.path).toBe("M 10 20 L 110 20");
    expect(geometry?.midpoint).toEqual({ x: 60, y: 20 });
    expect(connectionBounds(free({ start: { x: -20, y: -40 } }), [], 8)).toEqual({ x: -28, y: -48, width: 146, height: 76 });
  });
  it("retains legacy cubic anchors in either horizontal direction", () => {
    const a = { ...createCard("note", 20, 40), id: "a", width: 100, height: 60 };
    const b = { ...createCard("note", 400, 120), id: "b", width: 100, height: 80 };
    const line = free({ from: "a", to: "b", start: undefined, end: undefined });
    expect(connectionGeometry(line, [a, b])).toMatchObject({ kind: "cubic", start: { x: 120, y: 70 }, end: { x: 400, y: 160 }, midpoint: { x: 260, y: 115 } });
    expect(connectionGeometry({ ...line, from: "b", to: "a" }, [a, b])).toMatchObject({ start: { x: 400, y: 160 }, end: { x: 120, y: 70 } });
    expect(connectionGeometry(line, [a])).toBeNull();
  });
  it("places the curve handle on the actual midpoint and computes curve extrema", () => {
    const desired = { x: 60, y: 90 };
    expect(quadraticControlForMidpoint({ x: 10, y: 20 }, { x: 110, y: 20 }, desired)).toEqual({ x: 60, y: 160 });
    const curved = moveConnectionHandle(free(), [], "control", desired);
    const geometry = connectionGeometry(curved, [])!;
    expect(geometry.midpoint).toEqual(desired);
    expect(pointOnConnection(geometry, 0.5)).toEqual(desired);
    expect(connectionBounds(curved, [])).toEqual({ x: 10, y: 20, width: 100, height: 70 });
    const asymmetric = free({ start: { x: 0, y: 0 }, end: { x: 100, y: 20 }, control: { x: 200, y: 100 } });
    const bounds = connectionBounds(asymmetric, [])!;
    expect(bounds.width).toBeCloseTo(133.3333333);
    expect(bounds.height).toBeCloseTo(55.5555555);
  });
  it("detaches only the dragged endpoint and uses the collapsed column's visual height", () => {
    const a = { ...createCard("column", 0, 0), id: "a", collapsed: true };
    const b = { ...createCard("note", 400, 100), id: "b" };
    const line = free({ from: "a", to: "b", start: undefined, end: undefined });
    expect(connectionGeometry(line, [a, b])?.start.y).toBe(31.1);
    const detached = moveConnectionHandle(line, [a, b], "start", { x: 15, y: 30 });
    expect(detached.from).toBe(""); expect(detached.to).toBe("b");
    expect(detached.start).toEqual({ x: 15, y: 30 });
    expect(connectionGeometry(detached, [a, b])).toMatchObject({ kind: "straight", start: { x: 15, y: 30 } });
    expect(line.from).toBe("a");
  });
  it("keeps cubic control overshoot inside exported bounds", () => {
    const a = { ...createCard("note", 0, 0), id: "a", width: 100, height: 50 };
    const b = { ...createCard("note", 120, 100), id: "b", width: 100, height: 50 };
    const line = free({ from: "a", to: "b", bend: 200 });
    const geometry = connectionGeometry(line, [a, b])!, bounds = connectionBounds(line, [a, b])!;
    for (let i = 0; i <= 100; i++) {
      const point = pointOnConnection(geometry, i / 100);
      expect(point.x).toBeGreaterThanOrEqual(bounds.x - 1e-8); expect(point.x).toBeLessThanOrEqual(bounds.x + bounds.width + 1e-8);
      expect(point.y).toBeGreaterThanOrEqual(bounds.y - 1e-8); expect(point.y).toBeLessThanOrEqual(bounds.y + bounds.height + 1e-8);
    }
  });
});

describe("line endpoint editing", () => {
  it("constrains to the nearest axis through the opposite endpoint", () => {
    expect(constrainConnectionPoint({ x: 50, y: 80 }, { x: 150, y: 100 })).toEqual({ x: 150, y: 80 });
    expect(constrainConnectionPoint({ x: 50, y: 80 }, { x: 60, y: -20 })).toEqual({ x: 50, y: -20 });
  });
  it("reattaches the dragged end to a topmost card and preserves the other end", () => {
    const column = { ...createCard("column", 0, 0), id: "column", width: 400, height: 400, z: 99 };
    const note = { ...createCard("note", 20, 40), id: "note", width: 100, height: 60, z: 1 };
    expect(connectionTargetAt({ x: 80, y: 70 }, [note, column])?.id).toBe("note");
    expect(connectionTargetAt({ x: 80, y: 70 }, [note, column], "note")?.id).toBe("column");
    const attached = attachConnectionHandle(free(), "end", note);
    expect(attached).toMatchObject({ from: "", to: "note", start: { x: 10, y: 20 } });
    expect(attached.end).toBeUndefined();
    expect(connectionGeometry(attached, [note])?.end).toEqual({ x: 20, y: 70 });
  });
  it("keeps a held exact anchor proportional when the card moves or resizes, then detaches it", () => {
    const card = { ...createCard("note", 100, 40), id: "target", width: 200, height: 100 };
    const point = { x: 150, y: 120 }, anchor = connectionAnchorAt(card, point);
    expect(anchor).toEqual({ x: .25, y: .8 });
    const pinned = attachConnectionHandle(free(), "end", card, anchor);
    expect(connectionGeometry(pinned, [card])).toMatchObject({ kind: "straight", end: point });
    const resized = { ...card, x: 200, y: 80, width: 400, height: 200 };
    expect(connectionGeometry(pinned, [resized])?.end).toEqual({ x: 300, y: 240 });
    const detached = moveConnectionHandle(pinned, [resized], "end", { x: 500, y: 500 });
    expect(detached.toAnchor).toBeUndefined();
    expect(detached.to).toBe("");
  });
  it("straightens both quadratic and legacy attached curves without discarding attachments", () => {
    const curved = free({ bend: 60, control: { x: 50, y: 200 } });
    expect(connectionGeometry(straightenConnection(curved), [])?.kind).toBe("straight");
    const a = { ...createCard("note", 0, 0), id: "a" }, b = { ...createCard("note", 400, 100), id: "b" };
    const attached = straightenConnection(free({ from: "a", to: "b", bend: 100, control: { x: 0, y: 200 } }));
    expect(attached).toMatchObject({ from: "a", to: "b", bend: 0 });
    const geometry = connectionGeometry(attached, [a, b])!;
    for (const t of [.2, .5, .8]) {
      const point = pointOnConnection(geometry, t);
      expect((point.x - geometry.start.x) * (geometry.end.y - geometry.start.y) - (point.y - geometry.start.y) * (geometry.end.x - geometry.start.x)).toBeCloseTo(0);
    }
  });
});
