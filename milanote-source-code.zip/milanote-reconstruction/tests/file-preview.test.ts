import {describe,it,expect,vi} from 'vitest';
import {decodePdfAttachment,pdfBytesDigest,readPdfAttachment} from '../src/core/pdfPreview';
import {filePreviewKind,pdfPreviewHeight,fileDetailHeight,attachmentSizeLabel,FILE_ICON_HEIGHT,FILE_ICON_WIDTH} from '../src/core/filePreview';

describe('measured file preview contracts',()=>{
  it('does not treat supported upload extensions as permission to invent an Office/archive thumbnail',()=>{
    for(const [name,mime] of [['document.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document'],['slides.pptx','application/vnd.openxmlformats-officedocument.presentationml.presentation'],['archive.zip','application/zip'],['source.psd','image/vnd.adobe.photoshop'],['note.txt','text/plain']])expect(filePreviewKind({name,mime})).toBe('icon');
    expect(filePreviewKind({name:'paper.PDF',mime:''})).toBe('pdf');
    expect(filePreviewKind({name:'paper.pdf',mime:'application/octet-stream'})).toBe('pdf');
    expect(filePreviewKind({name:'recording.webm',mime:'video/webm'})).toBe('video');
    expect(filePreviewKind({name:'recording.mp3',mime:'audio/mpeg'})).toBe('audio');
    expect(filePreviewKind({name:'fake.pdf',mime:'text/plain'})).toBe('icon');
  });
  it('reproduces the actual PDF geometry without replacing it with an ideal mathematical ratio',()=>{
    expect(pdfPreviewHeight(270,360,480)).toBe(358);
    expect(fileDetailHeight(358)).toBe(430.375);
    expect(fileDetailHeight(358,{showFileInfo:false,showCaption:true})).toBe(358);
    expect(fileDetailHeight(358,{showCaption:true})).toBe(462.375);
    expect(fileDetailHeight(358,{showCaption:true,captionHeight:64})).toBe(494.375);
    expect([FILE_ICON_WIDTH,FILE_ICON_HEIGHT]).toEqual([78,111.171875]);
  });
  it('refuses invalid geometry instead of poisoning stored card dimensions',()=>{
    for(const dimensions of [[0,360,480],[270,0,480],[270,360,NaN],[270,360,-1],[Infinity,360,480]])expect(()=>pdfPreviewHeight(...dimensions as [number,number,number])).toThrow();
  });
  it('decodes only bounded local PDF attachments and retains their exact bytes',()=>{
    const bytes=new Uint8Array([37,80,68,70,45,49,46,55,10,0,255]);
    const base64=btoa(String.fromCharCode(...bytes));
    expect(decodePdfAttachment('data:application/pdf;base64,'+base64)).toEqual(bytes);
    expect(decodePdfAttachment('data:application/octet-stream;base64,'+base64)).toEqual(bytes);
    for(const source of ['https://example.com/paper.pdf','data:text/html;base64,SGVsbG8=','data:application/pdf;base64,','data:application/pdf;base64,!!!!','data:application/pdf;base64,A'])expect(()=>decodePdfAttachment(source)).toThrow();
  });
  it('rejects an oversized attachment before allocating its decoded body',()=>{
    expect(()=>decodePdfAttachment('data:application/pdf;base64,'+'A'.repeat(20*1024*1024+4))).toThrow(/size limit/);
  });
  it('shows the measured KB/MB forms without a supplied MIME string replacing the file size',()=>{
    expect(attachmentSizeLabel(1047)).toBe('1 KB');expect(attachmentSizeLabel(10240)).toBe('10 KB');expect(attachmentSizeLabel(1572864)).toBe('1.5 MB');
  });
});


describe('PDF source identity and bounded public reads',()=>{
  it('computes the same SHA-256 with and without secure-context WebCrypto',async()=>{
    const bytes=new TextEncoder().encode('abc'),expected='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad';
    expect(await pdfBytesDigest(bytes)).toBe(expected);
    const original=globalThis.crypto;vi.stubGlobal('crypto',undefined);
    try{expect(await pdfBytesDigest(bytes)).toBe(expected);}finally{vi.stubGlobal('crypto',original);}
    expect([...bytes]).toEqual([97,98,99]);
  });
  it('reads only public HTTP(S) URLs with omitted credentials and no referrer',async()=>{
    const original=globalThis.fetch,fetcher=vi.fn(async()=>new Response(new Uint8Array([37,80,68,70])));vi.stubGlobal('fetch',fetcher);
    try{
      expect(await readPdfAttachment('https://example.com/template.pdf')).toEqual(new Uint8Array([37,80,68,70]));
      expect(fetcher).toHaveBeenCalledWith('https://example.com/template.pdf',{signal:undefined,credentials:'omit',referrerPolicy:'no-referrer'});
      for(const source of ['javascript:alert(1)','file:///etc/passwd','https://user:password@example.com/p.pdf','/relative.pdf'])await expect(readPdfAttachment(source)).rejects.toThrow();
      expect(fetcher).toHaveBeenCalledTimes(1);
    }finally{vi.stubGlobal('fetch',original);}
  });
  it('rejects an aborted request and oversized public attachment without decoding it',async()=>{
    const controller=new AbortController();controller.abort();await expect(readPdfAttachment('https://example.com/p.pdf',controller.signal)).rejects.toMatchObject({name:'AbortError'});
    const original=globalThis.fetch,cancel=vi.fn();
    vi.stubGlobal('fetch',vi.fn(async()=>new Response(new ReadableStream({cancel}),{headers:{'content-length':String(16*1024*1024)}})));
    try{await expect(readPdfAttachment('https://example.com/p.pdf')).rejects.toThrow(/size limit/);expect(cancel).toHaveBeenCalledTimes(1);}finally{vi.stubGlobal('fetch',original);}
  });
});
