import {openSavedTemplates} from './helpers/saved-templates.mjs';
import assert from "node:assert/strict";
import { mkdir, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { chromium } from "playwright-core";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const artifacts = path.join(root, "artifacts");
await mkdir(artifacts, { recursive: true });
for (const name of await readdir(artifacts)) if (/^customization-failure-\d+\.png$/.test(name)) await rm(path.join(artifacts, name));
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium", headless: true, args: ["--no-sandbox", "--disable-dev-shm-usage"] });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true });
// Provider frames are inspected as URLs only; no external media or service is loaded.
await context.route("**/*", route => {
  const url = new URL(route.request().url());
  if (["http:", "https:"].includes(url.protocol) && !["127.0.0.1", "localhost"].includes(url.hostname)) return route.abort();
  return route.continue();
});
const page = await context.newPage(); page.setDefaultTimeout(7000);
const results = [], pageErrors = [];
page.on("pageerror", error => pageErrors.push(error.message));
const card = id => page.locator(`[data-card-id="${id}"]`);
const readField = locator => locator.evaluate(element => "value" in element ? element.value : (element.textContent || "").trim());
const picker = () => page.getByRole("dialog", { name: "Edit swatch color", exact: true });
const fixture = cards => ({
  version: 1, id: "customization-workspace", title: "Customization workspace", rootBoardId: "customization-board", updatedAt: "2026-10-25T00:00:00.000Z",
  boards: { "customization-board": { id: "customization-board", title: "Customization test board", cards, connections: [], viewport: { x: 35, y: 40, zoom: 1 }, background: "#ebedee", grid: true } },
});
const swatch = { id: "swatch", type: "swatch", value: "#b7c3a5", label: "Quiet green", x: 100, y: 100, width: 230, height: 170, z: 1 };
const image = { id: "image", type: "image", src: "/assets/studio-objects.jpg", caption: "Original caption", x: 100, y: 100, width: 330, height: 280, z: 1 };
const link = { id: "link", type: "link", url: "https://example.com/", title: "Reference website", description: "A useful reference", previewSrc: "/assets/studio-objects.jpg", x: 550, y: 100, width: 330, height: 280, z: 1 };
async function importFixture(value) {
  await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({ name: "customization-fixture.json", mimeType: "application/json", buffer: Buffer.from(JSON.stringify(value)) });
  await page.waitForFunction(() => document.querySelector('input[type=file][accept="application/json,.json"]')?.value === "");
  await page.getByText("Workspace imported. Undo to return to your previous workspace.", { exact: true }).waitFor();
  await page.waitForFunction(() => document.querySelector('[aria-label="Current board title"]')?.value === "Customization test board");
}
async function run(name, fn) {
  try { await fn(); results.push({ name, status: "passed" }); console.log("PASS", name); }
  catch (error) {
    results.push({ name, status: "failed", message: error.stack }); process.exitCode = 1; console.error("FAIL", name, error.message);
    await page.screenshot({ path: path.join(artifacts, `customization-failure-${results.length}.png`), fullPage: true }).catch(() => {});
    await page.keyboard.press("Escape").catch(() => {});
  }
}
async function download(name, filename) {
  const pending = page.waitForEvent("download"); pending.catch(() => {});
  await page.getByRole("button", { name }).click(); const item = await pending, destination = path.join(artifacts, filename);
  await item.saveAs(destination); return readFile(destination, "utf8");
}
async function backup(filename) {
  await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();
  const data = JSON.parse(await download(/Workspace backup/, filename));
  await page.getByTitle("Close dialog", { exact: true }).click(); return data;
}
async function openPicker() {
  await card("swatch").getByRole("button", { name: "Color settings", exact: true }).click(); await picker().waitFor();
}
try {
  await page.goto(process.env.TEST_URL || "http://127.0.0.1:5187", { waitUntil: "domcontentloaded" });
  await page.getByText("Saved on this device", { exact: true }).waitFor();
  await run("Swatch color picker accepts HEX, RGB and HSL, validates input and updates native color channels", async () => {
    await importFixture(fixture([swatch])); await openPicker();
    const value = picker().getByLabel("Swatch color value", { exact: true });
    await value.fill("rgb(12, 34, 56)"); await value.press("Enter");
    assert.equal(await value.inputValue(), "#0c2238"); assert.equal(await picker().getByLabel("Color red", { exact: true }).inputValue(), "12");
    assert.equal(await card("swatch").locator(".colorSwatch-block").evaluate(el => getComputedStyle(el).backgroundColor), "rgb(12, 34, 56)");
    await value.fill("hsl(120, 100%, 50%)"); await value.press("Enter");
    assert.equal(await value.inputValue(), "#00ff00");
    await picker().getByLabel("Color red", { exact: true }).fill("255");
    assert.equal(await value.inputValue(), "#ffff00");
    await picker().getByLabel("Color hue", { exact: true }).fill("180");
    assert.equal(await value.inputValue(), "#00ffff");
    await value.fill("not a color"); await value.press("Enter");
    await picker().getByRole("alert").waitFor(); assert.equal(await value.getAttribute("aria-invalid"), "true");
    assert.equal(await card("swatch").locator(".colorSwatch-block").evaluate(el => getComputedStyle(el).backgroundColor), "rgb(0, 255, 255)");
    await value.fill("#f83"); await value.press("Enter"); assert.equal(await value.inputValue(), "#ff8833");
    await picker().getByRole("button", { name: "Close color picker", exact: true }).click();
  });
  await run("Swatch display formats, caption visibility and pasted color values survive JSON backup and reload", async () => {
    await importFixture(fixture([swatch])); await openPicker();
    await picker().getByLabel("Color display", { exact: true }).selectOption("rgb");
    assert.match(await card("swatch").locator(".colorSwatch-code").innerText(), /^rgb\(/i);
    await picker().getByLabel("Color display", { exact: true }).selectOption("hsl");
    assert.match(await card("swatch").locator(".colorSwatch-code").innerText(), /^hsl\(/i);
    await picker().getByLabel("Color display", { exact: true }).selectOption("off");
    assert.equal(await card("swatch").locator(".colorSwatch-code").count(), 0);
    await picker().getByLabel("Show color caption", { exact: true }).uncheck();
    assert.equal(await card("swatch").getByRole("button", { name: "Edit swatch caption", exact: true }).count(), 0);
    await picker().getByLabel("Show color caption", { exact: true }).check();
    await picker().getByLabel("Color display", { exact: true }).selectOption("hex");
    await picker().getByRole("button", { name: "Close color picker", exact: true }).click();
    await card("swatch").getByRole("button", { name: "Edit swatch caption", exact: true }).click();await page.getByRole("textbox",{name:"Swatch caption",exact:true}).fill("Amber accent");await page.getByLabel("Current board title",{exact:true}).click();
    await card("swatch").getByLabel("Color swatch", { exact: true }).evaluate(element => {
      const clipboardData = new DataTransfer(); clipboardData.setData("text/plain", "#aabbcc");
      element.dispatchEvent(new ClipboardEvent("paste", { clipboardData, bubbles: true, cancelable: true }));
    });
    assert.equal(await card("swatch").locator(".colorSwatch-code").innerText(), "#AABBCC");
    await page.getByText("Saved on this device", { exact: true }).waitFor(); await page.reload({ waitUntil: "domcontentloaded" });
    assert.equal(await card("swatch").locator(".captionEditor-view").innerText().then(value=>value.trimEnd()), "Amber accent");
    assert.equal(await card("swatch").locator(".colorSwatch-code").innerText(), "#AABBCC");
    const data = await backup("customization-swatch.json"), stored = data.boards["customization-board"].cards[0];
    assert.equal(stored.value, "#aabbcc"); assert.equal(stored.colorSpace, "hex"); assert.equal(stored.showCaption, true);
    await importFixture(data); assert.equal(await card("swatch").locator(".captionEditor-view").innerText().then(value=>value.trimEnd()), "Amber accent");
  });
  await run("Image caption toggling and editing retain the original text; double-click opens image editing", async () => {
    await importFixture(fixture([image]));
    await card("image").click({ position: { x: 5, y: 5 } });
    await page.getByTitle("Image caption", { exact: true }).click();
    assert.equal(await card("image").locator(".image-caption").count(), 0);
    assert.equal(await card("image").getByLabel("Image caption", { exact: true }).count(), 0);
    await page.getByTitle("Edit image caption", { exact: true }).click();
    const caption = card("image").getByLabel("Image caption", { exact: true });
    assert.equal(await readField(caption), "Original caption"); await caption.fill("A customized caption"); await caption.blur();
    await card("image").locator(".image-caption .captionEditor-view").waitFor();
    assert.equal(await card("image").locator(".image-caption").innerText(), "A customized caption");
    await card("image").dblclick({ position: { x: 30, y: 30 } });
    await page.getByRole("dialog", { name: "Edit image", exact: true }).waitFor();
    await page.getByRole("dialog", { name: "Edit image", exact: true }).getByRole("button", { name: "Cancel", exact: true }).click();
    const data = await backup("customization-image.json");
    assert.equal(data.boards["customization-board"].cards[0].caption, "A customized caption");
    assert.equal(data.boards["customization-board"].cards[0].showCaption, true);
  });
  await run("Link preview, info and caption switches preserve editable metadata and custom preview after reload", async () => {
    await importFixture(fixture([link])); await card("link").click({ position: { x: 5, y: 5 } });
    await page.getByTitle("Link preview", { exact: true }).click(); assert.equal(await card("link").locator(".link-preview").count(), 0);
    await page.getByTitle("Link info", { exact: true }).click(); assert.equal(await card("link").locator(".link-content").count(), 0);
    await page.getByTitle("Link caption", { exact: true }).click();
    assert.equal(await card("link").getByLabel("Link caption", { exact: true }).count(), 0);
    await page.getByTitle("Link info", { exact: true }).click();
    const captionView=card("link").locator(".link-caption .captionEditor-view");if(await captionView.count())await captionView.click();
    await card("link").getByRole("textbox", { name: "Link caption", exact: true }).fill("Read before sketching");
    await card("link").getByRole("textbox", { name: "Link caption", exact: true }).blur();
    await page.getByTitle("Rename link", { exact: true }).click();
    await card("link").getByLabel("Link title", { exact: true }).fill("Updated reference"); await card("link").getByLabel("Link title", { exact: true }).blur();
    await card("link").getByLabel("Link URL", { exact: true }).fill("https://example.com/updated"); await card("link").getByLabel("Link URL", { exact: true }).blur();
    await card("link").getByLabel("Link description", { exact: true }).fill("Custom link details"); await card("link").getByLabel("Link description", { exact: true }).blur();
    await card("link").getByRole("button", { name: "Done", exact: true }).click();
    await page.getByTitle("Link preview", { exact: true }).click();
    assert.equal(await card("link").locator(".link-content strong").innerText(), "Updated reference");
    assert.equal(await card("link").locator(".link-preview img").getAttribute("src"), "/assets/studio-objects.jpg");
    await page.getByText("Saved on this device", { exact: true }).waitFor(); await page.reload({ waitUntil: "domcontentloaded" });
    assert.equal(await card("link").locator(".link-caption").innerText(), "Read before sketching");
    assert.equal(await card("link").locator(".link-content p").innerText(), "Custom link details");
    const data = await backup("customization-link.json"), stored = data.boards["customization-board"].cards[0];
    assert.equal(stored.url, "https://example.com/updated"); assert.equal(stored.showPreview, true); assert.equal(stored.showInfo, true); assert.equal(stored.showCaption, true);
  });
  await run("Rich image and link captions retain selected marks and hyperlinks through reload, backup and HTML export", async () => {
    await importFixture(fixture([image, link])); await card("image").click({ position: { x: 5, y: 5 } });
    await page.getByTitle("Edit image caption", { exact: true }).click();
    let field = card("image").getByRole("textbox", { name: "Image caption", exact: true }); await field.fill("Natural textures"); await field.press("ControlOrMeta+a");
    await card("image").getByTitle("Caption Bold", { exact: true }).click(); await card("image").getByTitle("Finish caption", { exact: true }).click();
    assert.equal(await card("image").locator(".captionEditor-view strong").innerText(), "Natural textures");
    await card("link").click({ position: { x: 5, y: 5 } }); await page.getByTitle("Link caption", { exact: true }).click(); await card("link").locator(".link-caption .captionEditor-view").click();
    field = card("link").getByRole("textbox", { name: "Link caption", exact: true }); await field.fill("Useful visual reference"); await field.press("ControlOrMeta+a");
    await card("link").getByTitle("Caption Italic", { exact: true }).click(); await card("link").getByTitle("Caption text link", { exact: true }).click();
    await card("link").getByLabel("Caption link URL", { exact: true }).fill("https://example.com/reference"); await card("link").locator(".captionEditor-link").getByRole("button", { name: "Apply", exact: true }).click();
    await card("link").getByTitle("Finish caption", { exact: true }).click();
    assert.equal(await card("link").locator(".captionEditor-view a").getAttribute("href"), "https://example.com/reference"); assert.equal(await card("link").locator(".captionEditor-view em").innerText(), "Useful visual reference");
    await page.getByText("Saved on this device", { exact: true }).waitFor(); await page.reload({ waitUntil: "domcontentloaded" });
    assert.equal(await card("image").locator(".captionEditor-view strong").innerText(), "Natural textures"); assert.equal(await card("link").locator(".captionEditor-view a").getAttribute("href"), "https://example.com/reference");
    const stored=await backup("customization-rich-captions.json"); assert.match(stored.boards["customization-board"].cards.find(c=>c.id==="image").captionHtml, /<strong>Natural textures<\/strong>/); assert.match(stored.boards["customization-board"].cards.find(c=>c.id==="link").captionHtml, /https:\/\/example.com\/reference/);
    await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click(); const html=await download(/Board as HTML/, "customization-rich-captions.html"); await page.getByTitle("Close dialog", { exact: true }).click(); assert.match(html, /<strong>Natural textures<\/strong>/); assert.match(html, /https:\/\/example.com\/reference/);
  });
  await run('Global labels on multiple card types persist and assignment undo preserves other labels',async()=>{
    await importFixture(fixture([image,link]));await card('image').click({position:{x:5,y:5}});await page.getByTitle('Labels',{exact:true}).click();
    const menu=page.getByRole('dialog',{name:'Labels',exact:true});
    for(const label of ['Reference','Urgent','Visual']){const field=menu.getByLabel('Enter label name',{exact:true});await field.fill(label);await field.press('Enter');}
    await page.keyboard.press('Escape');assert.deepEqual(await card('image').locator('.labelBadges [role=button]').allInnerTexts(),['Reference','Urgent','Visual']);
    await page.getByTitle('Undo (⌘Z)',{exact:true}).click();assert.equal(await card('image').locator('.labelBadges [role=button]').count(),2);await page.getByTitle('Redo (⇧⌘Z)',{exact:true}).click();assert.equal(await card('image').locator('.labelBadges [role=button]').count(),3);
    await card('link').click({position:{x:5,y:5}});await page.getByTitle('Labels',{exact:true}).click();const field=menu.getByLabel('Enter label name',{exact:true});await field.fill('Reading');await field.press('Enter');await page.keyboard.press('Escape');
    assert.deepEqual(await card('link').locator('.labelBadges [role=button]').allInnerTexts(),['Reading']);const data=await backup('customization-labels.json');
    assert.deepEqual(data.boards['customization-board'].cards.find(c=>c.id==='image').tags,['Reference','Urgent','Visual']);assert.deepEqual(data.boards['customization-board'].cards.find(c=>c.id==='link').tags,['Reading']);assert.equal(data.labels.length,4);
    await importFixture(data);assert.equal(await card('image').locator('.labelBadges [role=button]').count(),3);
  });

  await run("Known media providers embed through the media toggle, restore previews and persist without loading provider services", async () => {
    const providers = [
      ["https://youtu.be/dQw4w9WgXcQ", "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ"],
      ["https://vimeo.com/123456789", "https://player.vimeo.com/video/123456789"],
      ["https://open.spotify.com/track/abc123", "https://open.spotify.com/embed/track/abc123"],
      ["https://soundcloud.com/artist/track", "https://w.soundcloud.com/player/?url=https%3A%2F%2Fsoundcloud.com%2Fartist%2Ftrack&auto_play=false"],
      ["https://www.ted.com/talks/sir_ken_robinson_do_schools_kill_creativity?language=en", "https://embed.ted.com/talks/sir_ken_robinson_do_schools_kill_creativity"],
      ["https://www.google.com/maps?q=London", "https://maps.google.com/maps?q=London&output=embed"],
    ];
    for (const [url, expected] of providers) {
      await importFixture(fixture([{ ...link, url, title: "Embedded media example" }]));
      await card("link").click({ position: { x: 5, y: 5 } });
      await page.getByTitle("Show media", { exact: true }).click();
      const frame = card("link").locator("iframe"); await frame.waitFor();
      assert.equal(await frame.getAttribute("src"), expected);
      assert.match(await frame.getAttribute("sandbox"), /allow-scripts/);
      await page.getByTitle("Show media", { exact: true }).click();
      assert.equal(await frame.count(), 0); assert.equal(await card("link").locator(".link-preview").count(), 1);
    }
    await page.getByTitle("Show media", { exact: true }).click();
    await page.getByText("Saved on this device", { exact: true }).waitFor(); await page.reload({ waitUntil: "domcontentloaded" });
    await card("link").locator("iframe").waitFor();
    const data = await backup("customization-media.json");
    assert.equal(data.boards["customization-board"].cards[0].showMedia, true);
    assert.equal(data.boards["customization-board"].cards[0].url, "https://www.google.com/maps?q=London");
    await importFixture(fixture([{ ...link, url: "https://unrecognized.example/embed?html=script" }]));
    await card("link").click({ position: { x: 5, y: 5 } });
    assert.equal(await page.getByTitle("Show media", { exact: true }).count(), 0);
    assert.equal(await card("link").locator("iframe").count(), 0);
  });
  await run("Board icon customization is undoable, survives navigation and reload, and remains in backups", async () => {
    const data = fixture([{ id: "child-tile", type: "board", boardId: "child-board", title: "Child board", x: 100, y: 100, width: 160, height: 160, z: 1 }]);
    data.boards["child-board"] = { id: "child-board", title: "Child board", parentBoardId: "customization-board", cards: [], connections: [], viewport: { x: 35, y: 40, zoom: 1 } };
    await importFixture(data); await card("child-tile").click({ position: { x: 5, y: 5 } });
    await page.getByTitle("Board icon", { exact: true }).click();await page.getByRole("button",{name:"Letters & numbers",exact:true}).click();await page.getByRole("button",{name:"Icon S",exact:true}).click();await page.keyboard.press("Escape");
    assert.equal(await card("child-tile").locator(".board-custom-icon").innerText(), "S");
    await page.getByTitle("Undo (⌘Z)", { exact: true }).click(); assert.equal(await card("child-tile").locator(".board-custom-icon").count(), 0);
    await page.getByTitle("Redo (⇧⌘Z)", { exact: true }).click(); assert.equal(await card("child-tile").locator(".board-custom-icon").innerText(), "S");
    await card("child-tile").locator(".board-symbol").dblclick();
    assert.equal(await page.getByLabel("Current board title", { exact: true }).inputValue(), "Child board");
    await page.getByRole("navigation", { name: "Board breadcrumb" }).getByRole("button", { name: "Customization test board", exact: true }).click();
    await page.getByText("Saved on this device", { exact: true }).waitFor(); await page.reload({ waitUntil: "domcontentloaded" });
    assert.equal(await card("child-tile").locator(".board-custom-icon").innerText(), "S");
    const stored = await backup("customization-board-icon.json"); assert.equal(stored.boards["child-board"].icon, "S");
  });
  await run("Saved custom templates snapshot a complete nested board and create independent editable copies", async () => {
    const data = fixture([image, { id: "template-child-tile", type: "board", boardId: "template-child", title: "Nested starter", x: 600, y: 100, width: 160, height: 160, z: 2 }]);
    data.boards["template-child"] = { id: "template-child", title: "Nested starter", parentBoardId: "customization-board", icon: "💡", cards: [{ id: "template-child-note", type: "note", text: "Nested template note", html: "<p>Nested template note</p>", x: 100, y: 100, width: 270, height: 54, z: 1 }], connections: [], viewport: { x: 35, y: 40, zoom: 1 } };
    await importFixture(data);
    await openSavedTemplates(page);
    await page.getByRole("button", { name: "Save current board as a template", exact: true }).click();
    const savedButton = page.locator(".templates button").filter({ hasText: "Customization test board template" }); await savedButton.waitFor();
    await page.getByTitle("Close dialog", { exact: true }).click();
    await card("image").click({ position: { x: 5, y: 5 } }); await page.getByTitle("Edit image caption", { exact: true }).click();
    await card("image").getByLabel("Image caption", { exact: true }).fill("Changed after saving"); await card("image").getByLabel("Image caption", { exact: true }).blur();
    await openSavedTemplates(page); await savedButton.click();
    const clonedImage = page.locator(".card-image");
    assert.equal(await clonedImage.locator(".image-caption").innerText(), "Original caption");
    assert.notEqual(await clonedImage.getAttribute("data-card-id"), "image");
    const child = page.locator(".card-board"); assert.notEqual(await child.getAttribute("data-card-id"), "template-child-tile");
    await child.locator(".board-symbol").dblclick();
    assert.equal(await page.getByLabel("Current board title", { exact: true }).inputValue(), "Nested starter");
    assert.equal(await page.locator(".card-note").innerText(), "Nested template note");
    assert.notEqual(await page.locator(".card-note").getAttribute("data-card-id"), "template-child-note");
    const stored = await backup("customization-templates.json");
    const templates = Object.values(stored.boards).filter(board => board.isTemplate); assert.equal(templates.length, 1);
    assert.equal(templates[0].cards.find(item => item.type === "image").caption, "Original caption");
    assert.equal(stored.boards["customization-board"].cards.find(item => item.id === "image").caption, "Changed after saving");
    const clone = Object.values(stored.boards).find(board => board.parentBoardId === "customization-board" && board.id !== "template-child");
    assert(clone && !clone.isTemplate); assert.equal(clone.cards.find(item => item.type === "image").caption, "Original caption");
    assert.notEqual(clone.cards.find(item => item.type === "board").boardId, "template-child");
  });
  await run("Uploaded media preferences and file renaming persist in the player and editable backup", async () => {
    const wav = Buffer.alloc(44); wav.write("RIFF", 0); wav.writeUInt32LE(36, 4); wav.write("WAVEfmt ", 8); wav.writeUInt32LE(16, 16); wav.writeUInt16LE(1, 20); wav.writeUInt16LE(1, 22); wav.writeUInt32LE(8000, 24); wav.writeUInt32LE(16000, 28); wav.writeUInt16LE(2, 32); wav.writeUInt16LE(16, 34); wav.write("data", 36);
    const media = { id: "media-file", type: "file", name: "voice.wav", mime: "audio/wav", dataUrl: `data:audio/wav;base64,${wav.toString("base64")}`, size: wav.length, x: 100, y: 100, width: 330, height: 200, z: 1 };
    await importFixture(fixture([media])); await card("media-file").click({ position: { x: 5, y: 5 } });
    await page.getByTitle("Loop media", { exact: true }).click(); await page.getByTitle("Autoplay media", { exact: true }).click();
    assert.deepEqual(await card("media-file").locator("audio").evaluate(el => ({ loop: el.loop, autoplay: el.autoplay })), { loop: true, autoplay: true });
    await page.getByTitle("Rename file", { exact: true }).click(); await card("media-file").getByLabel("File name", { exact: true }).fill("Recorded reference.wav"); await card("media-file").getByLabel("File name", { exact: true }).press("Enter");
    assert.equal(await card("media-file").locator("strong").innerText(), "Recorded reference.wav");
    await page.getByText("Saved on this device", { exact: true }).waitFor(); await page.reload({ waitUntil: "domcontentloaded" });
    assert.deepEqual(await card("media-file").locator("audio").evaluate(el => ({ loop: el.loop, autoplay: el.autoplay })), { loop: true, autoplay: true });
    const stored = (await backup("customization-media-file.json")).boards["customization-board"].cards[0];
    assert.equal(stored.name, "Recorded reference.wav"); assert.equal(stored.loop, true); assert.equal(stored.autoplay, true); assert.equal(stored.dataUrl, media.dataUrl);
  });
  await run("No uncaught browser errors", async () => assert.deepEqual(pageErrors, []));
} catch (error) { results.push({ name: "Harness failure", status: "failed", message: error.stack }); process.exitCode = 1; console.error(error); }
finally { await writeFile(path.join(artifacts, "customization-e2e-results.json"), JSON.stringify({ results, pageErrors }, null, 2)); await browser.close(); }
