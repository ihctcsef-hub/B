import { describe, expect, it } from 'vitest';
import { createWorkspace } from '../src/core/model';
import { saveBoardTemplate, instantiateBoardTemplate } from '../src/core/templates';
import { exportWorkspace, importWorkspace } from '../src/core/storage';

describe('saved board templates', () => {
  it('preserves an independent snapshot and creates editable descendants with fresh IDs', () => {
    const original = createWorkspace();
    const saved = saveBoardTemplate(original, original.rootBoardId);
    const template = Object.values(saved.boards).find(board => board.isTemplate)!;
    expect(template.cards).toHaveLength(original.boards[original.rootBoardId].cards.length);
    expect(template.cards.some(card => original.boards[original.rootBoardId].cards.some(old => old.id === card.id))).toBe(false);
    const restored = importWorkspace(exportWorkspace(saved));
    const instance = instantiateBoardTemplate(restored, template.id, restored.rootBoardId, 50, 60);
    const board = instance.workspace.boards[instance.boardId!];
    expect(board.isTemplate).toBeUndefined();
    expect(board.cards).toHaveLength(template.cards.length);
    const nested = board.cards.find(card => card.type === 'board');
    if (nested?.type === 'board') expect(instance.workspace.boards[nested.boardId].parentBoardId).toBe(board.id);
    board.cards[0].x = 9999;
    expect(template.cards[0].x).not.toBe(9999);
  });
});
