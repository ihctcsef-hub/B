import assert from 'node:assert/strict';
import { mkdir,writeFile } from 'node:fs/promises';
import { chromium,webkit } from 'playwright-core';

const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium';
const artifacts=new URL(`../artifacts/${engine==='webkit'?'webkit/':''}`,import.meta.url);await mkdir(artifacts,{recursive:true});
const browser=await(engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']}));
const context=await browser.newContext({viewport:{width:1440,height:1000}}),page=await context.newPage();page.setDefaultTimeout(10000);
const errors=[],results=[];page.on('pageerror',error=>errors.push(error.stack||error.message));
const pixel='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScLbtAAAAABJRU5ErkJggg==';
const fixture=()=>({version:1,id:'drawing-presentation-browser',title:'Drawing presentation',rootBoardId:'root',updatedAt:'2026-10-26T00:00:00Z',labels:[{id:'priority',name:'Priority',color:'#ad6fff'}],boards:{root:{id:'root',title:'Drawing and presentation',viewport:{x:34,y:21,zoom:.8},cards:[
  {id:'note',type:'note',text:'A note for presentation',labelIds:['priority'],tags:['Priority'],x:100,y:100,width:270,height:54,z:1},
  {id:'sketch',type:'sketch',paths:[{color:'#ed4b35',width:4,points:[{x:30,y:40},{x:100,y:40}]},{color:'#323b4a',width:2,points:[{x:40,y:100},{x:120,y:100}]}],background:'#ffffff',x:550,y:140,width:240,height:180,z:2},
  {id:'image',type:'image',src:'/assets/studio-objects.jpg',cutoutSrc:pixel,useCutout:true,showCaption:false,caption:'Processed image',x:900,y:100,width:100,height:100,z:3},
],connections:[]}}});
const card=id=>page.locator(`[data-card-id="${id}"]`);
async function workspace(){return page.evaluate(()=>new Promise((resolve,reject)=>{const open=indexedDB.open('visual-workspace');open.onerror=()=>reject(open.error);open.onsuccess=()=>{const db=open.result,tx=db.transaction('documents','readonly'),req=tx.objectStore('documents').get('workspace');req.onsuccess=()=>{resolve(req.result?.workspace);db.close();};req.onerror=()=>reject(req.error);};}));}
async function persisted(check){for(let i=0;i<100;i++){const doc=await workspace();if(doc&&check(doc))return doc;await page.waitForTimeout(50);}throw Error('Document change did not persist');}
let importIndex=0;
async function importFixture(){
  const next=fixture();next.id=`drawing-presentation-browser-${++importIndex}`;
  await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:`drawing-presentation-test-${importIndex}.json`,mimeType:'application/json',buffer:Buffer.from(JSON.stringify(next))});
  await page.getByText('Workspace imported. Undo to return to your previous workspace.',{exact:true}).waitFor();
  await persisted(doc=>doc.id===next.id&&doc.boards.root.cards.find(c=>c.id==='note').text==='A note for presentation'&&doc.boards.root.cards.length===3);
}
async function stroke(canvas,from,to){const rect=await canvas.boundingBox();await page.mouse.move(rect.x+from.x*rect.width,rect.y+from.y*rect.height);await page.mouse.down();await page.mouse.move(rect.x+to.x*rect.width,rect.y+to.y*rect.height,{steps:8});await page.mouse.up();}
async function sketchEditor(){const editor=page.getByRole('dialog',{name:'Edit sketch',exact:true});await editor.waitFor();return editor;}
async function present(){
  await page.getByTitle('View',{exact:true}).click();await page.getByRole('menuitem',{name:'Present',exact:true}).click();
  const mode=page.getByRole('dialog',{name:'Presentation mode',exact:true});await mode.waitFor();return mode;
}
async function run(name,action){try{await action();results.push({name,status:'passed'});console.log('PASS',name);}catch(error){results.push({name,status:'failed',message:error.stack});process.exitCode=1;console.error('FAIL',name,error.message);await page.screenshot({path:new URL(`presentation-drawing-failure-${results.length}.png`,artifacts).pathname,fullPage:true}).catch(()=>{});throw error;}}
try{
  await page.goto(process.env.TEST_URL||'http://127.0.0.1:5278',{waitUntil:'networkidle'});await page.getByText('Saved on this device',{exact:true}).waitFor();
  await run('Board drawing saves multiple strokes as one editable card and one workspace undo transaction',async()=>{
    await importFixture();await page.getByTitle('Draw (P)',{exact:true}).click();const editor=page.getByRole('dialog',{name:'Draw on board',exact:true}),canvas=editor.getByLabel('Drawing canvas');await editor.waitFor();
    await stroke(canvas,{x:.15,y:.2},{x:.35,y:.24});await stroke(canvas,{x:.18,y:.35},{x:.38,y:.4});assert.equal(await canvas.locator('path').count(),2);
    assert.equal((await workspace()).boards.root.cards.length,3);await editor.getByRole('button',{name:'Save',exact:true}).click();
    const saved=await persisted(doc=>doc.boards.root.cards.length===4);const added=saved.boards.root.cards.find(c=>!['note','sketch','image'].includes(c.id));assert.equal(added.type,'sketch');assert.equal(added.paths.length,2);assert.equal(added.background,'transparent');assert.ok(added.width<1000&&added.height<700);
    await page.locator('.stage').click({position:{x:20,y:20}});await page.keyboard.press('Control+z');await persisted(doc=>doc.boards.root.cards.length===3);assert.equal(await card(added.id).count(),0);
    await page.keyboard.press('Control+Shift+z');await persisted(doc=>doc.boards.root.cards.length===4);await card(added.id).dblclick({position:{x:10,y:10}});const reopened=await sketchEditor();assert.equal(await reopened.getByLabel('Drawing canvas').locator('path').count(),2);await reopened.getByRole('button',{name:'Cancel',exact:true}).click();
  });
  await run('Existing drawing supports selection movement, delete, erase, undo, redo and cancel without mutating saved paths',async()=>{
    await importFixture();await card('sketch').dblclick({position:{x:10,y:10}});const editor=await sketchEditor(),canvas=editor.getByLabel('Drawing canvas');const original=await canvas.locator('path').first().getAttribute('d');
    await editor.getByRole('button',{name:'Selection tool',exact:true}).click();await stroke(canvas,{x:.05,y:.12},{x:.5,y:.3});assert.equal(await canvas.locator('[data-drawing-selection]').count(),1);const second=await canvas.locator('path').nth(1).getAttribute('d');await stroke(canvas,{x:.25,y:40/180},{x:.35,y:50/180});assert.notEqual(await canvas.locator('path').first().getAttribute('d'),original);assert.equal(await canvas.locator('path').nth(1).getAttribute('d'),second);await editor.getByRole('button',{name:'Undo drawing',exact:true}).click();assert.equal(await canvas.locator('path').first().getAttribute('d'),original);await page.keyboard.press('Control+a');assert.equal(await canvas.locator('[data-drawing-selection]').count(),1);await page.keyboard.press('ArrowRight');assert.notEqual(await canvas.locator('path').first().getAttribute('d'),original);
    await editor.getByRole('button',{name:'Delete selected drawing',exact:true}).click();assert.equal(await canvas.locator('path').count(),0);await editor.getByRole('button',{name:'Undo drawing',exact:true}).click();assert.equal(await canvas.locator('path').count(),2);await editor.getByRole('button',{name:'Undo drawing',exact:true}).click();assert.equal(await canvas.locator('path').first().getAttribute('d'),original);
    await editor.getByRole('button',{name:'Eraser',exact:true}).click();const rect=await canvas.boundingBox();await page.mouse.click(rect.x+60/240*rect.width,rect.y+40/180*rect.height);assert.equal(await canvas.locator('path').count(),1);
    await editor.getByRole('button',{name:'Undo drawing',exact:true}).click();assert.equal(await canvas.locator('path').count(),2);await editor.getByRole('button',{name:'Redo drawing',exact:true}).click();assert.equal(await canvas.locator('path').count(),1);
    await editor.getByRole('button',{name:'Cancel',exact:true}).click();const saved=await workspace();assert.deepEqual(saved.boards.root.cards.find(c=>c.id==='sketch').paths,fixture().boards.root.cards.find(c=>c.id==='sketch').paths);
  });
  await run('Drawing color, width and Escape save survive reopen and reload',async()=>{
    await card('sketch').dblclick({position:{x:10,y:10}});const editor=await sketchEditor(),canvas=editor.getByLabel('Drawing canvas');await editor.getByRole('button',{name:'Drawing color',exact:true}).click();await editor.getByRole('button',{name:'Drawing color #9359b4',exact:true}).click();await editor.getByRole('button',{name:'Line weight',exact:true}).click();await editor.getByRole('button',{name:'Line weight 4',exact:true}).click();await stroke(canvas,{x:.2,y:.75},{x:.7,y:.8});await editor.focus();await page.keyboard.press('Escape');
    await persisted(doc=>doc.boards.root.cards.find(c=>c.id==='sketch').paths.length===3);await page.reload({waitUntil:'networkidle'});await card('sketch').dblclick({position:{x:10,y:10}});const reopened=await sketchEditor();assert.equal(await reopened.getByLabel('Drawing canvas').locator('path').count(),3);const path=reopened.getByLabel('Drawing canvas').locator('path').last();assert.equal(await path.getAttribute('stroke'),'#9359b4');assert.equal(await path.getAttribute('stroke-width'),'8');await reopened.getByRole('button',{name:'Cancel',exact:true}).click();
  });
  await run('Presentation preserves viewport, hides grid, uses processed images and renders colored labels in focused duplicate',async()=>{
    await importFixture();await page.evaluate(()=>localStorage.removeItem('canvas-presentation-preferences-v1'));const mode=await present();assert.match(await mode.locator('.presentation-world').getAttribute('style'),/translate\(34px, 21px\) scale\(0.8\)/);
    assert.equal(await mode.locator('.presentation-stage').evaluate(el=>getComputedStyle(el).backgroundImage),'none');assert.equal((await mode.locator('.presentation-header').boundingBox()).height,80);
    assert.equal(await mode.getByRole('switch',{name:'Focus on selected cards',exact:true}).isChecked(),true);assert.equal(await mode.getByRole('switch',{name:'Prevent editing',exact:true}).isChecked(),false);assert.equal(await mode.getByRole('switch',{name:'Hide comments',exact:true}).isChecked(),false);
    assert.equal(await mode.locator('[data-presentation-card="image"] img').getAttribute('src'),pixel);assert.equal(await mode.locator('[data-presentation-card="note"]').getByRole('button',{name:'Label Priority',exact:true}).count(),1);
    const before=await mode.locator('.presentation-world').getAttribute('style');await mode.locator('[data-presentation-card="note"]').click({position:{x:10,y:10}});const focus=mode.locator('[data-presentation-focus="note"]');await focus.waitFor();assert.equal((await focus.boundingBox()).width,540);assert.equal(await mode.locator('.presentation-world').getAttribute('style'),before);assert.equal(await focus.getByRole('button',{name:'Label Priority',exact:true}).count(),1);await mode.getByLabel('Focused card',{exact:true}).click({position:{x:10,y:10}});assert.equal(await focus.count(),0);await mode.focus();await page.keyboard.press('Escape');await mode.waitFor({state:'hidden'});
  });
  await run('Presentation preferences persist; prevent editing blocks note mutation and movement, while editing callbacks save normally',async()=>{
    const mode=await present();await mode.getByRole('switch',{name:'Focus on selected cards',exact:true}).uncheck();await mode.getByRole('switch',{name:'Prevent editing',exact:true}).check();assert.equal(await mode.getByRole('menu',{name:'Presentation settings',exact:true}).isVisible(),true);
    const item=mode.locator('[data-presentation-card="note"]'),before=await item.boundingBox();await item.dblclick({position:{x:10,y:10}});assert.equal(await mode.getByLabel('Presentation note text').count(),0);await stroke(item,{x:.1,y:.1},{x:.5,y:.5});assert.equal((await item.boundingBox()).x,before.x);
    await mode.focus();await page.keyboard.press('Escape');await mode.waitFor({state:'hidden'});const reopened=await present();assert.equal(await reopened.getByRole('switch',{name:'Focus on selected cards',exact:true}).isChecked(),false);assert.equal(await reopened.getByRole('switch',{name:'Prevent editing',exact:true}).isChecked(),true);await reopened.getByRole('switch',{name:'Prevent editing',exact:true}).uncheck();await reopened.locator('[data-presentation-card="note"]').dblclick({position:{x:10,y:10}});const text=reopened.getByLabel('Presentation note text');await text.waitFor();await text.fill('Edited while presenting');await reopened.locator('.presentation-board-heading').click({position:{x:500,y:10}});await persisted(doc=>doc.boards.root.cards.find(c=>c.id==='note').text==='Edited while presenting');
    const movable=reopened.locator('[data-presentation-card="note"]'),box=await movable.boundingBox();await page.mouse.move(box.x+4,box.y+4);await page.mouse.down();await page.mouse.move(box.x+84,box.y+44,{steps:8});await page.mouse.up();const saved=await persisted(doc=>doc.boards.root.cards.find(c=>c.id==='note').x>150);assert.ok(saved.boards.root.cards.find(c=>c.id==='note').y>100);await reopened.focus();await page.keyboard.press('Escape');
  });
  assert.deepEqual(errors,[]);await page.screenshot({path:new URL('presentation-drawing-preview.png',artifacts).pathname,fullPage:true});
}finally{await writeFile(new URL('presentation-drawing-results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),engine,url:process.env.TEST_URL||'http://127.0.0.1:5278',results,errors},null,2));await browser.close();}
