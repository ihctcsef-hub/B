import {beforeAll,describe,expect,it} from 'vitest';
import {readFile} from 'node:fs/promises';
import {PDFArray,PDFDict,PDFDocument,PDFHexString,PDFName,PDFRawStream,decodePDFRawStream} from 'pdf-lib';
import {canPaintPdfText,embedPdfFonts,paintPdfText,pdfFontFileForText,selectPdfFont,type PdfFontFile,type PdfFontSet} from '../src/core/pdfFonts';
const loadFont=async(file:PdfFontFile)=>new Uint8Array(await readFile(new URL(`../public/fonts/pdf/${file}`,import.meta.url)));
let pdf:PDFDocument,fonts:PdfFontSet;
beforeAll(async()=>{pdf=await PDFDocument.create();fonts=await embedPdfFonts(pdf,{loadFont});});
describe('genuine PDF text fonts',()=>{
 it('loads only the requested unique font faces without registering unused page text',async()=>{
  const doc=await PDFDocument.create(),reads:PdfFontFile[]=[];
  const selected=await embedPdfFonts(doc,{fontFiles:['Inter-Regular.ttf','Inter-Regular.ttf'],loadFont:async file=>{reads.push(file);return loadFont(file);}});
  expect(reads).toEqual(['Inter-Regular.ttf']);expect([...selected.keys()]).toEqual(['Inter-Regular.ttf']);
  expect(pdfFontFileForText('Arabic مرحبا')).toBeNull();expect(pdfFontFileForText('مرحبا',{weight:700})).toBe('NotoSansArabic-Bold.ttf');
  expect(selectPdfFont(selected,'مرحبا')).toBeNull();
 });
 it('selects separately embedded rich-text faces and refuses missing glyphs and unsupported bidi mixes',()=>{
  expect(selectPdfFont(fonts,'Readable text')?.file).toBe('Inter-Regular.ttf');
  expect(selectPdfFont(fonts,'Bold italic',{weight:700,italic:true})?.file).toBe('Inter-BoldItalic.ttf');
  expect(selectPdfFont(fonts,'مرحبا بالعالم')?.file).toBe('NotoSansArabic-Regular.ttf');
  for(const text of ['English مرحبا','مرحبا123','مرحبا١٢٣','👩‍💻','漢字','line\nbreak','\u202bمرحبا\u202c'])expect(selectPdfFont(fonts,text)).toBeNull();
  expect(selectPdfFont(fonts,'مرحبا',{italic:true})).toBeNull();
  expect(canPaintPdfText(fonts,{text:'مرحبا',fontSize:12,width:30})).toBe(true);
  for(const run of [{text:'Example',fontSize:12,width:0},{text:'Example',fontSize:12,width:1e8},{text:'A مرحبا',fontSize:12,width:70}])expect(canPaintPdfText(fonts,run)).toBe(false);
 });
 it('paints visible embedded glyph text operators and retains exact logical Arabic ActualText',async()=>{
  const page=pdf.addPage([600,400]);
  const text='مرحبا بالعالم';expect(paintPdfText(pdf,page,{text,x:20,y:280,fontSize:22,width:180,color:[0,0,0]})).toBe(true);
  expect(paintPdfText(pdf,page,{text:'Visible vector',x:20,y:240,fontSize:14,width:100,color:[.2,.3,.4],weight:700})).toBe(true);
  const restored=await PDFDocument.load(await pdf.save());const first=restored.getPage(0),resources=first.node.Resources()!;
  const properties=resources.lookup(PDFName.of('Properties'),PDFDict);
  const values=properties.entries().map(([,ref])=>restored.context.lookup(ref,PDFDict).lookup(PDFName.of('ActualText'),PDFHexString).decodeText());
  expect(values).toEqual([text,'Visible vector']);
  const contents=first.node.Contents()!;const streams=contents instanceof PDFArray?contents.asArray():[contents];
  const operators=streams.map(ref=>{const stream=restored.context.lookup(ref);if(!(stream instanceof PDFRawStream))throw new Error('Expected a PDF content stream');return new TextDecoder().decode(decodePDFRawStream(stream).decode());}).join('\n');
  expect(operators).toContain(' BDC');expect(operators).toContain(' Tj');expect(operators).toContain('BT');expect(operators).not.toMatch(/\b3 Tr\b/);
  expect(resources.lookup(PDFName.of('Font'),PDFDict).entries()).toHaveLength(2);
 });
 it('validates tracked text before removal and retains unsupported cluster shaping in raster',()=>{
  expect(canPaintPdfText(fonts,{text:'office affinity AVATAR',fontSize:11.2,width:110,letterSpacing:-.08})).toBe(true);
  expect(canPaintPdfText(fonts,{text:'Spaced text',fontSize:11.2,width:100,letterSpacing:1.5})).toBe(true);
  for(const run of [{text:'مرحبا',fontSize:12,width:30,letterSpacing:-.08},{text:'e\u0301',fontSize:12,width:20,letterSpacing:1},{text:'Text',fontSize:12,width:30,letterSpacing:NaN},{text:'Text',fontSize:12,width:30,letterSpacing:20}])expect(canPaintPdfText(fonts,run)).toBe(false);
 });
 it('does not create content or a replacement text span for unsupported runs or invalid measurements',async()=>{
  const doc=await PDFDocument.create();await embedPdfFonts(doc,{loadFont});const page=doc.addPage();
  const run={text:'Example',x:10,y:20,fontSize:12,width:70,color:[0,0,0] as const};
  for(const invalid of [{...run,text:'A مرحبا'},{...run,width:0},{...run,fontSize:NaN},{...run,color:[2,0,0] as const},{...run,width:1e8}])expect(paintPdfText(doc,page,invalid)).toBe(false);
  expect(page.node.Contents()).toBeUndefined();expect(page.node.Resources()?.get(PDFName.of('Properties'))).toBeUndefined();
 });
});
