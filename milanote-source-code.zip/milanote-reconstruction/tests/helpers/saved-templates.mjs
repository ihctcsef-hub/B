/** The custom template library remains available in the workspace sidebar. */
export async function openSavedTemplates(page){
  if(!await page.getByRole('button',{name:'Saved templates & starters',exact:true}).isVisible())await page.getByTitle('Show boards',{exact:true}).click();
  await page.getByRole('button',{name:'Saved templates & starters',exact:true}).click();
  await page.locator('.modal-templates').waitFor();
}
