/** Inspect the actual canvas transform, independently of a zoom label. */
export async function renderedZoom(page){return page.locator('.stage .world').evaluate(element=>new DOMMatrix(getComputedStyle(element).transform).a);}
export async function fitBoard(page){await page.getByTitle('View',{exact:true}).click();await page.getByRole('menu',{name:'Board view',exact:true}).getByRole('menuitem',{name:'Scale to fit',exact:true}).click();await page.keyboard.press('Escape');}
