import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { chromium } from 'playwright-core';

const artifacts=new URL('../artifacts/',import.meta.url);await mkdir(artifacts,{recursive:true});
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
const context=await browser.newContext({viewport:{width:1440,height:1000},acceptDownloads:true});
const page=await context.newPage();page.setDefaultTimeout(10000);const results=[],pageErrors=[];
page.on('pageerror',error=>pageErrors.push(error.stack||error.message));
const card=id=>page.locator(`[data-card-id="${id}"]`);
const popup=()=>page.getByRole('dialog',{name:'Labels',exact:true});
const fixture=()=>({version:1,id:'labels-workspace',title:'Labels parity board',rootBoardId:'root',updatedAt:'2026-10-25T00:00:00Z',labels:[{id:'global',name:'Global',color:'#4ebafd'}],boards:{root:{id:'root',title:'Labels parity board',cards:[{id:'a',type:'note',text:'First item',x:100,y:150,width:270,height:54,z:1,labelIds:['global'],tags:['Global']},{id:'b',type:'note',text:'Second item',x:550,y:150,width:270,height:54,z:1},{id:'child-tile',type:'board',boardId:'child',title:'Nested',x:100,y:410,width:160,height:160,z:1}],connections:[],viewport:{x:20,y:20,zoom:1}},child:{id:'child',title:'Nested',parentBoardId:'root',cards:[{id:'c',type:'note',text:'Nested item',x:100,y:100,width:270,height:54,z:1,labelIds:['global'],tags:['Global']}],connections:[],viewport:{x:20,y:20,zoom:1}}}});
async function load(data=fixture()){
  await page.keyboard.press('Escape');
  await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'labels.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(data))});
  await page.getByText('Workspace imported. Undo to return to your previous workspace.',{exact:true}).waitFor();
  await page.getByText('Saved on this device',{exact:true}).waitFor();
}
async function open(ids=['a']){
  for(let i=0;i<ids.length;i++)await card(ids[i]).click({position:{x:3,y:3},modifiers:i?['Shift']:[]});
  await page.getByTitle('Labels',{exact:true}).click();await popup().waitFor();
}
async function close(){await page.getByLabel('Current board title',{exact:true}).click();await popup().waitFor({state:'detached'});}
async function backup(filename){
  await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();const pending=page.waitForEvent('download');pending.catch(()=>{});
  await page.getByRole('button',{name:/Workspace backup/}).click();const download=await pending,path=new URL(filename,artifacts);await download.saveAs(path.pathname);
  await page.getByTitle('Close dialog',{exact:true}).click();return JSON.parse(await readFile(path,'utf8'));
}
async function run(name,callback){try{await callback();results.push({name,status:'passed'});console.log('PASS',name);}catch(error){results.push({name,status:'failed',message:error.stack});process.exitCode=1;console.error('FAIL',name,error.message);await page.screenshot({path:new URL(`labels-failure-${results.length}.png`,artifacts).pathname,fullPage:true}).catch(()=>{});await page.keyboard.press('Escape').catch(()=>{});}}
try{
  await page.goto(process.env.TEST_URL||'http://127.0.0.1:5200',{waitUntil:'networkidle'});await page.getByText('Saved on this device',{exact:true}).waitFor();
  await run('Create label uses the observed 30-character field, assigns only selected items, and keeps the menu open',async()=>{
    await load();await open();const input=popup().getByLabel('Enter label name',{exact:true});assert.equal(await input.getAttribute('maxlength'),'30');
    await input.fill('Review');await input.press('Enter');await popup().getByRole('checkbox',{name:'Review',exact:true}).waitFor();assert.equal(await popup().getByRole('checkbox',{name:'Review',exact:true}).getAttribute('aria-checked'),'true');
    assert.equal(await card('a').getByRole('button',{name:'Label Review',exact:true}).count(),1);assert.equal(await card('b').getByRole('button',{name:'Label Review',exact:true}).count(),0);
    const rect=await popup().boundingBox();assert.equal(Math.round(rect.width),240);assert.equal(Math.round(rect.x),49);
    await close();const data=await backup('labels-created.json');assert.equal(data.labels.filter(label=>label.name==='Review').length,1);assert.equal(data.boards.root.cards.find(card=>card.id==='a').tags.includes('Review'),true);
  });
  await run('Mixed assignment adds/removes the label across the whole selection and preserves other boards',async()=>{
    await load();await open(['a','b']);const checkbox=popup().getByRole('checkbox',{name:'Global',exact:true});assert.equal(await checkbox.getAttribute('aria-checked'),'mixed');
    await checkbox.click();assert.equal(await checkbox.getAttribute('aria-checked'),'true');assert.equal(await card('b').getByRole('button',{name:'Label Global',exact:true}).count(),1);
    await checkbox.click();assert.equal(await checkbox.getAttribute('aria-checked'),'false');await close();const data=await backup('labels-mixed.json');assert.deepEqual(data.boards.root.cards.find(card=>card.id==='a').labelIds,[]);assert.deepEqual(data.boards.root.cards.find(card=>card.id==='b').labelIds,[]);assert.deepEqual(data.boards.child.cards[0].labelIds,['global']);
  });
  await run('Rename and color update every usage, while the usage count searches labeled items across boards',async()=>{
    await load();await open();await popup().getByRole('button',{name:'Open actions for Global',exact:true}).click();await popup().getByRole('menuitem',{name:'Rename',exact:true}).click();
    const rename=popup().getByRole('textbox',{name:'Edit name',exact:true});await rename.fill('Checked');await rename.press('Enter');assert.equal(await card('a').getByRole('button',{name:'Label Checked',exact:true}).count(),1);
    await popup().getByRole('button',{name:'Open actions for Checked',exact:true}).click();await popup().getByRole('menuitem',{name:'Change color',exact:true}).click();await popup().getByRole('button',{name:'Label color #ad6fff',exact:true}).click();
    assert.equal(await card('a').getByRole('button',{name:'Label Checked',exact:true}).evaluate(element=>getComputedStyle(element).backgroundColor),'rgb(173, 111, 255)');
    await popup().getByRole('button',{name:'Find items with label Checked',exact:true}).click();await page.locator('.modal-search').waitFor();assert.equal(await page.getByRole('searchbox',{name:'Search workspace',exact:true}).inputValue(),'Checked');assert.equal(await page.locator('.workspace-search .search-inner-hit').count(),2);
    await page.keyboard.press('Escape');const data=await backup('labels-renamed.json');assert.deepEqual(data.labels,[{id:'global',name:'Checked',color:'#ad6fff'}]);assert.deepEqual(data.boards.child.cards[0].tags,['Checked']);
    await page.getByText('Saved on this device',{exact:true}).waitFor();await page.reload({waitUntil:'networkidle'});assert.equal(await card('a').getByRole('button',{name:'Label Checked',exact:true}).count(),1);
  });
  await run('Deleting a focused badge removes only its assignment; global delete is undone as one transaction',async()=>{
    await load();await card('a').getByRole('button',{name:'Label Global',exact:true}).click();await page.keyboard.press('Delete');assert.equal(await card('a').count(),1);assert.equal(await card('a').getByRole('button',{name:'Label Global',exact:true}).count(),0);
    await open(['b']);await popup().getByRole('button',{name:'Open actions for Global',exact:true}).click();await popup().getByRole('menuitem',{name:'Delete',exact:true}).click();assert.equal(await popup().getByRole('checkbox',{name:'Global',exact:true}).count(),0);await close();
    let data=await backup('labels-deleted.json');assert.deepEqual(data.labels,[]);assert.deepEqual(data.boards.child.cards[0].labelIds,[]);
    await page.getByTitle('Undo (⌘Z)',{exact:true}).click();data=await backup('labels-delete-undo.json');assert.equal(data.labels[0].id,'global');assert.deepEqual(data.boards.child.cards[0].labelIds,['global']);assert.deepEqual(data.boards.root.cards.find(card=>card.id==='a').labelIds,[]);
  });
  await run('Badge double-click renames globally and a labeled nested board survives clipboard copy plus backup reload',async()=>{
    await load();const badge=card('a').getByRole('button',{name:'Label Global',exact:true});await badge.dblclick();const field=card('a').getByRole('textbox',{name:'Rename label Global',exact:true});await field.fill('Everywhere');await field.press('Enter');
    assert.equal(await card('a').getByRole('button',{name:'Label Everywhere',exact:true}).count(),1);await card('child-tile').click({position:{x:3,y:3}});await page.keyboard.press('Control+c');await page.keyboard.press('Control+v');
    const data=await backup('labels-copied.json');const copies=data.boards.root.cards.filter(card=>card.type==='board');assert.equal(copies.length,2);const copied=copies.find(card=>card.id!=='child-tile');assert.deepEqual(data.boards[copied.boardId].cards[0].labelIds,['global']);assert.deepEqual(data.boards[copied.boardId].cards[0].tags,['Everywhere']);
    await load(data);assert.equal(await card('a').getByRole('button',{name:'Label Everywhere',exact:true}).count(),1);
    await open();await popup().getByRole('button',{name:'Open actions for Everywhere',exact:true}).click();await popup().getByRole('menuitem',{name:'Change color',exact:true}).click();await page.screenshot({path:new URL('labels-preview.png',artifacts).pathname,fullPage:true});
  });
  assert.deepEqual(pageErrors,[]);results.push({name:'No uncaught browser errors',status:'passed'});
}finally{await writeFile(new URL('labels-e2e-results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),url:process.env.TEST_URL||'http://127.0.0.1:5200',results,pageErrors},null,2));await browser.close();}
