import { describe, expect, it } from "vitest";
import {
  noteContentHtml,
  richHtmlToMarkdown,
  richHtmlToPlainText,
  safeNoteLink,
  safeCalloutIcon,
  sanitizeNoteHtml,
} from "../src/core/richText";
import { renderNoteHtml } from "../src/core/text";

describe("rich note content", () => {
  it("migrates legacy Markdown with the established safe renderer", () => {
    const legacy = "# A **bold** idea\n\n*Soft* and ++underlined++\n- First\n- Second\n\nLiteral <script>alert(1)</script>";
    expect(noteContentHtml(legacy)).toBe(renderNoteHtml(legacy));
    expect(noteContentHtml(legacy)).toContain("<h1>A <strong>bold</strong> idea</h1>");
    expect(noteContentHtml(legacy)).toContain("&lt;script&gt;");
    expect(noteContentHtml(legacy, "")).toBe("");
  });

  it("preserves the editable schema and only the supported presentation attributes", () => {
    const html = '<h2 id="x" style="color:red;text-align:center" onclick="alert(1)">Title</h2><p><b>Bold</b> <i>soft</i> <del>gone</del> <u>under</u><br/>line <code>1 &lt; 2</code></p><ol start="3"><li><p>Three</p></li></ol><blockquote><p>Quote</p></blockquote><pre><code>const x = 1;</code></pre>';
    expect(sanitizeNoteHtml(html)).toBe('<h2 style="text-align: center">Title</h2><p><strong>Bold</strong> <em>soft</em> <s>gone</s> <u>under</u><br>line <code>1 &lt; 2</code></p><ol start="3"><li><p>Three</p></li></ol><blockquote><p>Quote</p></blockquote><pre><code>const x = 1;</code></pre>');
    expect(sanitizeNoteHtml(sanitizeNoteHtml(html))).toBe(sanitizeNoteHtml(html));
  });

  it("discards executable resources, hidden content, unsafe links, and event handlers", () => {
    const html = '<p onmouseover="bad()">Safe<img src=x onerror="bad()"><script>bad()</script><style>body{display:none}</style><iframe srcdoc="bad">hidden</iframe><svg><a href="https://bad.test">svg</a></svg><a href="jav&#x61;script:bad()">bad link</a><a href="https://example.com/a?x=1&amp;y=2" onclick="bad()" style="color:red">good link</a></p>';
    const safe = sanitizeNoteHtml(html);
    expect(safe).toBe('<p>Safebad link<a href="https://example.com/a?x=1&amp;y=2" target="_blank" rel="noopener noreferrer">good link</a></p>');
    expect(safe).not.toMatch(/(?:onerror|onmouseover|onclick|javascript|<script|<iframe|<svg|<img)/i);
    for (const href of ["javascript:alert(1)", "data:text/html,x", "//example.com", "https://example.com\n@evil.test", "https://example.com\u0000x"])
      expect(safeNoteLink(href)).toBeUndefined();
    expect(safeNoteLink("https://example.com/path")).toBe("https://example.com/path");
  });

  it("retains safe text from unsupported wrappers and repairs malformed markup", () => {
    const sanitized = sanitizeNoteHtml('<div><span>plain &amp; safe</span><p><strong>bold</p><p>next</div><!-- hidden -->');
    expect(sanitized).toContain("plain &amp; safe");
    expect(sanitized).not.toContain("<span");
    expect(sanitized).not.toContain("<div");
    expect(sanitizeNoteHtml(sanitized)).toBe(sanitized);
  });

  it("exports visible text and Markdown including marks, lists, links and block formatting", () => {
    const html = '<h2>Idea</h2><p><strong>Bold</strong> and <em>soft</em>, <s>gone</s>, <u>under</u>, <code>x*y</code>.</p><ul><li><p>First</p></li><li><p>Second</p><ul><li><p>Nested</p></li></ul></li></ul><ol start="3"><li><p>Third</p></li></ol><blockquote><p>A quote</p></blockquote><p><a href="https://example.com">Read more</a></p>';
    const plain = richHtmlToPlainText(html);
    expect(plain).toContain("Bold and soft, gone, under, x*y.");
    expect(plain).toContain("• First");
    expect(plain).toContain("  • Nested");
    expect(plain).toContain("3. Third");
    expect(plain).not.toMatch(/<\/?(?:strong|p|a|li)>/);
    const markdown = richHtmlToMarkdown(html);
    expect(markdown).toContain("## Idea");
    expect(markdown).toContain("**Bold** and *soft*, ~~gone~~, ++under++, `x*y`.");
    expect(markdown).toContain("- First\n- Second\n  - Nested");
    expect(markdown).toContain("3. Third");
    expect(markdown).toContain("> A quote");
    expect(markdown).toContain("[Read more](https://example.com/)");
  });

  it("keeps code opaque and chooses a fence longer than its backtick content", () => {
    const html = '<p>Literal *markers* <code>a`b</code></p><pre><code>const x = `hello`;\n**literal**</code></pre>';
    const markdown = richHtmlToMarkdown(html);
    expect(markdown).toContain("Literal \\*markers\\* ``a`b``");
    expect(markdown).toContain("```\nconst x = `hello`;\n**literal**\n```");
    expect(richHtmlToPlainText(html)).toContain("**literal**");
  });

  it("keeps fixed text color, highlight and small text styles without arbitrary CSS", () => {
    const html = '<p><span style="color:#AbC; font-size:10px; background:url(https://bad.test); position:fixed" onclick="bad()">Small color</span> <mark data-color="#fff3bc" style="background-color:rgb(255, 243, 188);color:inherit">Highlight</mark><span style="font-size:999px;color:expression(bad())">Plain</span></p>';
    const safe = sanitizeNoteHtml(html);
    expect(safe).toBe('<p><span style="color: #abc; font-size: 10px">Small color</span> <mark style="background-color: #fff3bc">Highlight</mark>Plain</p>');
    expect(sanitizeNoteHtml(safe)).toBe(safe);
    expect(richHtmlToPlainText(safe)).toBe("Small color HighlightPlain");
    expect(sanitizeNoteHtml('<span style="color:rgb(256,0,0)">No color</span>')).toBe("No color");
  });

  it("preserves a semantic callout separately from quotes without allowing arbitrary aside attributes", () => {
    const html = '<aside data-note-callout="true" class="unsafe" onclick="bad()"><p>A <strong>useful</strong> tip</p></aside><blockquote><p>A quotation</p></blockquote><aside data-note-callout="anything">Plain</aside>';
    const safe = sanitizeNoteHtml(html);
    expect(safe).toBe('<aside data-note-callout="true"><p>A <strong>useful</strong> tip</p></aside><blockquote><p>A quotation</p></blockquote>Plain');
    expect(sanitizeNoteHtml(safe)).toBe(safe);
    expect(richHtmlToPlainText(safe)).toContain("A useful tip\n\nA quotation");
    expect(richHtmlToMarkdown(safe)).toContain("> [!NOTE]\n> A **useful** tip");
    expect(richHtmlToMarkdown(safe)).toContain("> A quotation");
  });
  it('preserves observed custom callout icons and horizontal rules through sanitization and text exports',()=>{
    const html='<p>Before</p><hr onclick="bad()" style="position:fixed"><aside data-note-callout="true" data-note-callout-icon="❤️" onclick="bad()"><p>Keep this</p></aside><p>After</p>';
    const safe=sanitizeNoteHtml(html);
    expect(safe).toBe('<p>Before</p><hr><aside data-note-callout="true" data-note-callout-icon="❤️"><p>Keep this</p></aside><p>After</p>');
    expect(sanitizeNoteHtml(safe)).toBe(safe);
    expect(richHtmlToPlainText(safe)).toBe('Before\n\nKeep this\n\nAfter');
    expect(richHtmlToMarkdown(safe)).toContain('\n---\n');
    for(const icon of ['⏰','❤️','⚠️','🎥','❌','✅','👩🏽‍💻'])expect(safeCalloutIcon(icon)).toBe(icon);
    for(const icon of ['',undefined,'two icons','<','javascript:bad()','a\u0000','✅✅'])expect(safeCalloutIcon(icon)).toBeUndefined();
    expect(sanitizeNoteHtml('<aside data-note-callout="true" data-note-callout-icon="&lt;img onerror=bad()&gt;"><p>Safe</p></aside>')).toBe('<aside data-note-callout="true"><p>Safe</p></aside>');
  });
});
