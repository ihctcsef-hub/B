import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {chromium,webkit} from 'playwright-core';

const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const artifacts=path.join(root,'artifacts',engine==='webkit'?'webkit':'.');
await mkdir(artifacts,{recursive:true});
const browser=await (engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']}));
const context=await browser.newContext({viewport:{width:1440,height:1000},acceptDownloads:true});
const page=await context.newPage();page.setDefaultTimeout(8000);
const results=[],pageErrors=[];page.on('pageerror',error=>pageErrors.push(error.message));
let editorLabel='Note text';
const editor=()=>page.getByRole('textbox',{name:editorLabel,exact:true});
let sequence=0;
async function fixture(html='<p>Alpha bravo charlie.</p>',isDocument=false){
  editorLabel=isDocument?'Document text':'Note text';
  const id=`shortcut-note-${++sequence}`;
  const value={version:1,id:'note-shortcuts',title:'Note shortcuts',rootBoardId:'board',updatedAt:new Date().toISOString(),boards:{board:{id:'board',title:'Note shortcuts test',cards:[{id,type:'note',text:'',html,isDocument,title:isDocument?'Shortcut document':undefined,x:100,y:100,width:430,height:150,z:1,color:'#ffffff'}],connections:[],viewport:{x:35,y:40,zoom:1},background:'#ebedee',grid:true}}};
  await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'note-shortcuts.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(value))});
  const card=page.locator(`[data-card-id="${id}"]`);await card.waitFor();await card.dblclick();await editor().waitFor();await editor().focus();
}
// Use the browser's real Selection, then send actual keyboard events. This
// avoids assuming OS-specific Ctrl+Home/arrow caret offsets in WebKit.
async function selectText(start,length,expected){
  await editor().focus();
  await editor().evaluate((element,{start,length})=>{
    const walker=document.createTreeWalker(element,NodeFilter.SHOW_TEXT);let node,offset=0,first,last;
    while(node=walker.nextNode()){
      const size=node.textContent.length;
      if(!first&&start<offset+size)first={node,offset:start-offset};
      if(start+length<=offset+size){last={node,offset:start+length-offset};break;}
      offset+=size;
    }
    if(!first||!last)throw Error('Requested text selection is unavailable');
    const range=document.createRange();range.setStart(first.node,first.offset);range.setEnd(last.node,last.offset);
    const selection=getSelection();selection.removeAllRanges();selection.addRange(range);
  },{start,length});
  await page.waitForTimeout(40);
  assert.equal(await page.evaluate(()=>getSelection()?.toString()),expected);
}
async function backup(filename){
  if(editorLabel==='Document text')await page.getByTitle('Close dialog',{exact:true}).click();
  await page.getByLabel('Current board title',{exact:true}).click();
  await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();
  const pending=page.waitForEvent('download');pending.catch(()=>{});await page.getByRole('button',{name:/Workspace backup/}).click();
  const download=await pending,destination=path.join(artifacts,filename);await download.saveAs(destination);await page.getByTitle('Close dialog',{exact:true}).click();
  return JSON.parse(await readFile(destination,'utf8'));
}
async function run(name,fn){
  try{await fn();results.push({name,status:'passed'});console.log('PASS',name);}
  catch(error){results.push({name,status:'failed',message:error.stack});process.exitCode=1;console.error('FAIL',name,error.message);await page.screenshot({path:path.join(artifacts,`note-shortcuts-failure-${results.length}.png`)}).catch(()=>{});await page.keyboard.press('Escape').catch(()=>{});}
}
try{
  await page.goto(process.env.TEST_URL||'http://127.0.0.1:5301',{waitUntil:'domcontentloaded'});await page.getByText('Saved on this device',{exact:true}).waitFor();
  await run('Heading, normal text and small text use the documented Ctrl/Cmd+Shift number keys',async()=>{
    await fixture();await selectText(6,5,'bravo');
    await page.keyboard.press('Control+Shift+Digit1');assert.equal(await editor().locator('h1').innerText(),'Alpha bravo charlie.');
    await page.keyboard.press('Meta+Shift+Digit2');assert.equal(await editor().locator('h2').innerText(),'Alpha bravo charlie.');
    await page.keyboard.press('Control+Shift+Digit9');assert.equal(await editor().locator('span').innerText(),'bravo');assert.equal(await editor().locator('span').evaluate(el=>el.style.fontSize),'9.6px');
    await page.keyboard.press('Control+Shift+Digit0');assert.equal(await editor().locator('h1,h2').count(),0);assert.equal(await editor().locator('span').count(),0);assert.equal((await editor().innerText()).trimEnd(),'Alpha bravo charlie.');
    const data=await backup('note-shortcuts-blocks.json');assert.equal(data.boards.board.cards[0].html,'<p>Alpha bravo charlie.</p>');
  });
  await run('Highlight and strike format only the native selected range and keyboard undo/redo preserve its text',async()=>{
    await fixture();await selectText(6,5,'bravo');await page.keyboard.press('Control+j');assert.equal(await editor().locator('mark').innerText(),'bravo');
    assert.equal(await page.evaluate(()=>getSelection()?.toString()),'bravo');await page.keyboard.press('Control+z');assert.equal(await editor().locator('mark').count(),0);
    await page.keyboard.press('Control+Shift+z');assert.equal(await editor().locator('mark').innerText(),'bravo');
    await selectText(6,5,'bravo');await page.keyboard.press('Control+Shift+x');assert.equal(await editor().locator('s').innerText(),'bravo');
    await page.keyboard.press('Meta+j');assert.equal(await editor().locator('mark').count(),0);assert.equal((await editor().innerText()).trimEnd(),'Alpha bravo charlie.');
    const data=await backup('note-shortcuts-marks.json');assert.equal(data.boards.board.cards[0].html,'<p>Alpha <s>bravo</s> charlie.</p>');
  });
  await run('Bullet and numbered shortcuts create editable lists; Tab and Shift+Tab nest and lift list items',async()=>{
    await fixture();await selectText(6,5,'bravo');await page.keyboard.press('Control+Shift+u');assert.equal(await editor().locator('ul>li').count(),1);
    await page.keyboard.press('Control+Shift+o');assert.equal(await editor().locator('ol>li').count(),1);assert.equal(await editor().locator('ul').count(),0);
    await fixture('<ul><li><p>First item</p></li><li><p>Second item</p></li></ul>');await selectText(10,11,'Second item');
    await page.keyboard.press('Tab');assert.equal((await editor().locator('ul>li>ul>li').innerText()).trim(),'Second item');assert.equal(await page.evaluate(()=>getSelection()?.toString()),'Second item');
    await page.keyboard.press('Shift+Tab');assert.equal(await editor().locator('ul ul').count(),0);assert.equal(await editor().locator('ul>li').count(),2);
    const data=await backup('note-shortcuts-lists.json');assert.equal(data.boards.board.cards[0].html,'<ul><li><p>First item</p></li><li><p>Second item</p></li></ul>');
  });
  await run('Code, quote and center shortcuts persist their semantic HTML and preserve plain text',async()=>{
    await fixture();await selectText(6,5,'bravo');await page.keyboard.press('Control+Shift+Period');assert.equal((await editor().locator('pre>code').innerText()).trimEnd(),'Alpha bravo charlie.');
    await page.keyboard.press('Control+Shift+Period');assert.equal(await editor().locator('pre').count(),0);
    await page.keyboard.press('Control+Shift+Quote');assert.equal((await editor().locator('blockquote').innerText()).trimEnd(),'Alpha bravo charlie.');
    await page.keyboard.press('Control+Backslash');assert.equal(await editor().locator('blockquote p').evaluate(el=>getComputedStyle(el).textAlign),'center');
    const data=await backup('note-shortcuts-quote.json');assert.equal(data.boards.board.cards[0].html,'<blockquote><p style="text-align: center">Alpha bravo charlie.</p></blockquote>');
    await page.getByText('Saved on this device',{exact:true}).waitFor();await page.reload({waitUntil:'domcontentloaded'});
    const note=page.locator('[data-card-id]').filter({has:page.locator('.note-text')}).first();assert.equal(await note.locator('blockquote p').evaluate(el=>getComputedStyle(el).textAlign),'center');
  });
  await run('Ctrl/Cmd+K opens the existing link dialog and applies the link to the saved partial selection',async()=>{
    await fixture();await selectText(6,5,'bravo');await page.keyboard.press('Control+k');await page.getByLabel('Text link URL',{exact:true}).fill('https://example.com/shortcut');await page.getByRole('button',{name:'Apply link',exact:true}).click();
    await editor().waitFor();assert.equal(await editor().locator('a').innerText(),'bravo');assert.equal(await editor().locator('a').getAttribute('href'),'https://example.com/shortcut');
    const data=await backup('note-shortcuts-link.json');assert.match(data.boards.board.cards[0].html,/<a href="https:\/\/example.com\/shortcut"[^>]*>bravo<\/a>/);
  });
  await run('Document link keyboard editing retains its partial selection and returns to the editable document',async()=>{
    await fixture('<p>Alpha bravo charlie.</p>',true);await selectText(6,5,'bravo');await page.keyboard.press('Meta+k');
    const popup=page.getByRole('dialog',{name:'Add a text link',exact:true});await popup.waitFor();assert.equal(await popup.getAttribute('aria-modal'),'true');
    for(const key of ['Tab','Shift+Tab'])for(let index=0;index<10;index++){await page.keyboard.press(key);assert.equal(await popup.evaluate(element=>element.contains(document.activeElement)),true,'Link popup must contain keyboard focus');}
    await page.getByLabel('Text link URL',{exact:true}).fill('https://example.com/document');await page.getByLabel('Text link URL',{exact:true}).press('Enter');
    await editor().waitFor();assert.equal(await editor().locator('a').innerText(),'bravo');assert.equal(await editor().locator('a').getAttribute('href'),'https://example.com/document');
    await selectText(6,5,'bravo');await page.keyboard.press('Control+k');await page.getByLabel('Text link URL',{exact:true}).waitFor();await page.keyboard.press('Escape');
    assert.equal(await page.getByLabel('Text link URL',{exact:true}).count(),0);assert.equal(await editor().isVisible(),true);assert.equal(await editor().locator('a').innerText(),'bravo');
    const data=await backup('note-shortcuts-document-link.json');assert.match(data.boards.board.cards[0].html,/<a href="https:\/\/example.com\/document"[^>]*>bravo<\/a>/);
  });
  await run('No uncaught browser errors',async()=>assert.deepEqual(pageErrors,[]));
}catch(error){results.push({name:'Harness failure',status:'failed',message:error.stack});process.exitCode=1;console.error(error);}
finally{await writeFile(path.join(artifacts,'note-shortcuts-results.json'),JSON.stringify({engine,checkedAt:new Date().toISOString(),results,pageErrors},null,2));await browser.close();}
