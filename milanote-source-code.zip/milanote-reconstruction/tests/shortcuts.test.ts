import { describe, expect, it } from 'vitest';
import { createWorkspace, duplicateCards } from '../src/core/model';
import type { Card, Workspace } from '../src/core/model';
import { boardLocalUrl, createBoardShortcut, isBoardShortcut, localBoardIdFromUrl, ownedBoardDescendants, shortcutTarget, workspaceBoard } from '../src/core/shortcuts';
import { trashCards, restoreTrashEntry } from '../src/core/trash';
import { importWorkspace, exportWorkspace } from '../src/core/storage';
import { boardsForLinearExport } from '../src/export';

function fixture(): Workspace {
  return { version: 1, id: 'shortcuts', title: 'Shortcuts', rootBoardId: 'root', updatedAt: '2026-10-25T00:00:00Z', boards: {
    root: { id: 'root', title: 'Home', viewport: { x: 0, y: 0, zoom: 1 }, cards: [{ id: 'owner', type: 'board', boardId: 'child', title: 'Child', x: 0, y: 0, width: 160, height: 160, z: 1 }], connections: [] },
    child: { id: 'child', title: 'Child', parentBoardId: 'root', cards: [], connections: [], viewport: { x: 0, y: 0, zoom: 1 } },
  } };
}
describe('board shortcuts', () => {
  it('references the same board without changing ownership, and supports alias cycles including Home', () => {
    const source = fixture(), before = structuredClone(source);
    const created = createBoardShortcut(source, 'child', 'root', { x: 300, y: 200 });
    const shortcut = created.workspace.boards.root.cards.find(card => card.id === created.id)!;
    expect(isBoardShortcut(shortcut)).toBe(true);
    expect(shortcutTarget(created.workspace, shortcut)).toBe(created.workspace.boards.child);
    expect(created.workspace.boards.child.parentBoardId).toBe('root');
    const homeAlias = createBoardShortcut(created.workspace, 'root', 'child');
    expect(shortcutTarget(homeAlias.workspace, homeAlias.workspace.boards.child.cards[0])?.id).toBe('root');
    expect(ownedBoardDescendants(homeAlias.workspace, ['child'])).toEqual(new Set(['child']));
    expect(source).toEqual(before);
    expect(importWorkspace(exportWorkspace(homeAlias.workspace))).toEqual(homeAlias.workspace);
  });
  it('deleting an alias leaves the original, deleting its owner breaks the alias, and restore reactivates it', () => {
    const source = fixture(), created = createBoardShortcut(source, 'child', 'root');
    const withoutAlias = trashCards(created.workspace, 'root', [created.id!], '2026-10-25');
    expect(withoutAlias.boards.child).toEqual(source.boards.child);
    const withoutOriginal = trashCards(created.workspace, 'root', ['owner'], '2026-10-25');
    expect(withoutOriginal.boards.child).toBeUndefined();
    const alias = withoutOriginal.boards.root.cards.find(card => card.id === created.id)!;
    expect(shortcutTarget(withoutOriginal, alias)).toBeUndefined();
    expect(importWorkspace(exportWorkspace(withoutOriginal))).toEqual(withoutOriginal);
    const restored = restoreTrashEntry(withoutOriginal, withoutOriginal.trash![0].id, {}, '2026-10-26');
    expect(shortcutTarget(restored, alias)?.id).toBe('child');
  });
  it('duplicates an alias as another reference without cloning or reparenting its target', () => {
    const source = createBoardShortcut(fixture(), 'child', 'root');
    const next = duplicateCards(source.workspace, 'root', [source.id!]);
    const copy = next.workspace.boards.root.cards.find(card => card.id === next.ids[0])!;
    expect(copy).toMatchObject({ type: 'board', boardId: 'child', isShortcut: true });
    expect(Object.keys(next.workspace.boards)).toEqual(Object.keys(source.workspace.boards));
    expect(importWorkspace(exportWorkspace(next.workspace))).toEqual(next.workspace);
  });
  it('converts only valid same-app board URLs and keeps malformed/external schemes inert', () => {
    const source = fixture(), base = 'https://canvas.example/app?theme=light';
    expect(localBoardIdFromUrl(source, boardLocalUrl('child', base), base)).toBe('child');
    expect(localBoardIdFromUrl(source, '#board/child', base)).toBe('child');
    for (const url of ['javascript:alert(1)', 'https://evil.example/app#board/child', 'https://canvas.example/other#board/child', '#board/missing', '#board/%ZZ']) expect(localBoardIdFromUrl(source, url, base)).toBeNull();
    expect(createBoardShortcut(source, 'missing', 'root').workspace).toBe(source);
    expect(createBoardShortcut(source, 'child', 'missing').workspace).toBe(source);
    expect(createBoardShortcut(source, 'child', 'root', { x: NaN, y: 0 }).workspace).toBe(source);
  });
  it('rejects inherited registry names as routes or shortcut targets while preserving real own boards with those names', () => {
    const source=fixture();
    for(const id of ['constructor','toString','__proto__','hasOwnProperty']){
      expect(workspaceBoard(source,id)).toBeUndefined();
      expect(localBoardIdFromUrl(source,`#board/${id}`)).toBeNull();
      expect(createBoardShortcut(source,id,'root').workspace).toBe(source);
      expect(createBoardShortcut(source,'child',id).workspace).toBe(source);
      expect(ownedBoardDescendants(source,[id])).toEqual(new Set());
      expect(shortcutTarget(source,{...source.boards.root.cards[0],boardId:id,isShortcut:true} as Card)).toBeUndefined();
    }
    const own:Workspace={...source,boards:{...source.boards,constructor:{...source.boards.child,id:'constructor',title:'Own constructor'}}};
    own.boards.root.cards.push({...source.boards.root.cards[0],id:'own-constructor',boardId:'constructor'} as Card);
    const restored=importWorkspace(exportWorkspace(own));
    expect(localBoardIdFromUrl(restored,'#board/constructor')).toBe('constructor');
    expect(workspaceBoard(restored,'constructor')?.title).toBe('Own constructor');
    expect(createBoardShortcut(restored,'constructor','root').id).toBeDefined();
  });
  it('skips missing prototype-named shortcut targets while exporting subboards',()=>{
    const source=fixture();source.boards.root.cards.push({...source.boards.root.cards[0],id:'broken',boardId:'toString',isShortcut:true,title:'Deleted target'} as Card);
    const restored=importWorkspace(exportWorkspace(source));
    expect(boardsForLinearExport(restored.boards.root,{includeSubBoards:true,workspace:restored}).map(board=>board.id)).toEqual(['root','child']);
  });
});
