import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { chromium } from 'playwright-core';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const artifacts = path.join(root, 'artifacts');
await mkdir(artifacts, { recursive: true });
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const context = await browser.newContext({ viewport: { width: 1440, height: 1100 }, acceptDownloads: true });
const page = await context.newPage();
page.setDefaultTimeout(10000);
const results = [], errors = [];
page.on('pageerror', error => errors.push(error.stack || error.message));
const card = id => page.locator(`[data-card-id="${id}"]`);
const noteEditor = () => page.getByRole('textbox', { name: 'Note text', exact: true });
const documentEditor = () => page.getByRole('textbox', { name: 'Document text', exact: true });
const documentModal = () => page.locator('.modal-document');
const note = id => ({ id, type: 'note', text: 'Initial shared content', html: '<p>Initial shared content</p>', x: 90, y: 110, width: 270, height: 70, z: 1, color: '#ffffff' });
function fixture(cards = [], title = 'Document test board') {
  return { version: 1, id: 'document-workspace', title: 'Documents test', rootBoardId: 'document-board', updatedAt: '2026-10-25T00:00:00.000Z', boards: { 'document-board': { id: 'document-board', title, cards, connections: [], viewport: { x: 35, y: 40, zoom: 1 }, background: '#ebedee', grid: true } } };
}
async function importFixture(value) {
  if (await page.getByTitle('Close dialog', { exact: true }).isVisible()) await page.getByTitle('Close dialog', { exact: true }).click();
  await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({ name: 'documents-fixture.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(value)) });
  await page.waitForFunction(() => document.querySelector('input[type=file][accept="application/json,.json"]')?.value === '');
  await page.waitForFunction(title => document.querySelector('[aria-label="Current board title"]')?.value === title, value.boards[value.rootBoardId].title);
  await page.getByText('Workspace imported. Undo to return to your previous workspace.', { exact: true }).waitFor();
  const back = page.getByTitle('Back to tools', { exact: true });
  if (await back.isVisible()) await back.click();
}
async function backup(name) {
  await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();
  const pending = page.waitForEvent('download');
  await page.getByRole('button', { name: /Workspace backup/ }).click();
  const download = await pending, target = path.join(artifacts, name);
  await download.saveAs(target);
  await page.getByTitle('Close dialog', { exact: true }).click();
  return JSON.parse(await readFile(target, 'utf8'));
}
async function closeDocument() {
  await documentModal().getByTitle('Close dialog', { exact: true }).click();
  await documentModal().waitFor({ state: 'detached' });
}
async function closeNote() {
  await page.getByLabel('Current board title', { exact: true }).click();
  await noteEditor().waitFor({ state: 'detached' });
}
async function run(name, action) {
  try { await action(); results.push({ name, status: 'passed' }); console.log('PASS', name); }
  catch (error) {
    results.push({ name, status: 'failed', message: error.stack });
    process.exitCode = 1;
    console.error('FAIL', name, error.message);
    await page.screenshot({ path: path.join(artifacts, `documents-failure-${results.length}.png`), fullPage: true }).catch(() => {});
    await page.keyboard.press('Escape').catch(() => {});
  }
}
try {
  await page.goto(process.env.TEST_URL || 'http://127.0.0.1:5176', { waitUntil: 'domcontentloaded' });
  await page.getByText('Saved on this device', { exact: true }).waitFor();
  await run('Document modal edits title and rich text, downloads Markdown, reopens from its tile and persists through reload', async () => {
    await importFixture(fixture());
    await page.getByTitle('Add Document', { exact: true }).click();
    await documentEditor().waitFor();
    await page.getByLabel('Document title', { exact: true }).fill('Research document');
    await documentEditor().fill('A complete document');
    await documentEditor().focus();
    await page.keyboard.press('Control+a');
    await page.getByTitle('Document bold', { exact: true }).click();
    await documentEditor().locator('strong').waitFor();
    assert.equal(await documentEditor().locator('strong').innerText(), 'A complete document');
    const pending = page.waitForEvent('download');
    await page.getByTitle('Download document Markdown', { exact: true }).click();
    const download = await pending, target = path.join(artifacts, 'document-research.md');
    await download.saveAs(target);
    const markdown = await readFile(target, 'utf8');
    assert.match(markdown, /Research document/);
    assert.match(markdown, /\*\*A complete document\*\*/);
    await closeDocument();
    const tile = page.locator('.card-note').filter({ has: page.locator('.document-card strong', { hasText: 'Research document' }) });
    assert.equal(await tile.count(), 1);
    await tile.dblclick();
    await documentEditor().waitFor();
    assert.equal(await page.getByLabel('Document title', { exact: true }).inputValue(), 'Research document');
    assert.equal(await documentEditor().locator('strong').innerText(), 'A complete document');
    await closeDocument();
    await page.getByText('Saved on this device', { exact: true }).waitFor();
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.getByText('Saved on this device', { exact: true }).waitFor();
    await page.locator('.document-card').dblclick();
    await documentEditor().waitFor();
    assert.equal(await documentEditor().locator('strong').innerText(), 'A complete document');
    await closeDocument();
    const stored = await backup('documents-workspace.json');
    const saved = stored.boards['document-board'].cards.find(item => item.type === 'note');
    assert.equal(saved.isDocument, true); assert.equal(saved.title, 'Research document');
    assert.match(saved.html, /<strong>A complete document<\/strong>/);
  });
  await run('Converting a note to a document and back preserves editable rich content', async () => {
    await importFixture(fixture([note('convert-note')], 'Conversion board'));
    await card('convert-note').click({ position: { x: 5, y: 5 } });
    await page.getByTitle('Convert to document', { exact: true }).click();
    await documentEditor().waitFor();
    assert.equal(await documentEditor().innerText(), 'Initial shared content');
    await documentEditor().fill('Converted and edited');
    await documentEditor().focus(); await page.keyboard.press('Control+a');
    await page.getByTitle('Document italic', { exact: true }).click();
    await documentEditor().locator('em').waitFor();
    await closeDocument();
    await page.getByTitle('Convert to note', { exact: true }).click();
    assert.equal(await card('convert-note').locator('.document-card').count(), 0);
    assert.equal(await card('convert-note').locator('em').innerText(), 'Converted and edited');
    await card('convert-note').dblclick(); await noteEditor().waitFor();
    assert.equal(await noteEditor().locator('em').innerText(), 'Converted and edited');
    await closeNote();
  });
  await run('Synced copies update both notes, unlink isolates subsequent edits, and independent contents survive reload', async () => {
    await importFixture(fixture([note('original-note')], 'Synced board'));
    await card('original-note').click({ position: { x: 5, y: 5 } });
    await page.getByTitle('Create synced copy', { exact: true }).click();
    assert.equal(await page.locator('.card-note').count(), 2);
    const copyId = await page.locator('.card-note').evaluateAll(elements => elements.map(element => element.getAttribute('data-card-id')).find(id => id !== 'original-note'));
    assert(copyId);
    await card(copyId).dblclick(); await noteEditor().waitFor();
    await noteEditor().fill('Shared updated body');
    await noteEditor().focus(); await page.keyboard.press('Control+a');
    await page.getByTitle('Bold', { exact: true }).click();
    await noteEditor().locator('strong').waitFor(); await closeNote();
    assert.equal(await card('original-note').locator('strong').innerText(), 'Shared updated body');
    assert.equal(await card(copyId).locator('strong').innerText(), 'Shared updated body');
    const shared = await backup('documents-synced.json');
    const source = shared.boards['document-board'].cards.find(item => item.id === 'original-note');
    const copy = shared.boards['document-board'].cards.find(item => item.id === copyId);
    assert.equal(source.syncedId, copy.syncedId); assert(source.syncedId); assert.equal(source.html, copy.html);
    await card(copyId).click({ position: { x: 5, y: 5 } });
    await page.getByTitle('Unlink synced note', { exact: true }).click();
    await card(copyId).dblclick(); await noteEditor().waitFor();
    await noteEditor().fill('Independent copy body'); await closeNote();
    assert.equal(await card('original-note').innerText(), 'Shared updated body');
    assert.equal(await card(copyId).innerText(), 'Independent copy body');
    await page.getByText('Saved on this device', { exact: true }).waitFor();
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.getByText('Saved on this device', { exact: true }).waitFor();
    assert.equal(await card('original-note').innerText(), 'Shared updated body');
    assert.equal(await card(copyId).innerText(), 'Independent copy body');
    const isolated = await backup('documents-unlinked.json');
    assert.equal(isolated.boards['document-board'].cards.find(item => item.id === copyId).syncedId, undefined);
    assert(isolated.boards['document-board'].cards.find(item => item.id === 'original-note').syncedId);
  });
  assert.deepEqual(errors, []);
  results.push({ name: 'No uncaught browser errors', status: 'passed' });
} catch (error) {
  process.exitCode = 1; results.push({ name: 'Suite completion', status: 'failed', message: error.stack });
} finally {
  await writeFile(path.join(artifacts, 'documents-results.json'), JSON.stringify({ results, pageErrors: errors }, null, 2));
  await browser.close();
}
