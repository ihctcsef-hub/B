import { describe, expect, it } from "vitest";
import {
  arrangeAllColumns,
  arrangeColumn,
  columnChildren,
  expandSelection,
  placeInColumn,
  removeFromColumn,
  resizeColumn,
} from "../src/core/columns";
import {
  createCard,
  createWorkspace,
  type Board,
  type Card,
} from "../src/core/model";
import { importWorkspace, exportWorkspace } from "../src/core/storage";

function makeBoard(cards: Card[]): Board {
  return {
    id: "board",
    title: "Column tests",
    cards,
    connections: [],
    viewport: { x: 0, y: 0, zoom: 1 },
  };
}
const find = (board: Board, id: string) =>
  board.cards.find((card) => card.id === id)!;

describe("column layout", () => {
  it("snaps members in y order, fills the width, and grows without mutating input", () => {
    const column = {
      ...createCard("column", 100, 200),
      width: 300,
      height: 100,
    };
    const first = {
      ...createCard("note", 700, 400),
      height: 90,
      parentId: column.id,
    };
    const second = {
      ...createCard("image", -100, 500),
      height: 120,
      parentId: column.id,
    };
    const source = makeBoard([second, column, first]);
    const result = arrangeColumn(source, column.id);
    expect(find(result, first.id)).toMatchObject({
      x: expect.closeTo(106.4, 6),
      y: expect.closeTo(262.2, 6),
      width: expect.closeTo(287.2, 6),
      height: 90,
    });
    expect(find(result, second.id)).toMatchObject({
      x: expect.closeTo(106.4, 6),
      y: expect.closeTo(358.2, 6),
      width: expect.closeTo(287.2, 6),
      height: 120,
    });
    expect(find(result, column.id).height).toBeCloseTo(284.2, 6);
    expect(find(source, first.id).x).toBe(700);
    expect(arrangeColumn(result, column.id)).toBe(result);
  });

  it("reorders existing members at an insertion index and persists the new order", () => {
    const column = createCard("column");
    const children = [0, 1, 2].map((i) => ({
      ...createCard("note", 0, i * 100),
      height: 60,
      parentId: column.id,
    }));
    const board = arrangeColumn(makeBoard([column, ...children]), column.id);
    const moved = placeInColumn(board, [children[2].id], column.id, 0);
    expect(columnChildren(moved, column.id).map((card) => card.id)).toEqual([
      children[2].id,
      children[0].id,
      children[1].id,
    ]);
    expect(arrangeColumn(moved, column.id)).toBe(moved);
    const reordered = arrangeColumn(moved, column.id, [
      children[1].id,
      children[1].id,
      "missing",
    ]);
    expect(columnChildren(reordered, column.id).map((card) => card.id)).toEqual(
      [children[1].id, children[2].id, children[0].id],
    );
  });

  it("moves cards between columns and closes gaps in their former column", () => {
    const left = createCard("column", 0, 0),
      right = createCard("column", 400, 0);
    const first = {
      ...createCard("note", 0, 100),
      height: 60,
      parentId: left.id,
    };
    const last = {
      ...createCard("note", 0, 200),
      height: 60,
      parentId: left.id,
    };
    const source = arrangeAllColumns(makeBoard([left, right, first, last]));
    const moved = placeInColumn(source, [first.id], right.id, 0);
    expect(find(moved, first.id)).toMatchObject({
      parentId: right.id,
      x: expect.closeTo(406.4, 6),
      y: expect.closeTo(62.2, 6),
    });
    expect(find(moved, last.id)).toMatchObject({
      parentId: left.id,
      x: expect.closeTo(6.4, 6),
      y: expect.closeTo(62.2, 6),
    });
    const detached = removeFromColumn(moved, [first.id]);
    expect(find(detached, first.id)).toMatchObject({
      parentId: undefined,
      x: expect.closeTo(406.4, 6),
      y: expect.closeTo(62.2, 6),
    });
    expect(columnChildren(detached, right.id)).toHaveLength(0);
  });

  it("resizes member widths and cannot shrink the container below its content", () => {
    const column = createCard("column");
    const child = { ...createCard("note"), parentId: column.id, height: 120 };
    const resized = resizeColumn(
      makeBoard([column, child]),
      column.id,
      360,
      96,
    );
    expect(find(resized, column.id)).toMatchObject({
      width: 360,
      height: expect.closeTo(188.2, 6),
    });
    expect(find(resized, child.id)).toMatchObject({
      x: expect.closeTo(6.4, 6),
      y: expect.closeTo(62.2, 6),
      width: expect.closeTo(347.2, 6),
    });
    const narrow = resizeColumn(resized, column.id, 20, 20);
    expect(find(narrow, column.id).width).toBe(172);
    expect(find(narrow, child.id).width).toBeCloseTo(159.2, 6);
  });

  it("fits observed content height, shrinks after detaching, and restores the card width", () => {
    const column = createCard("column", 100, 200),
      first = { ...createCard("note"), height: 98 },
      second = { ...createCard("note"), height: 58 };
    const source = makeBoard([column, first, second]);
    const stacked = placeInColumn(source, [first.id, second.id], column.id);
    expect(find(stacked, column.id).height).toBeCloseTo(230.2, 6);
    const detached = removeFromColumn(stacked, [second.id]);
    expect(find(detached, column.id).height).toBeCloseTo(166.2, 6);
    expect(find(detached, second.id).width).toBe(second.width);
    expect(find(detached, second.id).parentId).toBeUndefined();
  });

  it("expands all selected columns, including collapsed and locked descendants", () => {
    const first = createCard("column"),
      second = { ...createCard("column"), collapsed: true };
    const a = { ...createCard("note"), parentId: first.id };
    const b = {
      ...createCard("note"),
      parentId: second.id,
      locked: true,
      unsorted: true,
    };
    const loose = createCard("note");
    const board = makeBoard([first, second, a, b, loose]);
    expect(
      expandSelection(board, [first.id, second.id, first.id, "missing"]),
    ).toEqual([first.id, second.id, a.id, b.id]);
  });

  it("refuses nesting columns or directly moving locked cards, but carries locked members", () => {
    const column = createCard("column"),
      other = createCard("column", 400, 0);
    const child = {
      ...createCard("note", 200, 200),
      parentId: column.id,
      locked: true,
    };
    const board = makeBoard([column, other, child]);
    expect(placeInColumn(board, [column.id], other.id)).toBe(board);
    expect(placeInColumn(board, [child.id], other.id)).toBe(board);
    expect(removeFromColumn(board, [child.id])).toBe(board);
    const resized = resizeColumn(board, column.id, 320, 500);
    expect(find(resized, child.id)).toMatchObject({
      x: expect.closeTo(6.4, 6),
      y: expect.closeTo(62.2, 6),
      width: expect.closeTo(307.2, 6),
      locked: true,
    });
  });

  it("keeps inbox children out of visible columns until explicitly placed", () => {
    const column = createCard("column");
    const inbox = {
      ...createCard("note", 900, 900),
      parentId: column.id,
      unsorted: true,
    };
    const source = makeBoard([column, inbox]);
    expect(columnChildren(source, column.id)).toHaveLength(0);
    expect(arrangeColumn(source, column.id)).toBe(source);
    const placed = placeInColumn(source, [inbox.id], column.id);
    expect(find(placed, inbox.id)).toMatchObject({
      unsorted: false,
      x: expect.closeTo(6.4, 6),
      y: expect.closeTo(62.2, 6),
    });
    const inboxColumn = { ...column, unsorted: true };
    const inboxLayout = arrangeColumn(
      makeBoard([inboxColumn, { ...inbox, unsorted: false }]),
      column.id,
    );
    expect(find(inboxLayout, inbox.id)).toMatchObject({
      unsorted: true,
      x: expect.closeTo(6.4, 6),
      y: expect.closeTo(62.2, 6),
    });
  });
});

describe("column and board import validation", () => {
  it("rejects a column assigned to another column", () => {
    const workspace = createWorkspace();
    const outer = createCard("column"),
      inner = { ...createCard("column"), parentId: outer.id };
    workspace.boards[workspace.rootBoardId].cards.push(outer, inner);
    expect(() => importWorkspace(exportWorkspace(workspace))).toThrow(
      "columns cannot contain columns",
    );
  });

  it("validates optional inbox flags and board background/grid preferences", () => {
    const workspace = createWorkspace();
    const board = workspace.boards[workspace.rootBoardId];
    board.background = "#abc";
    board.grid = true;
    board.cards[0].unsorted = false;
    expect(importWorkspace(exportWorkspace(workspace))).toEqual(workspace);
    const badInbox = structuredClone(workspace) as unknown as {
      boards: Record<string, { cards: { unsorted: unknown }[] }>;
    };
    badInbox.boards[workspace.rootBoardId].cards[0].unsorted = "true";
    expect(() => importWorkspace(JSON.stringify(badInbox))).toThrow(
      "card unsorted",
    );
    const badGrid = structuredClone(workspace) as unknown as {
      boards: Record<string, { grid: unknown }>;
    };
    badGrid.boards[workspace.rootBoardId].grid = "yes";
    expect(() => importWorkspace(JSON.stringify(badGrid))).toThrow(
      "board grid",
    );
    board.background = "url(https://example.com/image.png)";
    expect(() => importWorkspace(exportWorkspace(workspace))).toThrow(
      "board background",
    );
  });
});
