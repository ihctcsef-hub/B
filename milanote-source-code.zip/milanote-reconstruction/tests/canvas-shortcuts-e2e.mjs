import {openSavedTemplates} from './helpers/saved-templates.mjs';
import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {chromium,webkit} from 'playwright-core';
const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium';
const url=process.env.TEST_URL||'http://127.0.0.1:5301';
const artifacts=new URL(`../artifacts/${engine==='webkit'?'webkit/':''}`,import.meta.url);await mkdir(artifacts,{recursive:true});
const browser=await(engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']}));
const page=await browser.newPage({viewport:{width:1440,height:1000}});page.setDefaultTimeout(10000);
const results=[],errors=[];page.on('pageerror',error=>errors.push(error.message));
const note={id:'note',type:'note',text:'Keep the content',html:'<p>Keep the content</p>',x:100,y:100,width:270,height:54,z:1};
const fixture={version:1,id:'canvas-shortcuts',rootBoardId:'root',title:'Canvas shortcuts',updatedAt:new Date().toISOString(),boards:{root:{id:'root',title:'Home study',viewport:{x:20,y:30,zoom:1},cards:[{id:'child-tile',type:'board',boardId:'child',title:'Child study',x:420,y:100,width:160,height:160,z:2},note],connections:[]},child:{id:'child',title:'Child study',parentBoardId:'root',viewport:{x:45,y:55,zoom:.7},cards:[{...note,id:'child-note'}],connections:[]}}};
async function load(data=fixture){await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'canvas-shortcuts.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(data))});await page.waitForFunction(()=>document.querySelector('input[type=file][accept="application/json,.json"]')?.value==='');await title('Home study');await page.getByText('Saved on this device',{exact:true}).waitFor();}
async function title(text){await page.waitForFunction(text=>document.querySelector('[aria-label="Current board title"]')?.value===text,text);}
async function canvasFocus(){await page.locator('.stage').click({position:{x:1000,y:700}});}
async function matrix(){return page.locator('.world').evaluate(el=>{const m=new DOMMatrix(getComputedStyle(el).transform),r=el.closest('.stage').getBoundingClientRect();return {x:m.e,y:m.f,z:m.a,width:r.width,height:r.height};});}
async function check(name,fn){try{await fn();results.push({name,status:'passed'});console.log('PASS',name);}catch(error){results.push({name,status:'failed',message:error.stack});process.exitCode=1;console.error('FAIL',name,error.message);await page.screenshot({path:new URL(`canvas-shortcuts-failure-${results.length}.png`,artifacts).pathname});await page.keyboard.press('Escape').catch(()=>{});}}
try{
 await page.goto(url,{waitUntil:'networkidle'});await page.getByText('Saved on this device',{exact:true}).waitFor();await load();
 await check('Board zoom shortcuts change the canvas around its center and reset to 100% without changing browser zoom',async()=>{
  await canvasFocus();const before=await matrix();await page.keyboard.press('Control+=');let next=await matrix();assert.ok(Math.abs(next.z-1.2)<1e-5);
  assert.ok(Math.abs((before.width/2-before.x)/before.z-(next.width/2-next.x)/next.z)<1e-3);assert.ok(Math.abs((before.height/2-before.y)/before.z-(next.height/2-next.y)/next.z)<1e-3);
  await page.keyboard.press('Control+-');next=await matrix();assert.ok(Math.abs(next.z-1)<1e-5);
  await page.keyboard.press('Meta+=');assert.ok((await matrix()).z>1);await page.keyboard.press('Meta+0');assert.ok(Math.abs((await matrix()).z-1)<1e-5);
  assert.equal(await page.evaluate(()=>visualViewport.scale),1);
 });
 await check('Back, forward and parent shortcuts follow board visits and restore the stored canvas viewport',async()=>{
  await page.locator('[data-card-id="child-tile"]').dblclick({position:{x:5,y:5}});await title('Child study');assert.ok(Math.abs((await matrix()).z-.7)<1e-5);
  await canvasFocus();await page.keyboard.press('Control+[');await title('Home study');await page.keyboard.press('Control+]');await title('Child study');
  await page.keyboard.press('Meta+u');await title('Home study');await page.keyboard.press('Meta+[');await title('Child study');await page.keyboard.press('Meta+]');await title('Home study');
  await page.keyboard.press('Control+]');await title('Home study');
 });
 await check('Note underline and modal keystrokes stay inside the active editor or dialog',async()=>{
  await page.locator('[data-card-id="child-tile"]').dblclick({position:{x:5,y:5}});await title('Child study');await page.locator('[data-card-id="child-note"]').dblclick();const editor=page.getByRole('textbox',{name:'Note text',exact:true});await editor.press('Control+a');await editor.press('Control+u');assert.match(await editor.innerHTML(),/<u>Keep the content<\/u>/);await title('Child study');await editor.press('Escape');
  await canvasFocus();const count=await page.locator('.world .card').count();await page.keyboard.press('/');await page.locator('.modal-help').waitFor();await page.getByTitle('Close dialog',{exact:true}).focus();await page.keyboard.press('n');assert.equal(await page.locator('.world .card').count(),count);await page.keyboard.press('Escape');await page.locator('.modal-help').waitFor({state:'hidden'});
 });
 await check('Replacing the workspace clears board navigation history',async()=>{
  await canvasFocus();await page.keyboard.press('Control+u');await title('Home study');const next=structuredClone(fixture);next.id='replacement-canvas-shortcuts';next.boards.child.title='Replacement child';await load(next);await canvasFocus();await page.keyboard.press('Control+[');await title('Home study');assert.equal(await page.locator('[aria-label="Current board title"]').inputValue(),'Home study');await page.locator('[data-card-id="child-tile"]').dblclick({position:{x:5,y:5}});await title('Replacement child');await canvasFocus();await page.keyboard.press('Control+u');await title('Home study');await load(next);await canvasFocus();await page.keyboard.press('Control+[');await title('Home study');assert.ok(page.url().endsWith('#board/root'));await page.reload();await title('Home study');
 });
 await check('Saved and built-in template visits update navigation history and the reloadable board URL',async()=>{
  const data=structuredClone(fixture);data.id='canvas-template-navigation';data.boards.child.isTemplate=true;await load(data);
  await openSavedTemplates(page);await page.getByRole('button',{name:'Use template Child study',exact:true}).click();await title('Child study');assert.match(page.url(),/#board\//);
  await canvasFocus();await page.keyboard.press('Control+[');await title('Home study');await page.keyboard.press('Control+]');await title('Child study');await page.getByText('Saved on this device',{exact:true}).waitFor();await page.reload();await title('Child study');
  await canvasFocus();await page.keyboard.press('Control+u');await title('Home study');await openSavedTemplates(page);await page.getByRole('button',{name:/Blank canvas.*A little space for anything/}).click();await title('Blank canvas');assert.match(page.url(),/#board\//);await canvasFocus();await page.keyboard.press('Control+[');await title('Home study');
 });
 await check('Inherited object names stay invalid routes and broken shortcuts, while a real constructor board opens and reloads',async()=>{
  await load();
  for(const id of ['constructor','toString','__proto__']){
   await page.evaluate(id=>{location.hash=`board/${id}`;},id);await page.waitForTimeout(100);assert.equal(await page.locator('.app').count(),1);await title('Home study');
   await page.reload({waitUntil:'networkidle'});await title('Home study');assert.equal(await page.locator('.app').count(),1);
  }
  const own=structuredClone(fixture);own.id='own-board-names';own.boards.constructor={...structuredClone(own.boards.child),id:'constructor',title:'Own constructor'};own.boards.root.cards.push({id:'own-constructor',type:'board',boardId:'constructor',title:'Own constructor',x:650,y:100,width:160,height:160,z:3});
  await load(own);await page.evaluate(()=>{location.hash='board/constructor';});await title('Own constructor');await page.getByText('Saved on this device',{exact:true}).waitFor();await page.reload({waitUntil:'networkidle'});await title('Own constructor');
  await canvasFocus();await page.keyboard.press('Control+u');await title('Home study');
  own.boards.root.cards.push({id:'broken-prototype',type:'board',boardId:'toString',title:'Deleted prototype shortcut',isShortcut:true,x:850,y:100,width:160,height:160,z:4});await load(own);
  const broken=page.locator('[data-card-id="broken-prototype"]');assert.match(await broken.innerText(),/Original board deleted/);await broken.click({position:{x:3,y:3}});assert.equal(await page.getByTitle('Board icon',{exact:true}).count(),0);assert.equal(await page.getByTitle('Convert to Template',{exact:true}).isDisabled(),true);
  await page.getByRole('button',{name:'Export',exact:true}).click();await page.getByRole('switch',{name:'Include sub-boards',exact:true}).check();const pending=page.waitForEvent('download');pending.catch(()=>{});await page.getByRole('menuitem',{name:'Markdown',exact:true}).click();const download=await pending,filename=new URL('board-registry-subboards.md',artifacts).pathname;await download.saveAs(filename);const markdown=await readFile(filename,'utf8');assert.match(markdown,/Own constructor/);assert.match(markdown,/Deleted prototype shortcut/);assert.match(markdown,/Keep the content/);await page.keyboard.press('Escape');
 });
 assert.deepEqual(errors,[]);
}finally{await writeFile(new URL('canvas-shortcuts-results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),engine,url,referenceShortcutNamesObserved:true,referenceZoomStepMeasured:false,results,errors},null,2));await browser.close();}
