import {it,expect} from 'vitest';
import {createCard,createWorkspace} from '../src/core/model';
import {updateCardAppearance} from '../src/core/cardAppearance';
import {exportWorkspace,importWorkspace} from '../src/core/storage';
import {exportBoardHtml,exportBoardSvg} from '../src/export';

it('keeps card backgrounds and top strips independent, adjusts height once, and round-trips their appearance',()=>{
  const doc=createWorkspace(),id=doc.rootBoardId,a={...createCard('note',10,10),type:'note' as const,text:'Appearance',height:54};doc.boards={[id]:doc.boards[id]};doc.boards[id].cards=[a];doc.boards[id].connections=[];
  let next=updateCardAppearance(doc,id,[a.id],{strip:'#4ebafd'});expect(next.boards[id].cards[0]).toMatchObject({stripColor:'#4ebafd',height:58});
  next=updateCardAppearance(next,id,[a.id],{background:'transparent'});expect(next.boards[id].cards[0]).toMatchObject({color:'transparent',stripColor:'#4ebafd',height:58});
  expect(updateCardAppearance(next,id,[a.id],{strip:'#4ebafd'})).toBe(next);
  const imported=importWorkspace(exportWorkspace(next));expect(imported).toEqual(next);
  expect(exportBoardHtml(imported.boards[id])).toContain('class="card-top-strip" style="background:#4ebafd"');
  expect(exportBoardSvg(imported.boards[id])).toContain('background:transparent');
  next=updateCardAppearance(next,id,[a.id],{strip:null});expect(next.boards[id].cards[0]).toMatchObject({color:'transparent',stripColor:undefined,height:54});
});
it('applies a selection without changing unrelated cards, and retains at most seven distinct custom colors',()=>{
  const doc=createWorkspace(),id=doc.rootBoardId,a=createCard('note'),b=createCard('image');doc.boards={[id]:doc.boards[id]};doc.boards[id].cards=[a,b];doc.boards[id].connections=[];
  let next=doc;for(let i=0;i<9;i++){const value=`#00110${i}`;next=updateCardAppearance(next,id,[a.id],{background:value,remember:value});}
  expect(next.customColors).toEqual(['#001102','#001103','#001104','#001105','#001106','#001107','#001108']);expect(next.boards[id].cards[1]).toBe(b);
  next=updateCardAppearance(next,id,[a.id,b.id],{strip:'#ff5757'});expect(next.boards[id].cards.every(card=>card.stripColor==='#ff5757')).toBe(true);
  expect(importWorkspace(exportWorkspace(next))).toEqual(next);
});
it('rejects persisted executable styles and malformed color history while leaving invalid appearance actions unchanged',()=>{
  const doc=createWorkspace(),id=doc.rootBoardId,a=doc.boards[id].cards[0];expect(updateCardAppearance(doc,id,[a.id],{background:'url(https://bad.example)'})).toBe(doc);
  expect(()=>importWorkspace(exportWorkspace({...doc,customColors:['red']}))).toThrow('custom colors');
  doc.boards[id].cards[0]={...a,color:'url(https://bad.example)'};
  expect(()=>importWorkspace(exportWorkspace(doc))).toThrow('card color');
  doc.boards[id].cards[0]={...a,stripColor:'url(https://bad.example)'};
  expect(()=>importWorkspace(exportWorkspace(doc))).toThrow('color strip');
});
