import { describe, expect, it } from 'vitest';
import { mediaEmbedUrl } from '../src/core/media';

describe('media provider conversion', () => {
  it('normalizes YouTube, Vimeo and Spotify links without passing tracking or autoplay', () => {
    expect(mediaEmbedUrl('https://youtu.be/dQw4w9WgXcQ?autoplay=1')).toBe('https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ');
    expect(mediaEmbedUrl('https://vimeo.com/123456')).toBe('https://player.vimeo.com/video/123456');
    expect(mediaEmbedUrl('https://open.spotify.com/track/AbC123?si=x')).toBe('https://open.spotify.com/embed/track/AbC123');
  });
  it('accepts supported map queries and rejects injected HTML and lookalike hosts', () => {
    expect(mediaEmbedUrl('https://www.google.com/maps?q=Paris')).toBe('https://maps.google.com/maps?q=Paris&output=embed');
    for (const value of ['javascript:alert(1)', 'https://youtube.com.evil.test/watch?v=dQw4w9WgXcQ', '<iframe src=x>', 'https://example.com', 'https://youtube.com/watch?v=bad', 'https://google.com/maps/place/%ZZ']) expect(mediaEmbedUrl(value)).toBeNull();
  });
  it('embeds TED talk and language links using the provider player without carrying tracking parameters', () => {
    const player = 'https://embed.ted.com/talks/sir_ken_robinson_do_schools_kill_creativity';
    for (const url of ['https://www.ted.com/talks/sir_ken_robinson_do_schools_kill_creativity?language=en&autoplay=1', 'https://www.ted.com/talks/lang/ar/sir_ken_robinson_do_schools_kill_creativity', player]) expect(mediaEmbedUrl(url)).toBe(player);
    for (const url of ['https://ted.com.evil.test/talks/example', 'https://ted.com/playlists/1/example', 'https://ted.com/talks/example/extra', 'https://ted.com/talks/%22%3E%3Cscript%3E', 'https://embed.ted.com.evil.test/talks/example']) expect(mediaEmbedUrl(url)).toBeNull();
  });
});

describe('documented provider share routes', () => {
  it('accepts YouTube Music, live and existing private-domain players but refuses non-video paths', () => {
    const player = 'https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ';
    for (const source of ['https://music.youtube.com/watch?v=dQw4w9WgXcQ&si=tracking', 'https://youtube.com/live/dQw4w9WgXcQ?autoplay=1', player]) expect(mediaEmbedUrl(source)).toBe(player);
    for (const source of ['https://youtube.com/anything?v=dQw4w9WgXcQ', 'https://youtu.be/dQw4w9WgXcQ/extra', 'https://youtube.com/embed/dQw4w9WgXcQ/extra']) expect(mediaEmbedUrl(source)).toBeNull();
  });
  it('preserves the required Vimeo unlisted hash while removing tracking and supports channel share paths', () => {
    const player = 'https://player.vimeo.com/video/123456?h=abc987';
    expect(mediaEmbedUrl('https://vimeo.com/123456/abc987?share=copy')).toBe(player);
    expect(mediaEmbedUrl(`${player}&autoplay=1`)).toBe(player);
    for (const source of ['https://vimeo.com/channels/staffpicks/123456', 'https://vimeo.com/groups/shortfilms/videos/123456', 'https://vimeo.com/showcase/999/video/123456']) expect(mediaEmbedUrl(source)).toBe('https://player.vimeo.com/video/123456');
    for (const source of ['https://vimeo.com/channels/123456', 'https://vimeo.com/123456/extra/path', 'https://player.vimeo.com/not-video/123456']) expect(mediaEmbedUrl(source)).toBeNull();
  });
  it('handles localized and already embedded Spotify shares without autoplay or tracking', () => {
    for (const source of ['https://open.spotify.com/intl-ar/track/AbC123?si=tracking', 'https://open.spotify.com/embed/track/AbC123?autoplay=1']) expect(mediaEmbedUrl(source)).toBe('https://open.spotify.com/embed/track/AbC123');
    expect(mediaEmbedUrl('https://open.spotify.com/artist/Artist123')).toBe('https://open.spotify.com/embed/artist/Artist123');
    expect(mediaEmbedUrl('https://open.spotify.com/track/AbC123/extra')).toBeNull();
  });
  it('keeps a SoundCloud track or set identity without forwarding source tracking or treating a profile section as audio', () => {
    expect(mediaEmbedUrl('https://m.soundcloud.com/artist-name/track-name?utm_source=clipboard&auto_play=true#t=1:00')).toBe('https://w.soundcloud.com/player/?url=https%3A%2F%2Fsoundcloud.com%2Fartist-name%2Ftrack-name&auto_play=false');
    expect(mediaEmbedUrl('https://soundcloud.com/artist-name/sets/album-name?si=tracking')).toBe('https://w.soundcloud.com/player/?url=https%3A%2F%2Fsoundcloud.com%2Fartist-name%2Fsets%2Falbum-name&auto_play=false');
    for (const path of ['/artist-name/tracks', '/artist-name/sets', '/artist-name/track-name/extra']) expect(mediaEmbedUrl(`https://soundcloud.com${path}`)).toBeNull();
  });
  it('converts a Mixcloud show share to its public widget and rejects profile collections', () => {
    expect(mediaEmbedUrl('https://www.mixcloud.com/artist-name/show-name/?utm_campaign=share')).toBe('https://www.mixcloud.com/widget/iframe/?hide_cover=1&feed=%2Fartist-name%2Fshow-name%2F');
    for (const source of ['https://mixcloud.com/artist-name/', 'https://mixcloud.com/artist-name/uploads/', 'https://mixcloud.com/artist-name/show-name/extra']) expect(mediaEmbedUrl(source)).toBeNull();
  });
  it('keeps the chosen Apple Music album track while removing affiliate and playback fields', () => {
    const result = 'https://embed.music.apple.com/us/album/example-album/123456?i=987654';
    expect(mediaEmbedUrl('https://music.apple.com/us/album/example-album/123456?i=987654&at=affiliate&autoplay=true')).toBe(result);
    expect(mediaEmbedUrl(result)).toBe(result);
    expect(mediaEmbedUrl('https://music.apple.com/gb/playlist/example-playlist/pl.abc-123')).toBe('https://embed.music.apple.com/gb/playlist/example-playlist/pl.abc-123');
    for (const source of ['https://music.apple.com/us/artist/example/123456', 'https://music.apple.com/us/album/example/123456?i=invalid', 'https://music.apple.com/us/album/example/pl.abc']) expect(mediaEmbedUrl(source)).toBeNull();
  });
  it('normalizes numeric Deezer track, album and playlist shares to the documented widget', () => {
    for (const type of ['track', 'album', 'playlist']) expect(mediaEmbedUrl(`https://www.deezer.com/en/${type}/123456?utm_source=share`)).toBe(`https://widget.deezer.com/widget/dark/${type}/123456`);
    expect(mediaEmbedUrl('https://widget.deezer.com/widget/light/track/123456?autoplay=true')).toBe('https://widget.deezer.com/widget/dark/track/123456');
    expect(mediaEmbedUrl('https://deezer.com/en/artist/123456')).toBeNull();
  });
  it('converts a CodePen pen rather than arbitrary HTML or a profile', () => {
    for (const view of ['pen', 'full', 'embed']) expect(mediaEmbedUrl(`https://codepen.io/example-user/${view}/AbCdE?default-tab=js&editable=true`)).toBe('https://codepen.io/example-user/embed/AbCdE?default-tab=result');
    expect(mediaEmbedUrl('https://codepen.io/example-user')).toBeNull();
    expect(mediaEmbedUrl('https://codepen.io/example-user/pen/AbCdE/extra')).toBeNull();
  });
  it('embeds classic public Airtable shared views and leaves authenticated workspace URLs unsupported', () => {
    for (const source of ['https://airtable.com/shrAbCdEfGhIjKlMn?viewControls=off', 'https://airtable.com/embed/shrAbCdEfGhIjKlMn']) expect(mediaEmbedUrl(source)).toBe('https://airtable.com/embed/shrAbCdEfGhIjKlMn');
    for (const source of ['https://airtable.com/appAbCdEfGhIjKlMn/tblAbCdEfGhIjKlMn', 'https://airtable.com/shrshort', 'https://airtable.com/shrAbCdEfGhIjKlMn/extra']) expect(mediaEmbedUrl(source)).toBeNull();
  });
  it('decodes map searches exactly once and preserves literal percent and plus characters', () => {
    expect(mediaEmbedUrl('https://google.com/maps?q=100%25%20design%20%2B%20art')).toBe('https://maps.google.com/maps?q=100%25%20design%20%2B%20art&output=embed');
    expect(mediaEmbedUrl('https://google.com/maps/place/New+York')).toBe('https://maps.google.com/maps?q=New%20York&output=embed');
    expect(mediaEmbedUrl('https://google.com/maps-malicious?q=Paris')).toBeNull();
  });
  it('rejects credentials, nonstandard ports, lookalike hosts, controls and unresolved share shorteners', () => {
    for (const source of ['https://user:password@youtube.com/watch?v=dQw4w9WgXcQ', 'https://youtube.com:8443/watch?v=dQw4w9WgXcQ', 'https://music.apple.com.evil.test/us/album/example/123456', 'https://mixcloud.com.evil.test/user/show/', 'https://deezer.com@evil.test/track/123456', 'https://codepen.io/\nuser/pen/abc', 'https://on.soundcloud.com/example', 'https://spotify.link/example', 'https://music.amazon.com/albums/ASIN123', 'https://artist.bandcamp.com/track/example', 'data:text/html,<iframe>', 'https://youtube.com/watch?v=' + 'a'.repeat(4100)]) expect(mediaEmbedUrl(source)).toBeNull();
  });
});
