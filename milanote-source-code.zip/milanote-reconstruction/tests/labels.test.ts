import { describe, expect, it } from 'vitest';
import { createCard, createWorkspace } from '../src/core/model';
import type { Card, Workspace } from '../src/core/model';
import { exportWorkspace, importWorkspace } from '../src/core/storage';
import {
  createWorkspaceLabel, deleteWorkspaceLabel, isValidWorkspaceLabels, labelMatchesQuery,
  labelSelectionState, labelUsages, labelsForCard, migrateLegacyLabels, reconcileCopiedLabels,
  recolorWorkspaceLabel, renameWorkspaceLabel, searchWorkspaceLabels, setLabelAssignment,
} from '../src/core/labels';
import type { LabeledCard, LabelWorkspace } from '../src/core/labels';

function fixture():LabelWorkspace{
  const workspace=createWorkspace();
  const root=workspace.rootBoardId,child=Object.keys(workspace.boards).find(id=>id!==root)!;
  workspace.boards[root].cards=[
    {...createCard('note'),id:'a',type:'note',text:'First item'},
    {...createCard('note'),id:'b',type:'note',text:'Second item'},
    {...createCard('board'),id:'child-tile',type:'board',boardId:child,title:'Child'},
  ];
  workspace.boards[root].connections=[];
  workspace.boards[child].cards=[{...createCard('note'),id:'c',type:'note',text:'Nested item'}];
  return workspace;
}
const find=(workspace:Workspace,id:string)=>Object.values(workspace.boards).flatMap(board=>board.cards).find(card=>card.id===id)! as LabeledCard;
const childId=(workspace:Workspace)=>Object.keys(workspace.boards).find(id=>id!==workspace.rootBoardId)!;

describe('global label registry',()=>{
  it('migrates legacy tags across boards deterministically, preserves long names and does not revive removed IDs',()=>{
    const original=fixture(),long='Legacy label that is longer than thirty characters';
    find(original,'a').tags=['Research','مراجعة',long];
    find(original,'b').tags=['Research','research'];
    find(original,'c').tags=['مراجعة'];
    const before=structuredClone(original),first=migrateLegacyLabels(original),second=migrateLegacyLabels(structuredClone(original));
    expect(original).toEqual(before);
    expect(first.labels).toEqual(second.labels);
    expect(first.labels?.map(label=>label.name)).toEqual(['Research','مراجعة',long,'research']);
    expect(find(first,'a').labelIds?.[0]).toBe(find(first,'b').labelIds?.[0]);
    expect(find(first,'a').labelIds?.[1]).toBe(find(first,'c').labelIds?.[0]);
    expect(migrateLegacyLabels(first)).toBe(first);
    find(first,'b').labelIds=[];
    expect(find(migrateLegacyLabels(first),'b')).toMatchObject({labelIds:[],tags:[]});
    expect(importWorkspace(exportWorkspace(migrateLegacyLabels(first))).labels).toEqual(first.labels);
  });

  it('creates once, assigns only the selected cards and reports mixed selection before adding/removing the whole selection',()=>{
    const original=fixture(),root=original.rootBoardId;
    const result=createWorkspaceLabel(original,'Research',{boardId:root,cardIds:['a']});
    const id=result.label!.id;
    expect(original.labels).toBeUndefined();
    expect(find(result.workspace,'a').labelIds).toEqual([id]);
    expect(find(result.workspace,'b').labelIds).toBeUndefined();
    expect(labelSelectionState(result.workspace,root,['a','b'],id)).toBe('some');
    const assigned=setLabelAssignment(result.workspace,root,['a','b'],id,true);
    expect(labelSelectionState(assigned,root,['a','b'],id)).toBe('all');
    expect(labelSelectionState(assigned,root,[],id)).toBe('none');
    expect(createWorkspaceLabel(assigned,'Research',{boardId:root,cardIds:['b']}).workspace).toBe(assigned);
    const removed=setLabelAssignment(assigned,root,['a','b'],id,false);
    expect(labelSelectionState(removed,root,['a','b'],id)).toBe('none');
    expect(labelUsages(removed,id)).toEqual([]);
  });

  it('renames everywhere, preserves label identity and recolors without changing card content',()=>{
    const workspace=fixture(),root=workspace.rootBoardId;
    let {workspace:next,label}=createWorkspaceLabel(workspace,'Review',{boardId:root,cardIds:['a','b']},'#ff5757');
    next=setLabelAssignment(next,childId(next),['c'],label!.id,true);
    const old=structuredClone(next);
    const renamed=renameWorkspaceLabel(next,label!.id,'Checked');
    expect(labelUsages(renamed,label!.id).map(usage=>usage.cardId)).toEqual(['a','b','c']);
    for(const id of ['a','b','c'])expect(find(renamed,id)).toMatchObject({labelIds:[label!.id],tags:['Checked']});
    expect(find(next,'a').tags).toEqual(['Review']);
    const recolored=recolorWorkspaceLabel(renamed,label!.id,'#AD6FFF');
    expect(recolored.labels).toEqual([{id:label!.id,name:'Checked',color:'#ad6fff'}]);
    for(const id of ['a','b','c']){const current=find(recolored,id),previous=find(old,id);if(current.type!=='note'||previous.type!=='note')throw new Error('Expected note');expect(current.text).toBe(previous.text);}
    expect(renameWorkspaceLabel(recolored,label!.id,'Checked')).toBe(recolored);
    expect(recolorWorkspaceLabel(recolored,label!.id,'#ad6fff')).toBe(recolored);
  });

  it('deletes a definition and every live assignment while preserving other labels and card values',()=>{
    const workspace=fixture(),root=workspace.rootBoardId;
    let first=createWorkspaceLabel(workspace,'Delete me',{boardId:root,cardIds:['a','b']});
    let next=setLabelAssignment(first.workspace,childId(workspace),['c'],first.label!.id,true);
    const retained=createWorkspaceLabel(next,'Keep me',{boardId:root,cardIds:['a']});next=retained.workspace;
    const removed=deleteWorkspaceLabel(next,first.label!.id);
    expect(removed.labels?.map(label=>label.name)).toEqual(['Keep me']);
    expect(find(removed,'a')).toMatchObject({text:'First item',labelIds:[retained.label!.id],tags:['Keep me']});
    expect(find(removed,'b')).toMatchObject({labelIds:[],tags:[]});
    expect(find(removed,'c')).toMatchObject({labelIds:[],tags:[]});
    expect(labelUsages(removed,first.label!.id)).toEqual([]);
    expect(next.labels).toHaveLength(2);
    expect(importWorkspace(exportWorkspace(removed))).toEqual(removed);
  });

  it('filters and finds all cards by case-insensitive label text, including Arabic across boards',()=>{
    const workspace=fixture(),root=workspace.rootBoardId;
    const first=createWorkspaceLabel(workspace,'Research',{boardId:root,cardIds:['a']});
    const next=createWorkspaceLabel(first.workspace,'مراجعة الصور',{boardId:childId(workspace),cardIds:['c']});
    expect(searchWorkspaceLabels(next.workspace,'SEARCH').map(label=>label.name)).toEqual(['Research']);
    expect(searchWorkspaceLabels(next.workspace,'الصور').map(label=>label.name)).toEqual(['مراجعة الصور']);
    expect(labelMatchesQuery(next.workspace,find(next.workspace,'c'),'مراجعة')).toBe(true);
    expect(labelMatchesQuery(next.workspace,find(next.workspace,'b'),'مراجعة')).toBe(false);
    expect(labelMatchesQuery(next.workspace,find(next.workspace,'a'),'')).toBe(false);
    expect(labelsForCard(next.workspace,find(next.workspace,'c')).map(label=>label.id)).toEqual([next.label!.id]);
  });

  it('rejects invalid definitions and new names longer than the observed 30-character limit without mutating the document',()=>{
    const workspace=fixture();
    for(const name of ['', '   ', 'a'.repeat(31)])expect(createWorkspaceLabel(workspace,name).workspace).toBe(workspace);
    expect(createWorkspaceLabel(workspace,'Allowed',undefined,'red;position:fixed').workspace).toBe(workspace);
    const created=createWorkspaceLabel(workspace,'Allowed');
    expect(renameWorkspaceLabel(created.workspace,created.label!.id,'a'.repeat(31))).toBe(created.workspace);
    expect(recolorWorkspaceLabel(created.workspace,created.label!.id,'url(https://example.com)')).toBe(created.workspace);
    expect(isValidWorkspaceLabels([{id:'id',name:'Valid',color:'#ad6fff'}])).toBe(true);
    for(const invalid of [[{id:'id',name:' ',color:'#ad6fff'}],[{id:'id',name:'Valid',color:'red'}],[{id:'id',name:'One',color:'#ad6fff'},{id:'id',name:'Two',color:'#ff5757'}],[{id:'one',name:'Same',color:'#ad6fff'},{id:'two',name:'Same',color:'#ff5757'}]])expect(isValidWorkspaceLabels(invalid)).toBe(false);
  });
});

describe('clipboard label reconciliation',()=>{
  it('preserves nested assignments, remaps conflicting IDs and reuses target names and colors',()=>{
    const source=fixture(),target=fixture();
    source.labels=[{id:'collision',name:'Research',color:'#ad6fff'},{id:'source-ready',name:'Ready',color:'#ff5757'},{id:'new-label',name:'Novel',color:'#7cd651'}];
    target.labels=[{id:'collision',name:'Other',color:'#5882f8'},{id:'target-ready',name:'Ready',color:'#ffd14d'}];
    find(source,'a').labelIds=['collision','source-ready'];find(source,'a').tags=['Research','Ready'];
    find(source,'c').labelIds=['new-label','collision'];find(source,'c').tags=['Novel','Research'];
    const cards=[{...structuredClone(find(source,'a')),id:'copied-a'}] as Card[];
    const boards={copied:{...structuredClone(source.boards[childId(source)]),id:'copied',cards:[{...structuredClone(find(source,'c')),id:'copied-c'}] as Card[]}};
    const oldSource=structuredClone(source),oldTarget=structuredClone(target);
    const result=reconcileCopiedLabels(source,target,cards,boards);
    const research=result.labels.find(label=>label.name==='Research')!;
    expect(research.id).not.toBe('collision');
    expect(result.labels.find(label=>label.id==='collision')?.name).toBe('Other');
    expect(result.labels.find(label=>label.name==='Ready')).toMatchObject({id:'target-ready',color:'#ffd14d'});
    expect((result.cards[0] as LabeledCard).labelIds).toEqual([research.id,'target-ready']);
    expect((result.boards.copied.cards[0] as LabeledCard).labelIds).toEqual(['new-label',research.id]);
    expect(source).toEqual(oldSource);expect(target).toEqual(oldTarget);
    expect((cards[0] as LabeledCard).labelIds).toEqual(['collision','source-ready']);
  });

  it('uses unchanged global IDs and migrates copied legacy strings without losing old names',()=>{
    const source=fixture(),target=fixture();
    source.labels=[{id:'shared',name:'Shared',color:'#ad6fff'}];target.labels=structuredClone(source.labels);
    find(source,'a').labelIds=['shared'];find(source,'a').tags=['Shared'];find(source,'c').tags=['Legacy'];
    const result=reconcileCopiedLabels(source,target,[structuredClone(find(source,'a')),structuredClone(find(source,'c'))]);
    expect((result.cards[0] as LabeledCard).labelIds).toEqual(['shared']);
    expect(result.labels.filter(label=>label.name==='Shared')).toHaveLength(1);
    const legacy=result.labels.find(label=>label.name==='Legacy')!;
    expect((result.cards[1] as LabeledCard).labelIds).toEqual([legacy.id]);
    expect((result.cards[1] as LabeledCard).tags).toEqual(['Legacy']);
  });
});
