import {openSavedTemplates} from './helpers/saved-templates.mjs';
import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {chromium} from 'playwright-core';

const base=process.env.TEST_URL||'http://127.0.0.1:5279',artifacts=new URL('../artifacts/',import.meta.url),results=[],pageErrors=[];
await mkdir(artifacts,{recursive:true});
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
const context=await browser.newContext({viewport:{width:1440,height:1000},acceptDownloads:true});await context.grantPermissions(['clipboard-read','clipboard-write'],{origin:base});
const page=await context.newPage();page.setDefaultTimeout(10000);page.on('pageerror',error=>pageErrors.push(error.message));
const card=id=>page.locator(`[data-card-id="${id}"]`),notes=()=>page.locator('.world .card-note');
const fixture=(template=false)=>({version:1,id:'workspace-tools',title:'Workspace tools',rootBoardId:'root',updatedAt:'2026-10-25T00:00:00Z',labels:[{id:'keep',name:'Preserved',color:'#ad6fff'}],boards:{root:{id:'root',title:'Workspace tools',cards:[{id:'a',type:'note',text:'Drag me',x:100,y:150,width:270,height:54,z:1,labelIds:['keep'],tags:['Preserved']},{id:'child-tile',type:'board',boardId:'child',title:'Nested ideas',x:850,y:400,width:160,height:160,z:1}],connections:[],viewport:{x:20,y:20,zoom:1}},child:{id:'child',title:'Nested ideas',parentBoardId:'root',...(template?{isTemplate:true}:{}),cards:[{id:'child-note',type:'note',text:'Nested content',x:60,y:60,width:270,height:54,z:1}],connections:[],viewport:{x:25,y:35,zoom:.9}}}});
async function load(data=fixture()){
  await page.keyboard.press('Escape');await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'workspace-tools.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(data))});
  await page.getByText('Workspace imported. Undo to return to your previous workspace.',{exact:true}).waitFor();await page.getByText('Saved on this device',{exact:true}).waitFor();
}
async function backup(name){
  await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();const pending=page.waitForEvent('download');pending.catch(()=>{});await page.getByRole('button',{name:/Workspace backup/}).click();const download=await pending,destination=new URL(name,artifacts);await download.saveAs(destination.pathname);await page.getByTitle('Close dialog',{exact:true}).click();return JSON.parse(await readFile(destination,'utf8'));
}
async function check(name,callback){try{await callback();results.push({name,status:'passed'});console.log('PASS',name);}catch(error){results.push({name,status:'failed',error:error.stack});process.exitCode=1;console.error('FAIL',name,error.message);await page.screenshot({path:new URL(`workspace-tools-failure-${results.length}.png`,artifacts).pathname}).catch(()=>{});await page.mouse.up().catch(()=>{});await page.keyboard.up('Alt').catch(()=>{});await page.keyboard.press('Escape').catch(()=>{});}}
async function beginAltDrag(){const box=await card('a').boundingBox();assert.ok(box);await page.keyboard.down('Alt');await page.mouse.move(box.x+3,box.y+3);await page.mouse.down();return{x:box.x+3,y:box.y+3};}
async function endDrag(){await page.mouse.up();await page.keyboard.up('Alt');}
async function title(value){await page.waitForFunction(value=>document.querySelector('[aria-label="Current board title"]')?.value===value,value);}
async function templates(){await openSavedTemplates(page);await page.locator('.modal-templates').waitFor();}
try{
  await page.goto(base);await page.getByText('Saved on this device',{exact:true}).waitFor();
  await check('Alt-drag clones once across many pointer moves and a single undo removes the clone while retaining the original',async()=>{
    await load();const start=await beginAltDrag();await page.mouse.move(start.x+125,start.y+115,{steps:20});await endDrag();assert.equal(await notes().count(),2);
    const data=await backup('workspace-alt-drag.json'),original=data.boards.root.cards.find(card=>card.id==='a'),copy=data.boards.root.cards.find(card=>card.type==='note'&&card.id!=='a');assert.equal(original.x,100);assert.equal(original.y,150);assert.equal(copy.x,225);assert.equal(copy.y,265);assert.deepEqual(copy.labelIds,['keep']);assert.equal(data.boards.root.cards.length,3);
    await page.getByTitle('Undo (⌘Z)',{exact:true}).click();assert.equal(await notes().count(),1);assert.equal(await card('a').count(),1);assert.equal(await card('a').evaluate(element=>parseFloat(element.style.left)),100);await page.getByTitle('Redo (⇧⌘Z)',{exact:true}).click();assert.equal(await notes().count(),2);
  });
  await check('Alt-click with no movement creates no clone or undo transaction',async()=>{
    const before=fixture();before.boards.root.cards.push({...before.boards.root.cards[0],id:'prior',x:450});await load(before);await load();await beginAltDrag();await endDrag();assert.equal(await notes().count(),1);const data=await backup('workspace-alt-click.json');assert.equal(data.boards.root.cards.length,2);assert.equal(data.boards.root.cards.find(card=>card.id==='a').x,100);
    await page.getByTitle('Undo (⌘Z)',{exact:true}).click();assert.equal(await notes().count(),2);assert.equal(await card('prior').count(),1);
  });
  await check('Escape cancels an in-progress Alt duplicate and leaves no undo transaction',async()=>{
    const before=fixture();before.boards.root.cards.push({...before.boards.root.cards[0],id:'prior',x:450});await load(before);await load();const start=await beginAltDrag();await page.mouse.move(start.x+85,start.y+100,{steps:10});assert.equal(await notes().count(),2);await page.keyboard.press('Escape');await endDrag();assert.equal(await notes().count(),1);const data=await backup('workspace-alt-escape.json');assert.equal(data.boards.root.cards.find(card=>card.id==='a').x,100);
    await page.getByTitle('Undo (⌘Z)',{exact:true}).click();assert.equal(await notes().count(),2);assert.equal(await card('prior').count(),1);
  });
  await check('Pointer cancellation rolls back an in-progress Alt duplicate before a mouse-up can commit it',async()=>{
    await load();const start=await beginAltDrag();await page.mouse.move(start.x+80,start.y+95,{steps:10});assert.equal(await notes().count(),2);await page.locator('.stage').dispatchEvent('pointercancel',{pointerId:1,pointerType:'mouse',bubbles:true});await endDrag();assert.equal(await notes().count(),1);const data=await backup('workspace-alt-cancel.json');assert.equal(data.boards.root.cards.length,2);assert.equal(data.boards.root.cards.find(card=>card.id==='a').x,100);
  });
  await check('Local board links open by hash and after reload; pasting the copied local link creates a shortcut to the existing board',async()=>{
    await load();await card('child-tile').click({position:{x:3,y:3}});await page.getByTitle('Copy a Link to This Board',{exact:true}).click();const link=await page.evaluate(()=>navigator.clipboard.readText());assert.equal(new URL(link).hash,'#board/child');
    await page.evaluate(()=>location.hash='board/child');await title('Nested ideas');assert.equal(await card('child-note').count(),1);await page.getByText('Saved on this device',{exact:true}).waitFor();await page.reload();await title('Nested ideas');assert.equal(await card('child-note').count(),1);
    await page.evaluate(()=>location.hash='board/root');await title('Workspace tools');await page.locator('.stage').click({position:{x:600,y:600}});await page.evaluate(link=>navigator.clipboard.writeText(link),link);await page.keyboard.press('Control+v');await page.waitForFunction(()=>document.querySelectorAll('.world .card-board').length===2);
    const data=await backup('workspace-local-shortcut.json'),shortcuts=data.boards.root.cards.filter(card=>card.type==='board'&&card.isShortcut);assert.equal(shortcuts.length,1);assert.equal(shortcuts[0].boardId,'child');assert.equal(Object.keys(data.boards).length,2);assert.equal(data.boards.child.parentBoardId,'root');
  });
  await check('Template library rename updates its owning tile and undo restores the former name',async()=>{
    await load(fixture(true));await templates();await page.getByRole('button',{name:'Rename template Nested ideas',exact:true}).click();await page.getByRole('textbox',{name:'Template name',exact:true}).fill('Reusable ideas');await page.getByRole('textbox',{name:'Template name',exact:true}).press('Enter');await page.getByRole('button',{name:'Use template Reusable ideas',exact:true}).waitFor();await page.getByTitle('Close dialog',{exact:true}).click();
    const data=await backup('workspace-template-rename.json');assert.equal(data.boards.child.title,'Reusable ideas');assert.equal(data.boards.root.cards.find(card=>card.id==='child-tile').title,'Reusable ideas');assert.equal(data.boards.child.isTemplate,true);await page.getByTitle('Undo (⌘Z)',{exact:true}).click();await templates();await page.getByRole('button',{name:'Use template Nested ideas',exact:true}).waitFor();await page.getByTitle('Close dialog',{exact:true}).click();
  });
  await check('Revert removes the template flag/library entry while preserving the board, and undo restores it',async()=>{
    await load(fixture(true));await templates();await page.getByRole('button',{name:'Revert template Nested ideas to board',exact:true}).click();assert.equal(await page.getByRole('button',{name:'Use template Nested ideas',exact:true}).count(),0);await page.getByTitle('Close dialog',{exact:true}).click();const data=await backup('workspace-template-revert.json');assert.equal(data.boards.child.isTemplate,undefined);assert.equal(data.boards.child.cards[0].text,'Nested content');assert.equal(data.boards.root.cards.find(card=>card.id==='child-tile').boardId,'child');await page.getByTitle('Undo (⌘Z)',{exact:true}).click();await templates();await page.getByRole('button',{name:'Use template Nested ideas',exact:true}).waitFor();await page.getByTitle('Close dialog',{exact:true}).click();
  });
  await check('Deleting a template moves its full board into recoverable Trash and one undo restores both library and owning tile',async()=>{
    await load(fixture(true));await templates();await page.getByRole('button',{name:'Delete template Nested ideas',exact:true}).click();assert.equal(await page.getByRole('button',{name:'Use template Nested ideas',exact:true}).count(),0);await page.getByTitle('Close dialog',{exact:true}).click();assert.equal(await card('child-tile').count(),0);
    const data=await backup('workspace-template-delete.json');assert.equal(data.boards.child,undefined);assert.equal(data.trash.length,1);assert.equal(data.trash[0].boards.child.cards[0].text,'Nested content');await page.getByTitle('Undo (⌘Z)',{exact:true}).click();assert.equal(await card('child-tile').count(),1);await templates();await page.getByRole('button',{name:'Use template Nested ideas',exact:true}).waitFor();await page.getByTitle('Close dialog',{exact:true}).click();
  });
  assert.deepEqual(pageErrors,[]);results.push({name:'No uncaught browser errors',status:'passed'});
}finally{await writeFile(new URL('workspace-tools-e2e-results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),base,referenceParityClaimed:false,results,pageErrors},null,2));await browser.close();}
