import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {chromium,webkit} from 'playwright-core';
const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium',url=process.env.TEST_URL||'http://127.0.0.1:5306';
const artifacts=new URL(`../artifacts/${engine==='webkit'?'webkit/':''}template-catalog/`,import.meta.url);await mkdir(artifacts,{recursive:true});
const catalog=JSON.parse(await readFile(new URL('../src/data/templateCatalog.json',import.meta.url),'utf8'));
const browser=await(engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']}));
const context=await browser.newContext({viewport:{width:1440,height:1000}}),page=await context.newPage(),results=[],errors=[],catalogRequests=[];page.setDefaultTimeout(10000);page.on('pageerror',error=>errors.push(error.stack||error.message));
page.on('request',request=>{if(new URL(request.url()).pathname==='/src/data/templateCatalog.json')catalogRequests.push(request.url());});
// Catalog assets are public remote references. These behavioral tests deliberately
// block external requests; they do not establish asset availability or pixel parity.
await context.route('**/*',route=>{const destination=new URL(route.request().url());return destination.origin===new URL(url).origin||['data:','blob:'].includes(destination.protocol)?route.continue():route.abort();});
const fixture={version:1,id:'catalog-browser',title:'Catalog test',rootBoardId:'catalog-root',updatedAt:'2026-10-29T00:00:00.000Z',boards:{'catalog-root':{id:'catalog-root',title:'Catalog test',cards:[],connections:[],viewport:{x:16,y:16,zoom:1},background:'#ebedee',grid:true}}};
const picker=()=>page.getByRole('region',{name:'Choose a template',exact:true});
const template=id=>picker().locator(`[data-template-id="${id}"]`),category=id=>picker().locator(`[data-category-id="${id}"]`);
async function workspace(){return page.evaluate(()=>new Promise((resolve,reject)=>{const request=indexedDB.open('visual-workspace');request.onerror=()=>reject(request.error);request.onsuccess=()=>{const db=request.result,read=db.transaction('documents','readonly').objectStore('documents').get('workspace');read.onsuccess=()=>{resolve(read.result?.workspace);db.close();};read.onerror=()=>reject(read.error);};}));}
async function saved(predicate){for(let n=0;n<200;n++){const doc=await workspace();if(doc&&predicate(doc))return doc;await page.waitForTimeout(25);}await writeFile(new URL('persistence-diagnostic.json',artifacts),JSON.stringify({current:await workspace(),active:await page.evaluate(()=>({tag:document.activeElement?.tagName,history:document.querySelector('.app')?.getAttribute('data-history'),title:document.querySelector('[aria-label="Current board title"]')?.value,undo:document.querySelector('[title="Undo (⌘Z)"]')?.disabled,redo:document.querySelector('[title="Redo (⇧⌘Z)"]')?.disabled}))},null,2));throw Error('The expected workspace transaction did not persist');}
async function imported(){await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'catalog-fixture.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(fixture))});await page.getByText('Workspace imported. Undo to return to your previous workspace.',{exact:true}).waitFor();await saved(doc=>doc.id===fixture.id&&Object.keys(doc.boards).length===1);}
async function open(){await page.getByRole('button',{name:'Templates',exact:true}).click();await picker().waitFor();}
async function all(){await picker().getByRole('button',{name:'More templates...',exact:true}).click();await picker().getByLabel('Search templates',{exact:true}).waitFor();}
async function choose(id){if(await template(id).count()===0){if(await picker().getByRole('button',{name:'More templates...',exact:true}).count())await all();await picker().getByLabel('Search templates',{exact:true}).fill(catalog.entries.find(e=>e.id===id).title);}await template(id).click();await page.getByLabel('Template preview',{exact:true}).waitFor();}
async function run(name,action){try{await action();results.push({name,status:'passed'});console.log('PASS',name);}catch(error){results.push({name,status:'failed',message:error.stack});process.exitCode=1;await page.screenshot({path:new URL(`failure-${results.length}.png`,artifacts).pathname,fullPage:true}).catch(()=>{});throw error;}}
let baseline,chosenRoot,committed;
try{
 await page.goto(url,{waitUntil:'domcontentloaded'});await page.getByText('Saved on this device',{exact:true}).waitFor();await imported();baseline=await workspace();
 await run('Initial board and JSON import do not fetch the template catalog before its picker opens',async()=>assert.deepEqual(catalogRequests,[]));
 await run('All31 actual categories expose206 entries in captured order with exact IDs and category counts',async()=>{
  await open();assert.equal(catalogRequests.length,1);await all();assert.equal(await picker().locator('.template-library-category').count(),31);
  for(const item of catalog.categories){await category(item.id).click();assert.deepEqual(await picker().locator('.template-library-template').evaluateAll(buttons=>buttons.map(button=>({id:button.dataset.templateId,displayName:button.textContent}))),item.entries);await picker().getByRole('button',{name:'Back',exact:true}).click();}
  assert.deepEqual((await workspace()).boards,baseline.boards);
 });
 await run('Every214 registered template is reachable through its real search title without changing the saved workspace',async()=>{
  for(const entry of catalog.entries){await picker().getByLabel('Search templates',{exact:true}).fill(entry.title);await template(entry.id).waitFor();assert.equal(await template(entry.id).isVisible(),true,entry.id);}
  await picker().getByLabel('Search templates',{exact:true}).fill('no-match-template-493728');await picker().getByText('No templates found',{exact:true}).waitFor();assert.deepEqual((await workspace()).boards,baseline.boards);
 });
 await run('Preview and keep-example toggle render the two captured5Whys branches without autosaving or adding Undo history',async()=>{
  await choose('5-whys');await page.getByLabel('Template preview',{exact:true}).getByText('[Insert problem statement]',{exact:true}).waitFor();
  assert.equal(await page.locator('[data-template-preview-card]').count(),catalog.boards[catalog.entries.find(e=>e.id==='5-whys').emptyBoardId].cards.filter(c=>!c.unsorted).length);
  await picker().getByLabel('Keep example content',{exact:true}).check();await page.getByLabel('Template preview',{exact:true}).getByText('The product is not growing in its market share, yet those who have bought the product maintain high levels of satisfaction',{exact:false}).waitFor();assert.deepEqual((await workspace()).boards,baseline.boards);
  await picker().getByLabel('Keep example content',{exact:true}).uncheck();await page.getByLabel('Template preview',{exact:true}).getByText('[Insert problem statement]',{exact:true}).waitFor();
 });
 await run('Continue commits one complete editable branch; one Undo removes it and Redo restores all board, card and connection identities',async()=>{
  await picker().getByRole('button',{name:'Use this template',exact:true}).click();await picker().waitFor({state:'hidden'});committed=await saved(doc=>doc.boards[fixture.rootBoardId].cards.length===1);await writeFile(new URL('committed-before-undo.json',artifacts),JSON.stringify(committed,null,2));chosenRoot=committed.boards[fixture.rootBoardId].cards[0].boardId;
  const source=catalog.boards[catalog.entries.find(e=>e.id==='5-whys').emptyBoardId];assert.equal(committed.boards[chosenRoot].cards.length,source.cards.length);assert.equal(committed.boards[chosenRoot].connections.length,source.connections.length);assert.equal(committed.boards[chosenRoot].title,'5 Whys');
  await writeFile(new URL('before-undo.json',artifacts),JSON.stringify(await page.evaluate(()=>({active:document.activeElement?.tagName,history:document.querySelector('.app')?.getAttribute('data-history'),selected:window.getSelection()?.toString(),undo:document.querySelector('[title="Undo (⌘Z)"]')?.disabled})),null,2));
  await page.keyboard.press('Control+z');await saved(doc=>Object.keys(doc.boards).length===1&&doc.boards[fixture.rootBoardId].cards.length===0);
  await page.keyboard.press('Control+Shift+z');const redone=await saved(doc=>!!doc.boards[chosenRoot]);assert.deepEqual(redone.boards,committed.boards);
 });
 await run('Committed nested content and custom reference metadata survive a real reload; cancelling another preview leaves it unchanged',async()=>{
  const before=await workspace();await page.reload({waitUntil:'domcontentloaded'});await page.getByText('Saved on this device',{exact:true}).waitFor();const after=await saved(doc=>!!doc.boards[chosenRoot]);assert.deepEqual(after.boards,before.boards);
  await open();await choose('project-plan-template');await picker().getByLabel('Keep example content',{exact:true}).check();await page.locator('[data-template-preview-card] aside[data-note-callout-icon]').first().waitFor();
  const unchanged=await workspace();await page.keyboard.press('Escape');await picker().waitFor({state:'hidden'});assert.deepEqual((await workspace()).boards,unchanged.boards);
 });
 assert.deepEqual(errors,[]);await page.screenshot({path:new URL('preview.png',artifacts).pathname,fullPage:true});
}finally{await writeFile(new URL('results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),engine,url,results,errors,coverage:{registeredTemplates:214,categories:31,categoryEntries:206},limitation:'Behavioral source checks; public asset requests blocked. No reference pixel comparison, full template content fidelity or live external resource availability is established.'},null,2));await browser.close();}
