import {describe,expect,it} from 'vitest';
import {linkPreviewHeight} from '../src/core/linkPreview';

describe('reference-measured link image geometry',()=>{
  it.each([
    ['wide',270,400,200,134],
    ['tall',270,200,400,542],
    ['square',270,300,300,270],
  ])('%s uses the measured eight-pixel framing',(_name,width,naturalWidth,naturalHeight,expected)=>{
    expect(linkPreviewHeight(Number(width),Number(naturalWidth),Number(naturalHeight))).toBe(expected);
  });
  it('derives geometry from the actual resized width rather than default card width',()=>{
    expect(linkPreviewHeight(390,400,200)).toBe(190);
    expect(linkPreviewHeight(246,200,400)).toBe(494);
    expect(linkPreviewHeight(150,300,300)).toBe(150);
  });
  it('keeps the measured six-pixel minimum for very shallow images',()=>{
    expect(linkPreviewHeight(270,10000,1)).toBe(6);
  });
  it.each([0,-1,NaN,Infinity])('rejects invalid source or frame dimension %s',invalid=>{
    expect(()=>linkPreviewHeight(invalid,400,200)).toThrow();
    expect(()=>linkPreviewHeight(270,invalid,200)).toThrow();
    expect(()=>linkPreviewHeight(270,400,invalid)).toThrow();
  });
});
