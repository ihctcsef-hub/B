import {describe,it,expect} from 'vitest';
import http from 'node:http';
import net from 'node:net';
import {EventEmitter} from 'node:events';
import {createLinkMetadataMiddleware,getLinkMetadata,isPublicAddress,normalizeMetadataUrl,parseLinkMetadata,requestPublicPage,resolvePublicTarget} from '../server/link-metadata.mjs';
const publicLookup=async()=>[{address:'93.184.216.34',family:4}];
const response=()=>({statusCode:0,headers:{},body:'',setHeader(name,value){this.headers[name]=value;},end(value){this.body=value;}});
const page=body=>({status:200,headers:{'content-type':'text/html'},body});
describe('public link metadata adapter',()=>{
 it('parses real HTML entities, OG priorities, relative images and plain-text descriptions without returning scripts',()=>{
  const result=parseLinkMetadata('<title>Fallback &amp; title</title><meta name="twitter:title" content="Twitter"><meta property="og:title" content="OG &amp; title"><meta name="description" content="Plain description"><meta property="og:description" content="&lt;b&gt;Rich&lt;/b&gt; description"><meta property="og:image" content="../cover.jpg"><script>secret()</script>','https://example.com/path/article');
  expect(result).toEqual({url:'https://example.com/path/article',title:'OG & title',description:'Rich description',image:'https://example.com/cover.jpg'});
  expect(JSON.stringify(result)).not.toContain('secret');
 });
 it('uses Twitter and document metadata fallbacks, resolves a safe base, and omits absent/fake details',()=>{
  expect(parseLinkMetadata('<title>Document title</title><meta name="description" content="Words">','https://example.com/')).toEqual({url:'https://example.com/',title:'Document title',description:'Words'});
  expect(parseLinkMetadata('<base href="https://example.org/photos/"><meta name="twitter:title" content="Tweet"><meta name="twitter:image" content="photo.png">','https://example.com/')).toEqual({url:'https://example.com/',title:'Tweet',image:'https://example.org/photos/photo.png'});
  expect(parseLinkMetadata('<script>title</script><meta property="og:image" content="javascript:alert(1)">','https://example.com/')).toEqual({url:'https://example.com/'});
 });
 it('normalizes only credential-free web URLs on standard ports',()=>{
  expect(normalizeMetadataUrl(' HTTPS://EXAMPLE.COM/a#part')?.href).toBe('https://example.com/a');
  for(const url of ['file:///etc/passwd','data:text/html,x','https://user:secret@example.com/','https://example.com:8080/','http://[::1]:999/','https://example.com/'+ 'x'.repeat(4096)])expect(normalizeMetadataUrl(url)).toBeNull();
 });
 it('rejects private, loopback, documentation, multicast and transition addresses for IPv4/IPv6',()=>{
  for(const ip of ['127.0.0.1','0.0.0.0','10.1.2.3','100.64.0.1','169.254.169.254','172.31.2.1','192.168.0.1','192.0.2.1','192.88.99.1','198.18.1.1','198.51.100.1','203.0.113.1','224.0.0.1','255.255.255.255','::','::1','::ffff:8.8.8.8','fc00::1','fe80::1','ff02::1','2001:db8::1','2001::1','2002:0808:0808::1','3fff::1'])expect(isPublicAddress(ip),ip).toBe(false);
  for(const ip of ['8.8.8.8','93.184.216.34','1.1.1.1','203.0.114.1','198.51.101.1','192.0.3.1','2606:4700:4700::1111','2001:4860:4860::8888'])expect(isPublicAddress(ip),ip).toBe(true);
 });
 it('rejects alternate literal loopback formats, local DNS names and mixed DNS answers before any request',async()=>{
  let calls=0;const request=async()=>{calls++;return page('<title>Wrong</title>');};
  for(const url of ['http://2130706433','http://0x7f000001','http://127.1','http://[::1]','https://localhost','https://router.local'])await expect(getLinkMetadata(url,{lookup:publicLookup,request})).rejects.toThrow();
  await expect(getLinkMetadata('https://example.com/',{lookup:async()=>[{address:'8.8.8.8',family:4},{address:'127.0.0.1',family:4}],request})).rejects.toThrow('Private');expect(calls).toBe(0);
 });
 it('pins the resolved public address into the transport and revalidates every redirect destination',async()=>{
  const targets=[];const result=await getLinkMetadata('https://example.com/start',{lookup:publicLookup,request:async(url,target)=>{targets.push({url:url.href,...target});return targets.length===1?{status:302,headers:{location:'/final'},body:''}:page('<title>Final</title>');}});
  expect(result).toEqual({url:'https://example.com/final',title:'Final'});expect(targets).toHaveLength(2);expect(targets.every(t=>t.address==='93.184.216.34'&&t.hostname==='example.com'&&t.port===443)).toBe(true);
  let calls=0;await expect(getLinkMetadata('https://example.com/',{lookup:publicLookup,request:async()=>{calls++;return {status:302,headers:{location:'http://169.254.169.254/latest'},body:''};}})).rejects.toThrow('Private');expect(calls).toBe(1);
 });
 it('blocks credential/custom-port redirects, loops, too many hops and private image targets',async()=>{
  for(const location of ['http://user:pass@example.com/','https://example.com:444/','file:///etc/passwd','https://example.com/'])await expect(getLinkMetadata('https://example.com/',{lookup:publicLookup,request:async()=>({status:302,headers:{location},body:''})})).rejects.toThrow();
  let hops=0;await expect(getLinkMetadata('https://example.com/',{lookup:publicLookup,request:async()=>({status:302,headers:{location:'/step'+ ++hops},body:''})})).rejects.toThrow('Too many');expect(hops).toBe(5);
  expect(await getLinkMetadata('https://example.com/',{lookup:publicLookup,request:async()=>page('<title>Page</title><meta property="og:image" content="http://127.0.0.1/image">')})).toEqual({url:'https://example.com/',title:'Page'});
 });
 it('bounds body size and deadlines, including an injected transport that ignores cancellation',async()=>{
  await expect(getLinkMetadata('https://example.com/',{lookup:publicLookup,maxBytes:10,request:async()=>page('x'.repeat(11))})).rejects.toThrow('Unsupported');
  await expect(getLinkMetadata('https://example.com/',{lookup:publicLookup,signal:AbortSignal.timeout(20),request:()=>new Promise(()=>{})})).rejects.toThrow();
  await expect(resolvePublicTarget(new URL('https://example.com/'),{lookup:()=>new Promise(()=>{}),signal:AbortSignal.timeout(20)})).rejects.toThrow();
 });
 it('mounts only its exact GET route, caches public results and hides transport/private errors',async()=>{
  let calls=0;const handler=createLinkMetadataMiddleware({lookup:publicLookup,request:async()=>{calls++;return page('<title>Safe title</title>');}});
  for(let i=0;i<2;i++){const res=response();await handler({url:'/api/links/metadata?url=https%3A%2F%2Fexample.com%2F',method:'GET',headers:{cookie:'secret=1',authorization:'Bearer secret'}},res);expect(res.statusCode).toBe(200);expect(JSON.parse(res.body).title).toBe('Safe title');expect(res.headers['Cache-Control']).toBe('no-store');expect(res.body).not.toContain('secret');}expect(calls).toBe(1);
  let next=false;await handler({url:'/not-the-route',method:'GET'},response(),()=>next=true);expect(next).toBe(true);
  const wrong=response();await handler({url:'/api/links/metadata',method:'POST'},wrong);expect(wrong.statusCode).toBe(405);
  const invalid=response();await handler({url:'/api/links/metadata?url=file:///secret',method:'GET'},invalid);expect(invalid.statusCode).toBe(400);
  const denied=response();await handler({url:'/api/links/metadata?url=http://127.0.0.1/private',method:'GET'},denied);expect(denied.statusCode).toBe(503);expect(denied.body).not.toMatch(/127|Private destination/);
 });
 it('native transport preserves the intended Host, strips incoming credentials, rejects non-HTML and limits streamed bytes',async()=>{
  let received;const server=http.createServer((req,res)=>{received={headers:req.headers,url:req.url};res.setHeader('Content-Type',req.url==='/binary'?'image/png':'text/html');if(req.url==='/large'){res.write('x'.repeat(500));res.end('x'.repeat(500));}else res.end('<title>Native fixture</title>');});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const target={address:'127.0.0.1',family:4,hostname:'example.com',port:server.address().port};
  try{
   const result=await requestPublicPage(new URL('http://example.com/article?q=1'),target,{proxy:null,signal:AbortSignal.timeout(2000)});expect(result.body).toContain('Native fixture');expect(received.headers.host).toBe('example.com');expect(received.headers.cookie).toBeUndefined();expect(received.headers.authorization).toBeUndefined();expect(received.headers['accept-encoding']).toBe('identity');
   await expect(requestPublicPage(new URL('http://example.com/binary'),target,{proxy:null})).rejects.toThrow('Unsupported');await expect(requestPublicPage(new URL('http://example.com/large'),target,{proxy:null,maxBytes:100})).rejects.toThrow('too large');
  }finally{await new Promise(resolve=>server.close(resolve));}
 });
 it('numeric proxy CONNECT stays pinned, with proxy credentials isolated from the origin',async()=>{
  let originHeaders,connectTarget,proxyAuth;const sockets=new Set();
  const origin=http.createServer((req,res)=>{originHeaders=req.headers;res.setHeader('Content-Type','text/html');res.end('<title>Proxy fixture</title>');});await new Promise(resolve=>origin.listen(0,'127.0.0.1',resolve));
  const proxy=http.createServer();proxy.on('connect',(req,client,head)=>{connectTarget=req.url;proxyAuth=req.headers['proxy-authorization'];const upstream=net.connect({host:'127.0.0.1',port:origin.address().port},()=>{client.write('HTTP/1.1 200 Connection Established\r\n\r\n');if(head.length)upstream.write(head);client.pipe(upstream);upstream.pipe(client);});for(const socket of [client,upstream]){sockets.add(socket);socket.on('close',()=>sockets.delete(socket));socket.on('error',()=>{});}});await new Promise(resolve=>proxy.listen(0,'127.0.0.1',resolve));
  try{const value=await requestPublicPage(new URL('http://example.com/'),{hostname:'example.com',address:'93.184.216.34',family:4,port:80},{proxy:new URL(`http://proxy-user:proxy-pass@127.0.0.1:${proxy.address().port}`),signal:AbortSignal.timeout(2000)});expect(value.body).toContain('Proxy fixture');expect(connectTarget).toBe('93.184.216.34:80');expect(proxyAuth).toBe('Basic '+Buffer.from('proxy-user:proxy-pass').toString('base64'));expect(originHeaders.host).toBe('example.com');expect(originHeaders['proxy-authorization']).toBeUndefined();expect(originHeaders.authorization).toBeUndefined();expect(originHeaders.cookie).toBeUndefined();}
  finally{for(const socket of sockets)socket.destroy();await Promise.all([new Promise(resolve=>proxy.close(resolve)),new Promise(resolve=>origin.close(resolve))]);}
 });
 it('decodes declared legacy HTML encodings instead of corrupting page titles',async()=>{
  const server=http.createServer((_req,res)=>{res.setHeader('Content-Type','text/html; charset=windows-1252');res.end(Buffer.from('<title>Caf\xe9</title>','latin1'));});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  try{const value=await requestPublicPage(new URL('http://example.com/'),{hostname:'example.com',address:'127.0.0.1',family:4,port:server.address().port},{proxy:null,signal:AbortSignal.timeout(2000)});expect(parseLinkMetadata(value.body,'https://example.com/').title).toBe('Café');}finally{await new Promise(resolve=>server.close(resolve));}
 });
 it('limits concurrent upstream work and releases capacity after completion',async()=>{
  let release;const gate=new Promise(resolve=>release=resolve),handler=createLinkMetadataMiddleware({lookup:publicLookup,request:()=>gate});
  const pending=Array.from({length:8},(_,index)=>handler({url:'/api/links/metadata?url='+encodeURIComponent('https://example.com/page'+index),method:'GET'},response()));
  const excess=response();await handler({url:'/api/links/metadata?url=https://example.com/extra',method:'GET'},excess);expect(excess.statusCode).toBe(429);
  release(page('<title>Done</title>'));await Promise.all(pending);
  const next=response();await handler({url:'/api/links/metadata?url=https://example.com/after',method:'GET'},next);expect(next.statusCode).toBe(200);
 });
 it('aborts upstream work when the downstream response closes and cleans up its listeners',async()=>{
  let ready,signal;const started=new Promise(resolve=>ready=resolve),handler=createLinkMetadataMiddleware({lookup:publicLookup,request:(_url,_target,options)=>{signal=options.signal;ready();return new Promise(()=>{});}});
  const req=Object.assign(new EventEmitter(),{url:'/api/links/metadata?url=https://example.com/',method:'GET'}),res=Object.assign(new EventEmitter(),response());
  const pending=handler(req,res);await started;res.destroyed=true;res.emit('close');await pending;
  expect(signal.aborted).toBe(true);expect(res.body).toBe('');expect(req.listenerCount('aborted')).toBe(0);expect(res.listenerCount('close')).toBe(0);
 });
});
