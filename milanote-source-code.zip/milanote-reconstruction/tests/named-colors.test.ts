import {describe,it,expect} from 'vitest';
import {nearestNamedColor} from '../src/core/namedColors';

describe('public named color data',()=>{
 it('matches the two visible reference labels without hard-coding their sampled HEX values',()=>{
  expect(nearestNamedColor('#FD4E7A')).toEqual({color:'#fd5b78',name:'Wild Watermelon',exact:false});
  expect(nearestNamedColor('#A4948C')).toEqual({color:'#a59b91',name:'Zorba',exact:false});
 });
 it('recognizes exact canonical and short HEX, handles hue wrapping, and rejects executable or invalid values',()=>{
  expect(nearestNamedColor('#f00')).toEqual({color:'#ff0000',name:'Red',exact:true});
  expect(nearestNamedColor('#ff00ff')).toEqual({color:'#ff00ff',name:'Magenta / Fuchsia',exact:true});
  expect(nearestNamedColor('ffffff')?.name).toBe('White');
  for(const value of ['url(x)','red','#ff000000','#12','rgb(1,2,3)',''])expect(nearestNamedColor(value)).toBeNull();
 });
});
