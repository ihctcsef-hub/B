import {renderedZoom} from './helpers/canvas-view.mjs';
import assert from "node:assert/strict";
import { mkdir, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { chromium } from "playwright-core";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const artifacts = path.join(root, "artifacts");
await mkdir(artifacts, { recursive: true });
for (const name of await readdir(artifacts)) {
  if (/^tools-failure-\d+\.png$/.test(name))
    await rm(path.join(artifacts, name));
}
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
const context = await browser.newContext({
  viewport: { width: 1440, height: 1100 },
  acceptDownloads: true,
});
const page = await context.newPage();
page.setDefaultTimeout(7000);
const pageErrors = [];
page.on("pageerror", (error) => pageErrors.push(error.message));
const results = [];
const card = (id) => page.locator(`[data-card-id="${id}"]`);
const style = (loc) =>
  loc.evaluate((el) => ({
    x: parseFloat(el.style.left),
    y: parseFloat(el.style.top),
    w: parseFloat(el.style.width),
    h: parseFloat(el.style.height),
  }));
const bounds = async (loc) => {
  const value = await loc.boundingBox();
  assert(value, "Element has bounds");
  return value;
};
const note = (id, text, x = 50, y = 60) => ({
  id,
  type: "note",
  text,
  x,
  y,
  width: 220,
  height: 110,
  z: 1,
  color: "#ffffff",
});
const fixture = (cards = [], extra = {}) => ({
  version: 1,
  id: "tools-workspace",
  title: "Tools workspace",
  rootBoardId: "tools-board",
  updatedAt: "2026-10-24T00:00:00.000Z",
  boards: {
    "tools-board": {
      id: "tools-board",
      title: "Tools test board",
      cards,
      connections: [],
      viewport: { x: 25, y: 45, zoom: 0.9 },
      background: "#f5f3ef",
      grid: true,
      ...extra,
    },
  },
});
async function importFixture(value) {
  await page
    .locator('input[type=file][accept="application/json,.json"]')
    .setInputFiles({
      name: "tools-fixture.json",
      mimeType: "application/json",
      buffer: Buffer.from(JSON.stringify(value)),
    });
  await page.waitForFunction(
    () =>
      document.querySelector(
        'input[type=file][accept="application/json,.json"]',
      )?.value === "",
  );
  await page
    .getByText(
      "Workspace imported. Undo to return to your previous workspace.",
      { exact: true },
    )
    .waitFor();
  await page.waitForFunction(
    (title) =>
      document.querySelector('[aria-label="Current board title"]')?.value ===
      title,
    value.boards[value.rootBoardId].title,
  );
}
async function run(name, fn) {
  try {
    await fn();
    results.push({ name, status: "passed" });
    console.log("PASS", name);
  } catch (error) {
    results.push({ name, status: "failed", message: error.stack });
    console.error("FAIL", name, error.message);
    await page
      .screenshot({
        path: path.join(artifacts, `tools-failure-${results.length}.png`),
        fullPage: true,
      })
      .catch(() => {});
    process.exitCode = 1;
    await page.keyboard.press("Escape").catch(() => {});
  }
}
async function moveTo(loc, x, y) {
  const box = await bounds(loc),
    before = await style(loc);
  const zoom =
    await renderedZoom(page);
  await page.mouse.move(box.x + 5, box.y + 5);
  await page.mouse.down();
  await page.mouse.move(
    box.x + 5 + (x - before.x) * zoom,
    box.y + 5 + (y - before.y) * zoom,
    { steps: 15 },
  );
  await page.mouse.up();
}
async function resize(loc, dx, dy) {
  await loc.click({ position: { x: 5, y: 5 } });
  const handle = await bounds(loc.getByRole("button", { name: "Resize item" }));
  await page.mouse.move(
    handle.x + handle.width / 2,
    handle.y + handle.height / 2,
  );
  await page.mouse.down();
  await page.mouse.move(
    handle.x + handle.width / 2 + dx,
    handle.y + handle.height / 2 + dy,
    { steps: 10 },
  );
  await page.mouse.up();
}
async function download(name, output) {
  const pending = page.waitForEvent("download");
  await page.getByRole("button", { name }).click();
  const item = await pending;
  const destination = path.join(artifacts, output);
  await item.saveAs(destination);
  return readFile(destination, "utf8");
}

try {
  await page.goto(process.env.TEST_URL || "http://127.0.0.1:5173", {
    waitUntil: "domcontentloaded",
  });
  await page.getByText("Saved on this device", { exact: true }).waitFor();

  await run(
    "Move a canvas note to Unsorted, place it, undo and redo",
    async () => {
      await importFixture(fixture([note("inbox-note", "Existing idea")]));
      await card("inbox-note").click({ position: { x: 5, y: 5 } });
      await page.getByTitle("Move to Unsorted", { exact: true }).click();
      assert.equal(await card("inbox-note").count(), 0);
      const panel = page.getByRole("complementary", {
        name: "Unsorted items panel",
      });
      await panel.waitFor();
      assert.match(await panel.innerText(), /Existing idea/);
      await panel.getByTitle("Place on board", { exact: true }).click();
      assert.equal(await card("inbox-note").count(), 1);
      assert.equal(await panel.locator(".inbox-item").count(), 0);
      await page.getByTitle("Undo (⌘Z)", { exact: true }).click();
      assert.equal(await card("inbox-note").count(), 0);
      assert.equal(await panel.locator(".inbox-item").count(), 1);
      await page.getByTitle("Redo (⇧⌘Z)", { exact: true }).click();
      assert.equal(await card("inbox-note").count(), 1);
      await page.getByTitle("Undo (⌘Z)", { exact: true }).click();
      await page.getByTitle("Undo (⌘Z)", { exact: true }).click();
      assert.deepEqual(await style(card("inbox-note")), {
        x: 50,
        y: 60,
        w: 220,
        h: 110,
      });
    },
  );

  await run(
    "Unsorted quick notes drag to the canvas and canvas notes drag to the panel",
    async () => {
      await importFixture(fixture());
      if (!(await page.locator(".inbox-panel").count()))
        await page.getByTitle("Unsorted items", { exact: true }).click();
      await page.getByRole("button", { name: "Add a quick note" }).click();
      const quick = page
        .locator(".inbox-item")
        .filter({ hasText: "A thought for later…" });
      assert.equal(await quick.count(), 1);
      await quick.dragTo(page.locator(".stage"), {
        targetPosition: { x: 310, y: 300 },
      });
      const placed = page
        .locator(".card-note")
        .filter({ hasText: "A thought for later…" });
      await placed.waitFor();
      assert.equal(await quick.count(), 0);
      const source = await bounds(placed),
        panel = await bounds(page.locator(".inbox-panel"));
      await page.mouse.move(source.x + 5, source.y + 5);
      await page.mouse.down();
      await page.mouse.move(panel.x + panel.width / 2, panel.y + 180, {
        steps: 18,
      });
      await page.mouse.up();
      assert.equal(await placed.count(), 0);
      assert.equal(await quick.count(), 1);
      await page.getByTitle("Close Unsorted", { exact: true }).click();
    },
  );

  await run(
    "Background and grid changes are undoable and survive reload",
    async () => {
      await importFixture(
        fixture([note("appearance-note", "Appearance test")]),
      );
      await page.getByTitle("Board appearance", { exact: true }).click();
      await page
        .getByTitle("Board background #eef2e7", { exact: true })
        .click();
      await page.getByLabel("Show dot grid").uncheck();
      await page.getByTitle("Close dialog", { exact: true }).click();
      assert.equal(
        await page.locator(".stage").evaluate((el) => el.style.backgroundImage),
        "none",
      );
      assert.equal(
        await page.locator(".stage").evaluate((el) => el.style.backgroundColor),
        "rgb(238, 242, 231)",
      );
      await page.getByTitle("Undo (⌘Z)", { exact: true }).click();
      assert.notEqual(
        await page
          .locator(".stage")
          .evaluate((el) => getComputedStyle(el).backgroundImage),
        "none",
      );
      await page.getByTitle("Undo (⌘Z)", { exact: true }).click();
      assert.equal(
        await page.locator(".stage").evaluate((el) => el.style.backgroundColor),
        "rgb(245, 243, 239)",
      );
      await page.getByTitle("Redo (⇧⌘Z)", { exact: true }).click();
      await page.getByTitle("Redo (⇧⌘Z)", { exact: true }).click();
      await page.getByText("Saved on this device", { exact: true }).waitFor();
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.getByText("Saved on this device", { exact: true }).waitFor();
      assert.equal(
        await page.locator(".stage").evaluate((el) => el.style.backgroundImage),
        "none",
      );
      assert.equal(
        await page.locator(".stage").evaluate((el) => el.style.backgroundColor),
        "rgb(238, 242, 231)",
      );
    },
  );

  await run(
    "Notes render safe semantic formatting and Markdown/plain text downloads match it",
    async () => {
      const source =
        "# Heading\n**Bold** and _emphasis_ and `code`\n- First\n1. Second\n<img src=x onerror=alert(1)>";
      await importFixture(fixture([note("formatted-note", source)]));
      assert.equal(
        await card("formatted-note").locator("h1").innerText(),
        "Heading",
      );
      assert.equal(
        await card("formatted-note").locator("strong").innerText(),
        "Bold",
      );
      assert.equal(
        await card("formatted-note").locator("em").innerText(),
        "emphasis",
      );
      assert.equal(await card("formatted-note").locator("img").count(), 0);
      assert.match(
        await card("formatted-note").innerText(),
        /<img src=x onerror=alert\(1\)>/,
      );
      await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();
      const markdown = await download(/Board as Markdown/, "tools-board.md");
      const plain = await download(/Board as plain text/, "tools-board.txt");
      assert(
        markdown.includes(source.split("\n<img")[0]),
        "Markdown preserves supported note formatting",
      );
      assert(
        markdown.includes("&lt;img src=x onerror=alert(1)&gt;"),
        "Markdown escapes literal HTML",
      );
      assert.match(
        plain,
        /Heading\nBold and emphasis and code\n• First\n1\. Second/,
      );
      assert(
        !plain.includes("**") &&
          !plain.includes("`") &&
          !plain.includes("_emphasis_"),
      );
      await page.getByTitle("Close dialog", { exact: true }).click();
    },
  );

  await run(
    "Contextual underline, strike and alignment are preserved in visual export",
    async () => {
      await importFixture(
        fixture([note("toolbar-text", "First line\nSecond line", 120, 220)]),
      );
      await card("toolbar-text").click({ position: { x: 5, y: 5 } });
      await page.getByTitle("Strikethrough", { exact: true }).click();
      await card("toolbar-text").locator("s").first().waitFor();
      await page.getByLabel("Note text", { exact: true }).focus();
      await page.keyboard.press("Control+a");
      await page.getByTitle("Underline", { exact: true }).click();
      await card("toolbar-text").locator("u").first().waitFor();
      assert.equal(await card("toolbar-text").locator("s").innerText(), "First line\nSecond line");
      assert.equal(await card("toolbar-text").locator("u").innerText(), "First line\nSecond line");
      await page.getByLabel("Note text", { exact: true }).focus();
      await page.keyboard.press("Control+a");
      await page.getByTitle("Text alignment", { exact: true }).click();
      await page.getByLabel("Current board title").click();
      assert.equal(
        await card("toolbar-text")
          .locator(".note-text")
          .evaluate((el) => getComputedStyle(el).textAlign),
        "center",
      );
      await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();
      const html = await download(/Board as HTML/, "tools-format.html");
      assert.match(html, /<(?:u|s)>/);
      assert.match(html, /text-align:\s*center/);
      const exported = await page.context().newPage();
      await exported.setContent(html);
      assert.equal(await exported.locator(".text s").innerText(), "First line\nSecond line");
      assert.equal(await exported.locator(".text u").innerText(), "First line\nSecond line");
      await exported.close();
      await page.getByTitle("Close dialog", { exact: true }).click();
    },
  );

  await run(
    "Contextual list, text-style and code commands edit the selected note",
    async () => {
      await importFixture(
        fixture([{ ...note("list-text", "First line\nSecond line", 120, 220), html: "<p>First line</p><p>Second line</p>" }]),
      );
      await card("list-text").click({ position: { x: 5, y: 5 } });
      await page.getByTitle("Numbered list", { exact: true }).click();
      await card("list-text").locator("ol li").first().waitFor();
      assert.equal(await card("list-text").locator("ol li").count(), 2);
      await page.getByLabel("Note text", { exact: true }).focus();
      await page.keyboard.press("Control+a");
      await page.getByTitle("Bullet list", { exact: true }).click();
      await card("list-text").locator("ul li").first().waitFor();
      assert.equal(await card("list-text").locator("ul li").count(), 2);
      await page.getByLabel("Note text", { exact: true }).focus();
      await page.keyboard.press("Control+a");
      await page.getByTitle("Text style", { exact: true }).click();await page.getByRole("menu",{name:"Text style",exact:true}).getByRole("menuitem",{name:"Normal heading"}).click();
      await card("list-text").locator("h2").first().waitFor();
      assert.equal(await card("list-text").locator("h2").count(), 2);
      await importFixture(
        fixture([note("code-text", "const answer = 42;", 120, 220)]),
      );
      await card("code-text").click({ position: { x: 5, y: 5 } });
      await page.getByTitle("Inline code", { exact: true }).click();
      await card("code-text").locator("code").waitFor();
      assert.equal(
        await card("code-text").locator("code").innerText(),
        "const answer = 42;",
      );
    },
  );

  await run(
    "Column drops snap width and x, stack in order, reorder and reflow after resize",
    async () => {
      await importFixture(
        fixture([
          {
            id: "column",
            type: "column",
            title: "Structured ideas",
            x: 350,
            y: 20,
            width: 300,
            height: 580,
            z: 0,
          },
          note("first", "First idea", 120, 60),
          note("second", "Second idea", 120, 230),
        ]),
      );
      await moveTo(card("first"), 370, 90);
      let first = await style(card("first")),
        column = await style(card("column"));
      assert(Math.abs(first.x - column.x - 6.4) < 0.01);
      assert.equal(first.w, column.w - 12.8);
      assert.equal(first.y, column.y + 62.2);
      await moveTo(card("second"), 370, 230);
      let second = await style(card("second"));
      assert.equal(second.y, first.y + first.h + 6);
      assert.equal(second.x, first.x);
      assert.equal(second.w, first.w);
      assert.equal(await card("column").locator(".count").innerText(), "2");
      await moveTo(card("first"), first.x, second.y + second.h + 15);
      first = await style(card("first"));
      second = await style(card("second"));
      assert.equal(second.y, column.y + 62.2);
      assert.equal(first.y, second.y + second.h + 6);
      const beforeChildResize = first.y;
      await resize(card("second"), 0, 45);
      first = await style(card("first"));
      second = await style(card("second"));
      assert(
        first.y > beforeChildResize + 40,
        "The next member moves down when a child becomes taller",
      );
      assert.equal(first.y, second.y + second.h + 6);
      assert.equal(second.w, column.w - 12.8);
      await resize(card("column"), 72, 0);
      column = await style(card("column"));
      first = await style(card("first"));
      second = await style(card("second"));
      assert(column.w > 370, "Column width expands through the resize handle");
      assert.equal(first.w, column.w - 12.8);
      assert.equal(second.w, column.w - 12.8);
      const prior = { column, first, second };
      await card("column").click({ position: { x: 5, y: 5 } });
      await page.keyboard.press("ArrowRight");
      await page.keyboard.press("Shift+ArrowDown");
      for (const id of ["column", "first", "second"]) {
        const after = await style(card(id));
        assert.equal(after.x, prior[id].x + 1);
        assert.equal(after.y, prior[id].y + 10);
      }
    },
  );

  await run(
    "Double-click reopens an existing note and Escape commits the edited text",
    async () => {
      await importFixture(
        fixture([note("escape-note", "Before Escape", 120, 280)]),
      );
      await card("escape-note").dblclick();
      assert.equal(
        await page.locator(".card-note").count(),
        1,
        "Double-click edits the existing card without creating another card",
      );
      await page
        .getByLabel("Note text", { exact: true })
        .fill("Saved with Escape — العربية");
      await page.keyboard.press("Escape");
      assert.equal(
        await page.getByLabel("Note text", { exact: true }).count(),
        0,
      );
      assert.match(
        await card("escape-note").innerText(),
        /Saved with Escape — العربية/,
      );
      await page.getByText("Saved on this device", { exact: true }).waitFor();
      await page.reload({ waitUntil: "domcontentloaded" });
      await page.getByText("Saved on this device", { exact: true }).waitFor();
      assert.match(
        await card("escape-note").innerText(),
        /Saved with Escape — العربية/,
      );
    },
  );

  await run(
    "JSON import restores the saved pan and zoom viewport",
    async () => {
      await importFixture(
        fixture([note("viewport-note", "Imported viewport")], {
          viewport: { x: 137, y: 89, zoom: 0.64 },
        }),
      );
      assert.equal(
        await page.locator(".world").evaluate((el) => el.style.transform),
        "translate(137px, 89px) scale(0.64)",
      );
      assert.equal(await renderedZoom(page), 0.64);
    },
  );

  await run(
    "Dragging a new note from the creation rail into a column groups it",
    async () => {
      await importFixture(
        fixture([
          {
            id: "rail-column",
            type: "column",
            title: "Drop new ideas here",
            x: 350,
            y: 160,
            width: 300,
            height: 500,
            z: 0,
          },
        ]),
      );
      await page
        .getByTitle("Add Note", { exact: true })
        .dragTo(card("rail-column"), {
          targetPosition: { x: 100, y: 110 },
        });
      await page
        .getByLabel("Note text", { exact: true })
        .fill("Created straight into a column");
      await page.keyboard.press("Escape");
      assert.equal(await page.locator(".card-note").count(), 1);
      const column = await style(card("rail-column"));
      const child = await style(page.locator(".card-note"));
      assert(Math.abs(child.x - column.x - 6.4) < 0.01);
      assert.equal(child.y, column.y + 62.2);
      assert.equal(child.w, column.w - 12.8);
      assert.equal(
        await card("rail-column").locator(".count").innerText(),
        "1",
      );
    },
  );

  await run("No uncaught browser errors", async () =>
    assert.deepEqual(pageErrors, []),
  );
  await importFixture(
    fixture(
      [
        {
          id: "preview-column",
          type: "column",
          title: "Ideas taking shape",
          x: 450,
          y: 160,
          width: 300,
          height: 510,
          z: 0,
        },
        {
          ...note(
            "preview-a",
            "## A little structure\nBring related ideas together.\n\n**One idea leads to another.**",
            466,
            218,
          ),
          width: 268,
          height: 185,
          parentId: "preview-column",
        },
        {
          ...note(
            "preview-b",
            "- Capture a thought\n- Give it room to grow\n- Make something meaningful",
            466,
            419,
          ),
          width: 268,
          height: 150,
          parentId: "preview-column",
        },
        { ...note("preview-inbox", "A thought for tomorrow"), unsorted: true },
        {
          ...note(
            "preview-note",
            "# Space to think\nA visual canvas for all the pieces of your project.",
            120,
            200,
          ),
          height: 200,
        },
      ],
      { background: "#eef2e7" },
    ),
  );
  if (!(await page.locator(".inbox-panel").count()))
    await page.getByTitle("Unsorted items", { exact: true }).click();
  await page.getByText("Saved on this device", { exact: true }).waitFor();
  await page.locator(".toast").waitFor({ state: "hidden" });
  await page.screenshot({
    path: path.join(artifacts, "tools-preview.png"),
    fullPage: true,
  });
} catch (error) {
  results.push({
    name: "Harness failure",
    status: "failed",
    message: error.stack,
  });
  process.exitCode = 1;
  console.error(error);
} finally {
  await writeFile(
    path.join(artifacts, "tools-e2e-results.json"),
    JSON.stringify({ results, pageErrors }, null, 2),
  );
  await browser.close();
}
