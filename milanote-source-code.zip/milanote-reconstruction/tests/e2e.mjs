import {fitBoard,renderedZoom} from './helpers/canvas-view.mjs';
import assert from "node:assert/strict";
import { mkdir, writeFile, readFile, rm } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";

let pw;
try {
  pw = await import("playwright-core");
} catch {
  pw = await import(
    "/workspace/.npm-cache/_npx/a1722018f28f9df2/node_modules/playwright-core/index.mjs"
  );
}
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const artifacts = path.join(root, "artifacts");
await mkdir(artifacts, { recursive: true });
const url = process.env.TEST_URL || "http://127.0.0.1:5174";
const browser = await pw.chromium.launch({
  executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
const results = [];
const pageErrors = [];
const page = await browser.newPage({
  viewport: { width: 1440, height: 1000 },
  acceptDownloads: true,
});
page.on("pageerror", (e) => pageErrors.push(e.message));
const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const pass = (name) => {
  results.push({ name, status: "passed" });
  console.log("PASS", name);
};
const bounds = async (loc) => {
  const value = await loc.boundingBox();
  assert(value, "Element has bounds");
  return value;
};
const cardStyle = (loc) =>
  loc.evaluate((el) => ({
    x: parseFloat(el.style.left),
    y: parseFloat(el.style.top),
    w: parseFloat(el.style.width),
    h: parseFloat(el.style.height),
  }));
async function moveCard(loc, dx, dy) {
  const b = await bounds(loc);
  // Start on the card border, never on a nested input which intentionally stops dragging.
  await page.mouse.move(b.x + 5, b.y + 5);
  await page.mouse.down();
  await page.mouse.move(b.x + 5 + dx, b.y + 5 + dy, { steps: 12 });
  await page.mouse.up();
}
async function showTools() {
  const back = page.getByTitle("Back to tools", { exact: true });
  if (await back.isVisible()) await back.click();
}
async function showBoards() {
  if (!(await page.locator(".board-tree").isVisible()))
    await page.getByTitle("Show boards", { exact: true }).click();
}
async function hideBoards() {
  if (await page.locator(".board-tree").isVisible())
    await page.getByTitle("Collapse sidebar", { exact: true }).click();
}
async function addTool(title) {
  await showTools();
  await page.getByTitle(title, { exact: true }).click();
}
async function createBlank() {
  await page.getByRole("button", { name: "Templates", exact: true }).click();
  await page.getByRole("button", { name: "Empty board", exact: true }).click();
  await page.getByRole("button", { name: "Continue", exact: true }).click();
  await page.getByLabel("Current board title").fill("E2E workspace");
  await page.getByLabel("Current board title").blur();
  assert.equal(await page.locator(".card").count(), 0);
}

try {
  for (let tries = 0; ; tries++) {
    try {
      await page.goto(url, { waitUntil: "domcontentloaded", timeout: 5000 });
      break;
    } catch (err) {
      if (tries >= 35) throw err;
      await pause(1000);
    }
  }
  await page
    .getByText("Saved on this device", { exact: true })
    .waitFor({ timeout: 15000 });
  await page.screenshot({
    path: path.join(artifacts, "reference-preview.png"),
    fullPage: true,
  });
  await createBlank();
  pass("Application loads and an independent blank board can be created");
  const topbar = await bounds(page.locator(".topbar"));
  const stage = await bounds(page.locator(".stage"));
  const rail = await bounds(page.locator(".tool-rail"));
  assert.equal(topbar.height, 44, "Reference header is 44px high");
  assert.deepEqual({ x: stage.x, y: stage.y }, { x: 63, y: 80 });
  assert.deepEqual(
    { x: rail.x, y: rail.y, w: rail.width },
    { x: 0, y: 80, w: 63 },
  );
  assert.equal(
    await page.locator(".board-tree").isVisible(),
    false,
    "Board navigation starts closed",
  );
  pass(
    "Reference geometry places the stage below a 44px header and 36px board row beside the 63px tool rail",
  );

  await addTool("Add Note");
  await page
    .getByLabel("Note text", { exact: true })
    .fill("اختبار عربي — visual note\nSecond line");
  await page.getByLabel("Current board title").click();
  const note = page.locator(".card-note").filter({ hasText: "اختبار عربي" });
  await note.waitFor();
  const dock = await bounds(page.locator(".selection-toolbar.card-tools"));
  assert.deepEqual(
    { x: dock.x, y: dock.y, w: dock.width },
    { x: 0, y: 80, w: 63 },
  );
  assert.equal(
    await page.getByTitle("Add Note", { exact: true }).isVisible(),
    false,
  );
  assert(await page.getByTitle("Bold", { exact: true }).isVisible());
  pass(
    "Selecting a note replaces creation tools with the fixed contextual dock",
  );
  await page.screenshot({
    path: path.join(artifacts, "reference-note-preview.png"),
    fullPage: true,
  });
  assert.match(await note.innerText(), /Second line/);
  const before = await cardStyle(note);
  await moveCard(note, -240, -150);
  const moved = await cardStyle(note);
  assert(
    moved.x < before.x - 150 && moved.y < before.y - 80,
    "Drag updates canvas coordinates",
  );
  pass("Add and edit a multilingual note, then drag it");

  const r = await bounds(note.getByRole("button", { name: "Resize item" }));
  await page.mouse.move(r.x + r.width / 2, r.y + r.height / 2);
  await page.mouse.down();
  await page.mouse.move(r.x + r.width / 2 + 70, r.y + r.height / 2 + 40, {
    steps: 8,
  });
  await page.mouse.up();
  const resized = await cardStyle(note);
  assert(resized.w > moved.w + 40, "Resize increases width");
  await page.getByTitle("Undo (⌘Z)", { exact: true }).click();
  assert.equal((await cardStyle(note)).w, moved.w);
  await page.getByTitle("Redo (⇧⌘Z)", { exact: true }).click();
  assert.equal((await cardStyle(note)).w, resized.w);
  pass("Resize is a single undoable transaction and redo restores it");

  await note.click({ position: { x: 5, y: 5 } });
  await page.getByTitle("Bold", { exact: true }).click();
  await note.locator("strong").first().waitFor();
  await page.getByLabel("Current board title").click();
  assert(
    (await note.locator("strong").count()) > 0,
    "Bold formatting renders semantic strong text",
  );
  pass("Note toolbar applies visible rich text formatting");
  await page.getByTitle("Lock", { exact: true }).click();
  const lockedStyle = await cardStyle(note);
  await page.keyboard.press("ArrowRight");
  await page.keyboard.press("Shift+ArrowDown");
  assert.deepEqual(
    await cardStyle(note),
    lockedStyle,
    "Locked notes ignore keyboard movement",
  );
  await page.getByTitle("Unlock", { exact: true }).click();
  pass("Locked cards ignore keyboard nudges");

  await addTool("Add To-do");
  const todo = page.locator(".card-todo").last();
  assert.equal((await cardStyle(todo)).h, 54, "A new to-do starts as one compact task line");
  assert.equal(await todo.getByLabel("To-do list title").count(), 0);
  await todo.getByLabel("Task text").first().fill("Verify local save");
  await todo
    .getByRole("checkbox", { name: "Complete task", exact: true })
    .first()
    .click();
  assert.equal(
    await todo
      .getByRole("checkbox", { name: "Mark incomplete", exact: true })
      .count(),
    1,
  );
  await todo.getByRole("button", { name: "Add a task" }).click();
  assert((await todo.getByLabel("Task text").count()) >= 2);
  const todoBeforeDrag = await cardStyle(todo);
  await moveCard(todo, 240, -150);
  const todoAfterDrag = await cardStyle(todo);
  assert(todoAfterDrag.x > todoBeforeDrag.x + 200 && todoAfterDrag.y < todoBeforeDrag.y - 100, "To-do padding drags the card while task controls remain editable");
  pass("Compact to-do task editing, completion, insertion and card dragging");

  await addTool("Add Table");
  const table = page.locator(".card-table").last();
  await table.getByRole("gridcell", { name: "Row 1 column 1", exact: true }).dblclick();
  await table.getByLabel("Edit Row 1 column 1", { exact: true }).fill("Budget");
  await page.keyboard.press("Enter");
  await page.getByTitle("Add row", { exact: true }).click();
  await page.getByTitle("Add column", { exact: true }).click();
  assert.equal(
    await table.getByRole("gridcell", { name: "Row 1 column 1", exact: true }).innerText(),
    "Budget",
  );
  assert((await table.locator("tr").count()) >= 4);
  const tableBeforeDrag = await cardStyle(table);
  const tableGrip = await bounds(table.getByRole("button", { name: "Move table", exact: true }));
  await page.mouse.move(tableGrip.x + tableGrip.width / 2, tableGrip.y + tableGrip.height / 2); await page.mouse.down();
  await page.mouse.move(tableGrip.x + tableGrip.width / 2 + 50, tableGrip.y + tableGrip.height / 2 + 170, { steps: 12 }); await page.mouse.up();
  const tableAfterDrag = await cardStyle(table);
  assert(tableAfterDrag.x > tableBeforeDrag.x + 30 && tableAfterDrag.y > tableBeforeDrag.y + 140, "Move table grip repositions the grid without editing a cell");
  pass("Editable table can add rows and columns and move through its exposed grip");

  const sketchCount = await page.locator('.card-sketch').count();
  await addTool('Draw (P)');
  const drawing=page.getByRole('dialog',{name:'Draw on board',exact:true});await drawing.waitFor();
  const canvas=await bounds(drawing.getByLabel('Drawing canvas',{exact:true}));
  await page.mouse.move(canvas.x+canvas.width*.3,canvas.y+canvas.height*.45);await page.mouse.down();
  await page.mouse.move(canvas.x+canvas.width*.4,canvas.y+canvas.height*.55,{steps:12});await page.mouse.up();
  assert.equal(await page.locator('.card-sketch').count(),sketchCount,'A drawing session remains a draft until Save');
  await drawing.getByRole('button',{name:'Save',exact:true}).click();
  assert.equal(await page.locator('.card-sketch').count(),sketchCount+1);
  pass('Board drawing saves its session as one persisted sketch item');

  await addTool('Add Sketch');
  const dedicatedSketch=page.locator('.card-sketch').last(),sketchEditor=page.getByRole('dialog',{name:'Edit sketch',exact:true});await sketchEditor.waitFor();
  const sk=await bounds(sketchEditor.getByLabel('Drawing canvas',{exact:true}));
  await page.mouse.move(sk.x+sk.width*.2,sk.y+sk.height*.3);await page.mouse.down();await page.mouse.move(sk.x+sk.width*.6,sk.y+sk.height*.6,{steps:10});await page.mouse.up();
  await sketchEditor.getByRole('button',{name:'Save',exact:true}).click();assert.equal(await dedicatedSketch.locator('polyline').count(),1);
  await dedicatedSketch.dblclick({position:{x:5,y:5}});await sketchEditor.waitFor();await sketchEditor.getByTitle('Clear drawing',{exact:true}).click();await sketchEditor.getByRole('button',{name:'Save',exact:true}).click();
  assert.equal(await dedicatedSketch.locator('polyline').count(),0);await page.getByTitle('Undo (⌘Z)',{exact:true}).click();assert.equal(await dedicatedSketch.locator('polyline').count(),1);
  await moveCard(dedicatedSketch,-260,200);pass('Sketch card editing saves once and clearing its ink is undoable');

  await addTool("Add Board");
  const child = page.locator(".card-board").last();
  await child
    .getByLabel("Board name", { exact: true })
    .fill("Nested test board");
  await child.locator(".board-symbol").dblclick();
  assert.equal(
    await page.getByLabel("Current board title").inputValue(),
    "Nested test board",
  );
  assert.equal(await page.locator(".card").count(), 0);
  await addTool("Add Note");
  await page
    .getByLabel("Note text", { exact: true })
    .fill("Child board content");
  await page.getByLabel("Current board title").click();
  await page
    .getByRole("navigation", { name: "Board breadcrumb" })
    .getByRole("button", { name: "E2E workspace", exact: true })
    .click();
  assert.equal(
    await page.locator(".card-note").filter({ hasText: "اختبار عربي" }).count(),
    1,
  );
  pass("Nested board creation, editing and breadcrumb navigation");

  // Copy via real keyboard, paste via browser ClipboardEvent so the application
  // path is covered without depending on OS clipboard permission in headless CI.
  await note.click({ position: { x: 5, y: 5 } });
  await page.keyboard.press("Control+c");
  await child.locator(".board-symbol").dblclick();
  await page.evaluate(() => {
    const data = new DataTransfer();
    data.setData("text/plain", "clipboard fallback");
    window.dispatchEvent(
      new ClipboardEvent("paste", {
        clipboardData: data,
        bubbles: true,
        cancelable: true,
      }),
    );
  });
  assert.equal(
    await page.locator(".card-note").filter({ hasText: "اختبار عربي" }).count(),
    1,
  );
  await page
    .getByRole("navigation", { name: "Board breadcrumb" })
    .getByRole("button", { name: "E2E workspace", exact: true })
    .click();
  pass(
    "ClipboardEvent pastes copied cards across boards with preserved content",
  );

  await child.click({ position: { x: 5, y: 5 } });
  await page.keyboard.press("Control+c");
  await page
    .getByRole("navigation", { name: "Board breadcrumb" })
    .getByRole("button")
    .first()
    .click();
  const oldTiles = await page.locator(".card-board").count();
  await page.evaluate(() => {
    const data = new DataTransfer();
    window.dispatchEvent(
      new ClipboardEvent("paste", {
        clipboardData: data,
        bubbles: true,
        cancelable: true,
      }),
    );
  });
  assert.equal(await page.locator(".card-board").count(), oldTiles + 1);
  await page
    .locator(".card-board.selected")
    .locator(".board-symbol")
    .dblclick();
  assert.equal(
    await page
      .locator(".card-note")
      .filter({ hasText: "Child board content" })
      .count(),
    1,
  );
  assert.equal(
    await page.locator(".card-note").filter({ hasText: "اختبار عربي" }).count(),
    1,
  );
  await showBoards();
  await page
    .locator(".board-tree")
    .getByRole("button")
    .filter({ hasText: "E2E workspace" })
    .click();
  await hideBoards();
  pass("Pasting a board copies its complete independent nested graph");

  await showTools();
  // Place the new column in a clear area rather than underneath existing cards.
  await page.getByTitle("Add Column", { exact: true }).dragTo(page.locator(".stage"), { targetPosition: { x: 100, y: 25 } });
  const column = page.locator(".card-column").last();
  await column
    .getByLabel("Column title", { exact: true })
    .fill("Grouped ideas");
  await page.getByLabel("Current board title").click();
  await fitBoard(page);
  const cb = await bounds(column),
    nb = await bounds(note);
  const zoomValue =
    await renderedZoom(page);
  await moveCard(
    note,
    cb.x + 12 * zoomValue - nb.x,
    cb.y + 70 * zoomValue - nb.y,
  );
  assert.equal(await column.locator(".count").innerText(), "1");
  await column.getByTitle("Collapse column", { exact: true }).click();
  assert.equal(await note.count(), 0, "Collapsed column hides member cards");
  await column.getByTitle("Expand column", { exact: true }).click();
  assert.equal(await note.count(), 1);
  pass(
    "Dropping a card groups it into a column; collapse and expand preserve members",
  );

  // Connector creation through the user-facing handles.
  await note
    .getByTitle("Connect this item", { exact: true })
    .click();
  await todo
    .getByTitle("Connect this item", { exact: true })
    .click();
  assert.equal(await page.locator(".connection").count(), 1);
  pass("Card handles create a connector between stable item IDs");

  // Avoid depending on private React state: export via the public download UI.
  await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();
  const dlPromise = page.waitForEvent("download");
  await page.getByRole("button", { name: /Workspace backup/ }).click();
  const dl = await dlPromise;
  const backup = path.join(artifacts, "workspace-backup.json");
  await dl.saveAs(backup);
  const data = JSON.parse(await readFile(backup, "utf8"));
  assert(Object.keys(data.boards).length >= 3, "Backup contains nested boards");
  assert(JSON.stringify(data).includes("Child board content"));
  await page.getByTitle("Close dialog", { exact: true }).click();
  pass("JSON backup exports complete workspace and nested content");

  await addTool("Add Note");
  await page
    .getByLabel("Note text", { exact: true })
    .fill("Temporary item to replace");
  await page.getByLabel("Current board title").click();
  await page
    .locator('input[type=file][accept="application/json,.json"]')
    .setInputFiles(backup);
  await page
    .getByText(
      "Workspace imported. Undo to return to your previous workspace.",
      { exact: true },
    )
    .waitFor();
  assert.equal(
    await page.getByLabel("Current board title").inputValue(),
    data.boards[data.rootBoardId].title,
  );
  await page
    .getByRole("navigation", { name: "Board breadcrumb" })
    .getByRole("button")
    .first()
    .click();
  await showBoards();
  const treeTarget = page
    .locator(".board-tree")
    .getByRole("button")
    .filter({ hasText: "E2E workspace" });
  await treeTarget.click();
  await hideBoards();
  assert.equal(
    await page.getByText("Temporary item to replace", { exact: true }).count(),
    0,
  );
  assert.equal(
    await page.locator(".card-note").filter({ hasText: "اختبار عربي" }).count(),
    1,
  );
  pass("Import restores backup and replaces later edits");

  await page.getByText("Saved on this device", { exact: true }).waitFor();
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.getByText("Saved on this device", { exact: true }).waitFor();
  await showBoards();
  await page
    .locator(".board-tree")
    .getByRole("button")
    .filter({ hasText: "E2E workspace" })
    .click();
  await hideBoards();
  assert.equal(
    await page.locator(".card-note").filter({ hasText: "اختبار عربي" }).count(),
    1,
  );
  pass("IndexedDB persistence survives a full reload");
  await fitBoard(page);
  await page.screenshot({
    path: path.join(artifacts, "desktop.png"),
    fullPage: true,
  });

  await page.setViewportSize({ width: 1024, height: 1366 });
  await fitBoard(page);
  await page.screenshot({
    path: path.join(artifacts, "ipad.png"),
    fullPage: true,
  });
  await showTools();
  assert(await page.getByTitle("Add Note", { exact: true }).isVisible());
  assert.equal(
    await page.evaluate(
      () => document.documentElement.scrollWidth > window.innerWidth,
    ),
    false,
  );
  pass(
    "iPad-sized responsive layout remains usable without horizontal page overflow",
  );

  const cdp = await page.context().newCDPSession(page);
  await cdp.send("Emulation.setTouchEmulationEnabled", {
    enabled: true,
    maxTouchPoints: 5,
  });
  const stageBox = await bounds(page.locator(".stage"));
  const cx = stageBox.x + stageBox.width * 0.65,
    cy = stageBox.y + stageBox.height - 100;
  const beforePinch = await page
    .locator(".world")
    .evaluate((e) => e.style.transform);
  await cdp.send("Input.dispatchTouchEvent", {
    type: "touchStart",
    touchPoints: [
      { x: cx - 35, y: cy, id: 1 },
      { x: cx + 35, y: cy, id: 2 },
    ],
  });
  await cdp.send("Input.dispatchTouchEvent", {
    type: "touchMove",
    touchPoints: [
      { x: cx - 80, y: cy, id: 1 },
      { x: cx + 80, y: cy, id: 2 },
    ],
  });
  await pause(100);
  await cdp.send("Input.dispatchTouchEvent", {
    type: "touchEnd",
    touchPoints: [],
  });
  const afterPinch = await page
    .locator(".world")
    .evaluate((e) => e.style.transform);
  assert.notEqual(afterPinch, beforePinch, "Two-touch pinch updates viewport");
  pass("Chromium two-touch pinch changes viewport without browser errors");
  await fitBoard(page);
  const pinchedNote = page
    .locator(".card-note")
    .filter({ hasText: "اختبار عربي" });
  const pn = await bounds(pinchedNote),
    startStyle = await cardStyle(pinchedNote);
  const nx = pn.x + pn.width / 2,
    ny = pn.y + pn.height / 2;
  const beforeCardPinch = await page
    .locator(".world")
    .evaluate((e) => e.style.transform);
  await cdp.send("Input.dispatchTouchEvent", {
    type: "touchStart",
    touchPoints: [
      { x: nx - 20, y: ny, id: 1 },
      { x: nx + 20, y: ny, id: 2 },
    ],
  });
  await cdp.send("Input.dispatchTouchEvent", {
    type: "touchMove",
    touchPoints: [
      { x: nx - 55, y: ny, id: 1 },
      { x: nx + 55, y: ny, id: 2 },
    ],
  });
  await pause(100);
  await cdp.send("Input.dispatchTouchEvent", {
    type: "touchEnd",
    touchPoints: [],
  });
  assert.notEqual(
    await page.locator(".world").evaluate((e) => e.style.transform),
    beforeCardPinch,
  );
  assert.deepEqual(
    await cardStyle(pinchedNote),
    startStyle,
    "Pinch does not accidentally move note",
  );
  await cdp.detach();
  pass("Pinch beginning on a card zooms without moving that card");
  assert.deepEqual(pageErrors, [], "No uncaught page errors");
  pass("No uncaught browser errors");
  await rm(path.join(artifacts, "failure.png"), { force: true });
} catch (err) {
  results.push({ name: "Failure", status: "failed", message: err.stack });
  await page
    .screenshot({ path: path.join(artifacts, "failure.png"), fullPage: true })
    .catch(() => {});
  console.error(err);
  process.exitCode = 1;
} finally {
  await writeFile(
    path.join(artifacts, "e2e-results.json"),
    JSON.stringify({ results, pageErrors }, null, 2),
  );
  await browser.close();
}
