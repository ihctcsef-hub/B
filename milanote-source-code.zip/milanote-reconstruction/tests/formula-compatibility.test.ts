import {describe, expect, it} from 'vitest';
import * as FormulaFunctions from '@formulajs/formulajs';
import {installFormulaCompatibility} from '../src/core/formulaCompatibility';

type Formula = (...args: unknown[]) => unknown;
const functions = new Map<string, Formula>();
function collect(namespace: unknown, prefix = '', depth = 0) {
  if (!namespace || !['object', 'function'].includes(typeof namespace) || depth > 4) return;
  for (const [key, value] of Object.entries(namespace)) {
    if (!/^[A-Z0-9][A-Z0-9_]*$/.test(key)) continue;
    const name = prefix + key;
    if (typeof value === 'function') functions.set(name, value as Formula);
    collect(value, name + '.', depth + 1);
  }
}
collect(FormulaFunctions);
installFormulaCompatibility(functions);
const run = (name: string, ...args: unknown[]) => functions.get(name)!(...args);
const error = (value: unknown) => value instanceof Error ? value.message : value;

describe('measured scalar formula compatibility corrections', () => {
  // Captured from native reference cell input with a v: prefix so retained date
  // formatting cannot conceal the actual scalar result (28 October 2026).
  it.each([
    ['TIMEVALUE', ['12:00'], .5],
    ['ERF', [0, 1], .8427007929497149],
    ['ATAN2', [1, 0], 0],
    ['CHIDIST', [2, 2], .3678794411714422],
    ['CHIINV', [.8, 2], .4462871026284194],
    ['T.DIST', [0, 10, true], .49999999999975375],
    ['FDIST', [1, 5, 10], .4651194265377765],
    ['FINV', [.8, 5, 10], .45633642866287744],
    ['TINV', [.05, 10], 2.228138842468655],
  ] as const)('%s agrees with the measured scalar', (name, args, expected) => {
    expect(run(name, ...args)).toBeCloseTo(expected, 12);
  });
  it('matches the two measured text results', () => {
    expect(run('BASE', 255, 16)).toBe('FF');
    expect(run('SUBSTITUTE', 'a-b-a', 'a', 'x', 2)).toBe('a-b-x');
  });
  it('does not skip a first occurrence at offset zero and advances by the entire search token', () => {
    expect(run('SUBSTITUTE', 'a-b-a', 'a', 'x', 1)).toBe('x-b-a');
    expect(run('SUBSTITUTE', 'ababab', 'ab', 'x', 2)).toBe('abxab');
    expect(run('SUBSTITUTE', 'aaaa', 'aa', 'x', 2)).toBe('aax');
    expect(run('SUBSTITUTE', 'a-b-a', 'a', 'x', 3)).toBe('a-b-a');
    expect(run('SUBSTITUTE', 'a-b-a', 'a', 'x')).toBe('x-b-x');
    expect(run('SUBSTITUTE', 'abc', '', 'x')).toBe('abc');
    expect(error(run('SUBSTITUTE', 'abc', 'a', 'x', 0))).toBe('#VALUE!');
  });
  it('keeps ERF one-bound behavior and integrates either direction between two bounds', () => {
    expect(run('ERF', 1)).toBeCloseTo(.8427007929497149, 12);
    expect(run('ERF', 1, 0)).toBeCloseTo(-.8427007929497149, 12);
    expect(run('ERF', 1, 1)).toBe(0);
    expect(error(run('ERF', 'invalid', 1))).toBe('#VALUE!');
  });
  it('uses x,y argument order in every ATAN2 quadrant and preserves undefined-origin error', () => {
    expect(run('ATAN2', 0, 1)).toBe(Math.PI / 2);
    expect(run('ATAN2', -1, 0)).toBe(Math.PI);
    expect(run('ATAN2', 0, -1)).toBe(-Math.PI / 2);
    expect(error(run('ATAN2', 0, 0))).toBe('#DIV/0!');
    expect(error(run('ATAN2', 'invalid', 1))).toBe('#VALUE!');
  });
  it('parses time-only values without depending on a browser-specific Date parser', () => {
    expect(run('TIMEVALUE', '12:00 AM')).toBe(0);
    expect(run('TIMEVALUE', '12:00 PM')).toBe(.5);
    expect(run('TIMEVALUE', '6:30:15 PM')).toBeCloseTo(66615 / 86400, 12);
    expect(error(run('TIMEVALUE', '25:00'))).toBe('#VALUE!');
    expect(error(run('TIMEVALUE', '12:61'))).toBe('#VALUE!');
    expect(error(run('TIMEVALUE', '13:00 PM'))).toBe('#VALUE!');
  });
  it('distinguishes Student cumulative probabilities from density and uses negative x symmetry', () => {
    expect(run('T.DIST', 2, 10, true)).toBeCloseTo(.963305982652, 11);
    expect(run('T.DIST', -2, 10, true)).toBeCloseTo(.036694017348, 11);
    expect(run('T.DIST', 0, 10, false)).toBeCloseTo(.389108383966, 11);
    expect(run('T.DIST', -2, 10, false)).toBeCloseTo(Number(run('T.DIST', 2, 10, false)), 12);
    expect(error(run('T.DIST', 0, 0, true))).toBe('#NUM!');
    expect(error(run('T.DIST', 'invalid', 10, true))).toBe('#VALUE!');
  });
  it('preserves statistical domain errors and padded BASE strings', () => {
    expect(error(run('FDIST', -1, 5, 10))).toBe('#NUM!');
    expect(error(run('FINV', 2, 5, 10))).toBe('#NUM!');
    expect(error(run('TINV', 0, 10))).toBe('#NUM!');
    expect(run('BASE', 255, 16, 4)).toBe('00FF');
  });
});
