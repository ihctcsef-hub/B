import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { chromium, webkit } from 'playwright-core';

const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium';

const artifacts=new URL(engine==='webkit'?'../artifacts/webkit/':'../artifacts/',import.meta.url);
await mkdir(artifacts,{recursive:true});
const browser=await (engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']}));
const context=await browser.newContext({viewport:{width:1440,height:1000},acceptDownloads:true});
const page=await context.newPage();page.setDefaultTimeout(10000);
const results=[],pageErrors=[];page.on('pageerror',error=>pageErrors.push(error.message));
const table=()=>page.locator('[data-card-id="layout-table"]');
const grid=()=>table().getByRole('grid',{name:'Table',exact:true});
const cell=(r,c)=>table().getByRole('gridcell',{name:`Row ${r} column ${c}`,exact:true});
const fixture=(rows=Array.from({length:4},()=>['','','']))=>({version:1,id:'layout',title:'Table layout',rootBoardId:'root',updatedAt:'2026-10-25T00:00:00Z',boards:{root:{id:'root',title:'Table layout',cards:[{id:'layout-table',type:'table',title:'',rows,x:150,y:150,width:rows[0].length*90,height:rows.length*24-2,z:1}],connections:[],viewport:{x:25,y:25,zoom:1}}}});
async function load(value=fixture()){
  await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'table-layout.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(value))});
  await page.getByText('Workspace imported. Undo to return to your previous workspace.',{exact:true}).waitFor();await grid().waitFor();
}
async function run(name,fn){try{await fn();results.push({name,status:'passed'});console.log('PASS',name);}catch(error){results.push({name,status:'failed',message:error.stack});process.exitCode=1;console.error('FAIL',name,error.message);await page.screenshot({path:new URL(`table-layout-failure-${results.length}.png`,artifacts).pathname,fullPage:true}).catch(()=>{});await page.keyboard.press('Escape').catch(()=>{});}}
async function backup(name){await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();const pending=page.waitForEvent('download');await page.getByRole('button',{name:/Workspace backup/}).click();const download=await pending,destination=new URL(name,artifacts);await download.saveAs(destination.pathname);await page.getByTitle('Close dialog',{exact:true}).click();return JSON.parse(await readFile(destination,'utf8'));}
async function menu(r,c,name){await cell(r,c).click({button:'right'});await page.getByRole('menuitem',{name:new RegExp('^'+name)}).click();}
async function paste(text){await grid().evaluate((element,text)=>{const clipboardData=new DataTransfer();clipboardData.setData('text/plain',text);element.dispatchEvent(new ClipboardEvent('paste',{clipboardData,bubbles:true,cancelable:true}));},text);}
async function dragHandle(name,dx,cancel=false){const handle=table().getByRole('separator',{name,exact:true});const box=await handle.boundingBox();assert.ok(box);await page.mouse.move(box.x+box.width/2,box.y+box.height/2);await page.mouse.down();await page.mouse.move(box.x+box.width/2+dx,box.y+box.height/2,{steps:8});if(cancel)await page.keyboard.press('Escape');await page.mouse.up();}
async function assertWidth(width){await page.waitForFunction(({width})=>Math.abs(document.querySelector('[data-card-id="layout-table"]').getBoundingClientRect().width-width)<1,{width});}
async function dragHeader(axis,from,to){
  const role=axis==='column'?'columnheader':'rowheader',name=axis==='column'?`Column ${String.fromCharCode(65+from)}`:`Row ${from+1}`;
  const source=table().getByRole(role,{name,exact:true});await source.click();const start=await source.boundingBox(),destination=await table().getByRole(role).nth(to).boundingBox();assert.ok(start&&destination);
  const x=axis==='column'?destination.x+destination.width-1:start.x+start.width/2,y=axis==='row'?destination.y+destination.height-1:start.y+start.height/2;
  await page.mouse.move(start.x+start.width/2,start.y+start.height/2);await page.mouse.down();await page.mouse.move(x,y,{steps:10});await page.mouse.up();
}
async function dragGrid(dx,dy,cancel=false){const handle=table().getByRole('button',{name:'Resize table grid',exact:true}),rect=await handle.boundingBox();assert.ok(rect);await page.mouse.move(rect.x+rect.width/2,rect.y+rect.height/2);await page.mouse.down();await page.mouse.move(rect.x+rect.width/2+dx,rect.y+rect.height/2+dy,{steps:10});if(cancel)await page.keyboard.press('Escape');await page.mouse.up();}
try{
  await page.goto(process.env.TEST_URL||'http://127.0.0.1:5184',{waitUntil:'networkidle'});await page.getByText('Saved on this device',{exact:true}).waitFor();
  await run('Editing headers label columns and rows outside the default 270×94 grid and select complete ranges',async()=>{
    await load();const before=await table().boundingBox();assert.equal(Math.round(before.width),270);assert.equal(Math.round(before.height),94);await cell(2,2).click();
    assert.deepEqual(await table().getByRole('columnheader').allTextContents(),['A','B','C']);assert.deepEqual(await table().getByRole('rowheader').allTextContents(),['1','2','3','4']);
    await table().getByRole('columnheader',{name:'Column B',exact:true}).click();assert.equal(await table().locator('[role=gridcell][aria-selected=true]').count(),4);
    await table().getByRole('rowheader',{name:'Row 2',exact:true}).click();assert.equal(await table().locator('[role=gridcell][aria-selected=true]').count(),3);
    const after=await table().boundingBox();assert.equal(Math.round(after.height),94);assert.equal(Math.round(after.width),270);
  });
  await run('Column resizing commits once, supports Undo/Redo and Escape cancellation, then persists through reload',async()=>{
    await load();await cell(1,2).click();await dragHandle('Resize column B',60);await assertWidth(330);
    assert.equal(Math.round((await cell(1,2).boundingBox()).width),150);await page.getByTitle('Undo (⌘Z)', {exact:true}).click();await assertWidth(270);await page.getByTitle('Redo (⇧⌘Z)',{exact:true}).click();await assertWidth(330);
    await cell(1,2).click();await dragHandle('Resize column B',45,true);await assertWidth(330);
    const data=await backup('table-layout-widths.json');assert.deepEqual(data.boards.root.cards[0].columnWidths,[90,150,90]);
    await page.getByText('Saved on this device',{exact:true}).waitFor();await page.reload({waitUntil:'networkidle'});await assertWidth(330);assert.equal(Math.round((await cell(1,2).boundingBox()).width),150);
  });
  await run('Relative formula paste shifts mixed references while preserving literal text, cut references and paste values',async()=>{
    const raw='=A1+$A1+A$1+$A$1+SUM(A1:A2)+LOG10(100)';await load(fixture([['2','','',''],['3',raw,'',''],['','','',''],['','','','']]));
    await menu(2,2,'Copy');await cell(3,3).click();await paste(raw);assert.equal(await cell(3,3).getAttribute('title'),'=B2+$A2+B$1+$A$1+SUM(B2:B3)+LOG10(100)');
    await menu(2,2,'Cut');await cell(4,4).click();await paste(raw);assert.equal(await cell(4,4).getAttribute('title'),raw);assert.equal((await cell(2,2).innerText()).trimEnd(),'');
    await menu(4,4,'Copy');await cell(2,3).click();await menu(2,3,'Paste Values');
    const data=await backup('table-layout-copy.json');assert.equal(data.boards.root.cards[0].rows[1][1],'');assert.equal(data.boards.root.cards[0].rows[1][2],'15');assert.equal(data.boards.root.cards[0].rows[3][3],raw);
  });
  await run('Structural column edits preserve individual widths and exported layout metadata',async()=>{
    const value=fixture();value.boards.root.cards[0].columnWidths=[70,120,80];await load(value);await cell(1,2).click();await menu(1,2,'Add Column Left');await assertWidth(390);
    let data=await backup('table-layout-structure.json');assert.deepEqual(data.boards.root.cards[0].columnWidths,[70,120,120,80]);await cell(1,3).click();await menu(1,3,'Delete Column');await assertWidth(270);
    data=await backup('table-layout-structure.json');assert.deepEqual(data.boards.root.cards[0].columnWidths,[70,120,80]);
    await cell(1,2).click();await page.screenshot({path:new URL('table-layout-preview.png',artifacts).pathname,fullPage:true});
  });
  await run('Selected column headers reorder at insertion boundaries with widths and references, and support Undo',async()=>{
    const value=fixture([['A','B','C'],['x','y','z'],['2','3','=A3+B3']]);value.boards.root.cards[0].columnWidths=[80,100,90];await load(value);await cell(1,1).click();await dragHeader('column',1,2);
    let data=await backup('table-reorder-column.json');assert.deepEqual(data.boards.root.cards[0].rows,[['A','C','B'],['x','z','y'],['2','=A3+C3','3']]);assert.deepEqual(data.boards.root.cards[0].columnWidths,[80,90,100]);
    await page.getByTitle('Undo (⌘Z)',{exact:true}).click();data=await backup('table-reorder-column-undo.json');assert.deepEqual(data.boards.root.cards[0].rows,value.boards.root.cards[0].rows);assert.deepEqual(data.boards.root.cards[0].columnWidths,[80,100,90]);
  });
  await run('Selected row headers reorder whole rows and reproduce the observed formula-range contraction',async()=>{
    await load(fixture([['Metric','10','=SUM(B1:B2)'],['Other','0',''],['End','5','=A1']]));await cell(1,1).click();await dragHeader('row',0,2);
    const data=await backup('table-reorder-row.json');assert.deepEqual(data.boards.root.cards[0].rows,[['Other','0',''],['End','5','=A3'],['Metric','10','=SUM(B1:B1)']]);assert.equal((await cell(3,3).innerText()).trimEnd(),'0');
  });
  await run('Corner drag adds/removes grid cells as one undoable change and Escape cancels the preview',async()=>{
    await load();await cell(1,1).click();await dragGrid(90,48);await assertWidth(360);assert.equal(await grid().getAttribute('aria-rowcount'),'6');assert.equal(await grid().getAttribute('aria-colcount'),'4');
    await page.getByTitle('Undo (⌘Z)',{exact:true}).click();await assertWidth(270);assert.equal(await grid().getAttribute('aria-rowcount'),'4');
    await page.getByTitle('Redo (⇧⌘Z)',{exact:true}).click();await assertWidth(360);await cell(1,1).click();await dragGrid(90,24,true);await assertWidth(360);assert.equal(await grid().getAttribute('aria-rowcount'),'6');
    await dragGrid(-180,-72);await assertWidth(180);assert.equal(await grid().getAttribute('aria-rowcount'),'3');assert.equal(await grid().getAttribute('aria-colcount'),'2');
    const data=await backup('table-corner-grid.json');assert.deepEqual(data.boards.root.cards[0].rows,Array.from({length:3},()=>['','']));await page.getByText('Saved on this device',{exact:true}).waitFor();await page.reload({waitUntil:'networkidle'});await assertWidth(180);assert.equal(await grid().getAttribute('aria-rowcount'),'3');
  });
  await run('No uncaught browser errors',async()=>assert.deepEqual(pageErrors,[]));
}finally{await writeFile(new URL('table-layout-results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),engine,url:process.env.TEST_URL||'http://127.0.0.1:5184',results,pageErrors},null,2));await browser.close();}
