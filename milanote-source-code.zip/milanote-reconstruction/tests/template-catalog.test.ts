import {describe,it,expect} from 'vitest';
import {selectedBoardIconId} from '../src/core/boardIcons';
import catalogJson from '../src/data/templateCatalog.json?raw';
import {createWorkspace} from '../src/core/model';
import {validateWorkspace,exportWorkspace,importWorkspace} from '../src/core/storage';
import {getTemplateCatalog,getTemplateCategories,searchTemplateCatalog,getCatalogPreview,instantiateCatalogTemplate,applyCatalogTemplateToBoard,getTemplateCatalogCoverage} from '../src/core/templateCatalog';

function workspace(){const doc=createWorkspace(),root=doc.rootBoardId;return {...doc,boards:{[root]:{...doc.boards[root],cards:[],connections:[]}}};}
const entries=getTemplateCatalog();
describe('captured complete built-in template catalog',()=>{
 it('reconciles214 unique IDs,31 actual categories and206 displayed entries without counting hidden category headings as templates',()=>{
  expect(entries).toHaveLength(214);expect(new Set(entries.map(item=>item.id)).size).toBe(214);
  const categories=getTemplateCategories();expect(categories).toHaveLength(31);expect(categories.reduce((sum,category)=>sum+category.entries.length,0)).toBe(206);
  expect(categories.find(category=>category.id==='agencies')?.entries.map(item=>item.displayName)).toEqual(['Agency Hub','Design Project Plan','Logo Project Plan','Website Project Plan','Campaign Brief','Moodboard','Storyboard','Team Planner','Brand Positioning Map']);
  for(const category of categories)for(const entry of category.entries)expect(entries.some(template=>template.id===entry.id),`${category.id}/${entry.id}`).toBe(true);
  const coverage=getTemplateCatalogCoverage();expect(coverage.missingRootBoards).toEqual([]);expect(coverage.missingEmptyBoards).toEqual([]);
 });
 it('searches real titles, aliases and keywords while keeping category ordering and caller data detached',()=>{
  expect(searchTemplateCatalog({query:'pirate metrics'}).map(item=>item.id)).toContain('aarr-metrics');
  expect(searchTemplateCatalog({query:'mood board'}).map(item=>item.id)).toContain('moodboard-template');
  const category=searchTemplateCatalog({categoryId:'agencies'});expect(category[0].displayName).toBe('Agency Hub');
  category[0].title='Changed';getTemplateCatalog()[0].title='Changed';getTemplateCategories()[0].entries.length=0;
  expect(searchTemplateCatalog({categoryId:'agencies'})[0].title).toBe('Agency Hub');expect(getTemplateCategories()[0].entries.length).toBe(9);
  expect(searchTemplateCatalog({query:'no-matching-template-837920'})).toEqual([]);expect(searchTemplateCatalog({categoryId:'unknown'})).toEqual([]);
 });
 for(const entry of entries)for(const includeExampleContent of [false,true])it(`${entry.id}: ${includeExampleContent?'example':'empty'} branch preserves a valid, independent editable ownership graph`,()=>{
  const before=workspace(),snapshot=JSON.stringify(before),result=instantiateCatalogTemplate(before,entry.id,before.rootBoardId,{x:40,y:80},{includeExampleContent});
  expect(result.boardId).toBeTruthy();expect(result.workspace).not.toBe(before);expect(JSON.stringify(before)).toBe(snapshot);
  const checked=validateWorkspace(result.workspace),board=checked.boards[result.boardId!];expect(board.title).toBe(entry.title);expect(board.parentBoardId).toBe(before.rootBoardId);expect(board.isTemplate).not.toBe(true);
  expect(Object.values(checked.boards).flatMap(board=>board.cards).every(card=>!card.parentId||Object.values(checked.boards).some(board=>board.cards.some(parent=>parent.id===card.parentId&&parent.type==='column')))).toBe(true);
  const restored=importWorkspace(exportWorkspace(checked));expect(restored.boards[board.id].cards.length).toBe(board.cards.length);
  const preview=getCatalogPreview(entry.id,{includeExampleContent})!;expect(preview.includesExampleContent).toBe(includeExampleContent&&!entry.forceClear);expect(preview.boards[preview.rootBoardId].cards.length).toBe(board.cards.length);
 });
 it('resolves captured nested icon identities, preserves image overrides and keeps the user root icon on apply',()=>{
  const catalog=JSON.parse(catalogJson);let vectors=0,images=0,imageInstances=0;const observedImages=new Set(Object.values({...catalog.boards,...catalog.externalBoards}).map((board:unknown)=>(board as {icon?:string}).icon).filter(Boolean));
  for(const entry of entries)for(const examples of [false,true]){
   const preview=getCatalogPreview(entry.id,{includeExampleContent:examples})!;
   expect(preview.boards[preview.rootBoardId].icon).toBeUndefined();
   for(const board of Object.values(preview.boards)){
    if(board.id===preview.rootBoardId)continue;
    if(board.icon&&!board.icon.startsWith('data:image/svg+xml;base64,')){expect(observedImages.has(board.icon)).toBe(true);imageInstances++;}
    const sourceId=(board as typeof board&{sourceIconId?:string}).sourceIconId;
    if(board.icon?.startsWith('data:image/svg+xml;base64,')&&sourceId){expect(selectedBoardIconId(board.icon)).toBe(sourceId);vectors++;}
   }
  }
  for(const source of Object.values({...catalog.boards,...catalog.externalBoards}) as {icon?:string;sourceIconId?:string}[]){if(source.icon)images++;}
  expect(vectors).toBeGreaterThan(100);expect(images).toBe(81);expect(imageInstances).toBeGreaterThan(0);
  const before=workspace(),root=before.rootBoardId;before.boards[root].icon='data:image/png;base64,user-icon';
  const applied=applyCatalogTemplateToBoard(before,'project-plan-template',root);expect(applied.workspace.boards[root].icon).toBe(before.boards[root].icon);
 });
 it('uses separately captured empty structure instead of clearing example notes or deleting its tools',()=>{
  const empty=getCatalogPreview('5-whys',{includeExampleContent:false})!,example=getCatalogPreview('5-whys',{includeExampleContent:true})!;
  const a=empty.boards[empty.rootBoardId],b=example.boards[example.rootBoardId];
  expect(a.cards.filter(card=>card.type==='column').map(card=>'title' in card?card.title:'')).toContain('The problem');
  expect(a.cards.some(card=>card.type==='note'&&card.text==='[Insert problem statement]')).toBe(true);
  expect(b.cards.some(card=>card.type==='note'&&card.text.includes('market share'))).toBe(true);
  expect(a.connections.length).toBe(7);expect(a.cards.length).toBe(21);expect(b.cards.length).toBe(21);
 });
 it('creates two instances with disjoint board/card/task/line IDs and no synced-note coupling',()=>{
  const before=workspace(),first=instantiateCatalogTemplate(before,'academic-project-plan',before.rootBoardId,{x:0,y:0},{includeExampleContent:true}),second=instantiateCatalogTemplate(first.workspace,'academic-project-plan',before.rootBoardId,{x:400,y:0},{includeExampleContent:true});
  const collect=(root:string)=>{const boardIds=new Set([root]);for(const id of boardIds)for(const card of second.workspace.boards[id].cards)if(card.type==='board'&&!card.isShortcut)boardIds.add(card.boardId);return [...boardIds].flatMap(id=>[id,...second.workspace.boards[id].cards.flatMap(card=>[card.id,...(card.type==='todo'?card.items.map(item=>item.id):[])]),...second.workspace.boards[id].connections.map(line=>line.id)]);};
  const one=collect(first.boardId!),two=collect(second.boardId!);expect(one.some(id=>two.includes(id))).toBe(false);
  const board=second.workspace.boards[first.boardId!],note=board.cards.find(card=>card.type==='note');if(note?.type==='note')note.text='Independent mutation';
  expect(JSON.stringify(second.workspace.boards[second.boardId!])).not.toContain('Independent mutation');expect(Object.values(second.workspace.boards).flatMap(board=>board.cards).some(card=>card.type==='note'&&card.syncedId)).toBe(false);
 });
 it('applies to an existing board atomically and can return to the unchanged previous workspace',()=>{
  const before=workspace(),first=instantiateCatalogTemplate(before,'academic-project-plan',before.rootBoardId,{x:40,y:80},{includeExampleContent:true}),root=first.boardId!,snapshot=JSON.stringify(first.workspace),rootTitle=first.workspace.boards[root].title;
  const result=applyCatalogTemplateToBoard(first.workspace,'5-whys',root,{includeExampleContent:false});validateWorkspace(result.workspace);expect(result.boardId).toBe(root);expect(result.workspace.boards[root].title).toBe(rootTitle);expect(JSON.stringify(first.workspace)).toBe(snapshot);
  expect(result.workspace.boards[before.rootBoardId].cards.some(card=>card.type==='board'&&card.boardId===root)).toBe(true);
  expect(applyCatalogTemplateToBoard(first.workspace,'not-a-template',root).workspace).toBe(first.workspace);
  expect(instantiateCatalogTemplate(before,'5-whys','missing',{x:0,y:0}).workspace).toBe(before);
  const blank=applyCatalogTemplateToBoard(result.workspace,'empty-board',root);validateWorkspace(blank.workspace);expect(blank.workspace.boards[root].cards).toEqual([]);expect(blank.workspace.boards[root].connections).toEqual([]);
 });
});
