import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
import {chromium,webkit} from 'playwright-core';
const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium',url=process.env.TEST_URL||'http://127.0.0.1:5306',origin=new URL(url).origin;
const output=new URL(`../artifacts/link-preview-${engine}/`,import.meta.url);await mkdir(output,{recursive:true});
const browser=await(engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']}));
const context=await browser.newContext({viewport:{width:1440,height:1000}}),page=await context.newPage(),results=[],errors=[];page.setDefaultTimeout(10000);page.on('pageerror',error=>errors.push(error.stack||error.message));
const svg=(width,height,fill='#ed6363')=>`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}"><rect width="100%" height="100%" fill="${fill}"/></svg>`;
const image=(width,height,fill)=>'data:image/svg+xml;base64,'+Buffer.from(svg(width,height,fill)).toString('base64');
const fixtures={wide:image(400,200),tall:image(200,400),square:image(300,300)};
async function check(name,run){try{await run();results.push({name,status:'passed'});console.log('PASS',name);}catch(error){results.push({name,status:'failed',message:error.stack});process.exitCode=1;console.error('FAIL',name,error.message);await page.screenshot({path:new URL(`failure-${results.length}.png`,output).pathname}).catch(()=>{});}}
async function render(props,options={}){await page.evaluate(({props,options})=>window.linkHarness.render(props,options),{props,options});}
async function ready(){await page.locator('[data-link-preview-harness] [data-link-preview-state="ready"]').waitFor();}
async function dimensions(){return page.locator('[data-link-preview-harness] [data-link-preview-state]').evaluate(element=>{const rect=element.getBoundingClientRect(),style=getComputedStyle(element);return{width:rect.width,height:rect.height,padding:style.padding,logicalWidth:parseFloat(style.width),logicalHeight:parseFloat(style.height)};});}
try{
 await page.goto(url,{waitUntil:'networkidle'});await page.evaluate(async()=>{const mod=await import('/tests/fixtures/link-preview-harness.tsx');window.linkHarness=mod.createLinkPreviewHarness();});
 await check('A first render without an image mounts its fallback without accessing absent image state',async()=>{
  await render({src:undefined,automatic:true});await page.locator('[data-link-preview-harness] [data-link-preview-state="empty"]').waitFor();assert.equal(await page.locator('[data-testid="link-fallback"]').count(),1);assert.equal(await page.locator('[data-link-preview-harness] [data-link-preview-state] img').count(),0);assert.deepEqual(errors,[]);
 });
 await check('All three measured reference ratios produce exact visible sizes at270px width',async()=>{
  for(const [name,height] of [['wide',134],['tall',542],['square',270]]){await render({src:fixtures[name],automatic:true});await ready();await page.waitForFunction(expected=>document.querySelector('[data-link-preview-harness] [data-link-preview-state]').getBoundingClientRect().height===expected,height);assert.deepEqual(await dimensions(),{width:270,height,padding:'0px',logicalWidth:270,logicalHeight:height});}
 });
 await check('Actual resized and column-constrained width determines height without horizontal padding',async()=>{
  await render({src:fixtures.wide,automatic:true},{width:390});await ready();await page.waitForFunction(()=>document.querySelector('[data-link-preview-harness] [data-link-preview-state]').getBoundingClientRect().height===190);assert.equal((await dimensions()).width,390);
  await render({src:fixtures.tall,automatic:true},{width:246});await ready();await page.waitForFunction(()=>document.querySelector('[data-link-preview-harness] [data-link-preview-state]').getBoundingClientRect().height===494);assert.equal((await dimensions()).width,246);
 });
 await check('Canvas zoom scales the result once while preserving logical image geometry',async()=>{
  await render({src:fixtures.tall,automatic:true},{width:270,scale:.5});await ready();await page.waitForFunction(()=>document.querySelector('[data-link-preview-harness] [data-link-preview-state]').getBoundingClientRect().height===271);assert.deepEqual(await dimensions(),{width:135,height:271,padding:'0px',logicalWidth:270,logicalHeight:542});
 });
 await check('Manual card sizing remains controlled by its parent instead of natural image ratio',async()=>{
  await render({src:fixtures.tall,automatic:false},{height:300});await ready();const dimensionsBefore=await dimensions();assert.equal(dimensionsBefore.height,138);await render({src:fixtures.wide,automatic:false},{height:300});await ready();assert.equal((await dimensions()).height,138);
 });
 await check('Hidden then shown preview measures its actual width and recovers from an unloaded source',async()=>{
  await render({src:fixtures.square,automatic:true},{width:150,hidden:true});await render({src:fixtures.square,automatic:true},{width:150});await ready();await page.waitForFunction(()=>document.querySelector('[data-link-preview-harness] [data-link-preview-state]').getBoundingClientRect().height===150);assert.equal((await dimensions()).width,150);
 });
 await check('Image errors and source removal expose the supplied fallback and clear stale image geometry',async()=>{
  await render({src:'data:image/png;base64,YnJva2Vu',automatic:true});await page.locator('[data-link-preview-harness] [data-link-preview-state="error"]').waitFor();assert.equal(await page.locator('[data-testid="link-fallback"]').count(),1);assert.equal(await page.locator('[data-link-preview-harness] [data-link-preview-state] img').count(),0);
  await render({src:undefined,automatic:true});await page.locator('[data-link-preview-harness] [data-link-preview-state="empty"]').waitFor();assert.equal(await page.locator('[data-testid="link-fallback"]').count(),1);assert.equal(await page.locator('[data-link-preview-harness] [data-link-preview-state] img').count(),0);
  await render({src:fixtures.wide,automatic:true});await ready();await page.waitForFunction(()=>document.querySelector('[data-link-preview-harness] [data-link-preview-state]').getBoundingClientRect().height===134);
 });
 await check('A previously failed source is retried after removal instead of retaining an old failure forever',async()=>{
  const route=`${origin}/__link-preview/recover.svg`;let requests=0;await page.route(route,async request=>{requests++;await request.fulfill(requests===1?{status:503,contentType:'text/plain',body:'Unavailable'}:{status:200,contentType:'image/svg+xml',body:svg(400,200)});});
  await render({src:route,automatic:true});await page.locator('[data-link-preview-harness] [data-link-preview-state="error"]').waitFor();await render({src:undefined,automatic:true});await render({src:route,automatic:true});await ready();await page.waitForFunction(()=>document.querySelector('[data-link-preview-harness] [data-link-preview-state]').getBoundingClientRect().height===134);assert.equal(requests,2);await page.unroute(route);
 });
 await check('A replaced pending image cannot resize the new source when its network response finishes',async()=>{
  let held;const route=`${origin}/__link-preview/slow.svg`;await page.route(route,request=>new Promise(resolve=>{held={request,resolve};}));
  await render({src:route,automatic:true});for(let i=0;i<100&&!held;i++)await page.waitForTimeout(20);assert.ok(held);assert.equal(await page.locator('[data-link-preview-harness] [data-link-preview-state="loading"]').count(),1);
  await render({src:fixtures.wide,automatic:true});await ready();await page.waitForFunction(()=>document.querySelector('[data-link-preview-harness] [data-link-preview-state]').getBoundingClientRect().height===134);await held.request.fulfill({status:200,contentType:'image/svg+xml',body:svg(200,400)}).catch(()=>{});held.resolve();await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));assert.equal((await dimensions()).height,134);assert.equal(await page.locator('[data-link-preview-harness] [data-link-preview-state] img').getAttribute('src'),fixtures.wide);await page.unroute(route);
 });
 await check('Unmounting a pending preview aborts its old DOM lifetime without browser errors',async()=>{
  let held;const route=`${origin}/__link-preview/unmount.svg`;await page.route(route,request=>new Promise(resolve=>{held={request,resolve};}));await render({src:route,automatic:true});for(let i=0;i<100&&!held;i++)await page.waitForTimeout(20);assert.ok(held);await page.evaluate(()=>window.linkHarness.dispose());await held.request.fulfill({status:200,contentType:'image/svg+xml',body:svg(200,400)}).catch(()=>{});held.resolve();assert.equal(await page.locator('[data-link-preview-harness] [data-link-preview-state]').count(),0);assert.deepEqual(errors,[]);await page.unroute(route);
 });
}finally{await page.evaluate(()=>window.linkHarness?.dispose()).catch(()=>{});await writeFile(new URL('results.json',output),JSON.stringify({checkedAt:new Date().toISOString(),url,engine,referenceVisualParityClaimed:false,scope:'Isolated React LinkPreview with actual image loads; exact measured reference sizes checked, footer and full app integration are separate.',results,errors},null,2));await browser.close();}
