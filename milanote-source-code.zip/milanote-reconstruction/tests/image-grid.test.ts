import {describe,it,expect} from 'vitest';
import {droppedImageSize,layoutDroppedImages} from '../src/core/imageGrid';
import {createCard,type Board,type Card} from '../src/core/model';
const board=(cards:Card[]=[]):Board=>({id:'root',title:'Grid',cards,connections:[],viewport:{x:0,y:0,zoom:1}});
const images=()=>[[800,400],[400,800],[600,600],[1200,400],[400,1200],[960,640]].map(([w,h],i)=>({...createCard('image'),type:'image' as const,id:String(i),src:'/fixture.png',caption:'',showCaption:false,...droppedImageSize(w,h)}));
describe('measured image uploads and masonry',()=>{
 it('matches the six independently observed large-image dimensions',()=>{
  expect(images().map(({width,height})=>[width,height])).toEqual([[270,134],[270,542],[270,270],[270,86],[270,806],[270,182]]);
 });
 it('retains smaller originals with the measured quantized display ratio and guards invalid dimensions',()=>{
  expect(droppedImageSize(200,100)).toEqual({width:158,height:158*134/270});
  expect(droppedImageSize(100,200)).toEqual({width:78,height:78*542/270});
  for(const size of [[0,10],[100,NaN],[Infinity,10],[-1,20]])expect(droppedImageSize(...size as [number,number])).toEqual({width:270,height:220});
  expect(droppedImageSize(1,1).width).toBeGreaterThan(0);
 });
 it('reproduces six-image masonry at the measured four-column viewport, preserving input and order',()=>{
  const source=images(),before=structuredClone(source),placed=layoutDroppedImages(board(),source,{x:437,y:220},1377);
  expect(placed.map(c=>[c.x,c.y])).toEqual([[16,16],[304,16],[592,16],[880,16],[880,120],[16,168]]);
  expect(placed.map(c=>c.id)).toEqual(source.map(c=>c.id));expect(source).toEqual(before);
 });
 it('adapts to measured narrow/wide widths and the exact 1152px four-column boundary',()=>{
  expect(layoutDroppedImages(board(),images(),{x:0,y:0},961).map(c=>[c.x,c.y])).toEqual([[16,16],[304,16],[592,16],[16,168],[16,272],[592,304]]);
  expect(layoutDroppedImages(board(),images(),{x:0,y:0},1937).map(c=>[c.x,c.y])).toEqual([[16,16],[304,16],[592,16],[880,16],[1168,16],[1456,16]]);
  expect(layoutDroppedImages(board(),images().slice(0,4),{x:0,y:0},1152).map(c=>c.y)).toEqual([16,16,16,16]);
 });
 it('keeps existing content intact and places a nonempty batch at the snapped drop point',()=>{
  const existing=board([{...createCard('note',500,100),type:'note',text:'Keep me'}]);const before=structuredClone(existing);
  expect(layoutDroppedImages(existing,images().slice(0,2),{x:737,y:620},1377).map(c=>[c.x,c.y])).toEqual([[736,624],[1024,624]]);expect(existing).toEqual(before);
 });
 it('places a single image at the drop point even on an empty board; inbox contents do not block empty-board layout',()=>{
  expect(layoutDroppedImages(board(),images().slice(0,1),{x:637,y:370},1377)[0]).toMatchObject({x:640,y:368});
  const inbox=board([{...createCard('note'),type:'note',text:'Inbox',unsorted:true}]);
  expect(layoutDroppedImages(inbox,images().slice(0,2),{x:600,y:400},1377)[0]).toMatchObject({x:16,y:16});
 });
 it('defers columns and mixed file batches to their existing insertion paths',()=>{
  const column={...createCard('column',100,100),type:'column' as const,title:'Column',height:500};const input=images();
  expect(layoutDroppedImages(board([column]),input,{x:150,y:200},1377)).toBe(input);
  const mixed=[...input,{...createCard('file'),type:'file' as const,name:'text.txt',mime:'text/plain',size:1}];expect(layoutDroppedImages(board(),mixed,{x:0,y:0},1377)).toBe(mixed);
 });
});
