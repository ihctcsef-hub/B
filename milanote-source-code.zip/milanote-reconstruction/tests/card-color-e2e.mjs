import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {chromium} from 'playwright-core';

const artifacts=new URL('../artifacts/',import.meta.url);await mkdir(artifacts,{recursive:true});
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
const page=await browser.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});page.setDefaultTimeout(10000);
const errors=[],results=[];page.on('pageerror',error=>errors.push(error.message));
const card=id=>page.locator(`[data-card-id="${id}"]`),menu=()=>page.getByRole('dialog',{name:'Card color',exact:true});
const fixture={version:1,id:'card-color-test',title:'Card color',rootBoardId:'root',updatedAt:new Date().toISOString(),boards:{root:{id:'root',title:'Card color',viewport:{x:20,y:20,zoom:1},connections:[],cards:[{id:'a',type:'note',text:'Appearance sample',x:100,y:120,width:270,height:54,z:1},{id:'b',type:'note',text:'Second sample',x:600,y:120,width:270,height:54,z:1}]}}};
async function open(){await card('a').click({position:{x:3,y:3}});await page.getByTitle('Color',{exact:true}).click();await menu().waitFor();}
async function close(){await page.keyboard.press('Escape');await menu().waitFor({state:'hidden'});}
async function backup(name,format='json'){
  await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();
  const pending=page.waitForEvent('download');await page.getByRole('button',{name:format==='json'?/Workspace backup/:/Board as HTML/}).click();
  const download=await pending,file=new URL(name,artifacts);await download.saveAs(file.pathname);await page.getByTitle('Close dialog',{exact:true}).click();const value=await readFile(file,'utf8');return format==='json'?JSON.parse(value):value;
}
async function run(name,action){try{await action();results.push({name,status:'passed'});console.log('PASS',name);}catch(error){results.push({name,status:'failed',message:error.stack});process.exitCode=1;await page.screenshot({path:new URL(`card-color-failure-${results.length}.png`,artifacts).pathname});throw error;}}
try{
  await page.goto(process.env.TEST_URL||'http://127.0.0.1:5279');await page.getByText('Saved on this device',{exact:true}).waitFor();
  await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'card-color.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(fixture))});await page.getByText('Workspace imported. Undo to return to your previous workspace.',{exact:true}).waitFor();
  await run('Measured card palette applies independent background and four-pixel top strip without changing the other note',async()=>{
    await open();assert.equal(await menu().locator('.card-color-base>button').count(),13);const box=await menu().boundingBox();assert.equal(box.x,60.5);assert.equal(box.y,80);assert.equal(box.width,160);
    await menu().getByRole('button',{name:'Background #4ebafd',exact:true}).click();assert.equal(await card('a').evaluate(el=>getComputedStyle(el).backgroundColor),'rgb(78, 186, 253)');
    await menu().getByRole('button',{name:'Top strip',exact:true}).click();await menu().getByRole('button',{name:'Top strip #ff5757',exact:true}).click();
    assert.equal(await card('a').evaluate(el=>el.getBoundingClientRect().height),58);assert.equal(await card('a').getByLabel('Card top strip').evaluate(el=>el.getBoundingClientRect().height),4);
    const offset=await card('a').evaluate(el=>el.querySelector('.note-text p').getBoundingClientRect().top-el.getBoundingClientRect().top);assert.equal(offset,23);
    assert.equal(await card('b').getByLabel('Card top strip').count(),0);assert.equal(await card('b').evaluate(el=>el.getBoundingClientRect().height),54);
  });
  await run('Transparency retains the strip; removing only the strip adjusts height once and supports undo and redo',async()=>{
    await menu().getByRole('button',{name:'Background',exact:true}).click();await menu().getByRole('button',{name:'Background transparent',exact:true}).click();assert.equal(await card('a').evaluate(el=>getComputedStyle(el).backgroundColor),'rgba(0, 0, 0, 0)');assert.equal(await card('a').getByLabel('Card top strip').count(),1);
    await menu().getByRole('button',{name:'Top strip',exact:true}).click();await menu().getByRole('button',{name:'Top strip transparent',exact:true}).click();assert.equal(await card('a').getByLabel('Card top strip').count(),0);assert.equal(await card('a').evaluate(el=>el.getBoundingClientRect().height),54);await close();
    await page.getByTitle('Undo (⌘Z)',{exact:true}).click();assert.equal(await card('a').getByLabel('Card top strip').count(),1);assert.equal(await card('a').evaluate(el=>el.getBoundingClientRect().height),58);
    await page.getByTitle('Redo (⇧⌘Z)',{exact:true}).click();assert.equal(await card('a').getByLabel('Card top strip').count(),0);
  });
  await run('Custom native colors, strip edits and portable exports retain editable metadata through re-import and reload',async()=>{
    await open();await menu().getByLabel('Custom card color',{exact:true}).fill('#123456');await menu().getByRole('button',{name:'Top strip',exact:true}).click();await menu().getByRole('button',{name:'Top strip #4ebafd',exact:true}).click();await close();
    const data=await backup('card-color-workspace.json');assert.deepEqual(data.customColors,['#123456']);assert.equal(data.boards.root.cards[0].color,'#123456');assert.equal(data.boards.root.cards[0].stripColor,'#4ebafd');assert.equal(data.boards.root.cards[0].height,58);
    const html=await backup('card-color.html','html');assert.match(html,/card-top-strip" style="background:#4ebafd/);assert.match(html,/background:#123456/);
    await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'colors-reload.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(data))});await page.getByText('Saved on this device',{exact:true}).waitFor();await page.reload();await card('a').getByLabel('Card top strip').waitFor();assert.equal(await card('a').evaluate(el=>el.getBoundingClientRect().height),58);
    await card('a').dblclick({position:{x:20,y:25}});await page.getByRole('textbox',{name:'Note text',exact:true}).fill('A new paragraph\nSecond line');await page.keyboard.press('Escape');assert.equal(await card('a').getByLabel('Card top strip').evaluate(el=>el.getBoundingClientRect().height),4);assert.ok((await card('a').boundingBox()).height>=74);
  });
  assert.deepEqual(errors,[]);results.push({name:'No uncaught browser errors',status:'passed'});
}finally{await writeFile(new URL('card-color-results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),referenceParityClaimed:false,results,errors},null,2));await browser.close();}
