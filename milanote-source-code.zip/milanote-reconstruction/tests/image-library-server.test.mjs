import assert from 'node:assert/strict';
import {test} from 'vitest';
import {createImageLibraryMiddleware} from '../server/image-library.mjs';
function response(){return{statusCode:0,headers:{},body:'',setHeader(name,value){this.headers[name]=value;},end(value){this.body=value;}};}
const photo={id:123,width:800,height:600,alt:'Forest',src:{original:'https://images.pexels.com/photos/123/image.jpeg',medium:'https://images.pexels.com/photos/123/image.jpeg?w=320'},photographer:'Photo Author',photographer_url:'https://www.pexels.com/@author/',url:'https://www.pexels.com/photo/123/'};
test('uses the official provider server-side, sanitizes metadata and caches queries without returning the credential',async()=>{
 let calls=0;
 const handler=createImageLibraryMiddleware({apiKey:'test-provider-credential',fetchImpl:async(url,options)=>{calls++;assert.equal(url.hostname,'api.pexels.com');assert.equal(url.searchParams.get('query'),'forest');assert.equal(options.headers.Authorization,'test-provider-credential');return{ok:true,json:async()=>({photos:[photo],total_results:42,next_page:'https://api.pexels.com/v1/search?page=2'})};}});
 for(let index=0;index<2;index++){const res=response();await handler({url:'/api/images/search?query=forest&page=1',method:'GET'},res);assert.equal(res.statusCode,200);const body=JSON.parse(res.body);assert.equal(body.photos[0].photographer,'Photo Author');assert.equal(body.nextPage,2);assert.equal(res.body.includes('test-provider-credential'),false);}assert.equal(calls,1);
});
test('does not call a provider without configuration and hides upstream authentication details',async()=>{
 const missing=response();await createImageLibraryMiddleware({apiKey:'',fetchImpl:()=>{throw Error('must not fetch');}})({url:'/api/images/search',method:'GET'},missing);assert.equal(missing.statusCode,503);
 const denied=response();await createImageLibraryMiddleware({apiKey:'test',fetchImpl:async()=>({ok:false,status:401})})({url:'/api/images/search?query=forest',method:'GET'},denied);assert.equal(denied.statusCode,503);assert.equal(denied.body.includes('401'),false);
});
test('rejects invalid pagination and permits only its exact route',async()=>{
 const handler=createImageLibraryMiddleware({apiKey:'test',fetchImpl:()=>{throw Error('must not fetch');}});const invalid=response();await handler({url:'/api/images/search?page=Infinity',method:'GET'},invalid);assert.equal(invalid.statusCode,400);let next=false;await handler({url:'/another-route',method:'GET'},response(),()=>{next=true;});assert.equal(next,true);
});
