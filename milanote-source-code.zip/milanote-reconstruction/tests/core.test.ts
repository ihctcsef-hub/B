import { describe, it, expect, afterEach, vi } from "vitest";
import {
  createWorkspace,
  createCard,
  addCards,
  addConnection,
  deleteCards,
  duplicateCards,
  createNestedBoard,
  patchCards,
  copyCardsToBoard,
} from "../src/core/model";
import {
  createHistory,
  pushHistory,
  undoHistory,
  redoHistory,
} from "../src/core/history";
import {
  exportWorkspace,
  importWorkspace,
  saveWorkspace,
  loadWorkspace,
} from "../src/core/storage";
import { trashCards } from "../src/core/trash";

it("normalizes imported rich HTML in active cards and recoverable trash without losing supported formatting",()=>{
  const ws=createWorkspace(),root=ws.boards[ws.rootBoardId];
  const note={...createCard('note',100,100),type:'note' as const,text:'Safe text',html:'<p><span style="font-size:9.6px;color:rgb(245,41,41)" onclick="bad()">Safe text</span><script>bad()</script></p>'};
  const link={...createCard('link',200,200),type:'link' as const,url:'https://example.com',title:'Example',description:'',captionHtml:'<p><strong>Caption</strong><img src="https://bad.example"><a href="javascript:bad()">link</a></p>'};
  root.cards.push(note,link);
  const deleted=trashCards(ws,root.id,[note.id]),loaded=importWorkspace(exportWorkspace(deleted));
  const recovered=loaded.trash![0].cards.find(card=>card.id===note.id);
  expect(recovered?.type==='note'&&recovered.html).toContain('font-size: 9.6px');
  expect(recovered?.type==='note'&&recovered.html).toContain('color: #f52929');
  const captionCard=loaded.boards[root.id].cards.find(card=>card.id===link.id);
  expect(captionCard?.type==='link'&&captionCard.captionHtml).toBe('<p><strong>Caption</strong>link</p>');
  expect(exportWorkspace(loaded)).not.toMatch(/<script|onclick|javascript:|bad\.example/);
});

describe("document graph operations", () => {
  it("round trips every supported card type without losing content", () => {
    let ws = createWorkspace();
    const id = ws.rootBoardId;
    const types = [
      "note",
      "image",
      "link",
      "todo",
      "column",
      "file",
      "swatch",
      "sketch",
      "table",
      "label",
    ] as const;
    ws = addCards(
      ws,
      id,
      types.map((type, i) => createCard(type, i * 100, 400)),
    );
    const nested = createNestedBoard(ws, id, 400, 400, "Nested");
    ws = nested.workspace;
    expect(importWorkspace(exportWorkspace(ws))).toEqual(ws);
  });
  it("deletes column children and their attached lines atomically", () => {
    let ws = createWorkspace();
    const id = ws.rootBoardId;
    const column = createCard("column"),
      child = { ...createCard("note"), parentId: column.id },
      other = createCard("note");
    ws = addCards(ws, id, [column, child, other]);
    ws = addConnection(ws, id, child.id, other.id);
    const original = ws;
    ws = deleteCards(ws, id, [column.id]);
    expect(ws.boards[id].cards.some((c) => c.id === child.id)).toBe(false);
    expect(ws.boards[id].connections.some((c) => c.from === child.id)).toBe(
      false,
    );
    expect(original.boards[id].cards.some((c) => c.id === child.id)).toBe(true);
    expect(importWorkspace(exportWorkspace(ws))).toEqual(ws);
  });
  it("duplicates column contents and internal connections with independent data", () => {
    let ws = createWorkspace();
    const id = ws.rootBoardId;
    const column = createCard("column"),
      child = { ...createCard("todo"), parentId: column.id },
      other = { ...createCard("note"), parentId: column.id };
    ws = addCards(ws, id, [column, child, other]);
    ws = addConnection(ws, id, child.id, other.id);
    const result = duplicateCards(ws, id, [column.id]);
    const copies = result.workspace.boards[id].cards.filter((c) =>
      result.ids.includes(c.id),
    );
    expect(copies).toHaveLength(3);
    const newColumn = copies.find((c) => c.type === "column")!;
    expect(copies.filter((c) => c.parentId === newColumn.id)).toHaveLength(2);
    const todo = copies.find((c) => c.type === "todo");
    if (todo?.type === "todo") todo.items[0].text = "Changed";
    expect(child.type === "todo" && child.items[0].text).toBe("");
    expect(
      result.workspace.boards[id].connections.filter((c) =>
        result.ids.includes(c.from),
      ),
    ).toHaveLength(1);
  });
  it("refuses dangling or self connections", () => {
    const ws = createWorkspace(),
      id = ws.rootBoardId,
      card = ws.boards[id].cards[0];
    expect(addConnection(ws, id, card.id, card.id)).toBe(ws);
    expect(addConnection(ws, id, card.id, "missing")).toBe(ws);
  });
  it("duplicates nested board contents independently and cleans deleted board subtrees", () => {
    const ws = createWorkspace(),
      id = ws.rootBoardId,
      card = ws.boards[id].cards.find((c) => c.type === "board")!;
    if (card.type !== "board") throw new Error("missing demo board");
    const duplicate = duplicateCards(ws, id, [card.id]);
    const copy = duplicate.workspace.boards[id].cards.find((c) =>
      duplicate.ids.includes(c.id),
    )!;
    if (copy.type !== "board") throw new Error("missing copied board");
    expect(copy.boardId).not.toBe(card.boardId);
    expect(duplicate.workspace.boards[copy.boardId].cards[0].id).not.toBe(
      ws.boards[card.boardId].cards[0].id,
    );
    const after = deleteCards(duplicate.workspace, id, [copy.id]);
    expect(after.boards[copy.boardId]).toBeUndefined();
    expect(after.boards[card.boardId]).toBeDefined();
    expect(importWorkspace(exportWorkspace(after))).toEqual(after);
  });
  it("pastes nested boards and column children across workspaces with no dangling references", () => {
    let source = createWorkspace();
    const sid = source.rootBoardId;
    const column = createCard("column"),
      child = { ...createCard("note"), parentId: column.id };
    source = addCards(source, sid, [column, child]);
    const boardCard = source.boards[sid].cards.find((c) => c.type === "board")!;
    const target = createWorkspace(),
      tid = target.rootBoardId;
    const pasted = copyCardsToBoard(
      source,
      sid,
      [column.id, boardCard.id],
      target,
      tid,
    );
    const added = pasted.workspace.boards[tid].cards.filter((c) =>
      pasted.ids.includes(c.id),
    );
    expect(added).toHaveLength(3);
    const nested = added.find((c) => c.type === "board");
    if (nested?.type !== "board") throw new Error("missing board");
    expect(pasted.workspace.boards[nested.boardId].parentBoardId).toBe(tid);
    expect(importWorkspace(exportWorkspace(pasted.workspace))).toEqual(
      pasted.workspace,
    );
    const lone = copyCardsToBoard(source, sid, [child.id], target, tid);
    expect(
      lone.workspace.boards[tid].cards.find((c) => lone.ids.includes(c.id))
        ?.parentId,
    ).toBeUndefined();
  });
  it("preserves card identity and type during patches", () => {
    const ws = createWorkspace(),
      id = ws.rootBoardId,
      card = ws.boards[id].cards[0];
    const next = patchCards(ws, id, [card.id], {
      id: "bad",
      type: "file",
      x: 200,
    });
    expect(next.boards[id].cards[0]).toMatchObject({
      id: card.id,
      type: card.type,
      x: 200,
    });
  });
});
describe("history", () => {
  it("undoes and redoes atomic graph changes, dropping redo after a new edit", () => {
    let history = createHistory(createWorkspace());
    const initial = history.present,
      id = initial.rootBoardId;
    history = pushHistory(history, addCards(initial, id, [createCard("note")]));
    const after = history.present;
    history = undoHistory(history);
    expect(history.present).toBe(initial);
    history = redoHistory(history);
    expect(history.present).toBe(after);
    history = undoHistory(history);
    history = pushHistory(
      history,
      addCards(history.present, id, [createCard("label")]),
    );
    expect(history.future).toEqual([]);
    expect(redoHistory(history)).toBe(history);
  });
});
describe("import validation", () => {
  it("rejects malformed input and unsupported file versions", () => {
    expect(() => importWorkspace("{bad")).toThrow("not valid JSON");
    const ws = createWorkspace();
    expect(() =>
      importWorkspace(JSON.stringify({ ...ws, version: 2 })),
    ).toThrow("unsupported");
  });
  it("rejects nonfinite geometry, duplicate IDs and missing relation targets", () => {
    const ws = createWorkspace(),
      id = ws.rootBoardId;
    const badSize = structuredClone(ws);
    badSize.boards[id].cards[0].width = -1;
    expect(() => importWorkspace(JSON.stringify(badSize))).toThrow("size");
    const duplicate = structuredClone(ws);
    duplicate.boards[id].cards.push(duplicate.boards[id].cards[0]);
    expect(() => importWorkspace(JSON.stringify(duplicate))).toThrow(
      "duplicate card",
    );
    const dangling = structuredClone(ws);
    dangling.boards[id].connections[0].to = "absent";
    expect(() => importWorkspace(JSON.stringify(dangling))).toThrow("endpoint");
  });
  it("rejects cyclic board and column hierarchies", () => {
    const ws = createWorkspace(),
      id = ws.rootBoardId;
    ws.boards[id].parentBoardId = id;
    expect(() => importWorkspace(JSON.stringify(ws))).toThrow("cyclic board");
    delete ws.boards[id].parentBoardId;
    const col = createCard("column");
    col.parentId = col.id;
    ws.boards[id].cards.push(col);
    expect(() => importWorkspace(JSON.stringify(ws))).toThrow("cyclic column");
  });
  it("rejects root references and inconsistent nested-board ownership", () => {
    const ws = createWorkspace(),
      id = ws.rootBoardId;
    const rootReference = structuredClone(ws);
    rootReference.boards[id].cards.push({
      ...createCard("board"),
      type: "board",
      boardId: id,
      title: "Cycle",
    });
    expect(() => importWorkspace(JSON.stringify(rootReference))).toThrow(
      "root board cannot be nested",
    );
    const inconsistent = structuredClone(ws),
      child = Object.values(inconsistent.boards).find((b) => b.id !== id)!;
    delete child.parentBoardId;
    expect(() => importWorkspace(JSON.stringify(inconsistent))).toThrow(
      "parent does not match",
    );
    const multiple = structuredClone(ws),
      ref = multiple.boards[id].cards.find((c) => c.type === "board")!;
    multiple.boards[id].cards.push({ ...ref, id: "second-owner" });
    expect(() => importWorkspace(JSON.stringify(multiple))).toThrow(
      "multiple owners",
    );
  });
  it("rejects orphan board records and dangerous persisted resource URLs", () => {
    const ws = createWorkspace(),
      id = ws.rootBoardId;
    const orphan = structuredClone(ws);
    orphan.boards[id].cards = orphan.boards[id].cards.filter(
      (c) => c.type !== "board",
    );
    expect(() => importWorkspace(JSON.stringify(orphan))).toThrow(
      "not reachable",
    );
    const file = structuredClone(ws);
    file.boards[id].cards.push({
      ...createCard("file"),
      type: "file",
      name: "Unsafe",
      mime: "text/plain",
      size: 1,
      dataUrl: "javascript:alert(1)",
    });
    expect(() => importWorkspace(JSON.stringify(file))).toThrow(
      "file data URL",
    );
    const image = structuredClone(ws);
    image.boards[id].cards.push({
      ...createCard("image"),
      type: "image",
      src: "javascript:alert(1)",
      caption: "",
    });
    expect(() => importWorkspace(JSON.stringify(image))).toThrow(
      "image source",
    );
  });
});
describe("fallback storage", () => {
  afterEach(() => vi.unstubAllGlobals());
  it("saves and reloads locally when IndexedDB is unavailable", async () => {
    const memory = new Map<string, string>();
    vi.stubGlobal("indexedDB", undefined);
    vi.stubGlobal("localStorage", {
      getItem: (k: string) => memory.get(k) ?? null,
      setItem: (k: string, v: string) => memory.set(k, v),
      removeItem: (k: string) => memory.delete(k),
    });
    const ws = createWorkspace();
    expect(await saveWorkspace(ws)).toBe("localstorage");
    expect(await loadWorkspace()).toEqual(ws);
  });
  it("reports storage failure so the UI cannot falsely claim a save", async () => {
    vi.stubGlobal("indexedDB", undefined);
    vi.stubGlobal("localStorage", {
      setItem: () => {
        throw new Error("Quota exceeded");
      },
    });
    await expect(saveWorkspace(createWorkspace())).rejects.toThrow(
      "Quota exceeded",
    );
  });
});
