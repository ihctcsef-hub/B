import { describe, expect, it } from "vitest";
import {
  bakeImageEdits,
  defaultImageEdits,
  flipImageEdits,
  hasImageEdits,
  imageCropBounds,
  imagePathToSvg,
  isValidImageEdits,
  inverseImagePoint,
  normalizeImageEdits,
  rotateImageEdits,
  rotateNormalizedPoint,
  rotatedImageSize,
  transformImagePoint,
  unrotateNormalizedPoint,
  hitTestImagePath,
  imagePathsBounds,
  translateImagePaths,
} from "../src/core/imageEditing";
import type { ImageEdits } from "../src/core/imageEditing";

function expectCropClose(actual: ImageEdits["crop"], expected: ImageEdits["crop"]) {
  for (const key of ["x", "y", "width", "height"] as const)
    expect(actual[key]).toBeCloseTo(expected[key], 12);
}

const annotation = {
  points: [{ x: 0.12, y: 0.22 }, { x: 0.36, y: 0.48 }],
  color: "#e35151",
  width: 0.01,
};

describe("image editing geometry", () => {
  it("hit-tests the topmost stroke and isolated dots in screen pixels across rotations and flips", () => {
    const line = { color: "#ff0000", width: 0.01, points: [{ x: 0.2, y: 0.3 }, { x: 0.8, y: 0.3 }] };
    const dot = { color: "#0000ff", width: 0.02, points: [{ x: 0.5, y: 0.7 }] };
    const source = { width: 1200, height: 800 };
    for (const rotation of [0, 90, 180, 270] as const) for (const flipX of [false, true]) for (const flipY of [false, true]) {
      const edits: ImageEdits = { ...defaultImageEdits(), rotation, flipX, flipY,
        crop: { x: 0.1, y: 0.1, width: 0.7, height: 0.8 }, paths: [line, dot, structuredClone(line)] };
      const rotated = rotatedImageSize(source.width, source.height, rotation);
      const viewport = { width: rotated.width / 2, height: rotated.height / 2 };
      const center = transformImagePoint({ x: 0.5, y: 0.3 }, edits);
      expect(hitTestImagePath(edits, center, source, viewport)).toBe(2);
      expect(hitTestImagePath(edits, transformImagePoint(dot.points[0], edits), source, viewport)).toBe(1);
      expect(hitTestImagePath(edits, transformImagePoint({ x: 0.9, y: 0.1 }, edits), source, viewport)).toBeNull();
    }
    const edits = { ...defaultImageEdits(), paths: [dot] };
    expect(hitTestImagePath(edits, { x: 0.5 + 9 / 600, y: 0.7 }, source, { width: 600, height: 400 })).toBe(0);
    expect(hitTestImagePath(edits, { x: 0.5 + 13 / 600, y: 0.7 }, source, { width: 600, height: 400 })).toBeNull();
    expect(hitTestImagePath(edits, { x: 0.5, y: 0.7 }, source, { width: 0, height: 400 })).toBeNull();
  });

  it("moves a selected group with one clamped delta and leaves the document and other strokes untouched", () => {
    const second = { ...annotation, points: [{ x: 0.6, y: 0.7 }, { x: 0.9, y: 0.9 }] };
    const untouched = { ...annotation, points: [{ x: 0.5, y: 0.1 }] };
    const edits = { ...defaultImageEdits(), paths: [annotation, second, untouched] };
    const snapshot = structuredClone(edits);
    const translated = translateImagePaths(edits, [0, 1], { x: 0.8, y: -0.8 });
    expect(translated.paths[0].points[0].x).toBeCloseTo(0.22);
    expect(translated.paths[0].points[0].y).toBeCloseTo(0);
    expect(translated.paths[1].points[1].x).toBeCloseTo(1);
    expect(translated.paths[1].points[1].y).toBeCloseTo(0.68);
    expect(translated.paths[2]).toEqual(untouched);
    expect(translated.paths[0].points[1].x - translated.paths[0].points[0].x).toBeCloseTo(0.24);
    expect(edits).toEqual(snapshot);
    expect(isValidImageEdits(translated)).toBe(true);
    expect(translateImagePaths(edits, [], { x: 0.1, y: 0.2 })).toEqual(edits);
    expect(translateImagePaths(edits, [0], { x: NaN, y: 0 })).toEqual(edits);
  });

  it("keeps visible drag direction correct through every rotation and flip with an active crop", () => {
    const original = { x: 0.4, y: 0.4 };
    for (const rotation of [0, 90, 180, 270] as const) for (const flipX of [false, true]) for (const flipY of [false, true]) {
      const edits: ImageEdits = { ...defaultImageEdits(), rotation, flipX, flipY,
        crop: { x: 0.15, y: 0.1, width: 0.7, height: 0.8 }, paths: [{ ...annotation, points: [original] }] };
      const visibleStart = transformImagePoint(original, edits);
      const destination = inverseImagePoint({ x: visibleStart.x + 0.1, y: visibleStart.y - 0.05 }, edits);
      const moved = translateImagePaths(edits, [0], { x: destination.x - original.x, y: destination.y - original.y });
      const visibleEnd = transformImagePoint(moved.paths[0].points[0], moved);
      expect(visibleEnd.x - visibleStart.x).toBeCloseTo(0.1, 12);
      expect(visibleEnd.y - visibleStart.y).toBeCloseTo(-0.05, 12);
      expect(moved.crop).toEqual(edits.crop);
      const box = imagePathsBounds(moved, [0]);
      expect(box?.x).toBeCloseTo(visibleEnd.x, 12);
      expect(box?.y).toBeCloseTo(visibleEnd.y, 12);
      expect(box?.width).toBe(0);
      expect(box?.height).toBe(0);
    }
    expect(imagePathsBounds(defaultImageEdits(), [0])).toBeNull();
  });
  it("creates independent pristine editing documents", () => {
    const first = defaultImageEdits();
    const second = defaultImageEdits();
    expect(first).toEqual({
      rotation: 0,
      crop: { x: 0, y: 0, width: 1, height: 1 },
      paths: [],
    });
    first.crop.x = 0.1;
    first.paths.push(structuredClone(annotation));
    expect(second.crop.x).toBe(0);
    expect(second.paths).toEqual([]);
    expect(hasImageEdits(undefined)).toBe(false);
    expect(hasImageEdits(second)).toBe(false);
    expect(hasImageEdits(first)).toBe(true);
  });

  it("rotates normalized source points with an exact inverse at each quarter turn", () => {
    const point = { x: 0.2, y: 0.7 };
    const expected = [
      [0, { x: 0.2, y: 0.7 }],
      [90, { x: 0.3, y: 0.2 }],
      [180, { x: 0.8, y: 0.3 }],
      [270, { x: 0.7, y: 0.8 }],
    ] as const;
    for (const [rotation, destination] of expected) {
      const actual = rotateNormalizedPoint(point, rotation);
      expect(actual.x).toBeCloseTo(destination.x, 12);
      expect(actual.y).toBeCloseTo(destination.y, 12);
      const restored = unrotateNormalizedPoint(actual, rotation);
      expect(restored.x).toBeCloseTo(point.x, 12);
      expect(restored.y).toBeCloseTo(point.y, 12);
    }
  });

  it("preserves the same cropped source region and annotation points after rotation", () => {
    const edits: ImageEdits = {
      rotation: 0,
      crop: { x: 0.1, y: 0.2, width: 0.6, height: 0.4 },
      paths: [structuredClone(annotation)],
    };
    const snapshot = structuredClone(edits);
    const clockwise = rotateImageEdits(edits, 1);
    expect(clockwise.rotation).toBe(90);
    expectCropClose(clockwise.crop, { x: 0.4, y: 0.1, width: 0.4, height: 0.6 });
    expect(clockwise.paths).toEqual(edits.paths);
    expectCropClose(rotateImageEdits(clockwise, -1).crop, edits.crop);
    const counterclockwise = rotateImageEdits(edits, -1);
    expect(counterclockwise.rotation).toBe(270);
    expectCropClose(counterclockwise.crop, { x: 0.2, y: 0.3, width: 0.4, height: 0.6 });
    let fullTurn = edits;
    for (let turn = 0; turn < 4; turn++) fullTurn = rotateImageEdits(fullTurn, 1);
    expect(fullTurn.rotation).toBe(0);
    expectCropClose(fullTurn.crop, edits.crop);
    expect(fullTurn.paths).toEqual(edits.paths);
    expect(edits).toEqual(snapshot);
  });

  it("calculates pixel crop bounds using the rotated dimensions of a nonsquare image", () => {
    expect(rotatedImageSize(1200, 800, 0)).toEqual({ width: 1200, height: 800 });
    expect(rotatedImageSize(1200, 800, 90)).toEqual({ width: 800, height: 1200 });
    expect(rotatedImageSize(1200, 800, 180)).toEqual({ width: 1200, height: 800 });
    expect(rotatedImageSize(1200, 800, 270)).toEqual({ width: 800, height: 1200 });
    const edits: ImageEdits = {
      rotation: 90,
      crop: { x: 0.125, y: 0.25, width: 0.5, height: 0.625 },
      paths: [],
    };
    expect(imageCropBounds(1200, 800, edits)).toEqual({
      x: 100,
      y: 300,
      width: 400,
      height: 750,
    });
  });

  it("treats each visible edit independently as a changed image", () => {
    expect(hasImageEdits({ ...defaultImageEdits(), rotation: 90 })).toBe(true);
    expect(hasImageEdits({
      ...defaultImageEdits(),
      crop: { x: 0, y: 0, width: 0.8, height: 1 },
    })).toBe(true);
    expect(hasImageEdits({ ...defaultImageEdits(), paths: [annotation] })).toBe(true);
    expect(hasImageEdits({ ...defaultImageEdits(), flipX: true })).toBe(true);
    expect(hasImageEdits({ ...defaultImageEdits(), flipY: true })).toBe(true);
    expect(hasImageEdits({ ...defaultImageEdits(), flipX: false, flipY: false })).toBe(false);
  });

  it("mirrors the crop with a visible-axis flip while preserving source annotations", () => {
    const edits: ImageEdits = {
      rotation: 90,
      crop: { x: 0.1, y: 0.2, width: 0.6, height: 0.4 },
      paths: [structuredClone(annotation)],
    };
    const snapshot = structuredClone(edits);
    const horizontal = flipImageEdits(edits, "horizontal");
    expect(horizontal.flipX).toBe(true);
    expect(!!horizontal.flipY).toBe(false);
    expectCropClose(horizontal.crop, { x: 0.3, y: 0.2, width: 0.6, height: 0.4 });
    expect(horizontal.paths).toEqual(edits.paths);
    const vertical = flipImageEdits(edits, "vertical");
    expect(vertical.flipY).toBe(true);
    expect(!!vertical.flipX).toBe(false);
    expectCropClose(vertical.crop, { x: 0.1, y: 0.4, width: 0.6, height: 0.4 });
    const both = flipImageEdits(horizontal, "vertical");
    expect(both.flipX).toBe(true);
    expect(both.flipY).toBe(true);
    expectCropClose(both.crop, { x: 0.3, y: 0.4, width: 0.6, height: 0.4 });
    const restored = flipImageEdits(horizontal, "horizontal");
    expect(!!restored.flipX).toBe(false);
    expectCropClose(restored.crop, edits.crop);
    expect(edits).toEqual(snapshot);
  });

  it("maps points through every rotation and flip combination with a lossless inverse", () => {
    const point = { x: 0.13, y: 0.71 };
    for (const rotation of [0, 90, 180, 270] as const)
      for (const flipX of [false, true])
        for (const flipY of [false, true]) {
          const edits = { ...defaultImageEdits(), rotation, flipX, flipY };
          const rotated = rotateNormalizedPoint(point, rotation);
          const transformed = transformImagePoint(point, edits);
          expect(transformed.x).toBeCloseTo(flipX ? 1 - rotated.x : rotated.x, 12);
          expect(transformed.y).toBeCloseTo(flipY ? 1 - rotated.y : rotated.y, 12);
          const restored = inverseImagePoint(transformed, edits);
          expect(restored.x).toBeCloseTo(point.x, 12);
          expect(restored.y).toBeCloseTo(point.y, 12);
        }
  });

  it("rotates reflected content and swaps the visible flip axes", () => {
    const point = { x: 0.12, y: 0.38 };
    const edits: ImageEdits = {
      ...defaultImageEdits(),
      flipX: true,
      crop: { x: 0.15, y: 0.2, width: 0.55, height: 0.4 },
    };
    for (const direction of [1, -1] as const) {
      const turned = rotateImageEdits(edits, direction);
      expect(!!turned.flipX).toBe(false);
      expect(turned.flipY).toBe(true);
      const expected = rotateNormalizedPoint(transformImagePoint(point, edits), direction === 1 ? 90 : 270);
      const actual = transformImagePoint(point, turned);
      expect(actual.x).toBeCloseTo(expected.x, 12);
      expect(actual.y).toBeCloseTo(expected.y, 12);
      const restored = rotateImageEdits(turned, direction === 1 ? -1 : 1);
      expect(restored.flipX).toBe(true);
      expect(!!restored.flipY).toBe(false);
      expectCropClose(restored.crop, edits.crop);
    }
  });

  it("normalizes persisted editing data without changing valid geometry", () => {
    const edits: ImageEdits = {
      rotation: 270,
      crop: { x: 0.05, y: 0.1, width: 0.8, height: 0.7 },
      paths: [structuredClone(annotation)],
    };
    expect(normalizeImageEdits(edits)).toEqual(edits);
    expect(normalizeImageEdits(undefined)).toEqual(defaultImageEdits());
    expect(normalizeImageEdits(null)).toEqual(defaultImageEdits());
    const malformed = normalizeImageEdits({
      rotation: Infinity,
      crop: { x: -4, y: 7, width: NaN, height: -1 },
      paths: [null, { color: "#000", width: NaN, points: [{ x: NaN, y: Infinity }] }],
    });
    expect([0, 90, 180, 270]).toContain(malformed.rotation);
    for (const value of Object.values(malformed.crop)) expect(Number.isFinite(value)).toBe(true);
    expect(malformed.crop.x).toBeGreaterThanOrEqual(0);
    expect(malformed.crop.y).toBeGreaterThanOrEqual(0);
    expect(malformed.crop.width).toBeGreaterThan(0);
    expect(malformed.crop.height).toBeGreaterThan(0);
    expect(malformed.crop.x + malformed.crop.width).toBeLessThanOrEqual(1);
    expect(malformed.crop.y + malformed.crop.height).toBeLessThanOrEqual(1);
    for (const path of malformed.paths) {
      expect(Number.isFinite(path.width)).toBe(true);
      expect(path.width).toBeGreaterThan(0);
      for (const point of path.points) {
        expect(Number.isFinite(point.x)).toBe(true);
        expect(Number.isFinite(point.y)).toBe(true);
      }
    }
  });

  it("validates imported edit documents before they reach rendering", () => {
    const valid: ImageEdits = {
      rotation: 180,
      crop: { x: 0.1, y: 0.2, width: 0.9, height: 0.8 },
      paths: [structuredClone(annotation)],
    };
    expect(isValidImageEdits(defaultImageEdits())).toBe(true);
    expect(isValidImageEdits(valid)).toBe(true);
    expect(isValidImageEdits({ ...valid, flipX: true, flipY: false })).toBe(true);
    expect(normalizeImageEdits(valid)).toEqual(valid);
    expect(normalizeImageEdits({ ...valid, flipX: true, flipY: false })).toEqual({
      ...valid,
      flipX: true,
      flipY: false,
    });
    for (const invalid of [
      null,
      undefined,
      [],
      { ...valid, rotation: 45 },
      { ...valid, flipX: "true" },
      { ...valid, flipY: 1 },
      { ...valid, crop: { ...valid.crop, x: -0.1 } },
      { ...valid, crop: { ...valid.crop, width: 0 } },
      { ...valid, crop: { ...valid.crop, width: Infinity } },
      { ...valid, crop: { ...valid.crop, x: 0.2 } },
      { ...valid, paths: [{ ...annotation, width: 0 }] },
      { ...valid, paths: [{ ...annotation, width: 2 }] },
      { ...valid, paths: [{ ...annotation, color: "url(#external)" }] },
      { ...valid, paths: [{ ...annotation, points: [] }] },
      { ...valid, paths: [{ ...annotation, points: [{ x: 1.1, y: 0 }] }] },
      { ...valid, paths: [{ ...annotation, points: [{ x: 0, y: NaN }] }] },
    ]) expect(isValidImageEdits(invalid)).toBe(false);
    expect(isValidImageEdits(normalizeImageEdits({
      rotation: 15,
      crop: { x: -1, y: 4, width: NaN, height: -2 },
      paths: [null, { ...annotation, points: [{ x: -0.5, y: 2 }] }],
    }))).toBe(true);
  });

  it("returns an untouched source immediately when export has no edits", async () => {
    // This runs without a browser DOM: the common path does not need to load
    // or rasterize images and preserves portable data URLs byte for byte.
    const src = "data:image/png;base64,c291cmNl";
    await expect(bakeImageEdits(src)).resolves.toBe(src);
    await expect(bakeImageEdits(src, defaultImageEdits())).resolves.toBe(src);
  });

  it("keeps single-point strokes visible and serializes open annotation paths", () => {
    expect(imagePathToSvg([])).toBe("");
    const tap = imagePathToSvg([{ x: 0.25, y: 0.5 }]);
    expect(tap.match(/[ML]/g)).toEqual(["M", "L"]);
    expect(tap.match(/-?\d*\.?\d+/g)?.map(Number)).toEqual([0.25, 0.5, 0.25, 0.5]);
    const stroke = imagePathToSvg(annotation.points);
    expect(stroke.match(/[ML]/g)).toEqual(["M", "L"]);
    expect(stroke.match(/-?\d*\.?\d+/g)?.map(Number)).toEqual([0.12, 0.22, 0.36, 0.48]);
    expect(stroke).not.toMatch(/[Zz]/);
  });
});
