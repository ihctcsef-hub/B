/** Test host for real NoteEditor parsing, native editing, and serialization. */
import {createElement,createRef} from 'react';
import {createRoot} from 'react-dom/client';
import {flushSync} from 'react-dom';
import {NoteEditor,type NoteEditorHandle} from '../../src/components/NoteEditor';

export function createNoteBlocksHarness(){
  const app=document.querySelector<HTMLElement>('.app');if(app)app.style.display='none';
  const host=document.createElement('main');host.className='reference-layout';host.style.cssText='padding:60px;width:800px;background:#ebedee';document.body.append(host);
  const card=document.createElement('article');card.className='card-note';card.style.cssText='position:relative;width:400px;background:#fff;';host.append(card);
  const holder=document.createElement('div');card.append(holder);const root=createRoot(holder),ref=createRef<NoteEditorHandle>();
  let value={text:'',html:'',height:0},readOnly=false;
  function render(html:string,options:{readOnly?:boolean;background?:string}={}){
    readOnly=options.readOnly===true;
    card.style.background=options.background||'#fff';card.style.setProperty('--note-card-background',options.background||'#fff');card.style.setProperty('--note-callout-tint',options.background?'#000':'#323b4a');
    flushSync(()=>root.render(createElement(NoteEditor,{ref,text:'',html,readOnly,ariaLabel:'Note blocks text',onChange:next=>{value=next;}})));
  }
  return {render,getValue:()=>value,getHTML:()=>ref.current?.getHTML(),getMarkdown:()=>ref.current?.getMarkdown(),run:(command:Parameters<NoteEditorHandle['run']>[0],argument?:string|number)=>ref.current?.run(command,argument),dispose:()=>{flushSync(()=>root.unmount());host.remove();if(app)app.style.display='';}};
}
