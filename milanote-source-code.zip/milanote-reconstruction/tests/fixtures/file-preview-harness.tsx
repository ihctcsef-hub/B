/** Test-only controlled host for the isolated file view. Not imported by the app. */
import {createElement} from 'react';
import {createRoot} from 'react-dom/client';
import {flushSync} from 'react-dom';
import {FileCardView,type FileCardViewProps} from '../../src/components/FileCardView';

export function createFilePreviewHarness(){
  const main=document.querySelector<HTMLElement>('.app');if(main)main.style.display='none';
  const host=document.createElement('main');host.className='reference-layout';host.style.cssText='position:relative;padding:80px 100px;background:#ebedee;min-height:1000px';document.body.append(host);
  const card=document.createElement('article');card.style.cssText='position:relative;width:270px;height:auto;background:white';host.append(card);const root=createRoot(card);
  const events:{ready:unknown[];errors:string[];names:string[];finishes:number;captions:unknown[];layouts:unknown[]}={ready:[],errors:[],names:[],finishes:0,captions:[],layouts:[]};
  const initial={name:'01-two-pages.pdf',mime:'application/pdf',size:1047};
  let props:FileCardViewProps={file:initial};
  const callbacks=()=>({onReady:(value:unknown)=>events.ready.push(value),onError:(message:string)=>events.errors.push(message),onRename:(name:string)=>events.names.push(name),onFinishRename:()=>events.finishes++,onCaptionChange:(value:unknown)=>events.captions.push(value),onLayout:(value:unknown)=>events.layouts.push(value)});
  function render(next:FileCardViewProps,width=270){props={...next};card.style.width=width+'px';flushSync(()=>root.render(createElement(FileCardView,{...callbacks(),...props})));}
  function dispose(){flushSync(()=>root.unmount());host.remove();if(main)main.style.display='';}
  return {render,dispose,events,card};
}
