import { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { ImageLibrary } from '../../src/components/ImageLibrary';
import { decodeLibraryPhoto, LIBRARY_DRAG_TYPE } from '../../src/core/imageLibrary';

function Fixture(){
  const [open,setOpen]=useState(true),[selected,setSelected]=useState(''),[dropped,setDropped]=useState(''),[upload,setUpload]=useState(false);
  return <><button data-tool="image" onClick={()=>setOpen(true)}>Open image library</button><output aria-label="Selected photo">{selected}</output><output aria-label="Upload requested">{String(upload)}</output><div aria-label="Photo drop target" style={{position:'absolute',left:600,top:100,width:300,height:200,border:'1px solid'}} onDragOver={event=>event.preventDefault()} onDrop={event=>{event.preventDefault();setDropped(decodeLibraryPhoto(event.dataTransfer.getData(LIBRARY_DRAG_TYPE))?.id||'invalid');}}>Drop here<output aria-label="Dropped photo">{dropped}</output></div>{open&&<ImageLibrary onSelect={photo=>setSelected(photo.id)} onUpload={()=>setUpload(true)} onClose={()=>setOpen(false)}/>}</>;
}
createRoot(document.getElementById('root')!).render(<Fixture/>);
