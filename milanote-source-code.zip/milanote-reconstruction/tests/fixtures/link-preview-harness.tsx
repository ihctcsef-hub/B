/** Test-only controlled React host. The product does not import this file. */
import {createElement} from 'react';
import {createRoot} from 'react-dom/client';
import {flushSync} from 'react-dom';
import {LinkPreview,type LinkPreviewProps} from '../../src/components/LinkPreview';

export function createLinkPreviewHarness(){
  const app=document.querySelector<HTMLElement>('.app');if(app)app.style.display='none';
  const host=document.createElement('main');host.className='reference-layout';host.dataset.linkPreviewHarness='';host.style.cssText='padding:80px 100px;min-height:1000px;background:#ebedee';document.body.append(host);
  const column=document.createElement('div');column.style.cssText='position:relative;width:270px;height:auto';host.append(column);
  const card=document.createElement('article');card.style.cssText='position:relative;width:100%;height:auto;background:white;transform-origin:0 0';column.append(card);
  const holder=document.createElement('div');holder.className='link-auto-content';holder.style.cssText='height:auto;width:100%';card.append(holder);const root=createRoot(holder);
  function render(props:LinkPreviewProps,options:{width?:number;height?:number;scale?:number;hidden?:boolean}={}){
    column.style.width=(options.width||270)+'px';card.style.height=(options.height||300)+'px';card.style.transform=`scale(${options.scale||1})`;column.style.display=options.hidden?'none':'';
    holder.className=props.automatic?'link-auto-content':'';holder.style.height=props.automatic?'auto':'100%';
    flushSync(()=>root.render(createElement(LinkPreview,{placeholder:createElement('span',{'data-testid':'link-fallback'},'Website preview'),...props})));
  }
  function dispose(){flushSync(()=>root.unmount());host.remove();if(app)app.style.display='';}
  return {render,dispose,card,column};
}
