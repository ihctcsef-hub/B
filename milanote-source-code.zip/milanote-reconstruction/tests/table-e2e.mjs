import assert from "node:assert/strict";
import { mkdir, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { chromium,webkit } from 'playwright-core';

const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const artifacts = path.join(root, "artifacts", engine==='webkit'?'webkit':'.');
await mkdir(artifacts, { recursive: true });
for (const name of await readdir(artifacts)) if (/^table-failure-\d+\.png$/.test(name)) await rm(path.join(artifacts, name));
const browser=await (engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({ executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium", headless: true, args: ["--no-sandbox", "--disable-dev-shm-usage"] }));
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true });
const page = await context.newPage();
page.setDefaultTimeout(7000);
const results = [], pageErrors = [];
page.on("pageerror", error => pageErrors.push(error.message));
const table = () => page.locator('[data-card-id="test-table"]');
const cell = (row, column) => table().getByRole("gridcell", { name: `Row ${row} column ${column}`, exact: true });
const grid = () => table().getByRole("grid", { name: "Table", exact: true });
const fixture = (rows = Array.from({ length: 4 }, () => ["", "", ""]), meta = {}) => ({
  version: 1, id: "table-workspace", title: "Table workspace", rootBoardId: "table-board", updatedAt: "2026-10-25T00:00:00.000Z",
  boards: { "table-board": { id: "table-board", title: "Table test board", cards: [
    { id: "test-table", type: "table", title: "", rows, cellMeta: meta, x: 100, y: 100, width: 270, height: rows.length * 24 - 2, z: 1 },
  ], connections: [], viewport: { x: 35, y: 40, zoom: 1 }, background: "#ebedee", grid: true } },
});
async function importFixture(value = fixture()) {
  await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({ name: "table-fixture.json", mimeType: "application/json", buffer: Buffer.from(JSON.stringify(value)) });
  await page.waitForFunction(() => document.querySelector('input[type=file][accept="application/json,.json"]')?.value === "");
  await page.getByText("Workspace imported. Undo to return to your previous workspace.", { exact: true }).waitFor();
  await page.waitForFunction(() => document.querySelector('[aria-label="Current board title"]')?.value === "Table test board");
  await grid().waitFor();
}
async function edit(row, column, value, key = "Enter") {
  await cell(row, column).dblclick();
  await table().getByLabel(`Edit Row ${row} column ${column}`, { exact: true }).fill(value);
  await page.keyboard.press(key);
}
async function setType(type){
  const labels={currency:'Currency',percentage:'Percentage',checkbox:'Checkbox',number:'Number',date:'Date & Time',text:'Text',auto:'Auto'};
  await page.getByTitle('Cell type',{exact:true}).click();await page.getByRole('menuitemradio',{name:labels[type],exact:true}).click();await page.keyboard.press('Escape');
}
async function run(name, fn) {
  try { await fn(); results.push({ name, status: "passed" }); console.log("PASS", name); }
  catch (error) {
    results.push({ name, status: "failed", message: error.stack }); process.exitCode = 1; console.error("FAIL", name, error.message);
    await page.screenshot({ path: path.join(artifacts, `table-failure-${results.length}.png`), fullPage: true }).catch(() => {});
    await page.keyboard.press("Escape").catch(() => {});
  }
}
async function download(name, filename) {
  const pending = page.waitForEvent("download");
  pending.catch(() => {});
  await page.getByRole("button", { name }).click();
  const item = await pending, destination = path.join(artifacts, filename);
  await item.saveAs(destination); return readFile(destination, "utf8");
}
async function backup(filename) {
  await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();
  const data = JSON.parse(await download(/Workspace backup/, filename));
  await page.getByTitle("Close dialog", { exact: true }).click();
  return data;
}
async function paste(text) {
  await grid().evaluate((element, text) => {
    const clipboardData = new DataTransfer(); clipboardData.setData("text/plain", text);
    element.dispatchEvent(new ClipboardEvent("paste", { bubbles: true, cancelable: true, clipboardData }));
  }, text);
}
async function action(row, column, name) {
  await cell(row, column).click({ button: "right" });
  await page.getByRole("menu", { name: "Cell actions", exact: true }).getByRole("menuitem", { name, exact: true }).click();
}
try {
  await page.goto(process.env.TEST_URL || "http://127.0.0.1:5176", { waitUntil: "domcontentloaded" });
  await page.getByText("Saved on this device", { exact: true }).waitFor();

  await run("New table has the reference 3-column, 4-row compact geometry and no title", async () => {
    const empty=fixture();empty.boards['table-board'].cards=[];
    await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'empty-table-board.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(empty))});
    await page.waitForFunction(()=>document.querySelector('input[type=file][accept="application/json,.json"]')?.value==='');
    await page.getByText('Workspace imported. Undo to return to your previous workspace.',{exact:true}).waitFor();
    await page.getByTitle("Add Table", { exact: true }).click();
    const created = page.locator(".card-table");
    assert.equal(await created.locator("tr").count(), 4);
    assert.equal(await created.getByRole("gridcell").count(), 12);
    assert.equal(await created.getByLabel("Table title", { exact: true }).count(), 0);
    assert.deepEqual(await created.evaluate(el => ({ width: parseFloat(el.style.width), height: parseFloat(el.style.height) })), { width: 270, height: 94 });
  });

  await run("Cell double-click, native typing, Tab and Enter edit and navigate without moving the table", async () => {
    await importFixture();
    await edit(1, 1, "Budget", "Tab");
    assert.equal((await cell(1, 1).innerText()).trimEnd(), "Budget");
    assert.equal(await cell(1, 2).getAttribute("aria-selected"), "true");
    await page.keyboard.type("120");
    await page.keyboard.press("Enter");
    assert.equal((await cell(1, 2).innerText()).trimEnd(), "120");
    assert.equal(await cell(2, 2).getAttribute("aria-selected"), "true");
    await page.keyboard.press("Delete");
    assert.equal(await table().count(), 1);
    assert.deepEqual(await table().evaluate(el => ({ x: parseFloat(el.style.left), y: parseFloat(el.style.top) })), { x: 100, y: 100 });
  });

  await run("Spreadsheet formulas recalculate references and ranges, retain raw expressions and recover from errors", async () => {
    await importFixture(fixture([["8", "=SUM(A1:A2)", "=AVERAGE(A1:A2)"], ["12", "=A1*A2", "=1/0"], ["", "", ""], ["", "", ""]]));
    assert.equal((await cell(1, 2).innerText()).trimEnd(), "20");
    assert.equal((await cell(1, 3).innerText()).trimEnd(), "10");
    assert.equal((await cell(2, 2).innerText()).trimEnd(), "96");
    assert.equal((await cell(2, 3).innerText()).trimEnd(), "");
    const formulaError=cell(2,3).getByRole('img',{name:"Formula error: Numbers can't be divided by zero",exact:true});
    await formulaError.waitFor();assert.equal(await formulaError.getAttribute('data-formula-error'),'#DIV/0!');
    await formulaError.hover();await page.getByRole('tooltip',{name:"Numbers can't be divided by zero",exact:true}).waitFor();
    await page.mouse.move(1200,900);
    await edit(1, 1, "10");
    assert.equal((await cell(1, 2).innerText()).trimEnd(), "22");
    assert.equal((await cell(2, 2).innerText()).trimEnd(), "120");
    await edit(2, 3, "=MAX(A1:A2)");
    assert.equal((await cell(2, 3).innerText()).trimEnd(), "12");
    await cell(3, 3).click();
    await page.getByTitle("Formula", { exact: true }).click();
    const field = table().getByLabel("Edit Row 3 column 3", { exact: true });
    assert.equal(await field.inputValue(), "=");
    await field.fill("=COUNT(A1:A2)"); await page.keyboard.press("Enter");
    assert.equal((await cell(3, 3).innerText()).trimEnd(), "2");
    const data = await backup("table-formulas.json");
    assert.equal(data.boards["table-board"].cards[0].rows[0][1], "=SUM(A1:A2)");
    assert.equal(data.boards["table-board"].cards[0].rows[2][2], "=COUNT(A1:A2)");
  });

  await run("Cell type, color, text style and alignment customize selected cells and persist after reload", async () => {
    await importFixture(fixture([["1250.5", "0.25", ""], ["", "", ""], ["", "", ""], ["", "", ""]]));
    await cell(1, 1).click();
    await setType('currency');
    assert.match((await cell(1, 1).innerText()).trimEnd(), /1,250\.50/);
    await page.getByLabel("Cell color", { exact: true }).fill("#fff2b0");
    await page.getByLabel("Cell alignment", { exact: true }).selectOption("center");
    await page.getByLabel("Cell vertical alignment", { exact: true }).selectOption("bottom");
    assert.equal(await cell(1, 1).evaluate(el => getComputedStyle(el).verticalAlign), "bottom");
    await page.getByLabel("Table text style", { exact: true }).selectOption("bold");
    assert.deepEqual(await cell(1, 1).evaluate(el => ({ bg: getComputedStyle(el).backgroundColor, align: getComputedStyle(el).textAlign, weight: getComputedStyle(el).fontWeight })), { bg: "rgb(255, 242, 176)", align: "center", weight: "700" });
    await cell(1, 2).click();
    await setType('percentage');
    assert.match((await cell(1, 2).innerText()).trimEnd(), /25%/);
    await cell(1, 3).click();
    await setType('checkbox');
    await table().getByRole("checkbox", { name: "Toggle Row 1 column 3", exact: true }).click();
    assert.equal(await table().getByRole("checkbox", { name: "Toggle Row 1 column 3", exact: true }).getAttribute("aria-checked"), "true");
    await page.getByText("Saved on this device", { exact: true }).waitFor();
    await page.reload({ waitUntil: "domcontentloaded" });
    await grid().waitFor();
    assert.match((await cell(1, 1).innerText()).trimEnd(), /1,250\.50/);
    assert.equal(await cell(1, 1).evaluate(el => getComputedStyle(el).backgroundColor), "rgb(255, 242, 176)");
    assert.equal(await table().getByRole("checkbox", { name: "Toggle Row 1 column 3", exact: true }).getAttribute("aria-checked"), "true");
    const data = await backup("table-styles.json");
    const saved = data.boards["table-board"].cards[0];
    assert.equal(saved.cellMeta["0:0"].type, "currency"); assert.equal(saved.cellMeta["0:0"].color, "#fff2b0");
    assert.equal(saved.cellMeta["0:0"].align, "center"); assert.equal(saved.cellMeta["0:0"].bold, true);
    assert.equal(saved.cellMeta["0:0"].verticalAlign, "bottom");
    assert.equal(saved.rows[0][2], "true");
  });

  await run('Measured cell-type submenus apply decimal/grouping/currency/accounting settings to ranges and preserve them in backup',async()=>{
    await importFixture(fixture([['-12345.678','0.125',''],['12345.678','',''],['','',''],['','','']]));await cell(1,1).click();
    await page.getByTitle('Cell type',{exact:true}).click();const menu=page.getByRole('dialog',{name:'Cell type',exact:true});assert.equal(Math.round((await menu.boundingBox()).width),192);
    await menu.getByRole('menuitemradio',{name:'Currency',exact:true}).click();await menu.getByLabel('Decimals',{exact:true}).fill('3');await menu.getByLabel('Thousands separator',{exact:true}).uncheck();await menu.getByLabel('Accounting style',{exact:true}).check();
    assert.equal((await cell(1,1).innerText()).trimEnd(),'($12345.678)');await menu.getByLabel('Currency',{exact:true}).selectOption('EUR');await menu.getByLabel('Currency display',{exact:true}).selectOption('code');assert.match((await cell(1,1).innerText()).trimEnd(),/EUR/);
    assert.equal(await menu.getByRole('menuitemradio',{name:'Date & Time',exact:true}).isDisabled(),true);assert.equal(await menu.getByRole('menuitemradio',{name:'Checkbox',exact:true}).isDisabled(),true);await page.keyboard.press('Escape');
    await cell(1,2).click();await page.getByTitle('Cell type',{exact:true}).click();await menu.getByRole('menuitemradio',{name:'Percentage',exact:true}).click();await menu.getByLabel('Decimals',{exact:true}).fill('2');assert.equal((await cell(1,2).innerText()).trimEnd(),'12.50%');await page.keyboard.press('Escape');
    const data=await backup('table-formatting-controls.json'),saved=data.boards['table-board'].cards[0];assert.deepEqual(saved.cellMeta['0:0'],{type:'currency',decimals:3,thousandsSeparator:false,currency:'EUR',currencyDisplay:'code',accounting:true});assert.deepEqual(saved.cellMeta['0:1'],{type:'percentage',decimals:2});
  });
  await run('Date/time presets and calendar controls retain raw data, save once, cancel drafts and reload',async()=>{
    await importFixture(fixture([['2016-02-29T13:24:56','',''],['','',''],['','',''],['','','']],{'0:0':{type:'date'}}));await cell(1,1).click();await page.getByTitle('Cell type',{exact:true}).click();const menu=page.getByRole('dialog',{name:'Cell type',exact:true});
    await menu.getByLabel('Date format',{exact:true}).selectOption('numericDashed');await menu.getByLabel('Time format',{exact:true}).selectOption('twentyFourHourSeconds');assert.equal((await cell(1,1).innerText()).trimEnd(),'2-29-2016 (13:24:56)');await page.keyboard.press('Escape');
    await cell(1,1).dblclick();const calendar=page.getByRole('dialog',{name:'Choose table date',exact:true});await calendar.waitFor();const rect=await calendar.boundingBox();assert.equal(Math.round(rect.width),232);assert.equal(Math.round(rect.height),310);
    assert.equal(await calendar.getByRole('button',{name:'February 2016',exact:true}).isDisabled(),true);await calendar.getByRole('button',{name:'February 28, 2016',exact:true}).click();await page.keyboard.press('Escape');assert.equal((await cell(1,1).innerText()).trimEnd(),'2-29-2016 (13:24:56)');
    await cell(1,1).dblclick();await calendar.getByRole('button',{name:'February 28, 2016',exact:true}).click();await calendar.getByLabel('Table time hour',{exact:true}).selectOption('3');await calendar.getByLabel('Table time minute',{exact:true}).selectOption('30');await calendar.getByLabel('Table time period',{exact:true}).selectOption('pm');
    await page.getByLabel('Current board title',{exact:true}).click();assert.equal((await cell(1,1).innerText()).trimEnd(),'2-28-2016 (15:30:00)');
    await page.getByTitle('Undo (⌘Z)',{exact:true}).click();assert.equal((await cell(1,1).innerText()).trimEnd(),'2-29-2016 (13:24:56)');await page.getByTitle('Redo (⇧⌘Z)',{exact:true}).click();assert.equal((await cell(1,1).innerText()).trimEnd(),'2-28-2016 (15:30:00)');
    await cell(1,2).click();await page.getByTitle('Cell type',{exact:true}).click();await menu.getByRole('menuitemradio',{name:'Date & Time',exact:true}).click();await calendar.waitFor();await calendar.getByRole('button',{name:'Add time…',exact:true}).click();await calendar.getByLabel('Table time hour',{exact:true}).selectOption('4');await calendar.getByLabel('Table time minute',{exact:true}).selectOption('35');await calendar.getByLabel('Table time period',{exact:true}).selectOption('pm');await page.getByLabel('Current board title',{exact:true}).click();assert.match((await cell(1,2).innerText()).trimEnd(),/\(4:35 PM\)$/);
    const data=await backup('table-date-controls.json');assert.equal(data.boards['table-board'].cards[0].rows[0][0],'2016-02-28T15:30:00');await page.getByText('Saved on this device',{exact:true}).waitFor();await page.reload({waitUntil:'networkidle'});assert.equal((await cell(1,1).innerText()).trimEnd(),'2-28-2016 (15:30:00)');
  });
  await run("Cell context actions insert and delete rows and columns while keeping formula references and formatting aligned", async () => {
    await importFixture(fixture([["8", "=SUM(A1:A2)", ""], ["12", "", ""], ["", "", ""], ["", "", ""]], { "0:1": { color: "#fff2b0" } }));
    await action(1, 1, "Add Row Above");
    assert.equal(await table().locator("tr").count(), 5);
    assert.equal((await cell(2, 2).innerText()).trimEnd(), "20");
    await action(1, 1, "Add Column Left");
    assert.equal(await table().getByRole("gridcell").count(), 20);
    assert.equal((await cell(2, 3).innerText()).trimEnd(), "20");
    let data = await backup("table-structure.json");
    let saved = data.boards["table-board"].cards[0];
    assert.equal(saved.rows[1][2], "=SUM(B2:B3)"); assert.equal(saved.cellMeta["1:2"].color, "#fff2b0");
    await action(1, 1, "Delete Row");
    await action(1, 1, "Delete Column");
    assert.equal(await table().locator("tr").count(), 4); assert.equal(await table().getByRole("gridcell").count(), 12);
    assert.equal((await cell(1, 2).innerText()).trimEnd(), "20");
    await cell(4, 3).click();
    await page.getByTitle("Add row", { exact: true }).click();
    await page.getByTitle("Add column", { exact: true }).click();
    assert.equal(await table().locator("tr").count(), 5); assert.equal(await table().getByRole("gridcell").count(), 20);
    await page.getByTitle("Delete row", { exact: true }).click();
    await page.getByTitle("Delete column", { exact: true }).click();
    assert.equal(await table().locator("tr").count(), 4); assert.equal(await table().getByRole("gridcell").count(), 12);
  });

  await run("TSV paste expands the table; range selection, copy and paste values preserve the intended raw or computed data", async () => {
    await importFixture();
    await cell(1, 1).click(); await paste("3\t=SUM(A1:A2)\n7\tLabel");
    assert.equal((await cell(1, 1).innerText()).trimEnd(), "3"); assert.equal((await cell(1, 2).innerText()).trimEnd(), "10");
    assert.equal((await cell(2, 2).innerText()).trimEnd(), "Label");
    await cell(1, 2).click(); await page.keyboard.press("Shift+ArrowDown");
    assert.equal(await table().locator('[aria-selected="true"]').count(), 2);
    await page.keyboard.press("Control+c");
    await cell(3, 3).click(); await paste("=SUM(A1:A2)\nLabel");
    assert.equal((await cell(3, 3).innerText()).trimEnd(), "0"); assert.equal((await cell(4, 3).innerText()).trimEnd(), "Label");
    await cell(1, 2).click(); await page.keyboard.press("Control+c");
    await action(3, 1, "Paste Values");
    await cell(3, 1).getByText("10", { exact: true }).waitFor();
    assert.equal((await cell(3, 1).innerText()).trimEnd(), "10");
    const data = await backup("table-clipboard.json");
    assert.equal(data.boards["table-board"].cards[0].rows[2][0], "10");
    assert.equal(data.boards["table-board"].cards[0].rows[2][2], "=SUM(B3:B4)", "Copied formulas follow their relative row and column offset");
    await cell(4, 3).click(); await paste("End\tExpanded\nNext\tRow");
    assert.equal(await table().locator("tr").count(), 5); assert.equal(await table().getByRole("gridcell").count(), 20);
    assert.equal((await cell(5, 4).innerText()).trimEnd(), "Row");
    await action(5, 4, "Clear Cell"); assert.equal((await cell(5, 4).innerText()).trimEnd(), "");
    await page.getByTitle("Undo (⌘Z)", { exact: true }).click(); assert.equal((await cell(5, 4).innerText()).trimEnd(), "Row");
    await page.getByTitle("Redo (⇧⌘Z)", { exact: true }).click(); assert.equal((await cell(5, 4).innerText()).trimEnd(), "");
  });

  await run("Keyboard cut moves raw formulas and cell formatting while text-editor copy preserves its native selection", async () => {
    await importFixture(fixture([["3", "=SUM(A1:A2)", ""], ["7", "", ""], ["", "", ""], ["", "", ""]], { "0:1": { color: "#fff2b0", bold: true } }));
    await cell(1, 2).click(); await page.keyboard.press("Meta+x");
    await cell(1, 2).getByText("10", { exact: true }).waitFor({ state: "detached" });
    assert.equal((await cell(1, 2).innerText()).trimEnd(), "");
    await cell(3, 3).click(); await paste("=SUM(A1:A2)");
    assert.equal((await cell(3, 3).innerText()).trimEnd(), "10");
    assert.equal(await cell(3, 3).getAttribute("title"), "=SUM(A1:A2)", "Cut formulas retain their original references");
    assert.equal(await cell(3, 3).evaluate(el => getComputedStyle(el).backgroundColor), "rgb(255, 242, 176)");
    await cell(2, 1).dblclick();
    const input = table().getByLabel("Edit Row 2 column 1", { exact: true });
    await input.fill("Native text");
    await input.evaluate(element => element.setSelectionRange(0, 6));
    await page.keyboard.press("Control+c");
    assert.deepEqual(await input.evaluate(element => ({ focused: document.activeElement === element, start: element.selectionStart, end: element.selectionEnd, value: element.value })), { focused: true, start: 0, end: 6, value: "Native text" });
    await page.keyboard.press("Escape");
    const data = await backup("table-keyboard-cut.json"), saved = data.boards["table-board"].cards[0];
    assert.equal(saved.rows[0][1], ""); assert.equal(saved.rows[2][2], "=SUM(A1:A2)");
    assert.equal(saved.cellMeta["2:2"].bold, true); assert.equal(saved.cellMeta["2:2"].color, "#fff2b0");
    assert.equal(saved.rows[1][0], "7", "Escape still cancels the native text edit");
  });

  await run("HTML export contains calculated values and cell formatting while JSON reimports editable formulas", async () => {
    await importFixture(fixture([["10", "=A1*2", ""], ["", "", ""], ["", "", ""], ["", "", ""]], { "0:1": { color: "#fff2b0", bold: true, align: "right" } }));
    const data = await backup("table-export.json");
    await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();
    const html = await download(/Board as HTML/, "table-export.html");
    await page.getByTitle("Close dialog", { exact: true }).click();
    const exported = await context.newPage(); await exported.setContent(html);
    const exportedCell = exported.locator("tr").first().locator("th,td").nth(1);
    assert.equal(await exportedCell.innerText(), "20");
    assert.equal(await exportedCell.evaluate(el => getComputedStyle(el).backgroundColor), "rgb(255, 242, 176)");
    assert.equal(await exportedCell.evaluate(el => getComputedStyle(el).fontWeight), "700");
    await exported.close(); await page.bringToFront();
    await importFixture(data); await cell(1, 2).dblclick();
    assert.equal(await table().getByLabel("Edit Row 1 column 2", { exact: true }).inputValue(), "=A1*2");
    await page.keyboard.press("Escape");
  });
  await run("Formula catalog search inserts a selected function into the active cell", async () => {
    await importFixture(); await cell(1, 1).click(); await page.getByTitle("Browse formulas", { exact: true }).click();
    await page.getByLabel("Find formula", { exact: true }).fill("ROUND"); await page.getByRole("button", { name: "ROUND", exact: true }).click();
    const input = table().getByLabel("Edit Row 1 column 1", { exact: true }); await input.waitFor(); assert.equal(await input.inputValue(), "=ROUND()");
    await input.fill("=ROUND(12.345,2)"); await input.press("Enter"); assert.equal((await cell(1, 1).innerText()).trimEnd(), "12.35");
  });
  await run("No uncaught browser errors", async () => assert.deepEqual(pageErrors, []));
  await importFixture(fixture([["Item", "Amount", "Total"], ["Research", "125", "=SUM(B2:B4)"], ["Design", "280", ""], ["Review", "95", ""]], { "0:0": { bold: true }, "0:1": { bold: true }, "0:2": { bold: true }, "1:2": { color: "#fff2b0", type: "currency", bold: true } }));
  await page.locator(".toast").waitFor({ state: "hidden" });
  await page.screenshot({ path: path.join(artifacts, "table-preview.png"), fullPage: true });
} catch (error) { results.push({ name: "Harness failure", status: "failed", message: error.stack }); process.exitCode = 1; console.error(error); }
finally { await writeFile(path.join(artifacts, "table-e2e-results.json"), JSON.stringify({ results, pageErrors }, null, 2)); await browser.close(); }
