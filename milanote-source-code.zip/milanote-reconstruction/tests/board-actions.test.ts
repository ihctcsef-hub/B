import { describe, expect, it } from "vitest";
import { convertColumnToBoard, moveCardsToBoard } from "../src/core/boardActions";
import { arrangeAllColumns } from "../src/core/columns";
import { createCard, type Board, type Card, type Connection, type Workspace } from "../src/core/model";
import { exportWorkspace, importWorkspace } from "../src/core/storage";
import { labelUsages } from "../src/core/labels";

function makeBoard(id: string, parentBoardId?: string, cards: Card[] = []): Board {
  return { id, title: id, parentBoardId, cards, connections: [], viewport: { x: 0, y: 0, zoom: 1 } };
}
function fixture(): Workspace {
  const target = { ...createCard("board", 500, 300), type: "board" as const, id: "target-tile", title: "Target", boardId: "target" };
  const nested = { ...createCard("board", 106.4, 222.2), type: "board" as const, id: "nested-tile", title: "Nested", boardId: "nested", parentId: "column", preColumnWidth: 160 };
  const descendant = { ...createCard("board"), type: "board" as const, id: "descendant-tile", title: "Descendant", boardId: "descendant" };
  const column = { ...createCard("column", 100, 100), type: "column" as const, id: "column", title: "Research", tags: ["Reference"] };
  const note = { ...createCard("note", 106.4, 162.2), type: "note" as const, id: "note", text: "Finding", syncedId: "sync-group", parentId: "column", preColumnWidth: 400, height: 54 };
  const outside = { ...createCard("note", 800, 100), type: "note" as const, id: "outside", text: "Outside" };
  const root = arrangeAllColumns(makeBoard("root", undefined, [target, column, note, nested, outside]));
  root.connections = [
    { id: "internal", from: "note", to: "nested-tile", color: "#333333", style: "solid", control: { x: 500, y: 600 } },
    { id: "crossing", from: "note", to: "outside", color: "#333333", style: "solid" },
    { id: "column-line", from: "column", to: "outside", color: "#333333", style: "solid" },
    { id: "unrelated", from: "outside", to: "target-tile", color: "#333333", style: "solid" },
    { id: "free", from: "", to: "", start: { x: -50, y: -60 }, end: { x: 40, y: 80 }, color: "#333333", style: "solid" },
    { id: "half-free", from: "note", to: "", end: { x: 900, y: 900 }, color: "#333333", style: "solid" },
  ];
  return { version: 1, id: "workspace", title: "Board actions", rootBoardId: "root", updatedAt: "2026-10-25T00:00:00.000Z", boards: {
    root, target: makeBoard("target", "root", [{ ...createCard("note"), type: "note", id: "existing", text: "Existing" }]),
    nested: makeBoard("nested", "root", [descendant]), descendant: makeBoard("descendant", "nested"),
  } };
}
function getCard(workspace: Workspace, board: string, id: string) { return workspace.boards[board].cards.find(card => card.id === id)!; }
const roundTrip = (workspace: Workspace) => expect(importWorkspace(exportWorkspace(workspace))).toEqual(workspace);

describe("move cards between boards", () => {
  it("moves a column with all members, internal curves and nested board ownership, preserving IDs and input", () => {
    const source = fixture(), before = structuredClone(source);
    const next = moveCardsToBoard(source, "root", "target", ["column"], { x: 20, y: 30 });
    expect(source).toEqual(before);
    expect(next.boards.root.cards.map(card => card.id)).toEqual(["target-tile", "outside"]);
    expect(next.boards.target.cards.map(card => card.id)).toEqual(["existing", "column", "note", "nested-tile"]);
    expect(getCard(next, "target", "column")).toMatchObject({ x: 20, y: 30 });
    expect(getCard(next, "target", "note")).toMatchObject({ id: "note", syncedId: "sync-group", parentId: "column", x: 26.4, y: 92.2 });
    expect(next.boards.target.connections).toHaveLength(1);
    expect(next.boards.target.connections[0]).toMatchObject({ id: "internal", from: "note", to: "nested-tile", control: { x: 420, y: 530 } });
    expect(next.boards.root.connections.map(line => line.id)).toEqual(["unrelated", "free"]);
    expect(next.boards.nested.parentBoardId).toBe("target");
    expect(next.boards.descendant.parentBoardId).toBe("nested");
    roundTrip(next);
  });

  it("detaches an individual member, restores its width and closes the original column gap", () => {
    const source = fixture();
    const next = moveCardsToBoard(source, "root", "target", ["note"], { x: -20, y: 80 });
    expect(getCard(next, "target", "note")).toMatchObject({ x: -20, y: 80, width: 400, parentId: undefined, preColumnWidth: undefined });
    expect(getCard(next, "root", "nested-tile")).toMatchObject({ parentId: "column", y: 162.2 });
    expect(next.boards.root.connections.map(line => line.id)).toEqual(["column-line", "unrelated", "free"]);
    expect(next.boards.target.connections).toHaveLength(0);
    roundTrip(next);
  });

  it("rejects selected nested-board destinations and every descendant, including when selected through a column", () => {
    const source = fixture();
    for (const target of ["nested", "descendant"]) {
      expect(moveCardsToBoard(source, "root", target, ["nested-tile"])).toBe(source);
      expect(moveCardsToBoard(source, "root", target, ["column"])).toBe(source);
    }
    const next = moveCardsToBoard(source, "nested", "root", ["descendant-tile"]);
    expect(next.boards.descendant.parentBoardId).toBe("root");
    expect(next.boards.nested.cards).toEqual([]);
    roundTrip(next);
  });

  it("preserves coordinates and inbox status without explicit placement, and clears inbox status with placement", () => {
    const source = fixture();
    const outside = getCard(source, "root", "outside");
    outside.unsorted = true;
    const samePosition = moveCardsToBoard(source, "root", "target", [outside.id]);
    expect(getCard(samePosition, "target", outside.id)).toMatchObject({ x: 800, y: 100, unsorted: true });
    const placed = moveCardsToBoard(source, "root", "target", [outside.id], { x: 10, y: 20 });
    expect(getCard(placed, "target", outside.id)).toMatchObject({ x: 10, y: 20, unsorted: false });
    roundTrip(samePosition); roundTrip(placed);
  });

  it("returns the input for missing targets, empty selections, invalid coordinates and destination ID collisions", () => {
    const source = fixture();
    expect(moveCardsToBoard(source, "missing", "target", ["note"])).toBe(source);
    expect(moveCardsToBoard(source, "root", "missing", ["note"])).toBe(source);
    expect(moveCardsToBoard(source, "root", "root", ["note"])).toBe(source);
    expect(moveCardsToBoard(source, "root", "target", ["missing"])).toBe(source);
    expect(moveCardsToBoard(source, "root", "target", ["note"], { x: NaN, y: 0 })).toBe(source);
    source.boards.target.cards.push({ ...createCard("note"), type: "note", id: "note", text: "Same scoped ID" });
    expect(moveCardsToBoard(source, "root", "target", ["note"])).toBe(source);
    source.boards.target.cards.pop();
    const internal = source.boards.root.connections.find(line => line.id === "internal")!;
    source.boards.target.connections.push({ ...structuredClone(internal), from: "existing", to: "", end: { x: 0, y: 0 } });
    expect(moveCardsToBoard(source, "root", "target", ["column"])).toBe(source);
    roundTrip(source);
  });

  it("rejects inherited registry names as source and target without accepting them as saved boards", () => {
    const source = fixture(), before = structuredClone(source);
    for (const id of ["constructor", "toString", "__proto__", "hasOwnProperty"]) {
      expect(moveCardsToBoard(source, id, "target", ["note"])).toBe(source);
      expect(moveCardsToBoard(source, "root", id, ["note"])).toBe(source);
    }
    expect(source).toEqual(before);
    roundTrip(source);
  });

  it("moves into a real own constructor board and round-trips its ownership", () => {
    const source = fixture();
    source.boards = { ...source.boards, constructor: makeBoard("constructor", "root") };
    source.boards.root.cards.push({ ...createCard("board"), type: "board", id: "constructor-tile", title: "Constructor", boardId: "constructor" });
    roundTrip(source);
    const next = moveCardsToBoard(source, "root", "constructor", ["outside"], { x: 30, y: 40 });
    expect(getCard(next, "constructor", "outside")).toMatchObject({ x: 30, y: 40, text: "Outside" });
    expect(next.boards.root.cards.some(card => card.id === "outside")).toBe(false);
    expect(Object.hasOwn(next.boards, "constructor")).toBe(true);
    roundTrip(next);
  });

  it("rejects a malformed owning tile atomically, while a valid broken shortcut remains movable", () => {
    const source = fixture();
    const tile = getCard(source, "root", "nested-tile") as Extract<Card, { type: "board" }>;
    tile.boardId = "constructor";
    const before = structuredClone(source);
    expect(() => importWorkspace(exportWorkspace(source))).toThrow(/nested board does not exist/);
    expect(moveCardsToBoard(source, "root", "target", ["nested-tile"])).toBe(source);
    expect(moveCardsToBoard(source, "root", "target", ["column"])).toBe(source);
    expect(convertColumnToBoard(source, "root", "column")).toEqual({ workspace: source });
    expect(source).toEqual(before);
    expect(Object.hasOwn(source.boards, "constructor")).toBe(false);

    const valid = fixture();
    valid.boards.root.cards.push({ ...createCard("board"), type: "board", id: "broken-shortcut", title: "Deleted board", boardId: "constructor", isShortcut: true });
    roundTrip(valid);
    const moved = moveCardsToBoard(valid, "root", "target", ["broken-shortcut"]);
    expect(getCard(moved, "target", "broken-shortcut")).toMatchObject({ boardId: "constructor", isShortcut: true });
    expect(Object.hasOwn(moved.boards, "constructor")).toBe(false);
    roundTrip(moved);
  });

  it("translates stored endpoint points as well as curve controls while leaving free lines in the source", () => {
    const source = fixture();
    const internal = source.boards.root.connections.find(line => line.id === "internal")!;
    internal.start = { x: 10, y: 20 }; internal.end = { x: 30, y: 40 };
    const next = moveCardsToBoard(source, "root", "target", ["column"], { x: 120, y: 130 });
    expect(next.boards.target.connections[0]).toMatchObject({ start: { x: 30, y: 50 }, end: { x: 50, y: 70 }, control: { x: 520, y: 630 } });
    expect(next.boards.root.connections.find(line => line.id === "free")).toEqual(source.boards.root.connections.find(line => line.id === "free"));
    roundTrip(next);
  });
});

describe("convert columns into boards", () => {
  it("replaces the column with a tile, moves all members without deletion and preserves valid nested ownership", () => {
    const source = fixture();
    source.labels = [{ id: "reference-label", name: "Reference", color: "#5882f8" }];
    getCard(source, "root", "column").labelIds = ["reference-label"];
    const before = structuredClone(source);
    const result = convertColumnToBoard(source, "root", "column"), next = result.workspace;
    expect(result.boardId).toBeTruthy();
    expect(source).toEqual(before);
    const id = result.boardId!;
    expect(getCard(next, "root", "column")).toMatchObject({ type: "board", id: "column", boardId: id, title: "Research", x: 100, y: 100, width: 160, height: 160, tags: ["Reference"], labelIds: ["reference-label"] });
    expect(getCard(next, "root", "column").labelIds).not.toBe(getCard(source, "root", "column").labelIds);
    expect(next.boards[id]).toMatchObject({ parentBoardId: "root", title: "Research", viewport: { x: 0, y: 0, zoom: 1 } });
    expect(next.boards[id].cards.map(card => card.id)).toEqual(["note", "nested-tile"]);
    expect(getCard(next, id, "note")).toMatchObject({ x: 40, y: 40, width: 400, parentId: undefined, preColumnWidth: undefined, syncedId: "sync-group" });
    expect(getCard(next, id, "nested-tile")).toMatchObject({ width: 160, parentId: undefined });
    expect(next.boards.nested.parentBoardId).toBe(id);
    expect(next.boards[id].connections.map(line => line.id)).toEqual(["internal"]);
    expect(next.boards.root.connections.map(line => line.id)).toEqual(["column-line", "unrelated", "free"]);
    expect(labelUsages(next, "reference-label")).toEqual([{ boardId: "root", boardTitle: "root", cardId: "column", cardType: "board" }]);
    expect(labelUsages(importWorkspace(exportWorkspace(next)), "reference-label")).toEqual(labelUsages(next, "reference-label"));
    roundTrip(next);
  });

  it("creates a valid empty child board and preserves a locked/inbox column's tile state", () => {
    const source = fixture();
    source.boards.root.cards = source.boards.root.cards.filter(card => !["note", "nested-tile"].includes(card.id));
    source.boards.root.connections = [];
    delete source.boards.nested; delete source.boards.descendant;
    const column = getCard(source, "root", "column"); column.locked = true; column.unsorted = true;
    const { workspace: next, boardId } = convertColumnToBoard(source, "root", "column");
    expect(next.boards[boardId!].cards).toEqual([]);
    expect(getCard(next, "root", "column")).toMatchObject({ locked: true, unsorted: true });
    roundTrip(next);
  });

  it("does not convert another card type or a missing column", () => {
    const source = fixture();
    for (const [boardId, columnId] of [["root", "note"], ["root", "missing"], ["missing", "column"], ["constructor", "column"], ["__proto__", "column"]]) expect(convertColumnToBoard(source, boardId, columnId)).toEqual({ workspace: source });
  });
});
