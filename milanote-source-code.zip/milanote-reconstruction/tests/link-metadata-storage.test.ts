import {describe,it,expect} from 'vitest';
import {createCard,type Card,type Workspace} from '../src/core/model';
import {importWorkspace,exportWorkspace} from '../src/core/storage';
import {trashCards,restoreTrashEntry} from '../src/core/trash';
const link=():Extract<Card,{type:'link'}>=>({...createCard('link'),id:'link',type:'link',url:'https://example.com/#section',title:'Custom title',description:'Automatic description',previewSrc:'https://example.com/cover.png',linkMetadata:{url:'https://example.com/',title:'Fetched title',description:'Automatic description',image:'https://example.com/cover.png'},caption:'Custom caption',captionHtml:'<p><strong>Custom caption</strong></p>',showCaption:true,showPreview:false});
const workspace=():Workspace=>({version:1,id:'metadata-trash',title:'Metadata',rootBoardId:'root',updatedAt:'2026-10-27T00:00:00Z',boards:{root:{id:'root',title:'Root',cards:[link()],connections:[],viewport:{x:0,y:0,zoom:1}}}});
describe('link preview provenance in recoverable content',()=>{
  it('retains fetched provenance, original anchors, manual fields and visibility through Trash backup, restore and another import',()=>{
    const source=workspace(),before=structuredClone(source),deleted=trashCards(source,'root',['link']);
    const portable=importWorkspace(exportWorkspace(deleted));
    expect(portable.trash![0].cards[0]).toEqual(before.boards.root.cards[0]);
    const restored=restoreTrashEntry(portable,portable.trash![0].id);
    expect(restored.boards.root.cards[0]).toEqual(before.boards.root.cards[0]);
    expect(importWorkspace(exportWorkspace(restored))).toEqual(restored);
    expect(source).toEqual(before);
  });
  it('validates fetched provenance inside deleted cards instead of accepting a malformed hidden snapshot',()=>{
    const deleted=trashCards(workspace(),'root',['link']);
    Object.assign(deleted.trash![0].cards[0],{linkMetadata:{url:'file:///private',title:'Hidden snapshot'}});
    expect(()=>importWorkspace(JSON.stringify(deleted))).toThrow();
  });
});
