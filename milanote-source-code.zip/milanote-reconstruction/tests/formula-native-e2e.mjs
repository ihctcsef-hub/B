import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile}from'node:fs/promises';
import {chromium,webkit}from'playwright-core';
const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium',url=process.env.TEST_URL||'http://127.0.0.1:5310';
const artifacts=new URL(`../artifacts/formula-native/${engine}/`,import.meta.url);await mkdir(artifacts,{recursive:true});
const fixture=JSON.parse(await readFile(new URL('./fixtures/native-formula-observations.json',import.meta.url)));
const numeric=JSON.parse(await readFile(new URL('./fixtures/native-numeric-display.json',import.meta.url)));
assert.equal(fixture.cases.length,1832);assert.equal(fixture.nondeterministicCaseIds.length,5);
for(const row of fixture.cases)assert.match(row.sourceCaseSha256,/^[a-f\d]{64}$/);
const browser=await(engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']}));
const context=await browser.newContext({viewport:{width:1440,height:1000},timezoneId:'UTC'}),page=await context.newPage(),errors=[],results=[];page.on('pageerror',e=>errors.push(e.message));
try{
 await page.goto(url,{waitUntil:'domcontentloaded'});await page.getByText('Saved on this device',{exact:true}).waitFor();
 const rows=await page.evaluate(async fixture=>{
  const {evaluateTableCellDetails}=await import('/src/core/spreadsheet.ts'),dynamic=new Set(fixture.nondeterministicCaseIds),results=[];
  for(const source of fixture.cases){if(dynamic.has(source.caseId))continue;const data=fixture.fixture.map(row=>[...row]);data[fixture.target.row][fixture.target.column]=source.submitted;const actual=evaluateTableCellDetails(data,fixture.target.row,fixture.target.column);const matches=source.error===!!actual.error&&(source.error?(source.tooltips||[]).includes(actual.error?.message):source.text===String(actual.value));results.push({caseId:source.caseId,formula:source.formula,expected:source.error?source.tooltips:source.text,actual,matches});}
  return results;
 },fixture);
 await writeFile(new URL('static-cases.json',artifacts),JSON.stringify(rows,null,2));assert.equal(rows.length,1827);assert.deepEqual(rows.filter(r=>!r.matches),[]);results.push({name:'All1827 fixed native observations match exact scalar output or exact observed error diagnostic',status:'passed',cases:rows.length});
 const dynamic=await page.evaluate(async fixture=>{
  const {evaluateTableCellDetails}=await import('/src/core/spreadsheet.ts'),rows=[];
  for(const id of fixture.nondeterministicCaseIds){const source=fixture.cases.find(c=>c.caseId===id),samples=[];for(let i=0;i<24;i++){const data=fixture.fixture.map(r=>[...r]);data[4][0]=source.submitted;const before=Date.now(),actual=evaluateTableCellDetails(data,4,0),after=Date.now();samples.push({before,after,value:actual.value,error:actual.error});}rows.push({caseId:id,samples});}return rows;
 },fixture);
 const epoch=Date.UTC(1899,11,30);for(const row of dynamic){const values=[];for(const sample of row.samples){assert.equal(sample.error,undefined);const value=Number(String(sample.value).replace(/^v:/,''));assert.ok(Number.isFinite(value));values.push(value);if(row.caseId==='NOW:candidate'){assert.ok(value>=(sample.before-epoch-1000)/86400000&&value<=(sample.after-epoch+1000)/86400000);}else if(row.caseId==='TODAY:candidate'){assert.ok([Math.floor((sample.before-epoch)/86400000),Math.floor((sample.after-epoch)/86400000)].includes(value));}else if(row.caseId==='RAND:candidate'){assert.ok(value>=0&&value<1);}else{assert.ok(Number.isInteger(value));assert.ok(value>=(row.caseId.includes('blank-first')?0:1)&&value<=6);}}if(/RAND/.test(row.caseId))assert.ok(new Set(values).size>1);}
 await writeFile(new URL('dynamic-cases.json',artifacts),JSON.stringify(dynamic,null,2));results.push({name:'Five time/random cases respect the UTC evaluation interval, integer/range bounds and nonconstant output; historical random samples are not equality targets',status:'passed',cases:5,samplesPerCase:24});
 const numericRows=await page.evaluate(async fixture=>{const {evaluateTableCellDetails}=await import('/src/core/spreadsheet.ts');return fixture.cases.map(source=>{const data=fixture.fixture.map(row=>[...row]);data[4][0]=source.formula;const meta=source.requestedType==='Number'?{'4:0':{type:'number',thousandsSeparator:true}}:{};const actual=evaluateTableCellDetails(data,4,0,meta);return{...source,actual,matches:source.error===!!actual.error&&source.text===actual.display&&actual.value===Number(source.resultValue)};});},numeric);
 await writeFile(new URL('numeric-display-cases.json',artifacts),JSON.stringify(numericRows,null,2));assert.equal(numericRows.length,10);assert.deepEqual(numericRows.filter(r=>!r.matches),[]);results.push({name:'Ten explicitly measured Auto/Number displays match exactly without a numeric tolerance or a fixed ten-decimal cutoff',status:'passed',cases:10});
 assert.deepEqual(errors,[]);results.push({name:'No uncaught browser errors',status:'passed'});
}catch(e){results.push({name:'Native formula conformance',status:'failed',message:e.stack});process.exitCode=1;console.error(e);}finally{await writeFile(new URL('results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),engine,url,results,errors,referenceParityClaimed:false,limitation:'This proves the recorded scalar cases, not every input type, array persistence, worksheet cross-reference lifecycle, editor state or visual format.'},null,2));await browser.close();}
