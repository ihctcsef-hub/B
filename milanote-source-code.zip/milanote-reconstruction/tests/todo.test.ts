import { describe, expect, it } from "vitest";
import { indentTodoTask, isTodoDate, isTodoTime, isValidTodoMetadata, moveTodoTask, removeTodoTask } from "../src/core/todo";
const task = (id: string, indent = 0) => ({ id, text: id, done: false, indent });

describe("nested task editing", () => {
  it("indents a task together with its children and prevents skipped levels", () => {
    const source = [task("a"), task("b"), task("b-child", 1), task("c")];
    const nested = indentTodoTask(source, "b", 1);
    expect(nested.map(t => t.indent)).toEqual([0, 1, 2, 0]);
    expect(indentTodoTask(nested, "b", 1)).toBe(nested);
    expect(indentTodoTask(nested, "b", -1)).toEqual(source);
    expect(indentTodoTask(source, "a", 1)).toBe(source);
    expect(source.map(t => t.indent)).toEqual([0, 0, 1, 0]);
  });
  it("moves an entire subtree and repairs the hierarchy when moved to the start", () => {
    const source = [task("a"), task("a-child", 1), task("b"), task("b-child", 1), task("c")];
    expect(moveTodoTask(source, "a", "c").map(t => t.id)).toEqual(["b", "b-child", "a", "a-child", "c"]);
    const promoted = moveTodoTask(source, "b-child", "a");
    expect(promoted.map(t => [t.id, t.indent])).toEqual([["b-child", 0], ["a", 0], ["a-child", 1], ["b", 0], ["c", 0]]);
    expect(moveTodoTask(source, "a", "a-child")).toBe(source);
    expect(moveTodoTask(source, "a", null).map(t => t.id)).toEqual(["b", "b-child", "c", "a", "a-child"]);
  });
  it("deletes a single parent while promoting descendants and preserves a blank last row", () => {
    const source = [task("a"), task("b", 1), task("c", 2), task("d")];
    expect(removeTodoTask(source, "a").map(t => [t.id, t.indent])).toEqual([["b", 0], ["c", 1], ["d", 0]]);
    expect(removeTodoTask([{ ...task("last"), dueDate: "2026-10-25", reminderTime: "14:30", done: true }], "last")).toEqual([{ id: "last", text: "", done: false, indent: 0, dueDate: undefined, reminderTime: undefined }]);
  });
});

describe("task schedule metadata", () => {
  it("validates calendar dates and reminder times without timezone conversion", () => {
    expect(isTodoDate("2028-02-29")).toBe(true);
    expect(isTodoDate("2026-02-29")).toBe(false);
    expect(isTodoDate("2026-13-01")).toBe(false);
    expect(isTodoDate("tomorrow")).toBe(false);
    expect(isTodoTime("23:59")).toBe(true);
    expect(isTodoTime("24:00")).toBe(false);
    expect(isValidTodoMetadata({ indent: 2, dueDate: "2026-10-25", reminderTime: "09:30" })).toBe(true);
    expect(isValidTodoMetadata({ reminderTime: "09:30" })).toBe(false);
    expect(isValidTodoMetadata({ indent: 9 })).toBe(false);
    expect(isValidTodoMetadata({ indent: 1.5 })).toBe(false);
    expect(isValidTodoMetadata({})).toBe(true);
  });
});
