import assert from "node:assert/strict";
import { mkdir, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { chromium,webkit } from 'playwright-core';

// All fixtures are local. No account, reference browser, or external service is used.
const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const artifacts = path.join(root, "artifacts", engine==='webkit'?'webkit':'.');
await mkdir(artifacts, { recursive: true });
for (const name of await readdir(artifacts)) {
  if (/^editor-failure-\d+\.png$/.test(name)) await rm(path.join(artifacts, name));
}
const browser=await (engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({
  executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
}));
const context = await browser.newContext({ viewport: { width: 1440, height: 1100 }, acceptDownloads: true });
const page = await context.newPage();
page.setDefaultTimeout(8000);
const results = [], pageErrors = [];
page.on("pageerror", error => pageErrors.push(error.message));
const card = id => page.locator(`[data-card-id="${id}"]`);
const editor = () => page.getByRole("textbox", { name: "Note text", exact: true });
const note = (id, text = "Alpha bravo charlie delta.") => ({
  id, type: "note", text, html: `<p>${text}</p>`, x: 100, y: 100, width: 430, height: 150, z: 1, color: "#ffffff",
});
const fixture = cards => ({
  version: 1, id: "editor-workspace", title: "Editor workspace", rootBoardId: "editor-board", updatedAt: "2026-10-25T00:00:00.000Z",
  boards: { "editor-board": { id: "editor-board", title: "Editor test board", cards, connections: [], viewport: { x: 35, y: 40, zoom: 1 }, background: "#f5f3ef", grid: true } },
});
async function importFixture(value) {
  await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({
    name: "editor-fixture.json", mimeType: "application/json", buffer: Buffer.from(JSON.stringify(value)),
  });
  await page.waitForFunction(() => document.querySelector('input[type=file][accept="application/json,.json"]')?.value === "");
  await page.getByText("Workspace imported. Undo to return to your previous workspace.", { exact: true }).waitFor();
  await page.waitForFunction(title => document.querySelector('[aria-label="Current board title"]')?.value === title, value.boards[value.rootBoardId].title);
  const back = page.getByTitle("Back to tools", { exact: true });
  if (await back.isVisible()) await back.click();
}
async function run(name, fn) {
  try { await fn(); results.push({ name, status: "passed" }); console.log("PASS", name); }
  catch (error) {
    results.push({ name, status: "failed", message: error.stack }); process.exitCode = 1; console.error("FAIL", name, error.message);
    await page.screenshot({ path: path.join(artifacts, `editor-failure-${results.length}.png`), fullPage: true }).catch(() => {});
    await page.keyboard.press("Escape").catch(() => {});
  }
}
async function closeNote() {
  await page.getByLabel("Current board title").click();
  await editor().waitFor({ state: "detached" });
}
async function selectRange(start, length, expected) {
  await page.bringToFront();
  await editor().focus();
  // WebKit exposes a paragraph-boundary caret for Ctrl+Home. Select an actual DOM Range
  // for this engine so formatting tests exercise Selection without assuming OS key navigation.
  if(engine==='webkit'){
    await editor().evaluate((element,{start,length})=>{
      const walker=document.createTreeWalker(element,NodeFilter.SHOW_TEXT);let node,offset=0,first,last;
      while(node=walker.nextNode()){const size=node.textContent.length;if(!first&&start<=offset+size)first={node,offset:start-offset};if(start+length<=offset+size){last={node,offset:start+length-offset};break;}offset+=size;}
      if(!first||!last)throw Error('The requested text range is unavailable');
      const range=document.createRange();range.setStart(first.node,first.offset);range.setEnd(last.node,last.offset);const selection=getSelection();selection.removeAllRanges();selection.addRange(range);
    },{start,length});
    await page.waitForTimeout(40);assert.equal(await page.evaluate(()=>getSelection()?.toString()),expected);return;
  }
  const selectionTrace = [];
  const record = async key => selectionTrace.push(await editor().evaluate((element, key) => {
    const selection = document.getSelection();
    return { key, hasFocus: document.hasFocus(), active: document.activeElement?.outerHTML.slice(0, 180), anchor: selection?.anchorOffset, focus: selection?.focusOffset, selected: selection?.toString(), text: element.textContent };
  }, key));
  await page.keyboard.press("Control+Home");
  await record("Control+Home");
  for (let i = 0; i < start; i++) await page.keyboard.press("ArrowRight");
  await record("ArrowRight");
  for (let i = 0; i < length; i++) await page.keyboard.press("Shift+ArrowRight");
  await record("Shift+ArrowRight");
  assert.equal(await page.evaluate(() => window.getSelection()?.toString()), expected, `Native selection covers the intended text range: ${JSON.stringify(selectionTrace)}`);
}
async function download(name, filename) {
  const pending = page.waitForEvent("download");
  pending.catch(() => {});
  await page.getByRole("button", { name }).click();
  const item = await pending, destination = path.join(artifacts, filename);
  await item.saveAs(destination);
  return readFile(destination);
}
async function backup(filename = "editor-workspace.json") {
  await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();
  const data = JSON.parse(await download(/Workspace backup/, filename));
  await page.getByTitle("Close dialog", { exact: true }).click();
  return data;
}
async function bounds(loc) { const value = await loc.boundingBox(); assert(value); return value; }
async function dragOn(loc, points) {
  const box = await bounds(loc);
  await page.mouse.move(box.x + points[0][0] * box.width, box.y + points[0][1] * box.height);
  await page.mouse.down();
  for (const [x, y] of points.slice(1)) await page.mouse.move(box.x + x * box.width, box.y + y * box.height, { steps: 10 });
  await page.mouse.up();
}
const imageDialog = () => page.getByRole("dialog", { name: "Edit image", exact: true });
const imageCanvas = () => imageDialog().locator(".image-editor-canvas");
const imagePaths = () => imageCanvas().locator(":scope > g:first-child > path");
async function openImage(mode = "crop") {
  await page.locator(".card-image").click({ position: { x: 5, y: 5 } });
  await page.getByTitle(mode === "crop" ? "Crop and rotate image" : "Draw on image", { exact: true }).click();
  await imageCanvas().waitFor();
  await imageDialog().getByRole("button", { name: "Save changes", exact: true }).waitFor();
}

try {
  await page.goto(process.env.TEST_URL || "http://127.0.0.1:5176", { waitUntil: "domcontentloaded" });
  await page.getByText("Saved on this device", { exact: true }).waitFor();

  await run("Native selections apply bold, underline and links without Markdown markers; marks survive reload and both exports", async () => {
    await importFixture(fixture([note("range-note")]));
    await card("range-note").dblclick();
    await editor().waitFor();
    await selectRange(6, 5, "bravo");
    await page.getByTitle("Bold", { exact: true }).click();
    await editor().locator("strong").waitFor();
    assert.equal(await editor().locator("strong").innerText(), "bravo");
    await selectRange(12, 7, "charlie");
    await page.getByTitle("Underline", { exact: true }).click();
    assert.equal(await editor().locator("u").innerText(), "charlie");
    await selectRange(20, 5, "delta");
    await page.getByTitle("Text link", { exact: true }).click();
    await page.getByLabel("Text link URL", { exact: true }).fill("https://example.com/editor");
    await page.getByRole("button", { name: "Apply link", exact: true }).click();
    assert.equal(await editor().locator("a").innerText(), "delta");
    assert.equal(await editor().locator("a").getAttribute("href"), "https://example.com/editor");
    assert.equal((await editor().innerText()).trimEnd(), "Alpha bravo charlie delta.");
    assert(!/[\*_`]/.test((await editor().innerText()).trimEnd()), "Editing shows rendered text without mark syntax");
    await closeNote();
    await page.getByText("Saved on this device", { exact: true }).waitFor();
    await page.reload({ waitUntil: "domcontentloaded" });
    await page.getByText("Saved on this device", { exact: true }).waitFor();
    assert.equal(await card("range-note").locator("strong").innerText(), "bravo");
    assert.equal(await card("range-note").locator("u").innerText(), "charlie");
    assert.equal(await card("range-note").locator("a").innerText(), "delta");
    const data = await backup();
    const stored = data.boards["editor-board"].cards.find(c => c.id === "range-note");
    assert.equal(stored.text, "Alpha bravo charlie delta.");
    assert.match(stored.html, /<strong>bravo<\/strong>/);
    assert.match(stored.html, /<u>charlie<\/u>/);
    assert.match(stored.html, /href="https:\/\/example.com\/editor"/);
    await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();
    const html = (await download(/Board as HTML/, "editor-notes.html")).toString();
    await page.getByTitle("Close dialog", { exact: true }).click();
    const exported = await page.context().newPage();
    await exported.setContent(html);
    assert.equal(await exported.locator("strong").innerText(), "bravo");
    assert.equal(await exported.locator("u").innerText(), "charlie");
    assert.equal(await exported.locator("a").innerText(), "delta");
    await exported.close();
    await importFixture(data);
    assert.equal(await card("range-note").locator("strong").innerText(), "bravo");
    assert.equal(await card("range-note").locator("u").innerText(), "charlie");
    assert.equal(await card("range-note").locator("a").innerText(), "delta");
  });

  await run("Editor keyboard undo and redo restore a selected-range mark without moving or deleting the card", async () => {
    await importFixture(fixture([note("history-note")]));
    await card("history-note").dblclick();
    await selectRange(6, 5, "bravo");
    await page.keyboard.press("Control+b");
    assert.equal(await editor().locator("strong").innerText(), "bravo");
    await page.keyboard.press("Control+z");
    assert.equal(await editor().locator("strong").count(), 0);
    assert.equal(await card("history-note").count(), 1);
    await page.keyboard.press("Control+Shift+z");
    assert.equal(await editor().locator("strong").innerText(), "bravo");
    assert.equal((await editor().innerText()).trimEnd(), "Alpha bravo charlie delta.");
    await closeNote();
  });

  await run("Pasted HTML retains safe formatting while stripping executable tags, events, resource loads and unsafe links", async () => {
    await importFixture(fixture([note("paste-note", "Replace me")]));
    await card("paste-note").dblclick();
    await editor().focus();
    await page.keyboard.press("Control+a");
    await editor().evaluate(element => {
      const clipboardData = new DataTransfer();
      clipboardData.setData("text/html", '<p onclick="window.__unsafePaste=1">Safe <b>bold</b> <a href="javascript:window.__unsafePaste=2">bad link</a><img src="x" onerror="window.__unsafePaste=3"><script>window.__unsafePaste=4</script><iframe srcdoc="evil"></iframe></p>');
      clipboardData.setData("text/plain", "Safe bold bad link");
      element.dispatchEvent(new ClipboardEvent("paste", { bubbles: true, cancelable: true, clipboardData }));
    });
    await editor().locator("strong").waitFor();
    assert.equal(await editor().locator("strong").innerText(), "bold");
    assert.match((await editor().innerText()).trimEnd(), /Safe bold bad link/);
    assert.equal(await editor().locator("img,script,iframe,[onclick],[onerror],a").count(), 0);
    assert.equal(await page.evaluate(() => window.__unsafePaste), undefined);
    await closeNote();
    const data = await backup("editor-safe-paste.json");
    const stored = data.boards["editor-board"].cards.find(c => c.id === "paste-note");
    assert(!/javascript:|onclick|onerror|<script|<img|<iframe/.test(stored.html));
    assert.match(stored.html, /<strong>bold<\/strong>/);
  });

  await run("Text color, highlighting and small text apply to the native selection and persist in HTML and JSON", async () => {
    await importFixture(fixture([note("style-note")]));
    await card("style-note").dblclick();
    await selectRange(6, 5, "bravo");
    await page.getByLabel("Text color", { exact: true }).fill("#3f8bc9");
    await selectRange(6, 5, "bravo");
    await page.getByLabel("Highlight color", { exact: true }).fill("#f2bf35");
    await selectRange(6, 5, "bravo");
    await page.getByTitle("Text style", { exact: true }).click();await page.getByRole("menu",{name:"Text style",exact:true}).getByRole("menuitem",{name:"Small text"}).click();
    assert.equal(await editor().locator("mark").innerText(), "bravo");
    const styled = editor().locator('span[style*="font-size"]');
    assert.equal(await styled.innerText(), "bravo");
    assert.equal(await styled.evaluate(element => getComputedStyle(element).fontSize), "9.6px");
    assert.equal(await styled.evaluate(element => getComputedStyle(element).color), "rgb(63, 139, 201)");
    await closeNote();
    const data = await backup("editor-note-styles.json");
    const stored = data.boards["editor-board"].cards.find(c => c.id === "style-note");
    assert.match(stored.html, /color: #3f8bc9/);
    assert.match(stored.html, /background-color: #f2bf35/);
    assert.match(stored.html, /font-size: 9\.6px/);
    await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();
    const html = (await download(/Board as HTML/, "editor-note-styles.html")).toString();
    await page.getByTitle("Close dialog", { exact: true }).click();
    assert.match(html, /color: #3f8bc9/);
    assert.match(html, /background-color: #f2bf35/);
    assert.match(html, /font-size: 9\.6px/);
    await importFixture(data);
    assert.equal(await card("style-note").locator("mark").innerText(), "bravo");
  });

  await run("Uploaded image crop and rotation use local undo and redo, preserve the original, and survive backup and reload", async () => {
    await importFixture(fixture([]));
    await page.locator('input[type=file][accept="image/*"]').setInputFiles(path.join(root, "public/assets/studio-objects.jpg"));
    const uploaded = page.locator(".inbox-item").filter({ hasText: "studio-objects.jpg" });
    await uploaded.waitFor();
    await uploaded.getByTitle("Place on board", { exact: true }).click();
    await page.getByTitle("Close Unsorted", { exact: true }).click();
    const image = page.locator(".card-image");
    await image.waitFor();
    assert.equal(await image.locator("img").count(), 1);
    await openImage();
    const originalViewBox = await imageCanvas().getAttribute("viewBox");
    const crop = imageCanvas().locator('[data-crop-handle="move"]');
    const originalCropWidth = Number(await crop.getAttribute("width"));
    const handle = await bounds(imageCanvas().locator('[data-crop-handle="se"]'));
    const box = await bounds(imageCanvas());
    await page.mouse.move(handle.x + handle.width / 2, handle.y + handle.height / 2);
    await page.mouse.down();
    await page.mouse.move(handle.x + handle.width / 2 - box.width * 0.22, handle.y + handle.height / 2 - box.height * 0.18, { steps: 12 });
    await page.mouse.up();
    const croppedWidth = Number(await crop.getAttribute("width"));
    assert(croppedWidth < originalCropWidth * 0.85, "Dragging the crop handle reduces the visible source area");
    await imageDialog().getByRole("button", { name: "Rotate right", exact: true }).click();
    const rotatedViewBox = await imageCanvas().getAttribute("viewBox");
    assert.notEqual(rotatedViewBox, originalViewBox);
    await imageDialog().getByRole("button", { name: "Undo image edit", exact: true }).click();
    assert.equal(await imageCanvas().getAttribute("viewBox"), originalViewBox);
    assert.equal(Number(await crop.getAttribute("width")), croppedWidth, "Undo rotation retains the earlier crop");
    await page.keyboard.press("Control+Shift+z");
    assert.equal(await imageCanvas().getAttribute("viewBox"), rotatedViewBox);
    await imageDialog().getByRole("button", { name: "Flip horizontal", exact: true }).click();
    await imageDialog().getByRole("button", { name: "Flip vertical", exact: true }).click();
    assert.equal(await image.count(), 1, "Image editor history does not change workspace cards");
    await imageDialog().getByRole("button", { name: "Save changes", exact: true }).click();
    await image.locator(".edited-image-preview").waitFor();
    const data = await backup("editor-image-crop.json");
    const stored = data.boards["editor-board"].cards.find(c => c.type === "image");
    assert.equal(stored.imageEdits.rotation, 90);
    assert.equal(stored.imageEdits.flipX, true);
    assert.equal(stored.imageEdits.flipY, true);
    assert(stored.imageEdits.crop.width < 0.9 && stored.imageEdits.crop.height < 0.9);
    assert.deepEqual(Buffer.from(stored.src.split(",")[1], "base64"), await readFile(path.join(root, "public/assets/studio-objects.jpg")), "JSON retains the exact original JPEG bytes");
    await page.getByText("Saved on this device", { exact: true }).waitFor();
    await page.reload({ waitUntil: "domcontentloaded" });
    await page.getByText("Saved on this device", { exact: true }).waitFor();
    await image.locator(".edited-image-preview").waitFor();
    await importFixture(data);
    await image.locator(".edited-image-preview").waitFor();
    const roundtrip = await backup("editor-image-roundtrip.json");
    assert.deepEqual(roundtrip.boards["editor-board"].cards.find(c => c.type === "image").imageEdits, stored.imageEdits);
    await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();
    const html = (await download(/Board as HTML/, "editor-image-crop.html")).toString();
    await page.getByTitle("Close dialog", { exact: true }).click();
    const exported = await context.newPage();
    await exported.setContent(html);
    const baked = exported.locator("img");
    await baked.evaluate(image => image.decode());
    const dimensions = await baked.evaluate(image => ({ width: image.naturalWidth, height: image.naturalHeight }));
    const originalSize = await page.evaluate(async src => { const image = new Image(); image.src = src; await image.decode(); return { width: image.naturalWidth, height: image.naturalHeight }; }, stored.src);
    assert.equal(dimensions.width, Math.round(originalSize.height * stored.imageEdits.crop.width));
    assert.equal(dimensions.height, Math.round(originalSize.width * stored.imageEdits.crop.height));
    assert.match(await baked.getAttribute("src"), /^data:image\/png;base64,/);
    await exported.close();
  });

  await run("Image pen, eraser, keyboard history, cancel and portable HTML preserve the correct pixels and editable source", async () => {
    await importFixture(fixture([{ id: "ink-image", type: "image", src: "/assets/studio-objects.jpg", caption: "Editable studio image", x: 650, y: 100, width: 500, height: 400, z: 1 }]));
    await openImage("markup");
    await dragOn(imageCanvas(), [[0.24, 0.32], [0.4, 0.36], [0.65, 0.32]]);
    assert.equal(await imagePaths().count(), 1);
    await imageDialog().getByRole("button", { name: "Eraser", exact: true }).click();
    await dragOn(imageCanvas(), [[0.4, 0.36], [0.42, 0.36]]);
    assert.equal(await imagePaths().count(), 0, "Eraser removes the intersecting annotation");
    await page.keyboard.press("Control+z");
    assert.equal(await imagePaths().count(), 1, "Undo restores the erased stroke");
    await page.keyboard.press("Control+Shift+z");
    assert.equal(await imagePaths().count(), 0);
    await page.keyboard.press("Control+z");
    await imageDialog().getByRole("button", { name: "Crop & rotate", exact: true }).click();
    await imageDialog().getByRole("button", { name: "Rotate right", exact: true }).click();
    await imageDialog().getByRole("button", { name: "Save changes", exact: true }).click();
    const preview = card("ink-image").locator(".edited-image-preview");
    await preview.waitFor();
    assert.equal(await preview.locator("path").count(), 1);
    const before = await backup("editor-image-ink.json");
    const stored = before.boards["editor-board"].cards.find(c => c.id === "ink-image");
    assert.equal(stored.imageEdits.paths.length, 1);
    assert.equal(stored.imageEdits.rotation, 90);
    assert.match(stored.src, /^data:image\/jpeg;base64,/);
    await openImage();
    await imageDialog().getByRole("button", { name: "Rotate right", exact: true }).click();
    await imageDialog().getByRole("button", { name: "Draw on image", exact: true }).click();
    await dragOn(imageCanvas(), [[0.65, 0.6], [0.75, 0.7]]);
    assert.equal(await imagePaths().count(), 2);
    await imageDialog().getByRole("button", { name: "Cancel", exact: true }).click();
    const after = await backup("editor-image-cancel.json");
    assert.deepEqual(after.boards["editor-board"].cards.find(c => c.id === "ink-image"), stored, "Cancel discards every unsaved image edit");
    await page.locator(".card-image").click({ position: { x: 5, y: 5 } });
    const originalPending = page.waitForEvent("download");
    await page.getByTitle("Download original image", { exact: true }).click();
    const originalDownload = await originalPending;
    await originalDownload.saveAs(path.join(artifacts, "editor-original.jpg"));
    const original = await readFile(path.join(artifacts, "editor-original.jpg"));
    assert.deepEqual(original, await readFile(path.join(root, "public/assets/studio-objects.jpg")));
    await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();
    const html = (await download(/Board as HTML/, "editor-image.html")).toString();
    await page.getByTitle("Close dialog", { exact: true }).click();
    const exported = await page.context().newPage();
    await exported.setContent(html);
    const bakedImage = exported.locator("img");
    await bakedImage.evaluate(image => image.decode());
    const middlePoint = stored.imageEdits.paths[0].points[Math.floor(stored.imageEdits.paths[0].points.length / 2)];
    const pixels = await bakedImage.evaluate((image, point) => {
      const canvas = document.createElement("canvas"); canvas.width = image.naturalWidth; canvas.height = image.naturalHeight;
      const ctx = canvas.getContext("2d"); ctx.drawImage(image, 0, 0);
      // A clockwise rotation maps an original normalized (x,y) to (1-y,x).
      const sample = [...ctx.getImageData(Math.floor((1 - point.y) * canvas.width), Math.floor(point.x * canvas.height), 1, 1).data];
      return { width: image.naturalWidth, height: image.naturalHeight, sample };
    }, middlePoint);
    const originalSize = await page.evaluate(async src => { const image = new Image(); image.src = src; await image.decode(); return { width: image.naturalWidth, height: image.naturalHeight }; }, stored.src);
    assert.equal(pixels.width, originalSize.height);
    assert.equal(pixels.height, originalSize.width);
    assert(pixels.sample[0] > 180 && pixels.sample[1] < 110 && pixels.sample[2] < 90, "Portable PNG includes the red pen annotation at its rotated source coordinate");
    assert.match(await bakedImage.getAttribute("src"), /^data:image\/png;base64,/);
    assert.notEqual(await bakedImage.getAttribute("src"), stored.src);
    await exported.close();
    await page.getByText("Saved on this device", { exact: true }).waitFor();
    await page.reload({ waitUntil: "domcontentloaded" });
    await page.getByText("Saved on this device", { exact: true }).waitFor();
    await card("ink-image").locator(".edited-image-preview path").waitFor();
    await importFixture(before);
    await card("ink-image").locator(".edited-image-preview path").waitFor();
    await openImage("markup");
    assert.equal(await imagePaths().count(), 1, "Reimported image keeps editable vector annotations");
    await imageDialog().getByRole("button", { name: "Cancel", exact: true }).click();
  });

  await run("No uncaught browser errors", async () => assert.deepEqual(pageErrors, []));
  await importFixture(fixture([
    { ...note("preview-note", "Select a thought. Make it yours."), html: '<h1>A space for ideas</h1><p>Select a <strong>thought</strong>. Make it <u>yours</u>.</p><p><a href="https://example.com/">Connected and editable.</a></p>', height: 250 },
    { id: "preview-image", type: "image", src: "/assets/studio-objects.jpg", caption: "Your original, with room to create", x: 650, y: 100, width: 500, height: 430, z: 1, imageEdits: { rotation: 0, crop: { x: 0.08, y: 0.1, width: 0.84, height: 0.8 }, paths: [{ color: "#ed4b35", width: 0.012, points: [{ x: 0.2, y: 0.35 }, { x: 0.45, y: 0.29 }, { x: 0.7, y: 0.35 }] }] } },
  ]));
  await page.locator(".toast").waitFor({ state: "hidden" });
  await page.locator(".edited-image-preview").waitFor();
  await page.screenshot({ path: path.join(artifacts, "editor-preview.png"), fullPage: true });
} catch (error) {
  results.push({ name: "Harness failure", status: "failed", message: error.stack }); process.exitCode = 1; console.error(error);
} finally {
  await writeFile(path.join(artifacts, "editor-e2e-results.json"), JSON.stringify({ results, pageErrors }, null, 2));
  await browser.close();
}
