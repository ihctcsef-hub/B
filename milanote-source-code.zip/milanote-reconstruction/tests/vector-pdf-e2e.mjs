import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
import {chromium,webkit} from 'playwright-core';
import {PDFDocument,PDFDict,PDFHexString,PDFName,PDFArray,PDFRawStream,decodePDFRawStream} from 'pdf-lib';
import {installPdfRenderer} from './pdf-render-helpers.mjs';

const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium',url=process.env.TEST_URL||'http://127.0.0.1:5304';
const artifacts=new URL(`../artifacts/vector-pdf-${engine}/`,import.meta.url);await mkdir(artifacts,{recursive:true});
const browser=await(engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']}));
const page=await browser.newPage({viewport:{width:1440,height:1000}});page.setDefaultTimeout(30000);
const results=[],errors=[];page.on('pageerror',error=>errors.push(error.message));
async function check(name,run){try{await run();results.push({name,status:'passed'});console.log('PASS',name);}catch(error){results.push({name,status:'failed',message:error.stack});process.exitCode=1;console.error('FAIL',name,error.message);}}
async function save(name,bytes){await writeFile(new URL(name,artifacts),Buffer.from(bytes));}
async function image(name,data){await save(name,Buffer.from(data.split(',')[1],'base64'));}
function inspect(pdf){
 const page=pdf.getPage(0),resources=page.node.Resources(),properties=resources.lookupMaybe(PDFName.of('Properties'),PDFDict);
 const actualText=properties?.entries().map(([,ref])=>pdf.context.lookup(ref,PDFDict).lookup(PDFName.of('ActualText'),PDFHexString).decodeText())||[];
 const contents=page.node.Contents(),streams=contents instanceof PDFArray?contents.asArray():contents?[contents]:[];
 const operators=streams.map(ref=>{const stream=pdf.context.lookup(ref);return stream instanceof PDFRawStream?new TextDecoder().decode(decodePDFRawStream(stream).decode()):'';}).join('\n');
 return {actualText,operators,fonts:resources.lookupMaybe(PDFName.of('Font'),PDFDict)?.entries().length||0,annotations:page.node.Annots()?.size()||0};
}
try{
 await page.goto(url,{waitUntil:'networkidle'});await installPdfRenderer(page);
 await page.evaluate(async()=>{
  const formats=await import('/src/core/exportFormats.ts');
  const note=(html,extra={})=>({id:'note',type:'note',x:0,y:0,width:400,height:180,z:1,text:'',html,...extra});
  const board=cards=>({id:'vector',title:'Vector test',cards,connections:[],viewport:{x:400,y:-300,zoom:.4}});
  window.vectorTest={formats,note,board,bytes:async blob=>[...new Uint8Array(await blob.arrayBuffer())]};
 });
 await check('Visible Latin rich text is genuinely vector, retains all alphabet glyphs, styles and a clickable source link',async()=>{
  const result=await page.evaluate(async()=>{
   const e=window.vectorTest,board=e.board([e.note('<p>Alphabet ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz 0123456789.</p><p><strong>Bold</strong> <em>Italic</em> <u>Underline</u> <s>Strike</s> <a href="https://example.com/pdf-source">Source</a></p>')]);
   const vector=await e.bytes(await e.formats.exportBoardPdf(board)),raster=await e.bytes(await e.formats.exportBoardPdf(board,{vectorText:false}));
   return {vector,raster,vectorPage:(await window.inspectRenderedPdf(vector,{scale:2}))[0],rasterPage:(await window.inspectRenderedPdf(raster,{scale:2}))[0]};
  });
  await save('rich-vector.pdf',result.vector);await save('rich-raster-control.pdf',result.raster);await image('rich-vector.png',result.vectorPage.image);await image('rich-raster-control.png',result.rasterPage.image);
  const pdf=await PDFDocument.load(new Uint8Array(result.vector)),content=inspect(pdf);
  assert.ok(content.fonts>=3);assert.ok(content.annotations>=1);assert.match(content.operators,/\bBT\b/);assert.match(content.operators,/\bTj\b/);assert.doesNotMatch(content.operators,/\b3 Tr\b/);
  const logical=content.actualText.join('');assert.match(logical,/ABCDEFGHIJKLMNOPQRSTUVWXYZ/);assert.match(logical,/abcdefghijklmnopqrstuvwxyz/);assert.match(logical,/0123456789/);
  assert.match(result.vectorPage.text.replace(/\s+/g,''),/AlphabetABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789\./);
  assert.equal(result.vectorPage.width,result.rasterPage.width);assert.equal(result.vectorPage.height,result.rasterPage.height);
  assert.ok(result.vectorPage.ink>result.rasterPage.ink*.8,`Vector glyph coverage ${result.vectorPage.ink} must retain the raster control's visible alphabet ${result.rasterPage.ink}`);
  assert.ok(result.vectorPage.ink<result.rasterPage.ink*1.55,'Vector text must not be doubled over its raster glyphs');
 });
 await check('Pure Arabic uses visible joined glyphs and preserves exact logical Unicode on those same marked text runs',async()=>{
  const result=await page.evaluate(async()=>{
   const e=window.vectorTest,board=e.board([e.note('<p dir="rtl">مرحبا بالعالم</p><p dir="rtl">لغة عربية جميلة</p>')]);
   const bytes=await e.bytes(await e.formats.exportBoardPdf(board));return {bytes,page:(await window.inspectRenderedPdf(bytes,{scale:3}))[0]};
  });
  await save('arabic-vector.pdf',result.bytes);await image('arabic-vector.png',result.page.image);
  const content=inspect(await PDFDocument.load(new Uint8Array(result.bytes)));
  assert.deepEqual(content.actualText,['مرحبا بالعالم','لغة عربية جميلة']);assert.ok(content.fonts>=1);assert.ok(result.page.ink>500);assert.match(content.operators,/\bTj\b/);assert.doesNotMatch(content.operators,/\b3 Tr\b/);
 });
 await check('Overlapping cards retain their existing raster stacking rather than exposing lower-card text above the cover',async()=>{
  const result=await page.evaluate(async()=>{
   const e=window.vectorTest,board=e.board([e.note('<p>Lower text must remain covered</p>'),e.note('<p>Only this upper card is visible</p>',{id:'upper',z:2})]);
   const vector=await e.bytes(await e.formats.exportBoardPdf(board)),raster=await e.bytes(await e.formats.exportBoardPdf(board,{vectorText:false}));
   return {vector,one:(await window.inspectRenderedPdf(vector,{scale:2}))[0],two:(await window.inspectRenderedPdf(raster,{scale:2}))[0]};
  });
  await save('overlap-fallback.pdf',result.vector);await image('overlap-fallback.png',result.one.image);
  assert.deepEqual(inspect(await PDFDocument.load(new Uint8Array(result.vector))).actualText,[]);assert.equal(result.one.image,result.two.image);
 });
 await check('Mixed bidi, unsupported glyphs and code keep their visible raster rendering without partial text removal',async()=>{
  const result=await page.evaluate(async()=>{
   const e=window.vectorTest,board=e.board([e.note('<p>English مرحبا123</p><pre><code>const x = 1;</code></pre><p>🙂 漢字</p>')]);
   const vector=await e.bytes(await e.formats.exportBoardPdf(board)),raster=await e.bytes(await e.formats.exportBoardPdf(board,{vectorText:false}));
   return {vector,one:(await window.inspectRenderedPdf(vector,{scale:2}))[0],two:(await window.inspectRenderedPdf(raster,{scale:2}))[0]};
  });
  await save('unsupported-fallback.pdf',result.vector);await image('unsupported-fallback.png',result.one.image);
  assert.deepEqual(inspect(await PDFDocument.load(new Uint8Array(result.vector))).actualText,[]);assert.equal(result.one.image,result.two.image);
 });
 await check('Rendered editor capture keeps its source DOM, removes temporary surfaces and preserves its highlighted rich text as visible PDF objects',async()=>{
  const result=await page.evaluate(async()=>{
   const e=window.vectorTest,board=e.board([e.note('<p>Source capture</p>')]),source=document.createElement('div');source.className='world';
   source.innerHTML='<div class="card card-note" data-card-id="owned-source" style="position:absolute;left:0;top:0;width:400px;height:180px;background:white"><div class="note-text"><p>Native <strong>bold</strong> <mark style="background:#ffcc00">highlight</mark></p></div></div>';
   document.body.append(source);const before=source.innerHTML;
   try{const bytes=await e.bytes(await e.formats.exportBoardPdf(board,{sourceElement:source}));return {bytes,unchanged:source.innerHTML===before,captures:document.querySelectorAll('.export-capture').length,page:(await window.inspectRenderedPdf(bytes,{scale:2}))[0]};}
   finally{source.remove();}
  });
  await save('source-dom.pdf',result.bytes);await image('source-dom.png',result.page.image);
  assert.equal(result.unchanged,true);assert.equal(result.captures,0);assert.match(inspect(await PDFDocument.load(new Uint8Array(result.bytes))).actualText.join(''),/Native bold highlight/);assert.ok(result.page.ink>500);
 });
 await check('Measured note spacing stays selectable and visible in source PDF capture at negative and positive tracking',async()=>{
  const outputs=await page.evaluate(async()=>{
   const e=window.vectorTest,outputs=[];
   for(const spacing of [-.08,1.5]){
    const source=document.createElement('div');source.className='world reference-layout';
    source.innerHTML=`<div class="card card-note" style="position:absolute;left:0;top:0;width:400px;height:180px;background:white"><div class="note-text"><p style="letter-spacing:${spacing}px">Visual comparison</p><p style="letter-spacing:${spacing}px">A quiet place to collect ideas.</p><p style="letter-spacing:${spacing}px">office affinity AVATAR</p></div></div>`;
    document.body.append(source);await document.fonts.ready;const before=source.innerHTML;
    try{const board=e.board([e.note('<p>Spacing capture</p>')]),vector=await e.bytes(await e.formats.exportBoardPdf(board,{sourceElement:source})),raster=await e.bytes(await e.formats.exportBoardPdf(board,{sourceElement:source,vectorText:false}));outputs.push({spacing,vector,unchanged:source.innerHTML===before,captures:document.querySelectorAll('.export-capture').length,one:(await window.inspectRenderedPdf(vector,{scale:3}))[0],two:(await window.inspectRenderedPdf(raster,{scale:3}))[0]});}
    finally{source.remove();}
   }return outputs;
  });
  for(const r of outputs){await save(`tracking-${r.spacing}.pdf`,r.vector);await image(`tracking-${r.spacing}.png`,r.one.image);const content=inspect(await PDFDocument.load(new Uint8Array(r.vector)));assert.deepEqual(content.actualText,['Visual comparison','A quiet place to collect ideas.','office affinity AVATAR']);assert.equal(r.unchanged,true);assert.equal(r.captures,0);assert.match(r.one.text.replace(/\s+/g,''),/VisualcomparisonAquietplacetocollectideas\.officeaffinityAVATAR/);assert.doesNotMatch(content.operators,/\b3 Tr\b/);assert.ok(r.one.ink>r.two.ink*.8);assert.ok(r.one.ink<r.two.ink*1.55);}
 });
 await check('Source capture preserves explicit text-fill overrides and outlined text through pixel-identical raster fallback',async()=>{
  const cases=await page.evaluate(async()=>{
   const e=window.vectorTest,board=e.board([e.note('<p>Styled source capture</p>')]),outputs=[];
   for(const [name,style] of [['explicit-fill','color:#0000ff;-webkit-text-fill-color:#00aa00'],['outlined','color:#0000ff;-webkit-text-stroke:1px #ff0000']]){
    const source=document.createElement('div');source.className='world';
    source.innerHTML=`<div class="card card-note" style="position:absolute;left:0;top:0;width:400px;height:180px;background:white"><div class="note-text"><p style="${style};font-size:28px"><span>Preserve styled ink</span></p></div></div>`;
    document.body.append(source);const before=source.innerHTML;
    try{const vector=await e.bytes(await e.formats.exportBoardPdf(board,{sourceElement:source})),raster=await e.bytes(await e.formats.exportBoardPdf(board,{sourceElement:source,vectorText:false}));outputs.push({name,vector,unchanged:source.innerHTML===before,captures:document.querySelectorAll('.export-capture').length,one:(await window.inspectRenderedPdf(vector,{scale:2}))[0],two:(await window.inspectRenderedPdf(raster,{scale:2}))[0]});}
    finally{source.remove();}
   }
   return outputs;
  });
  for(const result of cases){
   await save(`${result.name}-fallback.pdf`,result.vector);await image(`${result.name}-fallback.png`,result.one.image);
   assert.equal(result.unchanged,true);assert.equal(result.captures,0);assert.deepEqual(inspect(await PDFDocument.load(new Uint8Array(result.vector))).actualText,[]);
   assert.ok(result.one.ink>500);assert.equal(result.one.image,result.two.image,`${result.name} must keep the original visible glyph ink`);
  }
 });
 assert.deepEqual(errors,[]);results.push({name:'No uncaught browser errors',status:'passed'});
}finally{await writeFile(new URL('results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),engine,url,pdfJsActualRendering:true,invisibleOcrLayerUsed:false,hybridTextVectorMode:true,completeVectorParityClaimed:false,results,errors},null,2));await browser.close();}
