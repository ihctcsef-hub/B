import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
import {chromium,webkit} from 'playwright-core';
const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium',url=process.env.TEST_URL||'http://127.0.0.1:5306';
const out=new URL(`../artifacts/note-blocks-${engine}/`,import.meta.url);await mkdir(out,{recursive:true});
const browser=await(engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']}));
const context=await browser.newContext({viewport:{width:1440,height:1000}}),page=await context.newPage(),results=[],errors=[];page.setDefaultTimeout(10000);page.on('pageerror',e=>errors.push(e.stack||e.message));
const icons=['⏰','❤️','⚠️','🎥','❌','✅'];
const html=`<p style="text-align: center"><span style="font-size: 9.6px; color: #4ebafd">Small blue text</span> <mark style="background-color: #c9f201">Highlight</mark></p><hr>${icons.map((icon,index)=>`<aside data-note-callout="true" data-note-callout-icon="${icon}"><p>Callout ${index+1}</p></aside>`).join('')}`;
const editor=()=>page.getByRole('textbox',{name:'Note blocks text',exact:true});
async function run(name,fn){try{await fn();results.push({name,status:'passed'});console.log('PASS',name);}catch(error){process.exitCode=1;results.push({name,status:'failed',message:error.stack});await page.screenshot({path:new URL(`failure-${results.length}.png`,out).pathname}).catch(()=>{});throw error;}}
try{
 await page.goto(url,{waitUntil:'domcontentloaded'});await page.getByText('Saved on this device',{exact:true}).waitFor();
 await page.evaluate(async()=>{const module=await import('/tests/fixtures/note-blocks-harness.tsx');window.noteBlocks=module.createNoteBlocksHarness();});
 await page.evaluate(html=>window.noteBlocks.render(html),html);await editor().locator('aside').last().waitFor();
 await run('The actual editor preserves all6 observed callout icons, a horizontal rule, measured text colors, highlight, small text and center alignment',async()=>{
   assert.deepEqual(await editor().locator('aside').evaluateAll(nodes=>nodes.map(node=>node.getAttribute('data-note-callout-icon'))),icons);
   assert.equal(await editor().locator('hr').count(),1);assert.equal(await editor().locator('p').first().evaluate(node=>getComputedStyle(node).textAlign),'center');
   const styles=await editor().locator('span').first().evaluate(node=>({fontSize:getComputedStyle(node).fontSize,color:getComputedStyle(node).color}));assert.deepEqual(styles,{fontSize:'9.6px',color:'rgb(78, 186, 253)'});
   assert.equal(await editor().locator('mark').evaluate(node=>getComputedStyle(node).backgroundColor),'rgb(201, 242, 1)');
   const saved=await page.evaluate(()=>window.noteBlocks.getHTML());for(const icon of icons)assert.ok(saved.includes(`data-note-callout-icon="${icon}"`));assert.ok(saved.includes('<hr>'));assert.match(saved,/font-size: 9\.6px/);
 });
 await run('Native text editing and one editor Undo retain the surrounding callout icon and horizontal rule',async()=>{
   const paragraph=editor().locator('aside').nth(1).locator('p');await paragraph.click();await page.keyboard.press('End');await page.keyboard.type(' edited');await paragraph.filter({hasText:'Callout 2 edited'}).waitFor();
   let saved=await page.evaluate(()=>window.noteBlocks.getHTML());assert.ok(saved.includes('data-note-callout-icon="❤️"'));assert.ok(saved.includes('<hr>'));
   await page.keyboard.press('Control+z');await page.waitForFunction(()=>document.querySelectorAll('[aria-label="Note blocks text"] aside p')[1]?.textContent==='Callout 2');saved=await page.evaluate(()=>window.noteBlocks.getHTML());assert.ok(saved.includes('data-note-callout-icon="❤️"'));assert.ok(saved.includes('<hr>'));
 });
 await run('Measured block geometry and the original public emoji assets apply in both white and colored cards',async()=>{
   const geometry=await editor().locator('aside').first().evaluate(node=>{const style=getComputedStyle(node),icon=getComputedStyle(node,'::before');return {height:node.getBoundingClientRect().height,padding:style.padding,margin:style.margin,border:style.borderWidth,radius:style.borderRadius,background:style.backgroundColor,icon:{width:icon.width,height:icon.height,left:icon.left,top:icon.top,image:icon.backgroundImage}};});
   assert.equal(geometry.height,32);assert.equal(geometry.padding,'8px 8px 0px 30.3844px');assert.equal(geometry.border,'0px');assert.equal(geometry.radius,'3.2px');for(const side of ['width','height'])assert.ok(Math.abs(parseFloat(geometry.icon[side])-14.390625)<.00005,`Measured emoji ${side}: ${geometry.icon[side]}`);assert.deepEqual([geometry.icon.left,geometry.icon.top],['8.8px','8.8px']);assert.match(geometry.icon.image,/\/assets\/callout\/23f0\.png/);
   const hr=await editor().locator('hr').evaluate(node=>{const s=getComputedStyle(node);return {height:node.getBoundingClientRect().height,padding:s.padding,border:s.borderBottomWidth,margin:s.margin};});assert.deepEqual(hr,{height:9,padding:'8px 0px 0px',border:'1px',margin:'0px 3.2px 15px 0px'});
   await page.evaluate(html=>window.noteBlocks.render(html,{background:'#b2d6e6'}),html);await page.waitForFunction(()=>{const background=getComputedStyle(document.querySelector('[aria-label="Note blocks text"] aside')).backgroundColor,canvas=document.createElement('canvas'),context=canvas.getContext('2d');canvas.width=canvas.height=1;context.fillStyle=background;context.fillRect(0,0,1,1);const pixel=context.getImageData(0,0,1,1).data;return pixel[0]===164&&pixel[1]===197&&pixel[2]===212;});
   await writeFile(new URL('geometry.json',out),JSON.stringify({white:geometry,hr,colored:await editor().locator('aside').first().evaluate(node=>getComputedStyle(node).backgroundColor)},null,2));
 });
 await run('Readonly mode rejects edits and commands without dropping icons or rules, and Markdown retains the separator',async()=>{
   const before=await page.evaluate(()=>window.noteBlocks.getHTML());await page.evaluate(html=>window.noteBlocks.render(html,{readOnly:true}),before);await page.waitForFunction(()=>document.querySelector('[aria-label="Note blocks text"]')?.getAttribute('contenteditable')==='false');
   assert.equal(await page.evaluate(()=>window.noteBlocks.run('calloutIcon','✅')),false);assert.equal(await page.evaluate(()=>window.noteBlocks.run('horizontalRule')),false);assert.equal(await page.evaluate(()=>window.noteBlocks.getHTML()),before);assert.ok((await page.evaluate(()=>window.noteBlocks.getMarkdown())).includes('\n---\n'));
 });
 assert.deepEqual(errors,[]);await page.screenshot({path:new URL('preview.png',out).pathname});
}finally{await writeFile(new URL('results.json',out),JSON.stringify({checkedAt:new Date().toISOString(),engine,url,results,errors,referenceEvidence:'/workspace/milanote-analysis/template-catalog-oct28/callout-hr-reference.json and callout-hr-css-reference.json',limitation:'Real editor behavioral and measured block checks. This is not a full template screenshot or all emoji pixel comparison.'},null,2));await browser.close();}
