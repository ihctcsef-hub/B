import { describe, expect, it } from "vitest";
import { displayColor, hexToRgb, hslToRgb, parseColor, rgbToHex, rgbToHsl, swatchInk } from "../src/core/colors";

describe("opaque swatch colors", () => {
  it("normalizes editable HEX, RGB and HSL values while rejecting arbitrary CSS", () => {
    expect(parseColor("abc")).toBe("#aabbcc");
    expect(parseColor("#FF3300")).toBe("#ff3300");
    expect(parseColor("rgb(255, 51, 0)")).toBe("#ff3300");
    expect(parseColor("hsl(12, 100%, 50%)")).toBe("#ff3300");
    for (const invalid of ["red", "#12345678", "#12", "rgb(256, 0, 0)", "rgba(1,2,3,.2)", "hsl(0, 101%, 20%)", "var(--color)", "url(x)", "hsl(1e999,0%,0%)"]) expect(parseColor(invalid)).toBeNull();
  });
  it("round trips primary and arbitrary colors without accumulating conversion drift", () => {
    for (const value of ["#000000", "#ffffff", "#ff0000", "#00ff00", "#0000ff", "#b7c3a5", "#123456", "#fff3bc"]) {
      const rgb = hexToRgb(value)!;
      expect(rgbToHex(hslToRgb(rgbToHsl(rgb)))).toBe(value);
    }
    expect(hslToRgb({ h: -120, s: 100, l: 50 })).toEqual({ r: 0, g: 0, b: 255 });
  });
  it("formats display without changing stored hex and keeps value text legible", () => {
    expect(displayColor("#ff0000", "rgb")).toBe("rgb(255, 0, 0)");
    expect(displayColor("#ff0000", "hsl")).toBe("hsl(0, 100%, 50%)");
    expect(displayColor("#abc", "hex")).toBe("#AABBCC");
    expect(swatchInk("#000000")).toBe("#ffffff");
    expect(swatchInk("#ffffff")).toBe("#323b4a");
  });
});
