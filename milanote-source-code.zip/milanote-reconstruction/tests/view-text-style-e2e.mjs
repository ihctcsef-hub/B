import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {chromium} from 'playwright-core';

const base=process.env.TEST_URL||'http://127.0.0.1:5279',artifacts=new URL('../artifacts/',import.meta.url),results=[],pageErrors=[];
await mkdir(artifacts,{recursive:true});
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
const page=await browser.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});page.setDefaultTimeout(10000);page.on('pageerror',error=>pageErrors.push(error.message));
const card=()=>page.locator('[data-card-id="a"]'),editor=()=>page.getByRole('textbox',{name:'Note text',exact:true}),styleMenu=()=>page.getByRole('menu',{name:'Text style',exact:true}),viewMenu=()=>page.getByRole('menu',{name:'Board view',exact:true});
const fixture=(html='<p>Alpha bravo charlie.</p><p>Second paragraph.</p>')=>({version:1,id:'view-text-style',title:'View and text styles',rootBoardId:'root',updatedAt:'2026-10-25T00:00:00Z',boards:{root:{id:'root',title:'View and text styles',cards:[{id:'a',type:'note',text:'Alpha bravo charlie.\nSecond paragraph.',html,x:120,y:130,width:430,height:130,z:1}],connections:[],viewport:{x:20,y:20,zoom:1}}}});
async function load(data=fixture()){
  await page.keyboard.press('Escape');await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'view-text-style.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(data))});await page.getByText('Workspace imported. Undo to return to your previous workspace.',{exact:true}).waitFor();await page.getByText('Saved on this device',{exact:true}).waitFor();
}
async function edit(){await card().dblclick({position:{x:45,y:22}});await editor().waitFor();}
async function selectAlpha(){await editor().focus();await page.keyboard.press('Control+Home');for(let i=0;i<5;i++)await page.keyboard.press('Shift+ArrowRight');assert.equal(await page.evaluate(()=>getSelection()?.toString()),'Alpha');}
async function openStyle(){await page.getByTitle('Text style',{exact:true}).click();await styleMenu().waitFor();}
async function closeNote(){await page.getByLabel('Current board title',{exact:true}).click();await editor().waitFor({state:'detached'});}
async function backup(name){await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();const pending=page.waitForEvent('download');pending.catch(()=>{});await page.getByRole('button',{name:/Workspace backup/}).click();const download=await pending,destination=new URL(name,artifacts);await download.saveAs(destination.pathname);await page.getByTitle('Close dialog',{exact:true}).click();return JSON.parse(await readFile(destination,'utf8'));}
async function check(name,callback){try{await callback();results.push({name,status:'passed'});console.log('PASS',name);}catch(error){results.push({name,status:'failed',error:error.stack});process.exitCode=1;console.error('FAIL',name,error.message);await page.screenshot({path:new URL(`view-text-style-failure-${results.length}.png`,artifacts).pathname}).catch(()=>{});await page.keyboard.press('Escape').catch(()=>{});}}
async function metrics(locator){return locator.evaluate(element=>{const s=getComputedStyle(element);return{fontSize:s.fontSize,lineHeight:s.lineHeight,fontWeight:s.fontWeight,marginTop:s.marginTop,marginBottom:s.marginBottom};});}
try{
  await page.goto(base);await page.getByText('Saved on this device',{exact:true}).waitFor();
  await check('Board View zoom, reset, fit, and Present are wired and zoom actions retain the menu',async()=>{
    await load();await page.getByTitle('View',{exact:true}).click();await viewMenu().waitFor();const rect=await viewMenu().boundingBox();assert.ok(rect);assert.ok(Math.abs(rect.width-232)<.1);await viewMenu().getByRole('button',{name:'Zoom in',exact:true}).click();assert.equal(await viewMenu().getByTitle('Reset zoom to 100%',{exact:true}).textContent(),'120%');
    await viewMenu().getByRole('button',{name:'Zoom out',exact:true}).click();assert.equal(await viewMenu().getByTitle('Reset zoom to 100%',{exact:true}).textContent(),'100%');await viewMenu().getByLabel('Board zoom',{exact:true}).focus();await page.keyboard.press('End');assert.equal(await viewMenu().getByTitle('Reset zoom to 100%',{exact:true}).textContent(),'250%');await viewMenu().getByTitle('Reset zoom to 100%',{exact:true}).click();assert.equal(await viewMenu().getByTitle('Reset zoom to 100%',{exact:true}).textContent(),'100%');
    await viewMenu().getByRole('menuitem',{name:'Scale to fit',exact:true}).click();assert.equal(await viewMenu().count(),1);await viewMenu().getByRole('menuitem',{name:'Present',exact:true}).click();await page.getByRole('dialog',{name:'Presentation mode',exact:true}).waitFor();assert.equal(await viewMenu().count(),0);await page.keyboard.press('Escape');await page.getByRole('dialog',{name:'Presentation mode',exact:true}).waitFor({state:'detached'});
  });
  await check('Text style has seven observed rows and six swatches per color group at measured popup geometry',async()=>{
    await load();await edit();await selectAlpha();await openStyle();const menu=styleMenu(),rect=await menu.boundingBox();assert.ok(rect);for(const[key,expected]of Object.entries({x:62.5,y:80,width:193.594,height:366.578}))assert.ok(Math.abs(rect[key]-expected)<.1,`${key}: ${rect[key]}`);
    assert.equal(await menu.getByRole('menuitem').count(),7);for(const name of['Large heading','Normal heading','Normal text','Small text','Code block','Callout','Quote block'])assert.equal(await menu.getByRole('menuitem').filter({hasText:name}).count(),1);
    assert.equal(await menu.getByRole('button',{name:/^Text color #/}).count(),6);assert.equal(await menu.getByRole('button',{name:/^Highlight color #/}).count(),6);assert.equal(await page.evaluate(()=>getSelection()?.toString()),'Alpha');await page.keyboard.press('Escape');assert.equal(await menu.count(),0);assert.equal(await editor().count(),1);
  });
  const cases=[
    {name:'Large heading',selector:'h1',expected:{fontSize:'16px',lineHeight:'24px',fontWeight:'600',marginTop:'-4.8px',marginBottom:'4.8px'}},
    {name:'Normal heading',selector:'h2',expected:{fontSize:'12.8px',lineHeight:'20px',fontWeight:'600',marginTop:'-3px',marginBottom:'7px'}},
    {name:'Normal text',selector:'p',initial:'<h2>Alpha bravo charlie.</h2><p>Second paragraph.</p>'},
    {name:'Small text',selector:'span[style*="font-size"]',expected:{fontSize:'9.6px'}},
    {name:'Code block',selector:'pre'},
    {name:'Callout',selector:'aside[data-note-callout="true"]'},
    {name:'Quote block',selector:'blockquote'},
  ];
  for(const item of cases)await check(`${item.name} formats the selected text or paragraph and keeps the style popup open`,async()=>{
    await load(fixture(item.initial));await edit();await selectAlpha();await openStyle();await styleMenu().getByRole('menuitem').filter({hasText:item.name}).click();await editor().locator(item.selector).first().waitFor();assert.equal(await styleMenu().count(),1);const styled=editor().locator(item.selector).first();assert.ok((await styled.textContent()).includes('Alpha'));if(item.expected){const actual=await metrics(styled);for(const[key,value]of Object.entries(item.expected))assert.equal(actual[key],value);}
    assert.equal(await editor().getByText('Second paragraph.',{exact:true}).count(),1);
  });
  await check('Heading formatting preserves native selection and participates in editor undo and redo',async()=>{
    await load();await edit();await selectAlpha();await openStyle();await styleMenu().getByRole('menuitem').filter({hasText:'Large heading'}).click();assert.equal(await editor().locator('h1').count(),1);await page.keyboard.press('Escape');await page.keyboard.press('Control+z');assert.equal(await editor().locator('h1').count(),0);await page.keyboard.press('Control+Shift+z');assert.equal(await editor().locator('h1').count(),1);
  });
  await check('Selected-range color and highlight remain scoped, persist through safe HTML backup/reload, and leave surrounding text unchanged',async()=>{
    await load();await edit();await selectAlpha();await openStyle();await styleMenu().getByRole('button',{name:'Text color #f52929',exact:true}).click();await styleMenu().getByRole('button',{name:'Highlight color #ffce26',exact:true}).click();assert.equal(await styleMenu().count(),1);assert.equal(await page.evaluate(()=>getSelection()?.toString()),'Alpha');
    const span=editor().locator('span').filter({hasText:'Alpha'});assert.equal(await span.evaluate(element=>getComputedStyle(element).color),'rgb(245, 41, 41)');assert.equal(await editor().locator('mark').textContent(),'Alpha');assert.equal(await editor().locator('mark').evaluate(element=>getComputedStyle(element).backgroundColor),'rgb(255, 206, 38)');
    await closeNote();const data=await backup('view-text-style-colors.json'),html=data.boards.root.cards[0].html;assert.match(html,/color: #f52929/);assert.match(html,/background-color: #ffce26/);assert.doesNotMatch(html,/<script|onerror=|javascript:/i);assert.ok(html.includes(' bravo charlie.'));
    await load(data);assert.equal(await card().locator('.note-text mark').textContent(),'Alpha');assert.equal(await card().locator('.note-text span').filter({hasText:'Alpha'}).evaluate(element=>getComputedStyle(element).color),'rgb(245, 41, 41)');await page.getByText('Saved on this device',{exact:true}).waitFor();await page.reload();assert.equal(await card().locator('.note-text mark').textContent(),'Alpha');
  });
  await check('Imported unsafe text HTML is sanitized while preserving supported small text and colors',async()=>{
    const data=fixture('<p><span style="font-size:9.6px;color:#f52929" onclick="alert(1)">Alpha</span><script>globalThis.stolen=true</script> bravo charlie.</p><p>Second paragraph.</p>');await load(data);assert.equal(await card().locator('script,[onclick]').count(),0);const span=card().locator('.note-text span');assert.equal(await span.evaluate(element=>getComputedStyle(element).fontSize),'9.6px');assert.equal(await span.evaluate(element=>getComputedStyle(element).color),'rgb(245, 41, 41)');assert.equal(await page.evaluate(()=>globalThis.stolen),undefined);const saved=await backup('view-text-style-safe-html.json');assert.doesNotMatch(saved.boards.root.cards[0].html,/<script|onclick=/i);
  });
  assert.deepEqual(pageErrors,[]);results.push({name:'No uncaught browser errors',status:'passed'});
}finally{await writeFile(new URL('view-text-style-e2e-results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),base,referenceParityClaimed:false,results,pageErrors},null,2));await browser.close();}
