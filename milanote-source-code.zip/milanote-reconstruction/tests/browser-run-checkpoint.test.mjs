import{describe,it,expect}from'vitest';
import{resumableBrowserResults}from'../scripts/browser-run-checkpoint.mjs';
const suites=['first','failed','interrupted'],hash='a'.repeat(64),other='b'.repeat(64);
const snapshot=()=>({sourceHashAtStart:hash,sourceHashAtEnd:hash,sourceChangedDuringRun:false,expectedSuites:suites,activeSuite:'interrupted',results:[{suite:'first',status:'passed',exitCode:0},{suite:'failed',status:'failed',exitCode:1}]});
describe('browser checkpoint evidence cannot turn an incomplete or failed round into success',()=>{
 it('retains a failed completed suite and omits the interrupted active suite',()=>{const prior=snapshot(),result=resumableBrowserResults(prior,hash,suites);expect(result.accepted).toBe(true);expect(result.results).toEqual(prior.results);expect(result.results.map(row=>row.suite)).toEqual(['first','failed']);result.results[0].status='failed';expect(prior.results[0].status).toBe('passed');});
 it.each(['sourceHashAtStart','sourceHashAtEnd'])('rejects mismatched %s',key=>{const prior=snapshot();prior[key]=other;expect(resumableBrowserResults(prior,hash,suites).accepted).toBe(false);});
 it('rejects a source mutation even after content was restored',()=>expect(resumableBrowserResults({...snapshot(),sourceChangedDuringRun:true},hash,suites).accepted).toBe(false));
 it('rejects changed suite order or added coverage',()=>{expect(resumableBrowserResults(snapshot(),hash,[...suites].reverse()).accepted).toBe(false);expect(resumableBrowserResults(snapshot(),hash,[...suites,'additional']).accepted).toBe(false);});
 it('rejects a noncontiguous result prefix and inconsistent success',()=>{const prior=snapshot();prior.results[0].suite='failed';expect(resumableBrowserResults(prior,hash,suites).accepted).toBe(false);const invalid=snapshot();invalid.results[0].exitCode=1;expect(resumableBrowserResults(invalid,hash,suites).accepted).toBe(false);});
 it('starts a fresh round rather than reusing an already completed one',()=>{const prior=snapshot();prior.results.push({suite:'interrupted',status:'passed',exitCode:0});expect(resumableBrowserResults(prior,hash,suites).accepted).toBe(false);});
 it('accepts a verified empty prefix and rejects absent evidence',()=>{expect(resumableBrowserResults({...snapshot(),results:[]},hash,suites)).toEqual({accepted:true,results:[]});expect(resumableBrowserResults(null,hash,suites).accepted).toBe(false);expect(resumableBrowserResults({...snapshot(),sourceChangedDuringRun:undefined},hash,suites).accepted).toBe(false);});
});
