import { describe, expect, it, vi } from "vitest";
import { unzipSync, strFromU8 } from "fflate";
import { createCard } from "../src/core/model";
import type { Board, Card } from "../src/core/model";
import { exportBoardAttachmentsZip, exportBoardWord, exportDocumentFile, pdfPageDimensions, rasterDimensions, safeAttachmentName } from "../src/core/exportFormats";
import { boardsForLinearExport, exportBoardHtml, exportBoardMarkdown, exportBoardSvg, exportBoardText } from "../src/export";

const make = (cards: Card[]): Board => ({ id: "export", title: "Export & test", cards, connections: [], viewport: { x: 0, y: 0, zoom: 1 } });
const png = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/l0sAAAAASUVORK5CYII=";

describe("binary format exports", () => {
  it("sizes output independently of browser zoom and refuses canvas dimensions that would truncate", () => {
    const board = make([{ ...createCard("note", -300, -200), type: "note", text: "Outside the origin" }]);
    const one = rasterDimensions(board, { scale: 1 }), two = rasterDimensions(board, { scale: 2, includeTitle: true });
    expect(one.width).toBe(334); expect(one.height).toBe(120);
    expect(two.pixelWidth).toBe(one.width * 2); expect(two.pixelHeight).toBe((one.height + 70) * 2);
    expect(() => rasterDimensions(board, { scale: 0 })).toThrow("scale");
    expect(() => rasterDimensions(make([{ ...createCard("note"), type: "note", text: "Huge", width: 100000 }]))).toThrow("too large");
  });
  it("crops a small translated table to the observed 32px content margin rather than the canvas origin", () => {
    const table = { ...createCard("table", 327, 208), type: "table" as const, title: "", rows: [["1","1",""]], width: 270, height: 94 };
    const source = make([table]), dimensions = rasterDimensions(source);
    expect(dimensions).toEqual({width:334,height:158,pixelWidth:668,pixelHeight:316});
    const moved = {...source,viewport:{x:400,y:-600,zoom:.25},cards:[{...table,x:-9000,y:8000}]};
    expect(rasterDimensions(moved)).toEqual(dimensions);
    const pair=make([table,{...table,id:'second',x:1015,y:624}]);
    expect(rasterDimensions(pair)).toEqual({width:1022,height:574,pixelWidth:2044,pixelHeight:1148});
  });
  it("keeps standard/high-quality PDF paper geometry identical and allows explicit paper settings", () => {
    expect(pdfPageDimensions({ format: "standard" }, 1200, 800)).toEqual([900.72, 600.72]);
    expect(pdfPageDimensions({ pageSize: "letter", orientation: "portrait" }, 1200, 800)).toEqual([612, 792]);
    expect(pdfPageDimensions({ format: "large" }, 1200, 800)).toEqual([900.72, 600.72]);
    expect(pdfPageDimensions({ pageSize: "board", orientation: "portrait" }, 1201, 801)).toEqual([901.44,601.44]);
    expect(pdfPageDimensions({ pageSize: "a4", format: "large", orientation: "portrait" }, 100000, 70000)).toEqual([595.28,841.89]);
    expect(pdfPageDimensions({ pageSize: "a4" }, 1200, 800)).toEqual([841.89,595.28]);
  });
  it("matches the paper geometry of four independently downloaded reference PNG/PDF pairs", () => {
    for (const [width,height,paperWidth,paperHeight] of [[334,158,251.04,119.04],[1022,574,767.04,431.04],[950,526,713.04,395.04],[1646,782,1235.04,587.04]]) {
      expect(pdfPageDimensions({},width,height)).toEqual([paperWidth,paperHeight]);
    }
  });
  it("refuses invalid or oversized custom PDF pages instead of truncating their board", () => {
    for (const [width,height] of [[0,800],[-1,800],[1200,NaN],[Infinity,800],[19200,800]]) {
      expect(() => pdfPageDimensions({}, width, height)).toThrow("PDF");
    }
    expect(pdfPageDimensions({}, 19199, 800)).toEqual([14400,600.72]);
  });
  it("includes nested boards in Markdown, text and Word once, handles shortcut cycles, and excludes unrelated boards", async () => {
    const root = make([{ ...createCard("board"), type: "board", boardId: "nested", title: "Nested tile" }, { ...createCard("board", 300, 0), type: "board", boardId: "nested", title: "Alias", isShortcut: true }]);
    const nested = { ...make([{ ...createCard("note"), type: "note" as const, text: "Nested unique content" }, { ...createCard("board", 0, 100), type: "board" as const, boardId: root.id, title: "Cycle", isShortcut: true }]), id: "nested", title: "Child board" };
    const unrelated = { ...make([{ ...createCard("note"), type: "note" as const, text: "Unrelated content" }]), id: "other" };
    const options = { includeSubBoards: true, workspace: { boards: { [root.id]: root, nested, other: unrelated } } };
    expect(boardsForLinearExport(root, options).map(board => board.id)).toEqual([root.id,"nested"]);
    for (const output of [exportBoardMarkdown(root, options), exportBoardText(root, options)]) {
      expect(output.match(/Nested unique content/g)).toHaveLength(1);
      expect(output).not.toContain("Unrelated content");
    }
    expect(exportBoardText(root)).not.toContain("Nested unique content");
    expect(() => exportBoardMarkdown(root, { includeSubBoards: true })).toThrow("workspace");
    const entries = unzipSync(new Uint8Array(await (await exportBoardWord(root, options)).arrayBuffer()));
    const xml = strFromU8(entries["word/document.xml"]);
    expect(xml.match(/Nested unique content/g)).toHaveLength(1);
    expect(xml).toContain('<w:br w:type="page"/>');
    expect(xml).not.toContain("Unrelated content");
  });
  it("writes real editable DOCX with rich marks, safe hyperlinks, lists, RTL, table results, colors and original image bytes", async () => {
    const board = make([
      { ...createCard("note"), type: "note", text: "old", html: '<h2>Brief</h2><p><strong>Bold</strong> <em>italic</em> <u>underlined</u> <s>removed</s> <span style="color: #aabbcc">Color</span> <mark style="background-color: #ffcc00">Highlight</mark> <a href="https://example.com/path">source</a></p><p>مرحبا بالعالم</p><ul><li><p>First</p></li><li><p>Second</p></li></ul><ol><li><p>Ordered</p></li></ol><script>bad()</script>' },
      { ...createCard("table", 0, 300), type: "table", title: "Budget", rows: [["10", "20", "=SUM(A1:B1)"]], cellMeta: { "0:2": { bold: true, color: "#dceadf", align: "right" } } },
      { ...createCard("todo", 0, 450), type: "todo", title: "Tasks", items: [{ id: "task", text: "Nested task", done: true, indent: 1, dueDate: "2026-11-02", reminderTime: "09:00" }] },
      { ...createCard("image", 0, 600), type: "image", src: png, caption: "Photo", width: 120, height: 155 },
    ]);
    const blob = await exportBoardWord(board), entries = unzipSync(new Uint8Array(await blob.arrayBuffer()));
    expect(blob.type).toBe("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
    expect(Object.keys(entries)).toContain("word/document.xml");
    const xml = strFromU8(entries["word/document.xml"]), relations = strFromU8(entries["word/_rels/document.xml.rels"]);
    for (const value of ["<w:b/>", "<w:i/>", "<w:u w:val=\"single\"/>", "<w:strike/>", "AABBCC", "FFCC00", "مرحبا بالعالم", "<w:bidi/>", "<w:rtl/>", "<w:numPr>", "<w:tbl>", ">30<", "DCEADF", "Nested task", "2026-11-02 09:00"]) expect(xml).toContain(value);
    expect(xml).not.toContain("bad()"); expect(relations).toContain("https://example.com/path");
    const imageName = Object.keys(entries).find(name => name.startsWith("word/media/") && name.endsWith(".png"));
    expect(imageName).toBeTruthy(); expect(entries[imageName!].slice(0, 8)).toEqual(new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10]));
  });
  it("exports complete document Markdown/plain text and Word without repeating a board/card title", async () => {
    const note = { ...createCard("note"), type: "note" as const, isDocument: true, title: "A *brief*", text: "old", html: "<p>A <strong>complete</strong> document.</p><p>Last paragraph.</p>" };
    expect(await (await exportDocumentFile(note, "markdown")).text()).toBe("# A \\*brief\\*\n\nA **complete** document.\n\nLast paragraph.\n");
    expect(await (await exportDocumentFile(note, "text")).text()).toBe("A *brief*\n\nA complete document.\nLast paragraph.\n");
    const entries = unzipSync(new Uint8Array(await (await exportDocumentFile(note, "word")).arrayBuffer()));
    const xml = strFromU8(entries["word/document.xml"]);
    expect(xml.match(/A \*brief\*/g)).toHaveLength(1); expect(xml).toContain("Last paragraph.");
  });
  it("ignores hidden resources in a Word export but rejects a visible resource that cannot be embedded", async () => {
    const image = { ...createCard("image"), type: "image" as const, src: "https://example.com/unavailable.png", caption: "Missing image" };
    const fetchResource = vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response("Denied", { status: 403 }));
    try {
      await exportBoardWord(make([{ ...image, unsorted: true }]));
      expect(fetchResource).not.toHaveBeenCalled();
      await expect(exportBoardWord(make([image]))).rejects.toThrow("Could not embed");
      expect(fetchResource).toHaveBeenCalledOnce();
    } finally { fetchResource.mockRestore(); }
  });
  it("retains raster board icons in portable visual/Word exports and excludes active SVG icon payloads", async () => {
    const root = { ...make([{ ...createCard("board"), type: "board" as const, boardId: "nested", title: "Nested icon board" }]), icon: png };
    const nested = { ...make([]), id: "nested", icon: png };
    const options = { workspace: { boards: { [root.id]: root, nested } } };
    for (const value of [exportBoardHtml(root, options), exportBoardSvg(root, options)]) {
      expect(value.match(/data:image\/png;base64/g)).toHaveLength(2);
      expect(value).not.toContain("&lt;img");
    }
    const word = unzipSync(new Uint8Array(await (await exportBoardWord(root, options)).arrayBuffer()));
    expect(strFromU8(word["word/document.xml"]).match(/<w:drawing>/g)).toHaveLength(2);
    const unsafe = { ...root, icon: "data:image/svg+xml;base64,PHN2ZyBvbmxvYWQ9ImFsZXJ0KDEpIj48L3N2Zz4=" };
    expect(exportBoardHtml(unsafe)).not.toContain("data:image/svg");
    expect(exportBoardSvg(unsafe)).not.toContain("data:image/svg");
    expect(exportBoardHtml({ ...root, icon: "★" })).toContain("★");
  });
  it("creates a real attachment ZIP with original image bytes, safe leaf filenames and unique duplicates", async () => {
    const board = make([
      { ...createCard("file"), type: "file", name: "../../notes.txt", mime: "text/plain", size: 5, dataUrl: "data:text/plain;base64,SGVsbG8=" },
      { ...createCard("file"), type: "file", name: "notes.txt", mime: "text/plain", size: 5, dataUrl: "data:text/plain;base64,V29ybGQ=" },
      { ...createCard("file"), type: "file", name: "__proto__", mime: "text/plain", size: 4, dataUrl: "data:text/plain;base64,c2FmZQ==" },
      { ...createCard("image"), type: "image", id: "photo", src: png, caption: "Edited caption", imageEdits: { rotation: 90, crop: { x: 0, y: 0, width: 1, height: 1 }, paths: [] } },
      { ...createCard("file"), type: "file", unsorted: true, name: "inbox.txt", mime: "text/plain", size: 1, dataUrl: "data:text/plain,hidden" },
    ]);
    const blob = await exportBoardAttachmentsZip(board), entries = unzipSync(new Uint8Array(await blob.arrayBuffer()));
    expect(blob.type).toBe("application/zip"); expect(Object.keys(entries).sort()).toEqual(["file-__proto__", "image-photo.png", "notes (2).txt", "notes.txt"].sort());
    expect(strFromU8(entries["notes.txt"])).toBe("Hello"); expect(strFromU8(entries["notes (2).txt"])).toBe("World"); expect(strFromU8(entries["file-__proto__"])).toBe("safe");
    expect(entries["image-photo.png"].slice(0, 8)).toEqual(new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10]));
    await expect(exportBoardAttachmentsZip(make([]))).rejects.toThrow("no downloadable");
  });
  it("normalizes invalid attachment names without allowing path traversal or control characters", () => {
    expect(safeAttachmentName("C:\\fakepath\\photo.png", "image.png")).toBe("photo.png");
    expect(safeAttachmentName("../..", "file.bin")).toBe("file.bin");
    expect(safeAttachmentName("a\u0000:b?.txt", "file.bin")).toBe("a__b_.txt");
  });
});
