import { describe,expect,it } from 'vitest';
import { normalizeSegmentationInput,segmentationMask } from '../src/core/backgroundRemoval';

describe('local segmentation preprocessing',()=>{
  it('uses planar RGB ImageNet normalization independently of alpha',()=>{
    const pixels=new Uint8ClampedArray(320*320*4);pixels.set([255,128,0,0]);const result=normalizeSegmentationInput(pixels),plane=320*320;
    expect(result[0]).toBeCloseTo((1-.485)/.229,5);expect(result[plane]).toBeCloseTo((128/255-.456)/.224,5);expect(result[plane*2]).toBeCloseTo((0-.406)/.225,5);
  });
  it('normalizes a real probability range and handles constant/invalid output explicitly',()=>{
    const values=new Float32Array(320*320);values.fill(.2);values[0]=.8;values[1]=.5;const mask=segmentationMask(values);expect(mask[0]).toBe(255);expect(mask[1]).toBe(127);expect(mask[2]).toBe(0);
    expect(segmentationMask(new Float32Array(320*320).fill(.7))[0]).toBe(255);values[3]=NaN;expect(()=>segmentationMask(values)).toThrow(/invalid probabilities/);
  });
});
