import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
import {chromium,webkit} from 'playwright-core';

// Browser touch emulation checks. This is not a physical iPad/Safari/Pencil test.
const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium';
const url=process.env.TEST_URL||'http://127.0.0.1:5287';
const artifacts=new URL(`../artifacts/touch-${engine}/`,import.meta.url);await mkdir(artifacts,{recursive:true});
const browser=await(engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']}));
const results=[],errors=[];
const fixture={version:1,id:'touch-workspace',title:'Touch study',rootBoardId:'root',updatedAt:new Date().toISOString(),boards:{root:{id:'root',title:'Touch study',viewport:{x:0,y:0,zoom:1},cards:[],connections:[]}}};
async function contained(page,locator){const r=await locator.boundingBox();assert(r);const viewport=page.viewportSize();assert(r.x>=-1&&r.y>=-1&&r.x+r.width<=viewport.width+1&&r.y+r.height<=viewport.height+1,`Element outside viewport ${JSON.stringify({r,viewport})}`);assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);}
async function saved(page){await page.getByText('Saved on this device',{exact:true}).waitFor({state:'attached'});}
async function persisted(page,expected){
  await page.waitForFunction(async expected=>{
    let db;
    try{
      db=await new Promise((resolve,reject)=>{const request=indexedDB.open('visual-workspace',1);request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});
      const snapshot=await new Promise((resolve,reject)=>{const request=db.transaction('documents','readonly').objectStore('documents').get('workspace');request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});
      const card=snapshot?.workspace?.boards.root?.cards.find(card=>card.id===expected.id);
      return !!card&&Object.entries(expected).every(([key,value])=>key==='htmlIncludes'?card.html?.includes(value):key==='rotation'?card.imageEdits?.rotation===value:card[key]===value);
    }catch{return false;}finally{db?.close();}
  },expected);
}
async function run(page,name,fn){try{await fn();results.push({name,status:'passed'});console.log('PASS',name);}catch(error){results.push({name,status:'failed',message:error.stack});process.exitCode=1;console.error('FAIL',name,error.message);await page.screenshot({path:new URL(`failure-${results.length}.png`,artifacts).pathname});await page.keyboard.press('Escape').catch(()=>{});}}
async function doubleTap(locator){await locator.tap({position:{x:5,y:5}});await new Promise(resolve=>setTimeout(resolve,65));await locator.tap({position:{x:5,y:5}});}
try{
  for(const viewport of [{width:1024,height:768},{width:768,height:1024}]){
    const tag=`${viewport.width}x${viewport.height}`;
    const context=await browser.newContext({viewport,isMobile:true,hasTouch:true,deviceScaleFactor:1,acceptDownloads:true});
    const page=await context.newPage();page.setDefaultTimeout(8000);page.on('pageerror',error=>errors.push(`${tag}: ${error.message}`));
    await page.goto(url,{waitUntil:'domcontentloaded'});await saved(page);
    await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'touch-fixture.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(fixture))});
    await page.getByText('Workspace imported. Undo to return to your previous workspace.',{exact:true}).waitFor();
    let noteId;
    await run(page,`${tag}: touch creates a note and applies rich formatting, color and independent strip; edits survive reload`,async()=>{
      await page.getByTitle('Add Note',{exact:true}).tap();const editor=page.getByRole('textbox',{name:'Note text',exact:true});await editor.waitFor();
      noteId=await page.locator('.card-note').getAttribute('data-card-id');await editor.fill('أفكار على الجهاز اللوحي\nTouch note');
      await page.getByTitle('Bold',{exact:true}).tap();await page.keyboard.insertText(' bold');
      assert.match(await editor.innerHTML(),/<strong> bold<\/strong>/);
      await page.getByLabel('Current board title',{exact:true}).tap();await editor.waitFor({state:'hidden'});
      const note=page.locator(`[data-card-id="${noteId}"]`);await note.tap({position:{x:3,y:3}});
      await page.getByTitle('Color',{exact:true}).tap();const menu=page.getByRole('dialog',{name:'Card color',exact:true});await contained(page,menu);
      await menu.getByRole('button',{name:'Background #4ebafd',exact:true}).tap();await menu.getByRole('button',{name:'Top strip',exact:true}).tap();await menu.getByRole('button',{name:'Top strip #ff5757',exact:true}).tap();
      await page.getByLabel('Current board title',{exact:true}).tap();await menu.waitFor({state:'hidden'});await persisted(page,{id:noteId,color:'#4ebafd',stripColor:'#ff5757',htmlIncludes:'<strong> bold</strong>'});await saved(page);await page.reload();await saved(page);
      assert.match(await note.innerText(),/أفكار على الجهاز اللوحي/);assert.equal(await note.locator('strong').innerText(),' bold');
      assert.equal(await note.evaluate(el=>getComputedStyle(el).backgroundColor),'rgb(78, 186, 253)');assert.equal(await note.getByLabel('Card top strip').evaluate(el=>el.getBoundingClientRect().height),4);await doubleTap(note);await page.getByRole('textbox',{name:'Note text',exact:true}).waitFor();await page.getByLabel('Current board title',{exact:true}).tap();await page.getByRole('textbox',{name:'Note text',exact:true}).waitFor({state:'hidden'});
    });
    if(engine==='chromium')await run(page,`${tag}: browser touch drag moves the selected card and can be undone without opening its editor`,async()=>{
      const note=page.locator(`[data-card-id="${noteId}"]`),rect=await note.boundingBox(),before=await note.evaluate(el=>({x:parseFloat(el.style.left),y:parseFloat(el.style.top)}));
      const cdp=await context.newCDPSession(page),start={x:rect.x+5,y:rect.y+5};await page.evaluate(()=>{window.touchTrace=[];for(const type of ['pointerdown','pointermove','pointerup','pointercancel'])document.addEventListener(type,event=>window.touchTrace.push({type:event.type,pointer:event.pointerId,target:event.target.className,x:event.clientX,y:event.clientY,pointerType:event.pointerType}),{capture:true});});
      await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{...start,id:1,force:1,radiusX:1,radiusY:1}]});
      for(let step=1;step<=6;step++)await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:start.x+step*10,y:start.y+step*8,id:1,force:1,radiusX:1,radiusY:1}]});
      await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
      // Wait for the native browser drag gesture to settle before a separate tap.
      await page.waitForTimeout(600);
      const after=await note.evaluate(el=>({x:parseFloat(el.style.left),y:parseFloat(el.style.top)}));assert.equal(after.x-before.x,60,JSON.stringify(await note.evaluate(el=>({events:window.touchTrace,css:[el,el.parentElement,el.closest('.stage'),el.querySelector('.note-text')].map(node=>({class:node.className,action:getComputedStyle(node).touchAction,overflow:getComputedStyle(node).overflow}))}))));assert.equal(after.y-before.y,48);assert.equal(await page.getByRole('textbox',{name:'Note text',exact:true}).count(),0);
      // Keep both actions on one browser touch driver; the Undo contact lasts 80ms.
      const undoButton=page.getByTitle('Undo (⌘Z)',{exact:true});assert.equal(await undoButton.isEnabled(),true);const undo=await undoButton.boundingBox();
      await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:undo.x+undo.width/2,y:undo.y+undo.height/2,id:1,force:1,radiusX:1,radiusY:1}]});await page.waitForTimeout(80);await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await cdp.detach();await page.waitForFunction(({id,before})=>{const el=document.querySelector(`[data-card-id="${id}"]`);return el&&parseFloat(el.style.left)===before.x&&parseFloat(el.style.top)===before.y;},{id:noteId,before});assert.deepEqual(await note.evaluate(el=>({x:parseFloat(el.style.left),y:parseFloat(el.style.top)})),before);
    });
    await run(page,`${tag}: double touch opens a child board and touch navigation returns to the edited parent`,async()=>{
      const back=page.getByTitle('Back to tools',{exact:true});if(await back.isVisible())await back.tap();
      await page.getByTitle('Add Board',{exact:true}).tap();const board=page.locator('.card-board');await board.tap({position:{x:5,y:5}});assert.equal(await page.getByLabel('Current board title',{exact:true}).inputValue(),'Touch study');await page.waitForTimeout(400);await doubleTap(board);
      await page.waitForFunction(()=>document.querySelector('[aria-label="Current board title"]')?.value==='Untitled board');
      await page.getByLabel('Current board title',{exact:true}).fill('Child touched');await saved(page);
      const parent=page.locator('.breadcrumbs').getByRole('button',{name:'Touch study',exact:true});if(await parent.isVisible())await parent.tap();else{await page.getByTitle('Show boards',{exact:true}).tap();await page.locator('.board-tree button').filter({hasText:'Touch study'}).tap();await page.getByTitle('Collapse sidebar',{exact:true}).tap();}await page.waitForFunction(()=>document.querySelector('[aria-label="Current board title"]')?.value==='Touch study');
      assert.equal(await page.locator(`[data-card-id="${noteId}"] strong`).innerText(),' bold');assert.equal(await page.locator('.card-board').getByLabel('Board name',{exact:true}).inputValue(),'Child touched');
    });
    await run(page,`${tag}: touch edits an image caption and rotates with Save/Cancel without replacing its source`,async()=>{
      // Import only test content; file chooser/paste keyboards are OS integrations outside this browser check.
      const image={id:'photo',type:'image',src:'/assets/studio-objects.jpg',caption:'Original caption',x:180,y:120,width:270,height:216,z:2};
      const ws=structuredClone(fixture);ws.boards.root.cards=[image];await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'touch-image.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(ws))});await page.getByText('Workspace imported. Undo to return to your previous workspace.',{exact:true}).waitFor();
      const photo=page.locator('[data-card-id="photo"]');await photo.getByRole('button',{name:'Edit image caption',exact:true}).tap();const caption=page.getByRole('textbox',{name:'Image caption',exact:true});await caption.fill('Caption written with touch selection');await page.getByTitle('Finish caption',{exact:true}).tap();
      await photo.tap({position:{x:3,y:3}});await page.getByTitle('Crop and rotate image',{exact:true}).tap();let dialog=page.getByRole('dialog',{name:'Edit image',exact:true});await contained(page,dialog);await dialog.getByRole('button',{name:'Rotate right',exact:true}).tap();await dialog.getByRole('button',{name:'Save changes',exact:true}).tap();await dialog.waitFor({state:'hidden'});
      await photo.locator('svg.edited-image-preview').waitFor();assert.equal(await photo.locator('svg.edited-image-preview').count(),1);assert.equal(await photo.locator('svg image').getAttribute('href'),'/assets/studio-objects.jpg');const savedTransform=await photo.locator('svg>g').getAttribute('transform');
      await page.getByTitle('Crop and rotate image',{exact:true}).tap();dialog=page.getByRole('dialog',{name:'Edit image',exact:true});await dialog.getByRole('button',{name:'Rotate right',exact:true}).tap();await dialog.getByRole('button',{name:'Cancel',exact:true}).tap();await dialog.waitFor({state:'hidden'});assert.equal(await photo.locator('svg>g').getAttribute('transform'),savedTransform);
      await persisted(page,{id:'photo',caption:'Caption written with touch selection',rotation:90});await saved(page);await page.reload();await saved(page);assert.match(await photo.innerText(),/Caption written with touch selection/);assert.equal(await photo.locator('svg>g').getAttribute('transform'),savedTransform);await page.screenshot({path:new URL(`${tag}-image.png`,artifacts).pathname});
    });
    await run(page,`${tag}: View and Export controls remain inside the touch viewport`,async()=>{
      await page.getByTitle('View',{exact:true}).tap();await contained(page,page.getByRole('menu',{name:'Board view',exact:true}));await page.getByLabel('Current board title',{exact:true}).tap();
      await page.getByRole('button',{name:'Export',exact:true}).tap();await contained(page,page.getByRole('menu',{name:'Export board',exact:true}));await page.getByLabel('Current board title',{exact:true}).tap();
    });
    await context.close();
  }
  assert.deepEqual(errors,[]);results.push({name:'No uncaught browser errors',status:'passed'});
}finally{await writeFile(new URL('results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),url,engine,physicalIPadVerified:false,referenceParityClaimed:false,inputLimits:'UI activation uses browser touchscreen taps. Text entry uses Playwright editing; no native virtual keyboard or Pencil. Chromium-only drag/Undo uses trusted browser-protocol touch events, a 600ms post-drag gesture pause and an 80ms Undo contact; immediate Undo is not asserted. WebKit dragging and pinch are not asserted by this suite.',results,errors},null,2));await browser.close();}
