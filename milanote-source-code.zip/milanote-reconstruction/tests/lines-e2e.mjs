import assert from "node:assert/strict";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { chromium, webkit } from "playwright-core";

const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const artifacts = path.join(root, "artifacts", engine==='webkit'?'webkit':'.');
await mkdir(artifacts, { recursive: true });
const browser=await (engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({ executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium", headless: true, args: ["--no-sandbox", "--disable-dev-shm-usage"] }));
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true });
page.setDefaultTimeout(7000);
const results = [], errors = [];
page.on("pageerror", error => errors.push(error.message));
const line = (id = "free") => page.locator(`[data-line-id="${id}"]`);
const handle = (name, id = "free") => line(id).locator(`[data-line-handle="${name}"]`);
const nearPoint = (actual, expected) => { assert(Math.abs(actual.x - expected.x) < .001, `x=${actual.x} ≈ ${expected.x}`); assert(Math.abs(actual.y - expected.y) < .001, `y=${actual.y} ≈ ${expected.y}`); };
const fixture = () => ({
  version: 1, id: "lines-workspace", title: "Line checks", rootBoardId: "lines-board", updatedAt: "2026-10-25T00:00:00.000Z",
  boards: { "lines-board": { id: "lines-board", title: "Line checks", cards: [{ id: "a", type: "note", text: "Start", x: 500, y: 80, width: 270, height: 54, z: 1 }, { id: "b", type: "note", text: "End", x: 850, y: 220, width: 270, height: 54, z: 2 }], connections: [{ id: "free", from: "", to: "", start: { x: 120, y: 220 }, end: { x: 340, y: 300 }, color: "#323b4a", style: "solid" }, { id: "attached", from: "a", to: "b", color: "#323b4a", style: "solid" }], viewport: { x: 20, y: 20, zoom: 1 }, background: "#ebedee", grid: true } },
});
async function load() {
  const value=fixture();value.id=`lines-workspace-${Date.now()}`;
  await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({ name: "lines.json", mimeType: "application/json", buffer: Buffer.from(JSON.stringify(value)) });
  await page.getByText("Workspace imported. Undo to return to your previous workspace.", { exact: true }).waitFor();
  await line().waitFor();
  await page.waitForFunction(id=>new Promise(resolve=>{const request=indexedDB.open('visual-workspace');request.onerror=()=>resolve(false);request.onsuccess=()=>{const db=request.result,read=db.transaction('documents','readonly').objectStore('documents').get('workspace');read.onsuccess=()=>{resolve(read.result?.workspace.id===id);db.close();};read.onerror=()=>{resolve(false);db.close();};};}),value.id);
}
async function pathPoint(id = "free", portion = 0.25) {
  return line(id).locator('.connection-stroke').evaluate((path, portion) => {
    const point = path.getPointAtLength(path.getTotalLength() * portion).matrixTransform(path.getScreenCTM());
    return { x: point.x, y: point.y };
  }, portion);
}
async function select(id = "free") { const point = await pathPoint(id); await page.mouse.click(point.x, point.y); await handle("start", id).waitFor(); }
async function drag(loc, dx, dy, cancel = false) {
  const rect = await loc.boundingBox(); assert(rect);
  // WebKit may quantize a requested screen coordinate by one pixel. Observe
  // native input rather than treating the driver request as an exact event.
  const input=await page.evaluateHandle(()=>{
    const sample={point:null};const record=event=>{if(event.buttons&1)sample.point={x:event.clientX,y:event.clientY};};
    window.addEventListener('pointermove',record,true);
    return {sample,stop:()=>window.removeEventListener('pointermove',record,true)};
  });
  try{
    await page.mouse.move(rect.x + rect.width / 2, rect.y + rect.height / 2); await page.mouse.down();
    await page.mouse.move(rect.x + rect.width / 2 + dx, rect.y + rect.height / 2 + dy, { steps: 10 });
    if (cancel) await page.keyboard.press("Escape");
    await page.mouse.up();
    return await input.evaluate(({sample})=>{
      if(!sample.point)throw Error('No native pointer movement was received');
      const point=new DOMPoint(sample.point.x,sample.point.y).matrixTransform(document.querySelector('.connectionLayer').getScreenCTM().inverse());
      return {x:point.x,y:point.y};
    });
  }finally{await input.evaluate(probe=>probe.stop());await input.dispose();}
}
async function backup() {
  await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();
  const pending = page.waitForEvent("download"); pending.catch(() => {});
  await page.getByRole("button", { name: /Workspace backup/ }).click();
  const downloaded = await pending, destination = path.join(artifacts, "lines-workspace.json");
  await downloaded.saveAs(destination);
  await page.getByTitle("Close dialog", { exact: true }).click();
  return JSON.parse(await readFile(destination, "utf8"));
}
async function run(name, fn) {
  try { await fn(); results.push({ name, status: "passed" }); console.log("PASS", name); }
  catch (error) { results.push({ name, status: "failed", message: error.stack }); process.exitCode = 1; console.error("FAIL", name, error.message); await page.screenshot({ path: path.join(artifacts, `lines-failure-${results.length}.png`) }).catch(() => {}); await page.keyboard.press("Escape").catch(() => {}); }
}
try {
  await page.goto(process.env.TEST_URL || "http://127.0.0.1:5176"); await page.getByLabel("Current board title").waitFor();
  await run("Free lines render straight with independently toggled arrow caps", async () => {
    await load(); await select();
    assert.equal(await line().locator('.connection-stroke').getAttribute("d"), "M 120 220 L 340 300");
    assert.equal(await line().locator('polygon.connection-cap').count(), 1);
    await page.getByTitle("Start arrow", { exact: true }).click();
    assert.equal(await line().locator('polygon.connection-cap').count(), 2);
    await page.getByTitle("End arrow", { exact: true }).click();
    assert.equal(await line().locator('polygon.connection-cap').count(), 1);
    await page.getByLabel("Line style", { exact: true }).selectOption("dashed");
    assert.equal(await line().locator('.connection-stroke').getAttribute("stroke-dasharray"), "5 5");
  });
  await run("Curve handle changes the real midpoint and commits one undo step", async () => {
    await load(); await select();
    await drag(handle("control"), 0, 70);
    assert.match(await line().locator('.connection-stroke').getAttribute("d"), / Q /);
    assert.equal(Number(await handle("control").getAttribute("cy")), 330);
    await page.getByTitle("Undo (⌘Z)", { exact: true }).click();
    assert.equal(await line().locator('.connection-stroke').getAttribute("d"), "M 120 220 L 340 300");
    await page.getByTitle("Redo (⇧⌘Z)", { exact: true }).click();
    assert.match(await line().locator('.connection-stroke').getAttribute("d"), / Q /);
  });
  await run("Escape restores a dragged endpoint and whole-line movement keeps its curve", async () => {
    await select();
    const before = await line().locator('.connection-stroke').getAttribute("d");
    assert.match(before,/ Q /);const [controlX,controlY]=before.split(' Q ')[1].split(',')[0].trim().split(/\s+/).map(Number);
    await drag(handle("start"), -40, -30, true);
    assert.equal(await line().locator('.connection-stroke').getAttribute("d"), before);
    // Drag the path away from its three selected handles.
    const location = await pathPoint();
    await page.mouse.move(location.x, location.y); await page.mouse.down(); await page.mouse.move(location.x + 40, location.y + 20, { steps: 10 }); await page.mouse.up();
    const after = await backup(), stored = after.boards['lines-board'].connections.find(item => item.id === "free");
    nearPoint(stored.start, { x: 160, y: 240 }); nearPoint(stored.end, { x: 380, y: 320 });
    nearPoint(stored.control, { x: controlX+40, y: controlY+20 });
    const released=await drag(handle("end"), 20, -10);
    nearPoint({ x: Number(await handle("end").getAttribute("cx")), y: Number(await handle("end").getAttribute("cy")) }, released);
  });
  await run("Dragging an attached endpoint detaches only that end and persists after reload", async () => {
    await load(); await select("attached");
    await drag(handle("start", "attached"), -50, 40);
    const data = await backup(), stored = data.boards['lines-board'].connections.find(item => item.id === "attached");
    assert.equal(stored.from, ""); assert.equal(stored.to, "b");
    assert.deepEqual(stored.start, { x: 720, y: 147 });
    await page.waitForTimeout(900); await page.reload(); await line("attached").waitFor();
    assert.match(await line("attached").locator('.connection-stroke').getAttribute("d"), /^M 720 147 /);
  });
  await run("Shift locks endpoint dragging to an axis and doubleclick straightens the curve", async () => {
    await load(); await select();
    await page.keyboard.down("Shift"); await drag(handle("end"), 80, 25); await page.keyboard.up("Shift");
    nearPoint({ x: Number(await handle("end").getAttribute("cx")), y: Number(await handle("end").getAttribute("cy")) }, { x: 420, y: 220 });
    await drag(handle("control"), 0, 60);
    assert.match(await line().locator('.connection-stroke').getAttribute("d"), / Q /);
    await handle("control").dblclick();
    assert.equal(await line().locator('.connection-stroke').getAttribute("d"), "M 120 220 L 420 220");
    await page.getByTitle("Undo (⌘Z)", { exact: true }).click();
    assert.match(await line().locator('.connection-stroke').getAttribute("d"), / Q /);
  });
  await run("Endpoint drops reattach and holding anchors an exact card point across reload", async () => {
    await load(); await select();
    async function endpointTo(point, hold = false) {
      const target = await page.locator('.connectionLayer').evaluate((svg, point) => {
        const value = svg.createSVGPoint(); value.x = point.x; value.y = point.y;
        const screen = value.matrixTransform(svg.getScreenCTM()); return { x: screen.x, y: screen.y };
      }, point);
      const rect = await handle("end").boundingBox(); assert(rect);
      await page.mouse.move(rect.x + rect.width / 2, rect.y + rect.height / 2); await page.mouse.down();
      await page.mouse.move(target.x, target.y, { steps: 3 });
      if (hold) await page.locator('[data-line-anchor-hint]').waitFor();
      await page.mouse.up();
    }
    await endpointTo({ x: 600, y: 100 });
    let data = await backup(), stored = data.boards['lines-board'].connections.find(item => item.id === "free");
    assert.equal(stored.to, "a"); assert.equal(stored.toAnchor, undefined); assert.equal(stored.end, undefined);
    nearPoint({ x: Number(await handle("end").getAttribute("cx")), y: Number(await handle("end").getAttribute("cy")) }, { x: 500, y: 107 });
    await endpointTo({ x: 650, y: 120 }, true);
    data = await backup(); stored = data.boards['lines-board'].connections.find(item => item.id === "free");
    assert.equal(stored.to, "a"); nearPoint(stored.toAnchor, { x: 150/270, y: 40/54 });
    nearPoint({ x: Number(await handle("end").getAttribute("cx")), y: Number(await handle("end").getAttribute("cy")) }, { x: 650, y: 120 });
    await page.waitForTimeout(900); await page.reload(); await line().waitFor();
    assert.equal(await line().locator('.connection-stroke').getAttribute("d"), "M 120 220 L 650 120");
  });
  await run("Dragging a card connector creates one undoable line; Escape cancels and click-connect still works", async () => {
    await load();
    const source = page.locator('[data-card-id="a"]'), target = page.locator('[data-card-id="b"]');
    async function connectorTo(card, point, cancel = false, hold = false) {
      await card.hover();
      const rect = await card.locator('.connector-handle').boundingBox(); assert(rect);
      const destination = await page.locator('.connectionLayer').evaluate((svg, point) => {
        const p = svg.createSVGPoint(); p.x = point.x; p.y = point.y;
        const s = p.matrixTransform(svg.getScreenCTM()); return { x: s.x, y: s.y };
      }, point);
      await page.mouse.move(rect.x + rect.width / 2, rect.y + rect.height / 2); await page.mouse.down();
      await page.mouse.move(destination.x, destination.y, { steps: 5 });
      if(hold)await page.locator('[data-line-anchor-hint]').waitFor();
      if(cancel)await page.keyboard.press("Escape");
      await page.mouse.up();
    }
    await connectorTo(source,{x:700,y:420});
    assert.equal(await page.locator('[data-line-id]').count(),3);
    let data=await backup(),created=data.boards['lines-board'].connections.filter(item=>!['free','attached'].includes(item.id));
    assert.equal(created.length,1);assert.equal(created[0].from,'a');assert.equal(created[0].to,'');nearPoint(created[0].end,{x:700,y:420});
    await page.getByTitle("Undo (⌘Z)",{exact:true}).click();assert.equal(await page.locator('[data-line-id]').count(),2);
    await page.getByTitle("Redo (⇧⌘Z)",{exact:true}).click();assert.equal(await page.locator('[data-line-id]').count(),3);
    await connectorTo(target,{x:1180,y:420},true);assert.equal(await page.locator('[data-line-id]').count(),3);
    await source.hover();await source.locator('.connector-handle').click();
    await target.hover();await target.locator('.connector-handle').click();
    assert.equal(await page.locator('[data-line-id]').count(),4);
    data=await backup();created=data.boards['lines-board'].connections.filter(item=>!['free','attached'].includes(item.id));
    assert.equal(created.filter(item=>item.from==='a'&&item.to==='b').length,1);
    await load();await source.hover();
    const clickRect=await source.locator('.connector-handle').boundingBox();assert(clickRect);
    await page.mouse.move(clickRect.x+clickRect.width/2,clickRect.y+clickRect.height/2);await page.mouse.down();
    await page.keyboard.press('Escape');await page.waitForTimeout(40);await page.mouse.up();
    assert.match(await page.locator('.stage').getAttribute('class'),/tool-select/);
    assert.equal(await page.locator('[data-line-id]').count(),2);
    await load();await connectorTo(source,{x:950,y:240},false,true);
    data=await backup();created=data.boards['lines-board'].connections.filter(item=>!['free','attached'].includes(item.id));
    assert.equal(created.length,1);assert.equal(created[0].from,'a');assert.equal(created[0].to,'b');nearPoint(created[0].toAnchor,{x:100/270,y:20/54});
  });
  await run("Line tool supports click creation and dragging from the rail", async () => {
    await load();
    const back = page.getByTitle("Back to tools", { exact: true });
    if (await back.isVisible()) await back.click();
    await page.getByTitle("Add Line", { exact: true }).click();
    assert.equal(await page.locator('[data-line-id]').count(), 3);
    await page.getByTitle("Back to tools", { exact: true }).click();
    await page.getByTitle("Add Line", { exact: true }).dragTo(page.locator('.stage'), { targetPosition: { x: 430, y: 440 } });
    assert.equal(await page.locator('[data-line-id]').count(), 4);
    const data = await backup(), created = data.boards['lines-board'].connections.filter(item => !['free', 'attached'].includes(item.id));
    assert.equal(created.length, 2);
    assert(created.every(item => item.from === "" && item.to === "" && item.start && item.end));
  });
  await run("No browser runtime errors", async () => assert.deepEqual(errors, []));
  await page.screenshot({ path: path.join(artifacts, "lines-preview.png") });
} finally {
  await writeFile(path.join(artifacts, "lines-e2e-results.json"), JSON.stringify({ checkedAt: new Date().toISOString(), engine, url: process.env.TEST_URL || "http://127.0.0.1:5176", results, pageErrors: errors }, null, 2));
  await browser.close();
}
