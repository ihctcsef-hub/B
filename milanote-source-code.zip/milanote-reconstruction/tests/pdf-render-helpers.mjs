/** Test-only PDF.js renderer. This module is never imported by application code. */
export async function installPdfRenderer(page) {
  await page.evaluate(async()=>{
    const pdfjs=await import('/node_modules/pdfjs-dist/build/pdf.mjs');
    pdfjs.GlobalWorkerOptions.workerSrc='/node_modules/pdfjs-dist/build/pdf.worker.mjs';
    window.inspectRenderedPdf=async(bytes,{scale=1,pageNumber}={})=>{
      const loading=pdfjs.getDocument({data:new Uint8Array(bytes),isEvalSupported:false,useSystemFonts:false,disableFontFace:true});
      const pdf=await loading.promise,results=[];
      try{for(let number=pageNumber||1;number<=(pageNumber||pdf.numPages);number++){
        const page=await pdf.getPage(number),viewport=page.getViewport({scale}),canvas=document.createElement('canvas');
        canvas.width=Math.ceil(viewport.width);canvas.height=Math.ceil(viewport.height);
        const context=canvas.getContext('2d');await page.render({canvasContext:context,canvas,viewport}).promise;
        const rgba=context.getImageData(0,0,canvas.width,canvas.height).data;let ink=0;
        for(let at=0;at<rgba.length;at+=4)if(rgba[at]<220||rgba[at+1]<220||rgba[at+2]<220)ink++;
        const text=await page.getTextContent();
        results.push({page:number,width:canvas.width,height:canvas.height,ink,text:text.items.map(item=>item.str||'').join(''),image:canvas.toDataURL('image/png')});
        page.cleanup();
      }}finally{await pdf.destroy();}
      return results;
    };
  });
}
