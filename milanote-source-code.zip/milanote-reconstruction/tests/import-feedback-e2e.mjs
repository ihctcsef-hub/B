import assert from 'node:assert/strict';
import{mkdir,writeFile}from'node:fs/promises';
import{chromium,webkit}from'playwright-core';
const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium',url=process.env.TEST_URL||'http://127.0.0.1:5310',out=new URL(`../artifacts/import-feedback/${engine}/`,import.meta.url);await mkdir(out,{recursive:true});
const browser=await(engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']})),page=await browser.newPage(),results=[],errors=[];page.on('pageerror',e=>errors.push(e.message));
const message='Workspace imported. Undo to return to your previous workspace.',toast=()=>page.getByText(message,{exact:true}),file=()=>page.locator('input[type=file][accept="application/json,.json"]');
function fixture(title){return{version:1,id:'import-feedback',title,rootBoardId:'import-root',updatedAt:'2026-11-04T00:00:00Z',boards:{'import-root':{id:'import-root',title,cards:[],connections:[],viewport:{x:16,y:16,zoom:1}}}};}
async function upload(title,name='import-feedback.json'){await file().setInputFiles({name,mimeType:'application/json',buffer:Buffer.from(JSON.stringify(fixture(title)))});}
async function title(value){await page.waitForFunction(value=>document.querySelector('[aria-label="Current board title"]')?.value===value,value);}
async function run(name,action){await action();results.push({name,status:'passed'});console.log('PASS',name);}
try{
 await page.goto(url,{waitUntil:'domcontentloaded'});await page.getByText('Saved on this device',{exact:true}).waitFor();
 await run('Repeating the same success message starts a fresh 3500ms lifetime instead of inheriting the previous deadline',async()=>{
  const start=new Date('2026-11-04T00:00:00Z');await page.clock.install({time:start});await page.clock.pauseAt(new Date(start.getTime()+1000));
  await upload('Import alpha');await title('Import alpha');await toast().waitFor();await page.clock.runFor(3000);
  await upload('Import beta');await title('Import beta');await toast().waitFor();await page.clock.runFor(1000);assert.equal(await toast().isVisible(),true);
  await page.clock.runFor(2490);assert.equal(await toast().isVisible(),true);await page.clock.runFor(20);assert.equal(await toast().isVisible(),false);await page.clock.resume();
 });
 await run('A pending file read clears the earlier success and cannot claim that the new workspace has been imported',async()=>{
  await upload('Import beta');await title('Import beta');await toast().waitFor();
  await page.evaluate(()=>{const original=File.prototype.text;File.prototype.text=function(){if(this.name!=='delayed-import.json')return original.call(this);const file=this;return new Promise(resolve=>{window.__releaseImportText=async()=>resolve(await original.call(file));});};});
  await upload('Delayed import','delayed-import.json');await page.waitForFunction(()=>typeof window.__releaseImportText==='function');await toast().waitFor({state:'hidden'});await title('Import beta');
 });
 await run('The newest import wins a delayed completion; one Undo and Redo restore the preceding and latest workspaces',async()=>{
  await upload('Newest import');await title('Newest import');await toast().waitFor();await page.evaluate(()=>window.__releaseImportText());
  await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));await title('Newest import');
  await page.getByTitle('Undo (⌘Z)',{exact:true}).click();await title('Import beta');await page.getByTitle('Redo (⇧⌘Z)',{exact:true}).click();await title('Newest import');
 });
 assert.deepEqual(errors,[]);results.push({name:'No uncaught browser errors',status:'passed'});
}catch(error){results.push({name:'Import feedback regression',status:'failed',message:error.stack});process.exitCode=1;console.error(error);await page.screenshot({path:new URL('failure.png',out).pathname}).catch(()=>{});}finally{await writeFile(new URL('results.json',out),JSON.stringify({checkedAt:new Date().toISOString(),engine,url,results,errors},null,2));await browser.close();}
