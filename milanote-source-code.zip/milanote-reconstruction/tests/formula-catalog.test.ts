import { describe,it,expect } from 'vitest';
import { evaluateTableCell,tableFormulaNames } from '../src/core/spreadsheet';

const evaluate=(formula:string)=>evaluateTableCell([[formula]],0,0);
describe('documented Milanote formula gaps',()=>{
  it('uses the documented scalar SPLIT contract, including empty tokens and out-of-range indices',()=>{
    expect(evaluate('=SPLIT("Lorem ipsum",0)')).toBe('Lorem');
    expect(evaluate('=SPLIT("Lorem ipsum",1)')).toBe('ipsum');
    expect(evaluate('=SPLIT("Lorem  ipsum",1)')).toBe('');
    expect(evaluate('=SPLIT("Lorem ipsum",2)')).toBe('#VALUE!');
    expect(evaluate('=SPLIT("Lorem ipsum",-1)')).toBe('#VALUE!');
    expect(evaluate('=ISBINARY(1010)')).toBe(true);expect(evaluate('=ISBINARY(2)')).toBe(false);expect(evaluate('=ISBINARY("001")')).toBe(true);
  });
  it('counts blank references distinctly while retaining numeric text and letter case',()=>{
    expect(evaluate('=COUNTUNIQUE(1,1,"1",2,"","")')).toBe(3);
    expect(evaluate('=COUNTUNIQUE("","")')).toBe(0);
    expect(evaluate('=COUNTUNIQUE(1,"1")')).toBe(2);
    expect(evaluate('=COUNTUNIQUE("A","a")')).toBe(2);
    expect(evaluateTableCell([['1','1'],['2',''],['=COUNTUNIQUE(A1:B2)','']],2,0)).toBe(3);
  });
  it('introspects source formulas without evaluating referenced errors or self-reference cycles',()=>{
    const rows=[['=1/0','=ISFORMULA(A1)','=FORMULATEXT(A1)'],['text','=ISFORMULA(A2)','=FORMULATEXT(A2)']];
    expect(evaluateTableCell(rows,0,1)).toBe(true);expect(evaluateTableCell(rows,0,2)).toBe('=1/0');
    expect(evaluateTableCell(rows,1,1)).toBe(false);expect(evaluateTableCell(rows,1,2)).toBe('#N/A');
    expect(evaluate('=ISFORMULA(A1)')).toBe(true);expect(evaluate('=FORMULATEXT(A1)')).toBe('=FORMULATEXT(A1)');
    expect(evaluateTableCell(rows,0,1,{'0:0':{type:'text'}})).toBe(false);
    expect(evaluate('=ISREF(#REF!)')).toBe(true);expect(evaluate('=ISREF(1/0)')).toBe(false);
    expect(evaluateTableCell([['10','=ISREF(A1)']],0,1)).toBe(false);expect(evaluate('=ISREF(Z999)')).toBe(false);
  });
  it('provides the observed legacy statistical aliases with numerical accuracy',()=>{
    for(const[formula,value]of [['=CONFIDENCE(0.05,2,100)',.39199279691],['=POISSON(2,3,TRUE)',.42319008113],['=TDIST2T(2,10)',.073388034695],['=TINV2T(0.05,10)',2.2281388425],['=WEIBULL(1,2,3,TRUE)',.10516068319]] as const)expect(evaluate(formula)).toBeCloseTo(value,9);
    for(const name of ['ISBINARY','COUNTUNIQUE','SPLIT','ISFORMULA','FORMULATEXT','ISREF','CONFIDENCE','POISSON','TDIST2T','TINV2T','WEIBULL'])expect(tableFormulaNames).toContain(name);
  });
  it('formats serial dates and times in TEXT while retaining numeric formatting',()=>{
    expect(evaluate('=TEXT(45000,"yyyy-mm-dd")')).toBe('2023-03-15');
    expect(evaluate('=TEXT(DATE(2026,10,26),"mmm d, yyyy")')).toBe('100 26, 2026');
    expect(evaluate('=TEXT(0.5,"hh:mm")')).toBe('12:00');
    expect(evaluate('=TEXT(0.625,"h:mm AM/PM")')).toBe('3:00 PM');
    expect(evaluate('=TEXT(12.3,"0.00")')).toBe('12.30');
    expect(evaluate('=TEXT(45000,"dddd, mmmm dd, yyyy")')).toBe('1515, 0300 15, 2023');
  });
});
