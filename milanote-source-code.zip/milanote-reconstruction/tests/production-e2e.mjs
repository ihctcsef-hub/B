import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { chromium,webkit } from 'playwright-core';

const url=process.env.TEST_URL||'http://127.0.0.1:5190';
const artifacts=new URL('../artifacts/',import.meta.url);
await mkdir(artifacts,{recursive:true});
const buildHash=createHash('sha256').update(await readFile(new URL('../dist/index.html',import.meta.url))).digest('hex');
const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium';
const browser=await (engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']}));
const artifactTag=engine==='webkit'?'working-webkit':'working';
const base={x:100,y:100,width:270,height:150,z:1};
const fixture={version:1,id:'production-workspace',title:'Creative project',rootBoardId:'root',updatedAt:'2026-10-25T00:00:00Z',boards:{root:{id:'root',title:'Creative project',background:'#ebedee',grid:true,viewport:{x:20,y:20,zoom:1},cards:[
  {...base,id:'note',type:'note',text:'أفكار تستحق مساحة\nA little room for big ideas.',html:'<h2>أفكار تستحق مساحة</h2><p>A little room for <strong>big ideas.</strong></p><aside data-note-callout="true"><p>Collect. Arrange. Create.</p></aside>',height:170,color:'#fff3bc'},
  {...base,id:'photo',type:'image',x:410,width:285,height:330,src:'/assets/studio-objects.jpg',caption:'Objects, textures & inspiration'},
  {...base,id:'tasks',type:'todo',x:740,title:'Make it happen',height:154,items:[{id:'task1',text:'Collect references',done:true},{id:'task2',text:'Explore a visual direction',done:false},{id:'task3',text:'Review colors and details',done:false,indent:1,dueDate:'2026-11-05',reminderTime:'09:00'}]},
  {...base,id:'table',type:'table',y:325,height:94,title:'',rows:[['Item','Budget','Actual'],['Materials','120','95'],['Lighting','80','75'],['Total','=SUM(B2:B3)','=SUM(C2:C3)']],cellMeta:{'0:0':{bold:true,color:'#eef2f8'},'0:1':{bold:true,color:'#eef2f8'},'0:2':{bold:true,color:'#eef2f8'},'3:1':{type:'currency'},'3:2':{type:'currency'}}},
  {...base,id:'document',type:'note',x:740,y:300,height:150,isDocument:true,title:'Project brief',text:'A calm, thoughtful studio. Natural materials, quiet details, and space to create.',html:'<p>A calm, thoughtful studio. Natural materials, quiet details, and space to create.</p>'},
  {...base,id:'swatch',type:'swatch',x:740,y:490,width:160,height:160,value:'#b7c3a5',label:'Sage',colorSpace:'hex',showCaption:true,showValue:true},
  {...base,id:'swatch2',type:'swatch',x:925,y:490,width:160,height:160,value:'#d9ae86',label:'Warm oak',colorSpace:'rgb',showCaption:true,showValue:true},
],connections:[{id:'line',from:'',to:'',start:{x:100,y:490},end:{x:360,y:490},control:{x:230,y:540},color:'#75816c',style:'dashed',width:1.6,label:'A new direction',endArrow:true}]}}};
const results=[],errors=[],external=[],failed=[];
async function importFixture(page){
  await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'production.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(fixture))});
  await page.getByText('Workspace imported. Undo to return to your previous workspace.',{exact:true}).waitFor();
  await page.getByText('Saved on this device',{exact:true}).waitFor({state:'attached'});
}
async function run(name,callback){await callback();results.push({name,status:'passed'});console.log('PASS',name);}
const context=await browser.newContext({viewport:{width:1440,height:1000},acceptDownloads:true});
context.on('request',request=>{const target=new URL(request.url());if(['http:','https:'].includes(target.protocol)&&target.origin!==new URL(url).origin)external.push(target.origin);});
const page=await context.newPage();page.setDefaultTimeout(12000);page.on('pageerror',error=>errors.push(error.message));page.on('response',response=>{if(response.status()>=400)failed.push({url:response.url(),status:response.status()});});
try{
  await run('Production loads bundled fonts and images with no external requests',async()=>{
    await page.goto(url,{waitUntil:'networkidle'});await page.evaluate(()=>document.fonts.ready);
    assert.equal(await page.locator('.app').count(),1);
    assert.equal(await page.evaluate(()=>[...document.images].every(image=>image.complete&&image.naturalWidth>0)),true);
    assert.equal(await page.evaluate(()=>document.fonts.check('12px Inter')),true);assert.deepEqual(external,[]);assert.deepEqual(failed,[]);
  });
  await run('Arabic rich content persists in production and renders after reload',async()=>{
    await importFixture(page);const note=page.locator('[data-card-id="note"]');await note.dblclick({position:{x:25,y:30}});
    await page.getByRole('textbox',{name:'Note text',exact:true}).fill('مساحة للأفكار\nتجربة تحفظ النص العربي');await page.keyboard.press('Escape');
    await page.getByText('Saved on this device',{exact:true}).waitFor({state:'attached'});await page.reload({waitUntil:'networkidle'});
    assert.match(await note.innerText(),/تجربة تحفظ النص العربي/);
    await importFixture(page);await page.evaluate(()=>document.fonts.ready);await page.locator('.toast').waitFor({state:'hidden'});await page.screenshot({path:new URL(`preview-${artifactTag}.png`,artifacts).pathname,fullPage:true});
  });
  await run('Portable HTML embeds images and editable JSON keeps all tool metadata',async()=>{
    await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();let pending=page.waitForEvent('download');pending.catch(()=>{});await page.getByRole('button',{name:/Board as HTML/}).click();let download=await pending;
    const destination=new URL('production-export.html',artifacts);await download.saveAs(destination.pathname);const html=await readFile(destination,'utf8');assert.match(html,/data:image\/jpeg;base64,/);assert.ok(!html.includes('src="/assets/'));
    pending=page.waitForEvent('download');pending.catch(()=>{});await page.getByRole('button',{name:/Workspace backup/}).click();download=await pending;const backup=new URL('production-workspace.json',artifacts);await download.saveAs(backup.pathname);const saved=JSON.parse(await readFile(backup,'utf8'));
    assert.equal(saved.boards.root.cards.find(card=>card.id==='document').isDocument,true);assert.equal(saved.boards.root.cards.find(card=>card.id==='tasks').items[2].indent,1);assert.equal(saved.boards.root.cards.find(card=>card.id==='table').rows[3][1],'=SUM(B2:B3)');assert.deepEqual(saved.boards.root.connections[0].control,{x:230,y:540});
    await page.keyboard.press('Escape');
  });
  await run('iPad-sized touch layout stays within the page and loads the same local tools',async()=>{
    const tablet=await browser.newContext({viewport:{width:1024,height:1366},isMobile:true,hasTouch:true,deviceScaleFactor:1});const tab=await tablet.newPage();tab.on('pageerror',error=>errors.push(error.message));await tab.goto(url,{waitUntil:'networkidle'});await importFixture(tab);await tab.evaluate(()=>document.fonts.ready);
    assert.equal(await tab.locator('[data-card-id]').count(),7);assert.equal(await tab.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth),true);await tab.locator('.toast').waitFor({state:'hidden'});await tab.screenshot({path:new URL(`ipad-${artifactTag}.png`,artifacts).pathname,fullPage:true});await tablet.close();
  });
  assert.deepEqual(errors,[]);assert.deepEqual(external,[]);assert.deepEqual(failed,[]);
}catch(error){results.push({name:'Production verification',status:'failed',message:error.stack});process.exitCode=1;console.error(error);await page.screenshot({path:new URL('production-failure.png',artifacts).pathname,fullPage:true}).catch(()=>{});}
finally{await writeFile(new URL(`production-${artifactTag}.json`,artifacts),JSON.stringify({checkedAt:new Date().toISOString(),url,engine,buildHash,results,errors,externalRequests:external,failedResponses:failed},null,2));await browser.close();}
