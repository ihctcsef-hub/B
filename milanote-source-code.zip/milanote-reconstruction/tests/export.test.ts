import { describe, it, expect, vi } from "vitest";
import { createCard, type Board, type Card } from "../src/core";
import { exportNotePlainText, renderNoteHtml } from "../src/core/text";
import * as imageEditing from "../src/core/imageEditing";
import {
  exportBoardHtml,
  exportBoardMarkdown,
  exportBoardSvg,
  exportBoardText,
  prepareBoardForExport,
} from "../src/export";

function card<T extends Card["type"]>(
  type: T,
  patch: Partial<Extract<Card, { type: T }>> = {},
): Extract<Card, { type: T }> {
  return { ...createCard(type), ...patch } as Extract<Card, { type: T }>;
}

function board(cards: Card[]): Board {
  return {
    id: "test-board",
    title: "Export <test>",
    cards,
    connections: [],
    viewport: { x: 0, y: 0, zoom: 1 },
  };
}
describe("visual exports", () => {
  it("escapes user text in HTML and SVG rather than interpreting markup", () => {
    const note = {
      ...createCard("note"),
      type: "note" as const,
      text: '</div><script>alert("x")</script><b>not markup</b>',
    };
    const table = {
      ...createCard("table"),
      type: "table" as const,
      title: '<img onerror="alert(1)">',
      rows: [["<th>", "& cell"]],
    };
    const source = board([note, table]);
    for (const output of [exportBoardHtml(source), exportBoardSvg(source)]) {
      expect(output).not.toContain("<script>");
      expect(output).not.toContain("<img onerror=");
      expect(output).toContain("&lt;script&gt;");
      expect(output).toContain("&amp; cell");
      expect(output).toContain("Export &lt;test&gt;");
    }
  });
  it("drops executable resource schemes and rejects style injection", () => {
    const link = {
      ...createCard("link"),
      type: "link" as const,
      title: "Open",
      description: "",
      url: "javascript:alert(1)",
      color: "red; background:url(https://bad.example)",
    };
    const image = {
      ...createCard("image"),
      type: "image" as const,
      src: "data:text/html;base64,PHNjcmlwdD4=",
      caption: '" onerror="alert(1)',
    };
    const source = board([link, image]);
    for (const output of [exportBoardHtml(source), exportBoardSvg(source)]) {
      expect(output).not.toContain('href="javascript:');
      expect(output).not.toContain('src="data:text/html');
      expect(output).not.toContain("background:url(");
      expect(output).not.toContain('onerror="alert(1)');
    }
  });
  it("includes negative-position content and omits children of collapsed columns", () => {
    const column = {
      ...createCard("column", -300, -200),
      type: "column" as const,
      title: "Collapsed",
      collapsed: true,
    };
    const child = {
      ...createCard("note", -280, -120),
      type: "note" as const,
      text: "Hidden content marker",
      parentId: column.id,
    };
    const visible = {
      ...createCard("note", -600, -500),
      type: "note" as const,
      text: "Visible content marker",
    };
    const source = board([column, child, visible]);
    const html = exportBoardHtml(source),
      svg = exportBoardSvg(source);
    expect(html).not.toContain("Hidden content marker");
    expect(svg).not.toContain("Hidden content marker");
    expect(html).toContain("Visible content marker");
    expect(svg).toContain('x="-600"');
    expect(svg).toMatch(/viewBox="-636 -606 /);
  });

  it("renders the supported note formatting without accepting source HTML or links", () => {
    const text =
      "# A **bold** idea\n\n*Soft* and `**literal** <script>`\n- First\n- Second\n\n3. Third\n4. Fourth";
    const rendered = renderNoteHtml(text);
    expect(rendered).toContain("<h1>A <strong>bold</strong> idea</h1>");
    expect(rendered).toContain(
      "<em>Soft</em> and <code>**literal** &lt;script&gt;</code>",
    );
    expect(rendered).toContain("<ul><li>First</li><li>Second</li></ul>");
    expect(rendered).toContain(
      '<ol start="3"><li>Third</li><li>Fourth</li></ol>',
    );
    const malicious = renderNoteHtml(
      "# **<img src=x onerror=alert(1)>**\n[click](javascript:alert(1))\n&lt;script&gt;",
    );
    expect(malicious).toContain(
      "<h1><strong>&lt;img src=x onerror=alert(1)&gt;</strong></h1>",
    );
    expect(malicious).not.toMatch(/<(?:img|script|a)\b/i);
    expect(malicious).toContain("&amp;lt;script&amp;gt;");
    expect(
      exportNotePlainText(
        "# C#\n**Bold** and _soft_ with `code`\n- A\n2. B\nfile_name",
      ),
    ).toBe("C#\nBold and soft with code\n• A\n2. B\nfile_name");
    const source = board([card("note", { text })]);
    expect(exportBoardHtml(source)).toContain(rendered);
    expect(exportBoardSvg(source)).toContain(rendered);
  });

  it("exports canonical rich notes with safe formatting and inline links", () => {
    const source = board([
      card("note", {
        text: "An outdated text summary",
        html: '<h2 style="text-align: center;position:fixed">A <strong>bold</strong> idea</h2><p><em>Soft</em> and <u>underlined</u> and <s>old</s> with <a href="https://example.com/read?q=a&amp;b=c" onclick="alert(1)">a reference</a>.</p><ol start="3"><li><p>Third</p></li><li><p>Fourth</p></li></ol><p><a href="javascript:alert(1)">Unsafe link text</a><img src=x onerror=alert(1)></p><script>malicious script</script>',
      }),
    ]);
    for (const output of [exportBoardHtml(source), exportBoardSvg(source)]) {
      expect(output).toContain('<h2 style="text-align: center">A <strong>bold</strong> idea</h2>');
      expect(output).toContain("<em>Soft</em> and <u>underlined</u> and <s>old</s>");
      expect(output).toContain('href="https://example.com/read?q=a&amp;b=c" target="_blank" rel="noopener noreferrer"');
      expect(output).toContain('<ol start="3">');
      expect(output).toContain("Unsafe link text");
      expect(output).not.toMatch(/javascript:|onclick=|onerror=|position:fixed|malicious script/);
      expect(output).not.toContain("An outdated text summary");
    }
  });

  it("keeps explicit empty rich notes empty instead of reviving their old summary", () => {
    const source = board([card("note", { text: "Obsolete text", html: "" })]);
    for (const output of [
      exportBoardHtml(source), exportBoardSvg(source),
      exportBoardMarkdown(source), exportBoardText(source),
    ]) expect(output).not.toContain("Obsolete text");
  });

  it("writes rich hard breaks as valid XHTML in standalone SVG exports", () => {
    const source = board([card("note", { text: "", html: "<p>First<br>Second</p>" })]);
    expect(exportBoardHtml(source)).toContain("<p>First<br>Second</p>");
    expect(exportBoardSvg(source)).toContain("<p>First<br/>Second</p>");
    expect(exportBoardSvg(source)).not.toContain("<br>");
  });

  it("exports evaluated table values and safe cell formatting", () => {
    const source = board([card("table", {
      title: "Budget",
      rows: [
        ["Item", "Cost", "Share", "Done"],
        ["Plan", "12.5", "0.25", "true"],
        ["Total", "=SUM(B2,7.5)", "=C2*2", "=1/0"],
        ["Literal", "=B2", "0", "false"],
      ],
      cellMeta: {
        "0:1": { color: "#edf0df", align: "right", bold: false, italic: true },
        "1:1": { type: "currency", color: "#abc", align: "right", bold: true, italic: true },
        "1:2": { type: "percentage" },
        "1:3": { type: "checkbox" },
        "2:1": { type: "currency" },
        "2:2": { type: "percentage" },
        "3:1": { type: "text" },
        "3:3": { type: "checkbox" },
      },
    })]);
    const original = structuredClone(source);
    for (const output of [exportBoardHtml(source), exportBoardSvg(source)]) {
      expect(output).toContain('<td dir="auto" style="background:#edf0df;text-align:right;font-weight:400;font-style:italic">Cost</td>');
      expect(output).toContain('<td dir="auto" style="background:#abc;text-align:right;font-weight:700;font-style:italic">$12.50</td>');
      for (const value of ["$20.00", "25%", "50%", "☑", "☐", "#DIV/0!", "=B2"])
        expect(output).toContain(`>${value}</td>`);
      expect(output).not.toContain("=SUM(B2,7.5)");
      expect(output).not.toContain("=C2*2");
    }
    expect(source).toEqual(original);
  });

  it("escapes evaluated table text and ignores forged cell styles", () => {
    const source = board([card("table", {
      rows: [["Header"], ['="<img src=x onerror=alert(1)>"']],
      cellMeta: {
        "0:0": { color: "red" },
        "1:0": {
          color: '#fff;position:fixed;background:url(https://bad.example)',
          align: "right;position:fixed" as "right",
          bold: "yes" as unknown as boolean,
          italic: true,
        },
      },
    })]);
    for (const output of [exportBoardHtml(source), exportBoardSvg(source)]) {
      expect(output).toContain('<td dir="auto" style="font-style:italic">&lt;img src=x onerror=alert(1)&gt;</td>');
      expect(output).not.toContain("<img src=x");
      expect(output).not.toMatch(/position:fixed|background:url|background:red/);
    }
  });

  it("requires preparation to flatten image edits and never interpolates them into CSS", () => {
    const source = board([
      card("image", {
        src: "https://example.com/original.png",
        imageEdits: {
          rotation: 90,
          crop: { x: 0.1, y: 0.2, width: 0.8, height: 0.6 },
          paths: [{ color: "#ed4b35", width: 0.01, points: [{ x: 0.2, y: 0.3 }] }],
        },
      }),
    ]);
    for (const output of [exportBoardHtml(source), exportBoardSvg(source)]) {
      expect(output).toContain('src="https://example.com/original.png"');
      expect(output).not.toContain("#ed4b35");
      expect(output).not.toContain("rotate(90");
    }
  });

  it("supports nested strike and underline while keeping inline code opaque", () => {
    const text =
      "~~old ++under **bold**++~~ and *italic **bold*** and **bold *italic***";
    const rendered =
      "<p><s>old <u>under <strong>bold</strong></u></s> and <em>italic <strong>bold</strong></em> and <strong>bold <em>italic</em></strong></p>";
    expect(renderNoteHtml(text)).toBe(rendered);
    expect(exportNotePlainText(text)).toBe(
      "old under bold and italic bold and bold italic",
    );
    expect(renderNoteHtml("~~before `~~` after~~ and ++`++`++")).toBe(
      "<p><s>before <code>~~</code> after</s> and <u><code>++</code></u></p>",
    );
    expect(renderNoteHtml("`~~<img onerror=x>~~ ++x++`")).toBe(
      "<p><code>~~&lt;img onerror=x&gt;~~ ++x++</code></p>",
    );
    expect(exportNotePlainText("`~~old~~ ++under++`")).toBe(
      "~~old~~ ++under++",
    );
    for (const output of [
      exportBoardHtml(board([card("note", { text })])),
      exportBoardSvg(board([card("note", { text })])),
    ]) {
      expect(output).toContain(rendered);
    }
  });

  it("keeps escaped, unmatched and empty markers literal and balances crossed input", () => {
    const escaped = String.raw`\~~literal\~~ \++literal\++ ~~a\~~b~~ ++a\++b++`;
    expect(renderNoteHtml(escaped)).toBe(
      "<p>~~literal~~ ++literal++ <s>a~~b</s> <u>a++b</u></p>",
    );
    expect(exportNotePlainText(escaped)).toBe(
      "~~literal~~ ++literal++ a~~b a++b",
    );
    for (const text of [
      "~~open",
      "++open",
      "~~ x~~",
      "++x ++",
      "++++",
      "~~~~",
    ]) {
      expect(renderNoteHtml(text)).toBe(`<p>${text}</p>`);
      expect(exportNotePlainText(text)).toBe(text);
    }
    expect(renderNoteHtml("~~strike ++under~~ end++")).toBe(
      "<p>~~strike <u>under~~ end</u></p>",
    );
    expect(exportNotePlainText("~~strike ++under~~ end++")).toBe(
      "~~strike under~~ end",
    );
  });

  it("escapes adversarial HTML inside every added format and handles deep nesting iteratively", () => {
    const text = "~~<svg/onload=alert(1)>~~ ++&lt;script&gt; \"&'++";
    expect(renderNoteHtml(text)).toBe(
      "<p><s>&lt;svg/onload=alert(1)&gt;</s> <u>&amp;lt;script&amp;gt; &quot;&amp;&#39;</u></p>",
    );
    expect(exportNotePlainText(text)).toBe(
      "<svg/onload=alert(1)> &lt;script&gt; \"&'",
    );
    const markers = Array.from({ length: 2000 }, (_, index) =>
      index % 2 ? "~~" : "++",
    );
    const nested = `${markers.join("")}safe${[...markers].reverse().join("")}`;
    const rendered = renderNoteHtml(nested);
    expect(exportNotePlainText(nested)).toBe("safe");
    expect(rendered).toMatch(/^<p><u><s>/);
    expect(rendered).toMatch(/<\/s><\/u><\/p>$/);
    expect((rendered.match(/<(?:s|u)>/g) ?? []).length).toBe(2000);
  });

  it("exports note alignment through a fixed style value", () => {
    for (const align of ["left", "center", "right"] as const) {
      const source = board([card("note", { text: "Aligned text", align })]);
      for (const output of [exportBoardHtml(source), exportBoardSvg(source)]) {
        expect(output).toContain(
          `class="pad text" dir="auto" style="text-align:${align}"`,
        );
      }
    }
    const forged = card("note", {
      text: "Aligned text",
      align: "center;position:fixed" as "center",
    });
    for (const output of [
      exportBoardHtml(board([forged])),
      exportBoardSvg(board([forged])),
    ]) {
      expect(output).toContain('style="text-align:left"');
      expect(output).not.toContain("center;position:fixed");
    }
  });

  it("retains valid attachment downloads and escapes their filenames", () => {
    const attachment = card("file", {
      name: 'brief" onclick="alert(1).pdf',
      mime: "application/pdf",
      size: 1024,
      dataUrl: "data:application/pdf;base64,JVBERi0=",
    });
    for (const output of [
      exportBoardHtml(board([attachment])),
      exportBoardSvg(board([attachment])),
    ]) {
      expect(output).toContain('href="data:application/pdf;base64,JVBERi0="');
      expect(output).toContain(
        'download="brief&quot; onclick=&quot;alert(1).pdf"',
      );
      expect(output).not.toContain(' onclick="');
    }
    for (const dataUrl of [
      "javascript:alert(1)",
      "blob:https://example.com/file",
      "https://example.com/file.pdf",
      "data:application/pdf;base64,not<base64>",
    ]) {
      expect(
        exportBoardHtml(board([{ ...attachment, dataUrl }])),
      ).not.toContain("Download attachment");
    }
    expect(
      exportBoardHtml(
        board([{ ...attachment, dataUrl: "data:text/plain,Hello%20world" }]),
      ),
    ).toContain('href="data:text/plain,Hello%20world"');
  });

  it("uses a collapsed column's visible height for the canvas and connection endpoints", () => {
    const column = card("column", {
      x: 0,
      y: 700,
      width: 280,
      height: 2000,
      collapsed: true,
    });
    const target = card("note", { x: 500, y: 700, width: 240, height: 170 });
    expect(exportBoardSvg(board([column]))).toContain(
      'viewBox="-36 -106 872 904.2"',
    );
    const source = board([column, target]);
    source.connections = [
      {
        id: "line",
        from: column.id,
        to: target.id,
        color: "#123456",
        width: 3,
        style: "dashed",
        bend: 0,
        label: "<flow>",
      },
    ];
    for (const output of [exportBoardHtml(source), exportBoardSvg(source)]) {
      expect(output).toContain('d="M 280 731.1 C 280 731.1, 500 785, 500 785"');
      expect(output).toContain('stroke-dasharray="5 5"');
      expect(output).toContain("&lt;flow&gt;");
    }
  });

  it("excludes unsorted cards and descendants from every export and preserves the board background", () => {
    const column = card("column", { unsorted: true, title: "Private column" });
    const child = card("note", { parentId: column.id, text: "Private child" });
    const grandchild = card("note", {
      parentId: child.id,
      text: "Private descendant",
    });
    const source = {
      ...board([
        column,
        child,
        grandchild,
        card("note", { text: "Published note" }),
      ]),
      background: "#edf2e8",
    };
    for (const output of [
      exportBoardHtml(source),
      exportBoardSvg(source),
      exportBoardText(source),
      exportBoardMarkdown(source),
    ]) {
      expect(output).not.toContain("Private");
      expect(output).toContain("Published note");
    }
    expect(exportBoardHtml(source)).toContain(
      '<body style="background:#edf2e8">',
    );
    expect(exportBoardSvg(source)).toContain('fill="#edf2e8"');
  });
});

describe("text exports", () => {
  it("exports formatted table results in Markdown and plain text while retaining raw formulas in backups", async () => {
    const source = board([card("table", {
      title: "Totals",
      rows: [
        ["Amount", "Rate", "Checked", "Error"],
        ["2.5", "0.125", "true", "=1/0"],
        ["=SUM(A2,7.5)", "=B2*2", "false", "=D3"],
      ],
      cellMeta: {
        "1:0": { type: "currency" }, "1:1": { type: "percentage" },
        "1:2": { type: "checkbox" }, "2:0": { type: "currency" },
        "2:1": { type: "percentage" }, "2:2": { type: "checkbox" },
      },
    })]);
    const original = structuredClone(source);
    const markdown = exportBoardMarkdown(source), plain = exportBoardText(source);
    expect(markdown).toContain("| $2\\.50 | 12\\.5% | ☑ | \\#DIV/0\\! |");
    expect(markdown).toContain("| $10\\.00 | 25% | ☐ | \\#CYCLE\\! |");
    expect(plain).toContain("$2.50\t12.5%\t☑\t#DIV/0!");
    expect(plain).toContain("$10.00\t25%\t☐\t#CYCLE!");
    for (const output of [markdown, plain]) {
      expect(output).not.toContain("=SUM(A2,7.5)");
      expect(output).not.toContain("=B2*2");
    }
    const fetchResource = vi.spyOn(globalThis, "fetch").mockRejectedValue(new Error("Offline fixture"));
    let backup: Board;
    try { backup = await prepareBoardForExport(source, { flattenImageEdits: false }); }
    finally { fetchResource.mockRestore(); }
    expect(backup).toEqual(original);
    expect(source).toEqual(original);
  });

  it("converts rich HTML to readable Markdown and plain text from the same canonical content", () => {
    const source = board([card("note", {
      text: "An outdated text summary",
      html: '<h2>Research</h2><p><strong>Bold</strong>, <em>soft</em>, <s>old</s>, and <u>underlined</u> <code>**literal**</code>.</p><ul><li><p>First</p></li><li><p>Second</p></li></ul><p><a href="https://example.com/read">Reference</a> <a href="data:text/html,bad">safe label</a></p>',
    })]);
    const markdown = exportBoardMarkdown(source), plain = exportBoardText(source);
    expect(markdown).toContain("## Research");
    expect(markdown).toContain("**Bold**, *soft*, ~~old~~, and ++underlined++ `**literal**`.");
    expect(markdown).toContain("- First\n- Second");
    expect(markdown).toContain("[Reference](https://example.com/read) safe label");
    expect(plain).toContain("Bold, soft, old, and underlined **literal**.");
    expect(plain).toContain("• First\n• Second");
    expect(plain).toContain("Reference safe label");
    for (const output of [markdown, plain]) {
      expect(output).not.toContain("An outdated text summary");
      expect(output).not.toContain("data:text/html");
      expect(output).not.toMatch(/<\/?(?:p|a|strong|h2)\b/);
    }
  });

  it("includes each card type with column grouping, checkboxes and a rectangular table", () => {
    const column = card("column", { title: "Research", x: 0, y: 0 });
    const source = board([
      column,
      card("note", {
        parentId: column.id,
        text: "**A useful finding**",
        y: 30,
      }),
      card("label", { text: "Direction", y: 10 }),
      card("todo", {
        title: "Actions",
        items: [
          { id: "done", text: "Read", done: true },
          { id: "open", text: "Write", done: false },
        ],
      }),
      card("table", {
        title: "Matrix",
        rows: [["A|B", "Details"], ["one\ntwo"]],
      }),
      card("link", {
        title: "Reference",
        url: "https://example.com/read",
        description: "Helpful source",
      }),
      card("image", {
        src: "https://example.com/image.jpg",
        caption: "Mood image",
      }),
      card("board", { title: "Next chapter", boardId: "nested-board" }),
      card("file", {
        name: "brief.pdf",
        mime: "application/pdf",
        size: 2048,
        dataUrl: "data:application/pdf;base64,JVBERi0=",
      }),
      card("swatch", { label: "Ocean", value: "#336699" }),
      card("sketch", {
        paths: [{ points: [{ x: 1, y: 2 }], color: "#333333", width: 2 }],
      }),
    ]);
    const markdown = exportBoardMarkdown(source),
      plain = exportBoardText(source);
    expect(markdown).toContain("## Research\n\n**A useful finding**");
    expect(markdown).toContain("- [x] Read\n- [ ] Write");
    expect(markdown).toContain(
      "| A\\|B | Details |\n| --- | --- |\n| one two |  |",
    );
    expect(markdown).toContain("[Reference](<https://example.com/read>)");
    expect(markdown).toContain("![Mood image](https://example.com/image.jpg)");
    expect(markdown).toContain(
      "[brief\\.pdf](<data:application/pdf;base64,JVBERi0=>)",
    );
    expect(plain).toContain("Research\n\nA useful finding");
    expect(plain).toContain("[x] Read\n[ ] Write");
    expect(plain).toContain("A|B\tDetails\none\ntwo");
    expect(plain).toContain("Nested board: Next chapter (nested-board)");
    for (const output of [plain, markdown]) {
      for (const text of [
        "Direction",
        "Helpful source",
        "Ocean",
        "Sketch: 1 stroke",
        "2048 bytes",
      ])
        expect(output).toContain(text);
    }
  });

  it("escapes raw HTML and unsupported links in note Markdown", () => {
    const markdown = exportBoardMarkdown(
      board([
        card("note", {
          text: "**Safe** <script>alert(1)</script> [bad](javascript:alert(1))",
        }),
      ]),
    );
    expect(markdown).toContain(
      "**Safe** &lt;script&gt;alert(1)&lt;/script&gt;",
    );
    expect(markdown).toContain("\\[bad\\](javascript:alert(1))");
    expect(markdown).not.toContain("<script>");
  });

  it("preserves strike and underline note markers in Markdown and strips them in plain text", () => {
    const source = board([
      card("note", { text: "~~Old~~ and ++underlined **new**++" }),
    ]);
    expect(exportBoardMarkdown(source)).toContain(
      "~~Old~~ and ++underlined **new**++",
    );
    expect(exportBoardText(source)).toContain("Old and underlined new");
  });
});

describe("portable resource preparation", () => {
  it("embeds shared local attachment and image bytes once without mutating the board", async () => {
    vi.stubGlobal("location", { href: "https://studio.example/workspace" });
    const fetchResource = vi
      .fn()
      .mockResolvedValue(
        new Response(new Blob(["file bytes"], { type: "text/plain" })),
      );
    vi.stubGlobal("fetch", fetchResource);
    try {
      const source = board([
        card("image", { src: "/upload/file" }),
        card("file", { dataUrl: "/upload/file" }),
      ]);
      const prepared = await prepareBoardForExport(source);
      expect(fetchResource).toHaveBeenCalledTimes(1);
      expect(prepared.cards[0]).toMatchObject({
        src: "data:text/plain;base64,ZmlsZSBieXRlcw==",
      });
      expect(prepared.cards[1]).toMatchObject({
        dataUrl: "data:text/plain;base64,ZmlsZSBieXRlcw==",
      });
      expect(source.cards[0]).toMatchObject({ src: "/upload/file" });
    } finally {
      vi.unstubAllGlobals();
    }
  });

  it("bakes embedded images once for visual exports and leaves the source board editable", async () => {
    const edits: imageEditing.ImageEdits = {
      rotation: 90,
      crop: { x: 0.1, y: 0.2, width: 0.8, height: 0.6 },
      paths: [{ color: "#ed4b35", width: 0.01, points: [{ x: 0.2, y: 0.3 }, { x: 0.6, y: 0.7 }] }],
    };
    const baked = "data:image/png;base64,YmFrZWQ=";
    const bake = vi.spyOn(imageEditing, "bakeImageEdits").mockResolvedValue(baked);
    vi.stubGlobal("location", { href: "https://studio.example/workspace" });
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(
      new Response(new Blob(["source image"], { type: "image/png" })),
    ));
    const source = board([card("image", { src: "/upload/source.png", imageEdits: edits })]);
    const original = structuredClone(source);
    try {
      const prepared = await prepareBoardForExport(source);
      expect(bake).toHaveBeenCalledExactlyOnceWith("data:image/png;base64,c291cmNlIGltYWdl", edits);
      expect(prepared.cards[0]).toMatchObject({ src: baked });
      expect(prepared.cards[0]).not.toHaveProperty("imageEdits");
      for (const output of [exportBoardHtml(prepared), exportBoardSvg(prepared)]) {
        expect(output).toContain(`src="${baked}"`);
      }
      await prepareBoardForExport(prepared);
      expect(bake).toHaveBeenCalledTimes(1);
      expect(source).toEqual(original);
    } finally {
      bake.mockRestore();
      vi.unstubAllGlobals();
    }
  });

  it("preserves source bytes and deeply cloned edits for editable JSON backups", async () => {
    const edits: imageEditing.ImageEdits = {
      rotation: 270,
      crop: { x: 0, y: 0.25, width: 1, height: 0.75 },
      paths: [{ color: "#123456", width: 0.02, points: [{ x: 0.4, y: 0.5 }] }],
    };
    const source = board([card("image", { src: "data:image/png;base64,c291cmNl", imageEdits: edits })]);
    const bake = vi.spyOn(imageEditing, "bakeImageEdits");
    try {
      const prepared = await prepareBoardForExport(source, { flattenImageEdits: false });
      expect(prepared).toEqual(source);
      expect(prepared).not.toBe(source);
      expect(prepared.viewport).not.toBe(source.viewport);
      expect(bake).not.toHaveBeenCalled();
      if (prepared.cards[0].type !== "image") throw new Error("Expected image");
      prepared.cards[0].imageEdits!.paths[0].points[0].x = 1;
      expect(edits.paths[0].points[0].x).toBe(0.4);
    } finally { bake.mockRestore(); }
  });

  it("rejects a failed edited-image bake instead of silently exporting the original", async () => {
    const edits = { ...imageEditing.defaultImageEdits(), rotation: 90 as const };
    const source = board([card("image", { src: "data:image/png;base64,c291cmNl", imageEdits: edits })]);
    const original = structuredClone(source);
    const bake = vi.spyOn(imageEditing, "bakeImageEdits").mockRejectedValue(new Error("Image export blocked"));
    try {
      await expect(prepareBoardForExport(source)).rejects.toThrow("Image export blocked");
      expect(source).toEqual(original);
    } finally { bake.mockRestore(); }
  });
});

describe("post-add customization exports", () => {
  it("honors image, link and swatch display options without deleting editable source metadata", async () => {
    const source = board([
      card("image", { src: "https://example.com/photo.png", caption: "Hidden photo caption", showCaption: false }),
      card("link", { title: "Hidden link title", url: "https://example.com", description: "Hidden link description", previewSrc: "https://example.com/preview.png", showPreview: false, showInfo: false, showCaption: true, caption: "Visible caption <safe>" }),
      card("swatch", { label: "Hidden swatch name", value: "#ff0000", showCaption: false, showValue: false }),
    ]);
    const before = structuredClone(source);
    for (const output of [exportBoardHtml(source), exportBoardSvg(source)]) {
      expect(output).not.toContain('<div class="caption" dir="auto">Hidden photo caption</div>');
      expect(output).not.toContain("Hidden link title");
      expect(output).not.toContain("Hidden link description");
      expect(output).not.toContain('src="https://example.com/preview.png"');
      expect(output).not.toContain("Visible caption &lt;safe&gt;");
      expect(output).not.toContain("Hidden swatch name");
      expect(output).not.toContain('<span class="swatch-code">');
    }
    expect(source).toEqual(before);
    // A backup keeps metadata even when its visual section is turned off.
    const fetchResource = vi.fn().mockImplementation(async () => new Response(new Blob(["fixture image bytes"], { type: "image/png" })));
    vi.stubGlobal("fetch", fetchResource);
    try {
      const backup = await prepareBoardForExport(source, { flattenImageEdits: false });
      expect(backup.cards[0]).toMatchObject({ caption: "Hidden photo caption", showCaption: false });
      expect(backup.cards[1]).toMatchObject({ showInfo: false, showCaption: true });
      expect(fetchResource.mock.calls.map(([url]) => url).sort()).toEqual(["https://example.com/photo.png", "https://example.com/preview.png"]);
      expect(source).toEqual(before);
    } finally {
      vi.unstubAllGlobals();
    }
  });

  it("renders selected color space and safe preview bytes, with independent caption controls", () => {
    const source = board([
      card("swatch", { value: "#ff0000", label: "Crimson", colorSpace: "rgb" }),
      card("swatch", { value: "#00ff00", label: "Leaf", colorSpace: "hsl", showCaption: false }),
      card("link", { previewSrc: "data:image/png;base64,aW1hZ2U=", showPreview: true, showInfo: false }),
      card("link", { previewSrc: "javascript:alert(1)", showPreview: true, showInfo: false }),
    ]);
    for (const output of [exportBoardHtml(source), exportBoardSvg(source)]) {
      expect(output).toContain('<span class="swatch-code">rgb(255, 0, 0)</span>');
      expect(output).toContain('<span class="swatch-code">hsl(120, 100%, 50%)</span>');
      expect(output).toContain('<div class="swatch-caption text" dir="auto" style="height:48px"><p>Crimson</p></div>');
      expect(output).not.toContain('<p>Leaf</p>');
      expect(output).toContain('src="data:image/png;base64,aW1hZ2U="');
      expect(output).not.toContain("javascript:alert");
    }
  });

  it("preserves nested task depths, due date/time and escaped labels in visual and text exports", () => {
    const source = board([card("todo", {
      title: "",
      items: [
        { id: "a", text: "Parent", done: false },
        { id: "b", text: "Child", done: true, indent: 1, dueDate: "2026-11-03", reminderTime: "13:45" },
        { id: "c", text: "Deep", done: false, indent: 2 },
      ],
      tags: ["Planning", "<img onerror=x>", "Planning"],
    })]);
    for (const output of [exportBoardHtml(source), exportBoardSvg(source)]) {
      expect(output).toContain('style="margin-inline-start:20px"');
      expect(output).toContain('style="margin-inline-start:40px"');
      expect(output).toContain('<small class="task-due">Due: 2026-11-03 13:45</small>');
      expect(output).toContain('aria-label="Item labels"><span dir="auto">Planning</span><span dir="auto">&lt;img onerror=x&gt;</span>');
      expect(output).not.toContain('<img onerror=x>');
      expect(output).not.toContain('<strong class="todo-title"');
    }
    const markdown = exportBoardMarkdown(source), text = exportBoardText(source);
    expect(markdown).toContain('- [ ] Parent\n  - [x] Child (Due: 2026\\-11\\-03 13:45)\n    - [ ] Deep');
    expect(markdown).toContain('Labels: Planning, &lt;img onerror=x&gt;');
    expect(text).toContain('[ ] Parent\n  [x] Child (Due: 2026-11-03 13:45)\n    [ ] Deep');
    expect(text).toContain('Labels: Planning, <img onerror=x>');
  });

  it("keeps default tables compact and treats the first row like every other cell", () => {
    const source = board([card("table", {
      width: 270, height: 94, title: "", rows: [["1", "2", "3"], ["4", "5", "6"], ["7", "8", "9"], ["10", "11", "12"]],
      cellMeta: { "0:0": { bold: false, verticalAlign: "bottom" } },
    })]);
    for (const output of [exportBoardHtml(source), exportBoardSvg(source)]) {
      expect(output).toContain('<div class="export-table"><table>');
      expect(output).toContain('<td dir="auto" style="vertical-align:bottom;font-weight:400">1</td>');
      expect(output).not.toContain('<th ');
      expect(output).not.toContain('<strong class="table-title"');
      expect((output.match(/<td\b/g) || []).length).toBe(12);
    }
  });

  it("exports independent start/end arrow flags and the observed dash spacing", () => {
    const a = card("note", { x: 0 }), b = card("note", { x: 400 });
    for (const [startArrow, endArrow] of [[true, false], [false, true], [true, true], [false, false]]) {
      const source = board([a, b]);
      source.connections = [{ id: "connector", from: a.id, to: b.id, color: "#323b4a", style: "dashed", startArrow, endArrow }];
      for (const output of [exportBoardHtml(source), exportBoardSvg(source)]) {
        expect(output.includes('marker-start="url(#export-arrow)"')).toBe(startArrow);
        expect(output.includes('marker-end="url(#export-arrow)"')).toBe(endArrow);
        expect(output).toContain('stroke-dasharray="5 5"');
      }
    }
  });

  it("embeds local link previews with the shared resource cache, even when hidden", async () => {
    vi.stubGlobal("location", { href: "https://studio.example/workspace" });
    const fetchResource = vi.fn().mockResolvedValue(new Response(new Blob(["image"], { type: "image/png" })));
    vi.stubGlobal("fetch", fetchResource);
    const source = board([
      card("image", { src: "/upload/shared.png" }),
      card("link", { previewSrc: "/upload/shared.png", showPreview: false }),
    ]);
    try {
      const prepared = await prepareBoardForExport(source, { flattenImageEdits: false });
      expect(fetchResource).toHaveBeenCalledTimes(1);
      expect(prepared.cards[1]).toMatchObject({ previewSrc: "data:image/png;base64,aW1hZ2U=", showPreview: false });
      expect(source.cards[1]).toMatchObject({ previewSrc: "/upload/shared.png" });
    } finally { vi.unstubAllGlobals(); }
  });
});

describe("documents and standalone lines", () => {
  it("exports document titles, canonical full content, callouts and synced state without reviving obsolete summaries", () => {
    const source = board([card("note", {
      isDocument: true, title: "Project brief <draft>", syncedId: "local-sync-group",
      text: "Obsolete summary",
      html: '<p>Full <strong>document</strong> text.</p><aside data-note-callout="true"><p>Remember this</p></aside><p>Last paragraph.</p>',
    })]);
    for (const output of [exportBoardHtml(source), exportBoardSvg(source)]) {
      expect(output).toContain('<h2 class="document-title">Project brief &lt;draft&gt;</h2>');
      expect(output).toContain('<aside data-note-callout="true"><p>Remember this</p></aside>');
      expect(output).toContain('<small class="note-sync">Synced note</small>');
      expect(output).toContain('<p>Last paragraph.</p>');
      expect(output).not.toContain("Obsolete summary");
      expect(output).not.toContain("local-sync-group");
    }
    expect(exportBoardMarkdown(source)).toContain('## Project brief &lt;draft&gt;\n\nSynced note\n\nFull **document** text.');
    expect(exportBoardMarkdown(source)).toContain('> [!NOTE]\n> Remember this');
    expect(exportBoardText(source)).toContain('Project brief <draft>\n\nSynced note\n\nFull document text.');
    for (const output of [exportBoardMarkdown(source), exportBoardText(source)]) {
      expect(output).toContain('Last paragraph.');
      expect(output).not.toContain('Obsolete summary');
    }
  });

  it("includes negative standalone line endpoints and caps inside the exported viewBox", () => {
    const source = board([]);
    source.connections = [{ id: "free", from: "", to: "", start: { x: -300, y: -200 }, end: { x: 1100, y: 800 }, style: "solid", color: "#323b4a", width: 1.6 }];
    for (const output of [exportBoardHtml(source), exportBoardSvg(source)]) expect(output).toContain('d="M -300 -200 L 1100 800"');
    expect(exportBoardSvg(source)).toContain('viewBox="-346 -316 1492 1162"');
  });

  it("includes a free curve's real extrema and positions its label on the curve", () => {
    const source = board([]);
    source.connections = [{ id: "curve", from: "", to: "", start: { x: 100, y: 100 }, end: { x: 300, y: 100 }, control: { x: 200, y: -300 }, label: "Curve", style: "dashed", color: "#323b4a" }];
    const svg = exportBoardSvg(source);
    expect(svg).toContain('d="M 100 100 Q 200 -300, 300 100"');
    // The quadratic curve peaks at y=-100; the text baseline is 8px above its midpoint.
    expect(svg).toContain('<text x="200" y="-108"');
    expect(svg).toContain('viewBox="-36 -230 872 766"');
  });

  it("represents enabled media embeds as safe portable links even with the other link sections hidden", () => {
    const source = board([card("link", {
      url: "https://youtu.be/dQw4w9WgXcQ", title: "Video", showMedia: true, showPreview: false, showInfo: false,
    })]);
    for (const output of [exportBoardHtml(source), exportBoardSvg(source)]) {
      expect(output).toContain('<div class="media-placeholder"><a href="https://youtu.be/dQw4w9WgXcQ"');
      expect(output).toContain('Open linked media ↗</a>');
      expect(output).not.toContain('<iframe');
      expect(output).not.toContain('youtube-nocookie.com');
    }
  });
});

describe('rich captions', () => {
  it('exports sanitized image/link caption marks and links in HTML, SVG and Markdown', () => {
    const rich='<p>A <strong>caption</strong> with <a href="https://example.com">a link</a><br>and a new line.</p><script>bad()</script>';
    const source=board([card('image',{caption:'A caption',captionHtml:rich,src:'https://example.com/image.png'}),card('link',{url:'https://example.com',caption:'A caption',captionHtml:rich,showCaption:true})]);
    for(const output of [exportBoardHtml(source),exportBoardSvg(source)]){
      expect(output).toContain('<strong>caption</strong>');
      expect(output).toContain('href="https://example.com/"');
      expect(output).not.toContain('<script>');
    }
    expect(exportBoardSvg(source)).toContain('<br/>');
    expect(exportBoardMarkdown(source)).toContain('A **caption** with [a link](https://example.com/)');
  });
  it('hides a link caption together with link information while retaining it in the editable model', () => {
    const source=board([card('link',{url:'https://example.com',caption:'Retained caption',captionHtml:'<p><em>Retained caption</em></p>',showCaption:true,showInfo:false,showPreview:false})]);
    expect(exportBoardHtml(source)).not.toContain('<em>Retained caption</em>');
    expect(source.cards[0]).toMatchObject({captionHtml:'<p><em>Retained caption</em></p>'});
  });
});


it('preserves independently sized table columns in portable snapshots',()=>{const source=board([card('table',{rows:[['A','B']],columnWidths:[120,60]})]);for(const output of [exportBoardHtml(source),exportBoardSvg(source)]){expect(output).toContain('<colgroup><col style="width:66.66666666666666%"/><col style="width:33.33333333333333%"/></colgroup>');}});
