/** Offline image comparison: no reference navigation, account access, or new dependency.
 * Input regions remain explicit; metrics never auto-approve reference parity. */
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';
import {chromium} from 'playwright-core';
const file=path.resolve(process.argv[2]||'artifacts/visual-parity/manifest.json'),manifest=JSON.parse(await readFile(file,'utf8'));
const out=path.resolve(path.dirname(file),manifest.outputDirectory||'comparison');await mkdir(out,{recursive:true});
const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']}),page=await browser.newPage();
const reports=[];
try{
 for(const pair of manifest.pairs){
  const reference=await readFile(path.resolve(path.dirname(file),pair.reference)),local=await readFile(path.resolve(path.dirname(file),pair.local));
  const result=await page.evaluate(async({reference,local,regions})=>{
   const load=async source=>{const img=new Image();img.src='data:image/png;base64,'+source;await img.decode();return img;};
   const [ref,loc]=await Promise.all([load(reference),load(local)]);if(ref.width!==loc.width||ref.height!==loc.height)throw Error('Screenshot dimensions differ; alignment must be explicit.');
   const output=[];
   for(const region of regions){
    const {x,y,width,height}=region;for(const value of [x,y,width,height])if(!Number.isInteger(value))throw Error('Regions require integer pixel geometry.');if(width<=0||height<=0||x<0||y<0||x+width>ref.width||y+height>ref.height)throw Error('Region outside screenshot.');
    const a=document.createElement('canvas'),b=document.createElement('canvas'),diff=document.createElement('canvas'),strip=document.createElement('canvas');a.width=b.width=diff.width=width;a.height=b.height=diff.height=height;strip.width=width*3;strip.height=height;
    const ac=a.getContext('2d'),bc=b.getContext('2d'),dc=diff.getContext('2d'),sc=strip.getContext('2d');ac.drawImage(ref,x,y,width,height,0,0,width,height);bc.drawImage(loc,x,y,width,height,0,0,width,height);const ap=ac.getImageData(0,0,width,height),bp=bc.getImageData(0,0,width,height),dp=dc.createImageData(width,height);
    let pixels=0,changed=0,changed16=0,sum=0,maximum=0,excluded=0;
    for(let py=0;py<height;py++)for(let px=0;px<width;px++){
     const at=(py*width+px)*4;if((region.exclusions||[]).some(r=>px>=r.x&&py>=r.y&&px<r.x+r.width&&py<r.y+r.height)){excluded++;dp.data.set([64,64,64,255],at);continue;}
     pixels++;let delta=0;for(let c=0;c<4;c++){const d=Math.abs(ap.data[at+c]-bp.data[at+c]);delta=Math.max(delta,d);if(c<3)sum+=d;}maximum=Math.max(maximum,delta);if(delta>0)changed++;if(delta>16)changed16++;
     const fade=Math.round((ap.data[at]+ap.data[at+1]+ap.data[at+2])/3*.35+165);dp.data.set(delta>16?[255,0,128,255]:[fade,fade,fade,255],at);
    }
    dc.putImageData(dp,0,0);sc.drawImage(a,0,0);sc.drawImage(b,width,0);sc.drawImage(diff,width*2,0);
    output.push({id:region.id,region,comparedPixels:pixels,excludedPixels:excluded,changedPixels:changed,changedPixelsOver16:changed16,exactDifferenceRatio:changed/pixels,differenceRatioOver16:changed16/pixels,meanAbsoluteRgbDelta:sum/(pixels*3),maxChannelDelta:maximum,reference:a.toDataURL(),local:b.toDataURL(),diff:diff.toDataURL(),triptych:strip.toDataURL()});
   }return {width:ref.width,height:ref.height,regions:output};
  },{reference:reference.toString('base64'),local:local.toString('base64'),regions:pair.regions});
  const regions=[];for(const region of result.regions){const prefix=`${pair.id}-${region.id}`;for(const kind of ['reference','local','diff','triptych'])await writeFile(path.join(out,`${prefix}-${kind}.png`),Buffer.from(region[kind].split(',')[1],'base64'));const {reference,local,diff,triptych,...metrics}=region;regions.push({...metrics,triptych:`${prefix}-triptych.png`,diff:`${prefix}-diff.png`});}
  reports.push({id:pair.id,sourceReference:pair.reference,sourceLocal:pair.local,width:result.width,height:result.height,state:pair.state,alignment:pair.alignment||'Same absolute screenshot coordinates',regions});
 }
 assert.ok(reports.length>0,'At least one comparison must be performed.');
}finally{await browser.close();}
await writeFile(path.join(out,'results.json'),JSON.stringify({checkedAt:new Date().toISOString(),viewport:manifest.viewport,renderer:'Chromium screenshot pixels, browser Canvas decoding; no smoothing or geometric registration',metrics:'Raw RGBA max-channel exact mismatch and >16-channel mismatch. The latter is a diagnostic, not an acceptance threshold.',referenceParityClaimed:false,pairs:reports,limitations:manifest.limitations||[]},null,2));
for(const pair of reports)for(const region of pair.regions)console.log(pair.id,region.id,`${(region.exactDifferenceRatio*100).toFixed(2)}% exact`,`${(region.differenceRatioOver16*100).toFixed(2)}% >16`,region.meanAbsoluteRgbDelta.toFixed(3));
