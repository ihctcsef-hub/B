import {describe,it,expect} from 'vitest';
import {chooseImageColor,colorImageSource,imageColorName,imagePalette,imagePixelColor,imagePointAt,visibleColorImages} from '../src/core/imageColors';
import type {Board,Card} from '../src/core/model';

describe('independent board image colors',()=>{
  it('finds visible image colors, ignores transparent pixels and chooses a different existing image color for a second swatch',()=>{
    const data=new Uint8ClampedArray([255,0,0,255,255,0,0,255,0,0,255,255,0,255,0,0]);
    const palette=imagePalette({data});expect(palette.map(item=>item.value)).toEqual(['#ff0000','#0000ff']);
    expect(chooseImageColor(palette,[])).toBe('#ff0000');expect(chooseImageColor(palette,['#ff0100'])).toBe('#0000ff');expect(chooseImageColor([],[])).toBeUndefined();
    expect(imageColorName('#ff0000')).toBe('Red');expect(imageColorName('#0000ff')).toBe('Blue');expect(imageColorName('#b7c3a5')).toBe('Rainee');
  });
  it('weights semitransparent colors and composites the picked pixel over the visible image background',()=>{
    const pixels={width:2,height:1,data:new Uint8ClampedArray([255,0,0,128,0,0,0,0])};expect(imagePalette(pixels)[0].value).toBe('#ff0000');
    expect(imagePixelColor(pixels,{x:0,y:0},'#0000ff')).toBe('#80007f');expect(imagePixelColor(pixels,{x:1,y:0},'#123456')).toBe('#123456');
  });
  it('maps image cover cropping without sampling captions or outside the image',()=>{
    const rect={x:100,y:200,width:100,height:100};expect(imagePointAt(rect,400,200,100,200)).toEqual({x:100,y:0});expect(imagePointAt(rect,400,200,150,250)).toEqual({x:200,y:100});
    expect(imagePointAt(rect,400,200,200,250)).toBeNull();expect(imagePointAt(rect,400,200,150,301)).toBeNull();
  });
  it('uses only visible board images and the active cutout rather than discarded or hidden originals',()=>{
    const image={id:'visible',type:'image',src:'original',cutoutSrc:'cutout',useCutout:true,x:0,y:0,width:100,height:100,z:1,caption:''} as const;
    const board:Board={id:'root',title:'Colors',viewport:{x:0,y:0,zoom:1},connections:[],cards:[image,{...image,id:'unsorted',unsorted:true},{id:'column',type:'column',title:'Closed',collapsed:true,x:0,y:0,width:100,height:100,z:1},{...image,id:'inside',parentId:'column'},{...image,id:'orphan',parentId:'missing'}] as Card[]};
    expect(visibleColorImages(board).map(card=>card.id)).toEqual(['visible']);expect(colorImageSource(image)).toBe('cutout');expect(colorImageSource({...image,useCutout:false})).toBe('original');
  });
});
