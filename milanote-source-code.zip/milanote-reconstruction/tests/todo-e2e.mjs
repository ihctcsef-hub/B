import assert from "node:assert/strict";
import { mkdir, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { chromium, webkit } from "playwright-core";

const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const artifacts = path.join(root, "artifacts", engine==='webkit'?'webkit':'.');
await mkdir(artifacts, { recursive: true });
const browser=await (engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({ executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium", headless: true, args: ["--no-sandbox", "--disable-dev-shm-usage"] }));
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true });
page.setDefaultTimeout(7000);
const results = [], errors = [];
page.on("pageerror", error => errors.push(error.message));
const card = page.locator('[data-card-id="todo-check"]');
const tasks = () => card.getByLabel("Task text", { exact: true });
const fixture = (items = [{ id: "a", text: "", done: false }]) => ({
  version: 1, id: "todo-workspace", title: "Task checks", rootBoardId: "todo-board", updatedAt: "2026-10-25T00:00:00.000Z",
  boards: { "todo-board": { id: "todo-board", title: "Task checks", cards: [{ id: "todo-check", type: "todo", title: "", items, x: 120, y: 100, width: 270, height: 54 + (items.length - 1) * 24, z: 1 }], connections: [], viewport: { x: 20, y: 20, zoom: 1 }, background: "#ebedee", grid: true } },
});
async function load(items) {
  await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({ name: "tasks.json", mimeType: "application/json", buffer: Buffer.from(JSON.stringify(fixture(items))) });
  await page.getByText("Workspace imported. Undo to return to your previous workspace.", { exact: true }).waitFor();
  await card.waitFor();
}
async function run(name, fn) {
  try { await fn(); results.push({ name, status: "passed" }); console.log("PASS", name); }
  catch (error) { results.push({ name, status: "failed", message: error.stack }); process.exitCode = 1; console.error("FAIL", name, error.message); await page.screenshot({ path: path.join(artifacts, `todo-failure-${results.length}.png`) }).catch(() => {}); await page.keyboard.press("Escape").catch(() => {}); }
}
try {
  await page.goto(process.env.TEST_URL || "http://127.0.0.1:5176");
  await page.getByLabel("Current board title").waitFor();
  await run("New task list keeps the measured 270×54 default with no title", async () => {
    await load();
    assert.equal(await tasks().count(), 1);
    assert.equal(await tasks().first().getAttribute("placeholder"), "Add a task…");
    assert.equal(await card.getByLabel("To-do list title").count(), 0);
    const rect = await card.boundingBox();
    assert.equal(Math.round(rect.width), 270); assert.equal(Math.round(rect.height), 54);
  });
  await run("Enter splits at the caret; Tab and Shift+Tab indent without deleting text", async () => {
    await tasks().first().fill("FirstSecond");
    await tasks().first().evaluate(field => field.setSelectionRange(5, 5));
    await tasks().first().press("Enter");
    assert.deepEqual(await tasks().evaluateAll(fields => fields.map(field => field.value)), ["First", "Second"]);
    await tasks().nth(1).press("Tab");
    assert.equal(await card.locator('.todoEditor-row').nth(1).evaluate(row => parseFloat(row.style.paddingLeft)), 18);
    await tasks().nth(1).press("Shift+Tab");
    assert.equal(await card.locator('.todoEditor-row').nth(1).evaluate(row => parseFloat(row.style.paddingLeft)), 0);
    await tasks().nth(1).press("End");
    await tasks().nth(1).press("Shift+Enter");
    await tasks().nth(1).press("x");
    assert.equal(await tasks().nth(1).inputValue(), "Second\nx");
    assert((await card.boundingBox()).height >= 94);
  });
  await run("Title and due date controls save editable date/time metadata", async () => {
    await tasks().first().click();
    await page.getByTitle("To-do title", { exact: true }).click();
    await card.getByLabel("To-do list title").fill("Project tasks");
    await tasks().first().click();
    await page.getByTitle("Due date", { exact: true }).click();
    const dialog = page.getByRole("dialog", { name: "Task due date" });
    await dialog.getByLabel("Task due date", { exact: true }).fill("2026-11-12");
    await dialog.getByLabel("Task reminder time").fill("14:30");
    await dialog.getByRole("button", { name: "Done", exact: true }).click();
    assert.equal(await card.getByRole("button", { name: "Due 2026-11-12 at 14:30", exact: true }).count(), 1);
    await card.getByRole("checkbox", { name: "Complete task" }).first().click();
    assert.equal(await card.getByRole("checkbox", { name: "Mark incomplete" }).getAttribute("aria-checked"), "true");
    await page.waitForTimeout(900);
    await page.reload();
    await card.waitFor();
    assert.equal(await card.getByLabel("To-do list title").inputValue(), "Project tasks");
    assert.equal(await card.getByRole("button", { name: "Due 2026-11-12 at 14:30", exact: true }).count(), 1);
    assert.equal(await card.getByRole("checkbox", { name: "Mark incomplete" }).getAttribute("aria-checked"), "true");
  });
  await run("Nested task reorder moves children with their parent", async () => {
    await load([{ id: "a", text: "Parent", done: false }, { id: "b", text: "Child", done: false, indent: 1 }, { id: "c", text: "Other", done: false }]);
    await tasks().first().click();
    await tasks().first().press("Alt+ArrowDown");
    assert.deepEqual(await tasks().evaluateAll(fields => fields.map(field => field.value)), ["Other", "Parent", "Child"]);
    assert.equal(await card.locator('.todoEditor-row').nth(2).evaluate(row => parseFloat(row.style.paddingLeft)), 18);
    // A pointer drag of the parent back above Other keeps the nested child attached.
    const handle = await card.getByRole("button", { name: "Reorder task 2", exact: true }).boundingBox();
    const target = await card.locator('.todoEditor-row').first().boundingBox();
    await page.mouse.move(handle.x + handle.width / 2, handle.y + handle.height / 2);
    await page.mouse.down();
    await page.mouse.move(target.x + 30, target.y + 2, { steps: 12 });
    await page.mouse.up();
    assert.deepEqual(await tasks().evaluateAll(fields => fields.map(field => field.value)), ["Parent", "Child", "Other"]);
  });
  await run("Removing a due date and deleting a parent preserves its child", async () => {
    await tasks().first().click();
    await page.getByTitle("Due date", { exact: true }).click();
    const dialog = page.getByRole("dialog", { name: "Task due date" });
    await dialog.getByLabel("Task due date", { exact: true }).fill("2026-11-12");
    await dialog.getByRole("button", { name: "Remove due date", exact: true }).click();
    assert.equal(await card.locator('.todoEditor-due').count(), 0);
    await card.locator('.todoEditor-row').first().click({ button: "right" });
    await page.getByRole("menu", { name: "Task actions" }).getByRole("menuitem", { name: "Delete task", exact: true }).click();
    assert.deepEqual(await tasks().evaluateAll(fields => fields.map(field => field.value)), ["Child", "Other"]);
    assert.equal(await card.locator('.todoEditor-row').first().evaluate(row => parseFloat(row.style.paddingLeft)), 0);
    await tasks().nth(1).fill("");
    await tasks().nth(1).press("Backspace");
    assert.equal(await tasks().count(), 1);
  });
  await run("A later focus or pointer choice cancels queued task focus while normal add/delete focus still works", async () => {
    await load([{ id: "a", text: "Parent", done: false }, { id: "b", text: "Child", done: false, indent: 1 }, { id: "c", text: "Other", done: false }]);
    // Explicit test clock: hold application rAF callbacks to reproduce the old
    // post-delete focus race without depending on machine speed or a sleep.
    await page.evaluate(() => {
      const request = window.requestAnimationFrame.bind(window), cancel = window.cancelAnimationFrame.bind(window), held = new Map();
      let serial = -1, holding = true;
      window.requestAnimationFrame = callback => { if (!holding) return request(callback); const id = serial--; held.set(id, callback); return id; };
      window.cancelAnimationFrame = id => { if (held.has(id)) held.delete(id); else cancel(id); };
      window.__todoFocusClock = {
        count: () => held.size,
        hold: () => { holding = true; },
        flush: () => { holding = false; const callbacks = [...held.values()]; held.clear(); callbacks.forEach(callback => callback(performance.now())); },
        restore: () => { held.clear(); window.requestAnimationFrame = request; window.cancelAnimationFrame = cancel; },
      };
    });
    try {
      await card.locator('.todoEditor-row').first().click({ button: "right" });
      await page.getByRole("menu", { name: "Task actions" }).getByRole("menuitem", { name: "Delete task", exact: true }).click();
      assert.deepEqual(await tasks().evaluateAll(fields => fields.map(field => field.value)), ["Child", "Other"]);
      assert.ok(await page.evaluate(() => window.__todoFocusClock.count()) > 0);
      await tasks().nth(1).fill("Other remains");
      await tasks().nth(1).evaluate(field => field.setSelectionRange(5, 5));
      await page.evaluate(() => window.__todoFocusClock.flush());
      assert.deepEqual(await tasks().nth(1).evaluate(field => ({ active: document.activeElement === field, cursor: field.selectionStart })), { active: true, cursor: 5 });
      await page.keyboard.type("!");
      assert.deepEqual(await tasks().evaluateAll(fields => fields.map(field => field.value)), ["Child", "Other! remains"]);

      await page.evaluate(() => window.__todoFocusClock.hold());
      await tasks().first().press("End"); await tasks().first().press("Enter");
      assert.equal(await tasks().count(), 3);
      assert.ok(await page.evaluate(() => window.__todoFocusClock.count()) > 0);
      await page.locator('.stage').click({ position: { x: 1000, y: 700 } });
      const activeBefore = await page.evaluate(() => document.activeElement?.id || document.activeElement?.tagName);
      await page.evaluate(() => window.__todoFocusClock.flush());
      assert.equal(await page.evaluate(() => document.activeElement?.id || document.activeElement?.tagName), activeBefore);

      await tasks().nth(1).fill("Ready");
      const previousLast = await tasks().last().getAttribute("id");
      await card.getByRole("button", { name: "Add a task", exact: true }).click();
      await page.waitForFunction(id => { const fields = [...document.querySelectorAll('[aria-label="Task text"]')]; return fields.length === 4 && document.activeElement === fields[3] && fields[3].id !== id; }, previousLast);
      await page.keyboard.type("Normal focus");
      assert.equal(await tasks().last().inputValue(), "Normal focus");
      await tasks().last().fill(""); await tasks().last().press("Backspace");
      assert.equal(await tasks().count(), 3);
      await page.waitForFunction(id => document.activeElement?.id === id, previousLast);
      assert.equal(await tasks().last().inputValue(), "Other! remains");
    } finally { await page.evaluate(() => window.__todoFocusClock?.restore()); }
  });
  await run("No browser runtime errors", async () => assert.deepEqual(errors, []));
  await page.screenshot({ path: path.join(artifacts, "todo-preview.png") });
} finally {
  await writeFile(path.join(artifacts, "todo-e2e-results.json"), JSON.stringify({ checkedAt: new Date().toISOString(), engine, url: process.env.TEST_URL || "http://127.0.0.1:5176", results, pageErrors: errors }, null, 2));
  await browser.close();
}
