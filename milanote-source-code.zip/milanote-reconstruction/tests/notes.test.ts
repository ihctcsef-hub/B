import { describe, expect, it } from 'vitest';
import { createCard, createWorkspace, updateBoard } from '../src/core/model';
import { applyNoteContent, createSyncedNote, syncedNoteLocations } from '../src/core/notes';
import { exportWorkspace, importWorkspace } from '../src/core/storage';
import { trashCards, restoreTrashEntry } from '../src/core/trash';
import type { Workspace } from '../src/core/model';

function fixture():Workspace{return {version:1,id:'synced-study',title:'Synced study',rootBoardId:'root',updatedAt:'2026-10-26T00:00:00Z',boards:{
  root:{id:'root',title:'Current board',viewport:{x:0,y:0,zoom:1},connections:[],cards:[
    {id:'source',type:'note',text:'Before deletion',html:'<p>Before deletion</p>',syncedId:'shared',x:100,y:100,width:270,height:54,z:1},
    {id:'child-tile',type:'board',title:'Other board',boardId:'child',x:600,y:100,width:160,height:160,z:2},
  ]},
  child:{id:'child',title:'Other board',parentBoardId:'root',viewport:{x:0,y:0,zoom:1},connections:[],cards:[
    {id:'copy',type:'note',text:'Before deletion',html:'<p>Before deletion</p>',syncedId:'shared',x:340,y:220,width:310,height:80,z:3,color:'#ff5757',stripColor:'#4ebafd',unsorted:true},
  ]},
}};}

describe('synced local notes', () => {
  it('updates linked note content across boards and leaves independent notes and template snapshots alone', () => {
    let workspace = createWorkspace();
    const note = workspace.boards[workspace.rootBoardId].cards.find(card => card.type === 'note')!;
    const linked = createSyncedNote(workspace, workspace.rootBoardId, note.id);
    const childId = Object.keys(workspace.boards).find(id => id !== workspace.rootBoardId)!;
    const copy = linked.workspace.boards[workspace.rootBoardId].cards.find(card => card.id === linked.id)!;
    workspace = updateBoard(linked.workspace, childId, board => ({ ...board, cards: [...board.cards, { ...copy, id: 'across-board' }] }));
    const result = applyNoteContent(workspace, workspace.rootBoardId, note.id, { text: 'Changed', html: '<p><strong>Changed</strong></p>' }, 54);
    expect(result.boards[childId].cards.find(card => card.id === 'across-board')).toMatchObject({ text: 'Changed', html: '<p><strong>Changed</strong></p>' });
    expect(result.boards[childId].cards[0]).toEqual(workspace.boards[childId].cards[0]);
    expect(importWorkspace(exportWorkspace(result))).toEqual(result);
    expect(workspace.boards[workspace.rootBoardId].cards.find(card => card.id === note.id)).not.toMatchObject({ text: 'Changed' });
  });
  it('creates an editable linked copy at the observed sixteen-pixel offset without mutating the original workspace',()=>{
    const before=fixture(),snapshot=structuredClone(before),created=createSyncedNote(before,'root','source');
    expect(created.workspace.boards.root.cards.find(card=>card.id===created.id)).toMatchObject({type:'note',syncedId:'shared',x:116,y:116,width:270,text:'Before deletion'});
    expect(syncedNoteLocations(created.workspace,'shared').reduce((count,location)=>count+location.noteIds.length,0)).toBe(3);
    expect(before).toEqual(snapshot);
  });
  it('groups active copy locations by board and includes Unsorted while excluding recoverable deleted copies',()=>{
    const before=fixture(),locations=syncedNoteLocations(before,'shared');
    expect(locations).toEqual([{boardId:'root',title:'Current board',icon:undefined,noteIds:['source'],unsorted:false},{boardId:'child',title:'Other board',icon:undefined,noteIds:['copy'],unsorted:true}]);
    const deleted=trashCards(before,'child',['copy'],'2026-10-26');
    expect(syncedNoteLocations(deleted,'shared').flatMap(location=>location.noteIds)).toEqual(['source']);
    expect(deleted.trash?.[0].cards[0]).toMatchObject({id:'copy',syncedId:'shared',text:'Before deletion'});
    expect(syncedNoteLocations(before,undefined)).toEqual([]);
  });
  it('restores a deleted copy into the live group with current content and its own appearance, retaining the original Trash snapshot',()=>{
    const deleted=trashCards(fixture(),'child',['copy'],'2026-10-26'),snapshot=structuredClone(deleted.trash![0]);
    const edited=applyNoteContent(deleted,'root','source',{text:'Edited while copy was deleted',html:'<p><strong>Edited while copy was deleted</strong></p>'},54);
    const restored=restoreTrashEntry(edited,edited.trash![0].id,{},'2026-10-27');
    expect(restored.boards.child.cards[0]).toMatchObject({id:'copy',text:'Edited while copy was deleted',html:'<p><strong>Edited while copy was deleted</strong></p>',color:'#ff5757',stripColor:'#4ebafd',x:340,y:220,width:310,height:80,unsorted:true});
    expect(syncedNoteLocations(restored,'shared').flatMap(location=>location.noteIds)).toEqual(['source','copy']);
    expect(edited.trash![0]).toEqual(snapshot);
    expect(importWorkspace(exportWorkspace(restored))).toEqual(restored);
  });
  it('reactivates copies in restored nested boards and leaves an explicitly unlinked note independent',()=>{
    const deleted=trashCards(fixture(),'root',['child-tile'],'2026-10-26');
    const edited=applyNoteContent(deleted,'root','source',{text:'New shared body',html:'<p>New shared body</p>'},54);
    const restored=restoreTrashEntry(edited,edited.trash![0].id,{},'2026-10-27');
    expect(restored.boards.child.cards[0]).toMatchObject({text:'New shared body',height:80,color:'#ff5757'});
    const separate=updateBoard(restored,'child',board=>({...board,cards:board.cards.map(card=>({...card,syncedId:undefined}))}));
    const next=applyNoteContent(separate,'root','source',{text:'Only linked notes change',html:'<p>Only linked notes change</p>'},54);
    expect(next.boards.child.cards[0]).toMatchObject({text:'New shared body',syncedId:undefined});
    expect(syncedNoteLocations(next,'shared').flatMap(location=>location.noteIds)).toEqual(['source']);
  });
});
