import { describe,expect,it } from 'vitest';
import { commitDrawing,drawingBounds,drawingHistory,drawingPathData,drawingPathsInRect,hitDrawingPath,redoDrawing,translateDrawingPaths,undoDrawing } from '../src/core/drawing';
import type { SketchPath } from '../src/core/model';
const paths:SketchPath[]=[{color:'#ff0000',width:4,points:[{x:10,y:20},{x:50,y:20}]},{color:'#000000',width:6,points:[{x:30,y:50}]}];
describe('drawing geometry and sessions',()=>{
  it('hit tests strokes and single-point marks from the top layer using screen-scaled tolerance',()=>{
    expect(hitDrawingPath(paths,{x:25,y:23},1)).toBe(0);
    expect(hitDrawingPath(paths,{x:30,y:52},0)).toBe(1);
    expect(hitDrawingPath(paths,{x:30,y:40},2)).toBeNull();
    expect(drawingPathData(paths[1].points)).toContain('l 0.01 0');
  });
  it('moves a selected group without distorting it, clamps the shared delta, and leaves original data alone',()=>{
    const moved=translateDrawingPaths(paths,[0,1],{x:100,y:-100},{width:100,height:100});
    expect(drawingBounds(moved)).toEqual({x:56,y:0,width:44,height:35});
    expect(moved[0].points[1].x-moved[0].points[0].x).toBe(40);
    expect(paths[0].points[0]).toEqual({x:10,y:20});
    expect(translateDrawingPaths(paths,[1],{x:4,y:5})[0]).toBe(paths[0]);
  });
  it('supports reverse selection rectangles and ignores empty strokes',()=>{
    expect(drawingPathsInRect(paths,{x:55,y:24,width:-50,height:-10})).toEqual([0]);
    expect(drawingBounds([{color:'#000',width:2,points:[]}])).toBeNull();
  });
  it('commits one completed gesture, clears redo after a branch, and keeps cancel outside committed history',()=>{
    const initial=drawingHistory(paths),moved=translateDrawingPaths(paths,[0],{x:3,y:4});
    const committed=commitDrawing(initial,moved);
    expect(committed.past).toHaveLength(1);
    const undone=undoDrawing(committed);expect(undone.present).toEqual(paths);
    expect(redoDrawing(undone).present).toEqual(moved);
    expect(commitDrawing(undone,paths.slice(1)).future).toEqual([]);
    expect(commitDrawing(initial,structuredClone(paths))).toBe(initial);
  });
});
