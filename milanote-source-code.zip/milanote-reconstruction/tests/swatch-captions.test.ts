import {describe,it,expect} from 'vitest';
import {unzipSync,strFromU8} from 'fflate';
import {createCard,createWorkspace,type Board,type Card} from '../src/core/model';
import {exportWorkspace,importWorkspace} from '../src/core/storage';
import {trashCards} from '../src/core/trash';
import {exportBoardHtml,exportBoardSvg,exportBoardText,exportBoardMarkdown} from '../src/export';
import {exportBoardWord} from '../src/core/exportFormats';

const rich = '<p><strong>Warm red</strong> <a href="https://example.com/swatch">caption</a></p><p>Second line</p>';
const makeSwatch = ():Extract<Card,{type:'swatch'}> => ({...createCard('swatch',100,100),type:'swatch',value:'#ff0000',label:'Warm red caption\nSecond line',captionHtml:rich,captionHeight:64,height:158});
const board=(cards:Card[]):Board=>({id:'swatch-board',title:'Swatch test',viewport:{x:0,y:0,zoom:1},cards,connections:[]});

describe('rich swatch captions',()=>{
 it('keeps legacy labels and rich caption layout through JSON, and sanitizes active and deleted swatch HTML on import',()=>{
  const ws=createWorkspace(),root=ws.boards[ws.rootBoardId],active=makeSwatch(),deleted={...makeSwatch(),id:'deleted-swatch'};
  active.captionHtml='<p><strong>Warm red</strong><script>bad()</script><a href="javascript:bad()"> caption</a><img src="https://bad.example" onerror="bad()"></p>';
  deleted.captionHtml=active.captionHtml;root.cards.push(active,deleted);
  const loaded=importWorkspace(exportWorkspace(trashCards(ws,root.id,[deleted.id]))),saved=loaded.boards[root.id].cards.find(card=>card.id===active.id);
  expect(saved).toMatchObject({type:'swatch',value:'#ff0000',label:active.label,captionHeight:64,height:158,captionHtml:'<p><strong>Warm red</strong> caption</p>'});
  expect(loaded.trash![0].cards.find(card=>card.id===deleted.id)).toMatchObject({captionHtml:'<p><strong>Warm red</strong> caption</p>',captionHeight:64});
  expect(exportWorkspace(loaded)).not.toMatch(/<script|javascript:|onerror|bad\.example/);
  const legacy={...createWorkspace()};legacy.boards={[legacy.rootBoardId]:{...legacy.boards[legacy.rootBoardId],connections:[],cards:[{...createCard('swatch'),type:'swatch',value:'#b7c3a5',label:'Legacy label'}]}};
  expect(importWorkspace(exportWorkspace(legacy)).boards[legacy.rootBoardId].cards[0]).toEqual(legacy.boards[legacy.rootBoardId].cards[0]);
 });
 it('rejects malformed rich caption metadata while retaining supported safe markup and hiding visual captions without deleting source',()=>{
  const ws=createWorkspace(),card=makeSwatch();ws.boards[ws.rootBoardId].cards=[card];
  const invalidHtml=JSON.parse(exportWorkspace(ws));invalidHtml.boards[ws.rootBoardId].cards[0].captionHtml=123;
  expect(()=>importWorkspace(JSON.stringify(invalidHtml))).toThrow('rich caption');
  const invalidHeight=JSON.parse(exportWorkspace(ws));invalidHeight.boards[ws.rootBoardId].cards[0].captionHeight=0;
  expect(()=>importWorkspace(JSON.stringify(invalidHeight))).toThrow('caption height');
  for(const output of [exportBoardHtml(board([card])),exportBoardSvg(board([card]))]){
   expect(output).toContain('<strong>Warm red</strong>');expect(output).toContain('href="https://example.com/swatch"');expect(output).toContain('style="height:64px"');
  }
  const hidden={...card,showCaption:false,showValue:false};
  for(const output of [exportBoardHtml(board([hidden])),exportBoardSvg(board([hidden]))]){
   expect(output).not.toContain('<strong>Warm red</strong>');expect(output).not.toContain('<span class="swatch-code">');
  }
  for(const output of [exportBoardText(board([card])),exportBoardMarkdown(board([card]))]){
   expect(output).toContain('Warm red caption');expect(output).toContain('Second line');expect(output).not.toContain('<strong>');
  }
  expect(card.captionHtml).toBe(rich);
 });
 it('writes editable rich swatch captions and safe links into Word while honoring hidden caption and value flags',async()=>{
  const card=makeSwatch();
  const contents=unzipSync(new Uint8Array(await(await exportBoardWord(board([card]))).arrayBuffer()));
  const xml=strFromU8(contents['word/document.xml']),rels=strFromU8(contents['word/_rels/document.xml.rels']);
  expect(xml).toContain('<w:b/>');expect(xml).toContain('Warm red');expect(xml).toContain('Second line');expect(xml).toContain('>#FF0000<');expect(xml).toContain('w:fill="FF0000"');expect(rels).toContain('https://example.com/swatch');
  const hidden=unzipSync(new Uint8Array(await(await exportBoardWord(board([{...card,showCaption:false,showValue:false}]))).arrayBuffer()));
  const hiddenXml=strFromU8(hidden['word/document.xml']);expect(hiddenXml).not.toContain('Warm red');expect(hiddenXml).not.toContain('>#FF0000<');expect(hiddenXml).toContain('w:fill="FF0000"');
  const dark=unzipSync(new Uint8Array(await(await exportBoardWord(board([{...card,value:'#000080'}]))).arrayBuffer()));
  const darkXml=strFromU8(dark['word/document.xml']);expect(darkXml).toMatch(/w:color w:val="FFFFFF"[^>]*\/>.*?#000080/s);expect(darkXml).toContain('w:fill="000080"');
 });
});
