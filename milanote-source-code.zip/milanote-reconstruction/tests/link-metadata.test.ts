import {describe,it,expect,vi} from 'vitest';
import {normalizeLinkUrl,fetchLinkMetadata,linkMetadataPatch} from '../src/core/linkMetadata';
import {createCard,type Card} from '../src/core/model';
import {importWorkspace,exportWorkspace} from '../src/core/storage';
type LinkCard=Extract<Card,{type:'link'}>;
const link=(extra:Partial<LinkCard>={}):LinkCard=>({...createCard('link'),type:'link',url:'https://example.com/',title:'example.com',description:'',...extra});
describe('link metadata client and provenance',()=>{
 it('normalizes credential-free web addresses without accepting active resource schemes',()=>{expect(normalizeLinkUrl(' HTTPS://EXAMPLE.COM/path#part ')).toBe('https://example.com/path#part');for(const value of ['javascript:alert(1)','file:///tmp/x','https://user:pass@example.com','bad url','x'.repeat(4097)])expect(normalizeLinkUrl(value)).toBeNull();});
 it('requests typed metadata without browser credentials and validates every returned field',async()=>{
  const controller=new AbortController(),fetcher=vi.spyOn(globalThis,'fetch').mockResolvedValue(new Response(JSON.stringify({url:'https://example.org/final',title:'<b>Page</b>',description:'Useful\n  words',image:'https://example.org/photo.png',html:'<script>bad()</script>'}),{headers:{'Content-Type':'application/json'}}));
  try{expect(await fetchLinkMetadata('https://example.com/',{signal:controller.signal})).toEqual({url:'https://example.org/final',title:'Page',description:'Useful words',image:'https://example.org/photo.png'});expect(fetcher).toHaveBeenCalledWith('/api/links/metadata?url=https%3A%2F%2Fexample.com%2F',{signal:controller.signal,credentials:'omit',headers:{Accept:'application/json'}});}finally{fetcher.mockRestore();}
 });
 it('surfaces unavailable/invalid responses without pretending to return details',async()=>{
  const fetcher=vi.spyOn(globalThis,'fetch');try{for(const response of [new Response('denied',{status:503}),new Response('<html>Static hosting fallback</html>'),new Response('{}'),new Response('{"url":"javascript:bad()"}')]){fetcher.mockResolvedValueOnce(response);await expect(fetchLinkMetadata('https://example.com/')).rejects.toThrow('unavailable');}fetcher.mockRejectedValueOnce(new TypeError('Network diagnostic detail'));await expect(fetchLinkMetadata('https://example.com/')).rejects.toThrow('unavailable');await expect(fetchLinkMetadata('file:///tmp/x')).rejects.toThrow('valid');}finally{fetcher.mockRestore();}
 });
 it('fills only automatic unchanged fields and records provenance without rewriting the original URL',()=>{
  const baseline=link(),metadata={url:'https://example.org/final',title:'Fetched title',description:'Fetched description',image:'https://example.org/image.png'};
  const patch=linkMetadataPatch(baseline,baseline,metadata);expect(patch).toEqual({title:metadata.title,description:metadata.description,previewSrc:metadata.image,linkMetadata:metadata});expect(patch).not.toHaveProperty('url');
 });
 it('preserves custom details made both before and during a fetch, including captions and display options',()=>{
  const baseline=link({title:'My custom title',description:'My words',previewSrc:'data:image/png;base64,abcd',caption:'Keep caption',showPreview:false}),metadata={url:baseline.url,title:'Fetched',description:'Remote words',image:'https://example.com/image.png'};
  expect(linkMetadataPatch(baseline,baseline,metadata)).toEqual({linkMetadata:metadata});
  const automatic=link();expect(linkMetadataPatch({...automatic,title:'Typed during request',previewSrc:'/own-image.png'},automatic,metadata)).toEqual({description:'Remote words',linkMetadata:metadata});
 });
 it('refreshes previously automatic values but ignores stale/locked targets and never clears fields absent from metadata',()=>{
  const old={url:'https://example.com/',title:'Old auto',description:'Old auto description',image:'https://example.com/old.png'},baseline=link({title:old.title,description:old.description,previewSrc:old.image,linkMetadata:old}),metadata={url:'https://example.com/new',title:'New auto'};
  const patch=linkMetadataPatch(baseline,baseline,metadata);expect(patch).toEqual({title:'New auto',linkMetadata:{...old,...metadata}});
  const next={...baseline,...patch};expect(linkMetadataPatch(next,next,{url:next.url,description:'Updated automatic description',image:'https://example.com/new.png'})).toMatchObject({description:'Updated automatic description',previewSrc:'https://example.com/new.png'});
  const customized={...next,description:'User custom after partial fetch'};expect(linkMetadataPatch(customized,customized,{url:next.url,description:'Remote next'})).not.toHaveProperty('description');
  for(const current of [{...baseline,locked:true},{...baseline,id:'different'},{...baseline,url:'https://other.example/'}])expect(linkMetadataPatch(current,baseline,metadata)).toEqual({});
 });
 it('round-trips validated fetched provenance, accepts legacy cards and rejects malformed metadata',()=>{
  const card=link({linkMetadata:{url:'https://example.com/final',title:'Fetched',description:'Description',image:'https://example.com/cover.png'}}),workspace={version:1 as const,id:'metadata',title:'Metadata',rootBoardId:'root',updatedAt:new Date().toISOString(),boards:{root:{id:'root',title:'Root',cards:[card],connections:[],viewport:{x:0,y:0,zoom:1}}}};
  expect(importWorkspace(exportWorkspace(workspace))).toEqual(workspace);
  const legacy=structuredClone(workspace);delete legacy.boards.root.cards[0].linkMetadata;expect(importWorkspace(exportWorkspace(legacy))).toEqual(legacy);
  for(const metadata of [null,[],{url:'javascript:bad()'},{url:'https://user:secret@example.com/'},{url:'https://example.com/',image:'file:///x'},{url:'https://example.com/',title:1}]){const invalid=structuredClone(workspace);Object.assign(invalid.boards.root.cards[0],{linkMetadata:metadata});expect(()=>importWorkspace(JSON.stringify(invalid))).toThrow('link metadata');}
 });
});
