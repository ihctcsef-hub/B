import {describe,it,expect} from 'vitest';
import {createFormulaWorkbook,reconcileFormulaWorkbook,formulaContextForTable,evaluateTableCell,evaluateTableCellDetails,evaluateTableDetails,evaluateTable,formatTableCell,tableFormulaNames} from '../src/core/spreadsheet';

const cell=(formula:string,context?:ReturnType<typeof formulaContextForTable>)=>evaluateTableCell([[formula]],0,0,{},context);
describe('transient formula workbook identity',()=>{
  it('rebuilds compact stable indices in load order without mutable shared state',()=>{
    const workbook=createFormulaWorkbook(['first','second','first']);
    expect(workbook.sheetCount).toBe(2);expect(workbook.tableIndices).toEqual({first:1,second:2});
    expect(Object.isFrozen(workbook)).toBe(true);expect(Object.isFrozen(workbook.tableIndices)).toBe(true);
    expect(cell('=SHEET()',formulaContextForTable(workbook,'second'))).toBe(2);
    expect(cell('=SHEETS()',formulaContextForTable(workbook,'second'))).toBe(2);
  });
  it('matches measured load/add/delete/undo/reload count sequence rather than current card count',()=>{
    const loaded=createFormulaWorkbook(['first']);
    const added=reconcileFormulaWorkbook(loaded,['first','second'],{createdTableIds:['second']});
    expect(loaded).toEqual({tableIndices:{first:1},sheetCount:1,creationSlotReserved:false});
    expect(added).toEqual({tableIndices:{first:1,second:3},sheetCount:3,creationSlotReserved:true});
    const deleted=reconcileFormulaWorkbook(added,['first']);
    expect(deleted).toBe(added);
    expect(cell('=SHEETS()',formulaContextForTable(deleted,'first'))).toBe(3);
    const undo=reconcileFormulaWorkbook(deleted,['first','second'],{createdTableIds:['second']});
    expect(undo).toBe(added);
    expect(cell('=SHEET()',formulaContextForTable(undo,'second'))).toBe(3);
    const reloaded=createFormulaWorkbook(['first','second']);
    expect(cell('=SHEET()',formulaContextForTable(reloaded,'second'))).toBe(2);
    expect(cell('=SHEETS()',formulaContextForTable(reloaded,'first'))).toBe(2);
  });
  it('reserves only one creation ghost per document, including a hard-reloaded empty board',()=>{
    const empty=createFormulaWorkbook([]),first=reconcileFormulaWorkbook(empty,['first'],{createdTableIds:['first']});
    expect(first.sheetCount).toBe(2);expect(first.tableIndices.first).toBe(2);
    const second=reconcileFormulaWorkbook(first,['first','second'],{createdTableIds:['second']});
    expect(second.sheetCount).toBe(3);expect(second.tableIndices).toEqual({first:2,second:3});
    const third=reconcileFormulaWorkbook(second,['first','second','third'],{createdTableIds:['third']});
    expect(third.sheetCount).toBe(4);expect(third.tableIndices.third).toBe(4);
    expect(first.sheetCount).toBe(2);
  });
  it('registers newly loaded tables once while retaining visited identities',()=>{
    const initial=createFormulaWorkbook(['a']),visited=reconcileFormulaWorkbook(initial,['b','c']);
    expect(visited.tableIndices).toEqual({a:1,b:2,c:3});
    expect(reconcileFormulaWorkbook(visited,['a'])).toBe(visited);
    expect(reconcileFormulaWorkbook(visited,['b','c'])).toBe(visited);
  });
  it('replacement imports explicitly rebuild even when table identifiers are reused',()=>{
    const old=reconcileFormulaWorkbook(createFormulaWorkbook(['x']),['x','y'],{createdTableIds:['y']});
    const replacement=createFormulaWorkbook(['y','x']);
    expect(cell('=SHEET()',formulaContextForTable(old,'y'))).toBe(3);
    expect(cell('=SHEET()',formulaContextForTable(replacement,'y'))).toBe(1);
  });
  it('handles arbitrary imported identifiers without prototype collisions',()=>{
    const workbook=createFormulaWorkbook(['__proto__','toString']);
    expect(workbook.sheetCount).toBe(2);expect(cell('=SHEET()',formulaContextForTable(workbook,'__proto__'))).toBe(1);
    expect(cell('=SHEET()',formulaContextForTable(workbook,'toString'))).toBe(2);
    expect(cell('=SHEET()',formulaContextForTable(workbook,'missing'))).toBe('#REF!');
  });
});
describe('reference-aware SHEET and SHEETS AST semantics',()=>{
  const workbook=createFormulaWorkbook(['first','current']),context=formulaContextForTable(workbook,'current');
  it('evaluates reference arguments without evaluating cell content or introducing self cycles',()=>{
    const rows=[['=1/0','=SHEET(A1)','=SHEETS(A1)'],['=SHEET(A2)','=SHEETS(B2)','=SHEET(A1:C2)']];
    expect(evaluateTable(rows,{},context)).toEqual([['#DIV/0!','2','1'],['2','1','2']]);
    expect(evaluateTableCell([['=SHEETS(A1:C2)']],0,0,{},context)).toBe(1);
  });
  it('preserves explicit reference errors and supports lazy recovery',()=>{
    expect(cell('=SHEET(#REF!)',context)).toBe('#REF!');
    expect(cell('=SHEETS(#REF!)',context)).toBe('#REF!');
    for(const formula of ['=SHEET(1/0)','=SHEETS(1/0)'])expect(evaluateTableCellDetails([[formula]],0,0,{},context).error).toEqual({code:'#DIV/0!',message:"Numbers can't be divided by zero"});
    for(const name of ['Sheet1','Sheet2','sheet1'])expect(evaluateTableCellDetails([[`=SHEET("${name}")`]],0,0,{},context).error).toEqual({code:'#N/A',message:'Sheet does not exist'});
    expect(cell('=IFERROR(SHEETS(1),"fallback")',context)).toBe('fallback');
    expect(cell('=IF(TRUE,SHEET(),SHEETS(1))',context)).toBe(2);
  });
  it('retains measured tooltip diagnostics separate from raw error codes',()=>{
    for(const formula of ['=SHEET(1)','=SHEET("x")'])expect(evaluateTableCellDetails([[formula]],0,0,{},context).error).toEqual({code:'#N/A',message:'Sheet does not exist'});
    for(const formula of ['=SHEETS(1)','=SHEETS("x")'])expect(evaluateTableCellDetails([[formula]],0,0,{},context).error).toEqual({code:'#VALUE!',message:'Cell reference expected'});
    expect(cell('=ISNA(SHEET(1))',context)).toBe(true);expect(cell('=ISERR(SHEET(1))',context)).toBe(false);
    expect(cell('=ISNA(SHEET(1,2))',context)).toBe(true);expect(cell('=ISNA(SHEETS(1))',context)).toBe(false);
    expect(evaluateTableCellDetails([['=SHEET(1,2)']],0,0,{},context).error?.message).toBe('Wrong number of arguments');
    expect(evaluateTableCellDetails([['=SHEETS(#REF!)']],0,0,{},context).error).toEqual({code:'#REF!',message:'#REF!'});
  });
  it('registers both functions and treats a standalone table as its own workbook',()=>{
    expect(tableFormulaNames).toContain('SHEET');expect(tableFormulaNames).toContain('SHEETS');
    expect(cell('=SHEET()')).toBe(1);expect(cell('=SHEETS()')).toBe(1);
    expect(cell('=SHEET()',formulaContextForTable(workbook,'missing'))).toBe('#REF!');
  });
});
describe('formula errors and presentation display',()=>{
  it('keeps evaluator error codes while allowing blank UI/export display',()=>{
    const rows=[['=1/0','=Z999','=SHEET(1)','= #REF!']],context=formulaContextForTable(createFormulaWorkbook(['t']),'t',{errorDisplay:'blank'});
    expect(evaluateTableCell(rows,0,0,{},context)).toBe('#DIV/0!');
    expect(evaluateTable(rows,{},context)).toEqual([['','','','']]);
    expect(formatTableCell(rows,0,0,{},context)).toBe('');
    expect(evaluateTableDetails(rows,{},context).map(row=>row.map(value=>value.error?.message))).toEqual([["Numbers can't be divided by zero",undefined,'Sheet does not exist','#REF!']]);
  });
  it('retains detailed error diagnostics through dependent cell references',()=>{
    const rows=[['=SHEETS(1)','=A1']];
    expect(evaluateTableCellDetails(rows,0,1).error).toEqual({code:'#VALUE!',message:'Cell reference expected'});
    expect(evaluateTableCell([['=SHEETS(1)','=IFERROR(A1,7)']],0,1)).toBe(7);
  });
  it('does not treat literal error-looking text or text cells as formula errors',()=>{
    const rows=[['#DIV/0!','=1/0']];
    expect(evaluateTableCellDetails(rows,0,0).error).toBeUndefined();
    expect(evaluateTableCellDetails(rows,0,1,{'0:1':{type:'text'}})).toEqual({value:'=1/0',display:'=1/0'});
    expect(evaluateTableCellDetails([['="#VALUE!"']],0,0)).toEqual({value:'#VALUE!',display:'#VALUE!'});
    expect(evaluateTableCell([['#DIV/0!','=ISERROR(A1)']],0,1)).toBe(true);
    expect(cell('=ISERROR("#REF!")')).toBe(false);
    expect(evaluateTableCell([['="#VALUE!"','=A1&" literal"']],0,1)).toBe('#VALUE! literal');
  });
});
