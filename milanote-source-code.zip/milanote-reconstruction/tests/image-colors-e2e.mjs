import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
import {chromium,webkit} from 'playwright-core';
const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium',base=process.env.TEST_URL||'http://127.0.0.1:5304';
const artifacts=new URL(`../artifacts/image-colors-${engine}/`,import.meta.url);await mkdir(artifacts,{recursive:true});
const browser=await(engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']}));
const context=await browser.newContext({viewport:{width:1440,height:1000}});await context.addInitScript(()=>Object.defineProperty(window,'EyeDropper',{value:undefined,configurable:true}));
await context.addInitScript(()=>{
 const originalPixels=CanvasRenderingContext2D.prototype.getImageData;
 CanvasRenderingContext2D.prototype.getImageData=function(...args){const result=originalPixels.apply(this,args);window.completedColorReads=(window.completedColorReads||0)+1;return result;};
 const originalRead=FileReader.prototype.readAsDataURL;
 FileReader.prototype.readAsDataURL=function(blob){
  const onload=this.onload;
  if(window.delayFileDelivery)this.onload=event=>{window.fileDeliveryReady=true;window.releaseFileDelivery=()=>{window.delayFileDelivery=false;onload?.call(this,event);};};
  return originalRead.call(this,blob);
 };
});
const page=await context.newPage();page.setDefaultTimeout(10000);const results=[],errors=[];page.on('pageerror',error=>errors.push(error.message));
const card=id=>page.locator(`[data-card-id="${id}"]`),picker=()=>page.getByRole('dialog',{name:'Edit swatch color',exact:true}),sampler=()=>page.getByRole('dialog',{name:'Pick a color from an image',exact:true});
const image=(src,extra={})=>({id:'image',type:'image',src,caption:'Image description',showCaption:false,x:100,y:100,width:300,height:200,z:1,...extra});
const swatch={id:'swatch',type:'swatch',value:'#b7c3a5',label:'Sage',x:600,y:160,width:160,height:180,z:2};
const fixture=(cards,title='Image colors',id='image-colors')=>({version:1,id,title,rootBoardId:'root',updatedAt:new Date().toISOString(),boards:{root:{id:'root',title,cards,connections:[],viewport:{x:20,y:20,zoom:1},background:'#ebedee'}}});
async function load(value){await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'image-colors.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(value))});await page.waitForFunction(()=>document.querySelector('input[type=file][accept="application/json,.json"]')?.value==='');await page.waitForFunction(title=>document.querySelector('[aria-label="Current board title"]')?.value===title,value.title);}
async function workspace(){return page.evaluate(()=>new Promise((resolve,reject)=>{const open=indexedDB.open('visual-workspace');open.onerror=()=>reject(open.error);open.onsuccess=()=>{const db=open.result,request=db.transaction('documents','readonly').objectStore('documents').get('workspace');request.onsuccess=()=>{resolve(request.result?.workspace);db.close();};request.onerror=()=>reject(request.error);};}));}
async function persisted(test){for(let i=0;i<100;i++){const data=await workspace();if(data?.boards?.root&&test(data))return data;await page.waitForTimeout(50);}throw Error('Expected image-color edits were not persisted');}
async function closePicker(){await picker().getByRole('button',{name:'Close color picker',exact:true}).click();await picker().waitFor({state:'hidden'});}
async function openPicker(){await card('swatch').getByRole('button',{name:'Color settings',exact:true}).click();await picker().waitFor();}
async function check(name,fn){try{await fn();results.push({name,status:'passed'});console.log('PASS',name);}catch(error){results.push({name,status:'failed',message:error.stack});process.exitCode=1;console.error('FAIL',name,error.message);await page.screenshot({path:new URL(`failure-${results.length}.png`,artifacts).pathname}).catch(()=>{});await page.keyboard.press('Escape').catch(()=>{});}}
try{
 await page.goto(base,{waitUntil:'networkidle'});await page.getByText('Saved on this device',{exact:true}).waitFor();
 const sources=await page.evaluate(()=>{const paint=(first,second)=>{const c=document.createElement('canvas');c.width=120;c.height=80;const ctx=c.getContext('2d');ctx.fillStyle=first;ctx.fillRect(0,0,80,80);ctx.fillStyle=second;ctx.fillRect(80,0,40,80);return c.toDataURL();};return {original:paint('#ff0000','#0000ff'),cutout:paint('#00ff00','#ffff00')};});
 await check('Adding two swatches chooses different visible image colors and names, with one-step Undo and reload persistence',async()=>{
  await load(fixture([image(sources.original),image(sources.cutout,{id:'hidden',unsorted:true})]));
  await page.getByTitle('Add Color',{exact:true}).click();await page.waitForFunction(()=>document.querySelectorAll('.world .card-swatch').length===1);
  let data=await persisted(doc=>doc.boards.root.cards.filter(card=>card.type==='swatch').length===1);let first=data.boards.root.cards.find(card=>card.type==='swatch');assert.equal(first.value,'#ff0000');assert.equal(first.label,'Red');
  await page.keyboard.press('Escape');await page.getByTitle('Add Color',{exact:true}).click();await page.waitForFunction(()=>document.querySelectorAll('.world .card-swatch').length===2);
  data=await persisted(doc=>doc.boards.root.cards.filter(card=>card.type==='swatch').length===2);const colors=data.boards.root.cards.filter(card=>card.type==='swatch');assert.deepEqual(colors.map(card=>card.value),['#ff0000','#0000ff']);assert.equal(colors[1].label,'Blue');
  await page.getByTitle('Undo (⌘Z)',{exact:true}).click();await page.waitForFunction(()=>document.querySelectorAll('.world .card-swatch').length===1);await page.getByTitle('Redo (⇧⌘Z)',{exact:true}).click();await page.waitForFunction(()=>document.querySelectorAll('.world .card-swatch').length===2);
  await persisted(doc=>doc.boards.root.cards.filter(card=>card.type==='swatch').length===2);await page.reload({waitUntil:'networkidle'});assert.equal(await page.locator('.world .card-swatch').count(),2);data=await workspace();assert.equal(data.boards.root.cards.find(card=>card.id==='image').src,sources.original);
 });
 await check('Board eyedropper works without a native EyeDropper and samples the active cutout after crop, rotation and annotation, outside caption and strip',async()=>{
  const edits={rotation:90,crop:{x:0,y:0,width:1,height:2/3},paths:[{color:'#0000ff',width:.3,points:[{x:1/3,y:.5}]}]};
  await load(fixture([image(sources.original,{width:240,height:294,showCaption:true,captionHeight:50,stripColor:'#ff5757',cutoutSrc:sources.cutout,useCutout:true,imageEdits:edits}),swatch]));await card('image').locator('svg.image-preview').waitFor();
  const rect=await card('image').locator('.image-preview').boundingBox();await openPicker();assert.equal(await picker().getByRole('button',{name:'Eyedropper',exact:true}).isEnabled(),true);await picker().getByRole('button',{name:'Eyedropper',exact:true}).click();await sampler().waitFor();
  await page.mouse.click(rect.x+rect.width/2,rect.y+rect.height/2);await sampler().waitFor({state:'hidden'});await page.waitForFunction(()=>document.querySelector('[aria-label="Swatch color value"]')?.value==='#0000ff');await closePicker();
  let data=await persisted(doc=>doc.boards.root.cards.find(card=>card.id==='swatch')?.value==='#0000ff');const saved=data.boards.root.cards.find(card=>card.id==='image');assert.equal(saved.src,sources.original);assert.equal(saved.cutoutSrc,sources.cutout);assert.deepEqual(saved.imageEdits,edits);assert.equal(saved.captionHeight,50);assert.equal(saved.stripColor,'#ff5757');
  await page.getByTitle('Undo (⌘Z)',{exact:true}).click();await persisted(doc=>doc.boards.root.cards.find(card=>card.id==='swatch')?.value==='#b7c3a5');await openPicker();await picker().getByRole('button',{name:'Eyedropper',exact:true}).click();await sampler().waitFor();await page.mouse.click(rect.x+rect.width/4,rect.y+rect.height/2);await sampler().waitFor({state:'hidden'});await page.waitForFunction(()=>document.querySelector('[aria-label="Swatch color value"]')?.value==='#00ff00');await closePicker();await persisted(doc=>doc.boards.root.cards.find(card=>card.id==='swatch')?.value==='#00ff00');await page.reload({waitUntil:'networkidle'});assert.equal(await card('swatch').locator('.colorSwatch-code').innerText(),'#00FF00');
 });
 await check('Cancel and Escape leave the current color and image unchanged; missing image resources report an error without replacing the swatch',async()=>{
  await openPicker();await picker().getByRole('button',{name:'Eyedropper',exact:true}).click();await sampler().waitFor();await sampler().getByRole('button',{name:'Cancel color sampling',exact:true}).click();await sampler().waitFor({state:'hidden'});assert.equal(await picker().getByLabel('Swatch color value',{exact:true}).inputValue(),'#00ff00');
  await picker().getByRole('button',{name:'Eyedropper',exact:true}).click();await sampler().waitFor();await page.keyboard.press('Escape');await sampler().waitFor({state:'hidden'});assert.equal(await picker().getByLabel('Swatch color value',{exact:true}).inputValue(),'#00ff00');await closePicker();
  await page.route('**/unreadable-color-image.png',route=>route.fulfill({status:403,contentType:'text/plain',body:'Fixture denies image access'}));await load(fixture([image('/unreadable-color-image.png'),swatch]));await openPicker();const rect=await card('image').locator('.image-preview').boundingBox();await picker().getByRole('button',{name:'Eyedropper',exact:true}).click();await sampler().waitFor();await page.mouse.click(rect.x+20,rect.y+20);await sampler().getByText(/could not be read|blocks color sampling/).waitFor();await sampler().getByRole('button',{name:'Cancel color sampling',exact:true}).click();assert.equal(await picker().getByLabel('Swatch color value',{exact:true}).inputValue(),'#b7c3a5');await closePicker();
 });
 await check('Sampling rejects an image hidden below another card, and a canceled pointer cannot apply a color on a later release',async()=>{
  await load(fixture([image(sources.original),swatch,{id:'cover',type:'note',text:'Covering the image',x:100,y:100,width:150,height:200,z:10,color:'#ffffff'}]));const rect=await card('image').locator('.image-preview').boundingBox();await openPicker();await picker().getByRole('button',{name:'Eyedropper',exact:true}).click();await sampler().waitFor();await page.mouse.click(rect.x+30,rect.y+30);await sampler().getByText('Choose a point on an image.',{exact:true}).waitFor();assert.equal(await picker().getByLabel('Swatch color value',{exact:true}).inputValue(),'#b7c3a5');
  await sampler().evaluate(root=>root.addEventListener('pointerdown',event=>window.samplingPointer=event.pointerId,{once:true}));await page.mouse.move(rect.x+rect.width*.9,rect.y+rect.height/2);await page.mouse.down();const pointerId=await page.evaluate(()=>window.samplingPointer);await sampler().dispatchEvent('pointercancel',{pointerId,isPrimary:true,pointerType:'mouse'});await page.mouse.up();assert.equal(await sampler().isVisible(),true);assert.equal(await picker().getByLabel('Swatch color value',{exact:true}).inputValue(),'#b7c3a5');await sampler().getByRole('button',{name:'Cancel color sampling',exact:true}).click();await closePicker();
 });
 await check('Overlapping images at the same layer sample the image actually painted on top',async()=>{
  await load(fixture([image(sources.original),image(sources.cutout,{id:'top-image'}),swatch]));const rect=await card('top-image').locator('.image-preview').boundingBox();await openPicker();await picker().getByRole('button',{name:'Eyedropper',exact:true}).click();await sampler().waitFor();await page.mouse.click(rect.x+rect.width/4,rect.y+rect.height/2);await sampler().waitFor({state:'hidden'});await page.waitForFunction(()=>document.querySelector('[aria-label="Swatch color value"]')?.value==='#00ff00');await closePicker();
 });
 await check('Importing even the same workspace cancels an in-flight swatch extraction so no delayed card appears in the replacement board',async()=>{
  let release;const gate=new Promise(resolve=>release=resolve),imageBytes=Buffer.from(sources.original.split(',')[1],'base64');await page.route('**/slow-color-image.png',async route=>{await gate;await route.fulfill({status:200,contentType:'image/png',body:imageBytes}).catch(()=>{});});
  await load(fixture([image('/slow-color-image.png')],'Slow image colors'));await page.getByTitle('Add Color',{exact:true}).click();await load(fixture([],'Replacement image colors'));release();await page.waitForTimeout(800);assert.equal(await page.locator('.world .card-swatch').count(),0);await persisted(doc=>doc.boards.root.title==='Replacement image colors'&&doc.boards.root.cards.length===0);
 });
 await check('A palette extraction finishing during a native card drag waits for that transaction and keeps both actions independently undoable',async()=>{
  let release,ready;const gate=new Promise(resolve=>release=resolve),requested=new Promise(resolve=>ready=resolve);let count=0;
  const bytes=Buffer.from(sources.original.split(',')[1],'base64');
  await page.route('**/color-drag-race.png',async route=>{if(++count>1){ready();await gate;}await route.fulfill({status:200,contentType:'image/png',headers:{'Cache-Control':'no-store'},body:bytes});});
  await load(fixture([image('/color-drag-race.png',{x:600,y:100}),{id:'moving',type:'note',text:'Move while colors are prepared',x:100,y:100,width:270,height:54,z:2}],'Color drag race'));
  const beforeReads=await page.evaluate(()=>window.completedColorReads||0);await page.getByTitle('Add Color',{exact:true}).click();await requested;
  const rect=await card('moving').boundingBox();await page.mouse.move(rect.x+3,rect.y+3);await page.mouse.down();await page.mouse.move(rect.x+43,rect.y+23,{steps:5});
  release();await page.waitForFunction(before=>(window.completedColorReads||0)>before,beforeReads);await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  assert.equal(await page.locator('.world .card-swatch').count(),0,'An asynchronous palette must not commit inside a drag preview');
  await page.mouse.move(rect.x+83,rect.y+43,{steps:5});await page.mouse.up();await page.waitForFunction(()=>document.querySelectorAll('.world .card-swatch').length===1);
  await persisted(doc=>doc.boards.root.cards.some(card=>card.type==='swatch')&&doc.boards.root.cards.find(card=>card.id==='moving')?.x===180);
  await page.getByTitle('Undo (⌘Z)',{exact:true}).click();let doc=await persisted(doc=>!doc.boards.root.cards.some(card=>card.type==='swatch'));assert.equal(doc.boards.root.cards.find(card=>card.id==='moving').x,180);
  await page.getByTitle('Undo (⌘Z)',{exact:true}).click();await persisted(doc=>doc.boards.root.cards.find(card=>card.id==='moving')?.x===100);
 });
 await check('An uploaded file delivered during a drag waits, preserves its bytes, and is canceled by a same-ID import',async()=>{
  const note={id:'moving',type:'note',text:'Upload while moving',x:100,y:100,width:270,height:54,z:2};await load(fixture([note],'Upload drag race'));await persisted(doc=>doc.boards.root.title==='Upload drag race'&&doc.boards.root.cards.length===1&&doc.boards.root.cards[0].id==='moving');
  await page.evaluate(()=>{window.delayFileDelivery=true;window.fileDeliveryReady=false;});
  const bytes=Buffer.from(sources.original.split(',')[1],'base64');await page.locator('input[type=file][multiple]').setInputFiles({name:'retained-colors.png',mimeType:'image/png',buffer:bytes});await page.waitForFunction(()=>window.fileDeliveryReady);
  const rect=await card('moving').boundingBox();await page.mouse.move(rect.x+3,rect.y+3);await page.mouse.down();await page.mouse.move(rect.x+43,rect.y+23,{steps:5});await page.evaluate(()=>window.releaseFileDelivery());await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  assert.equal((await workspace()).boards.root.cards.filter(card=>card.type==='image').length,0);
  await page.mouse.move(rect.x+83,rect.y+43,{steps:5});await page.mouse.up();let doc=await persisted(doc=>doc.boards.root.cards.some(card=>card.type==='image')&&doc.boards.root.cards.find(card=>card.id==='moving')?.x===180);const uploaded=doc.boards.root.cards.find(card=>card.type==='image');assert.equal(uploaded.src,sources.original);assert.equal(uploaded.unsorted,true);
  await page.getByTitle('Undo (⌘Z)',{exact:true}).click();doc=await persisted(doc=>!doc.boards.root.cards.some(card=>card.type==='image'));assert.equal(doc.boards.root.cards.find(card=>card.id==='moving').x,180);
  await page.evaluate(()=>{window.delayFileDelivery=true;window.fileDeliveryReady=false;});await page.locator('input[type=file][multiple]').setInputFiles({name:'canceled-colors.png',mimeType:'image/png',buffer:bytes});await page.waitForFunction(()=>window.fileDeliveryReady);await load(fixture([],'Replacement upload race'));await page.evaluate(()=>window.releaseFileDelivery());await page.waitForTimeout(100);await persisted(doc=>doc.boards.root.title==='Replacement upload race'&&doc.boards.root.cards.length===0);
 });
 assert.deepEqual(errors,[]);results.push({name:'No uncaught browser errors',status:'passed'});
}finally{await writeFile(new URL('results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),engine,url:base,nativeEyeDropperUsed:false,pointerCancelInput:'Injected browser PointerEvent after a trusted mouse press; not a physical touch gesture',fileReaderTiming:'Real FileReader bytes with delivery callback deliberately held for deterministic asynchronous-race testing',referencePaletteAlgorithmClaimed:false,results,errors},null,2));await browser.close();}
