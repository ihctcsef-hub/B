import { describe, expect, it } from 'vitest';
import type { Card, Workspace } from '../src/core/model';
import { exportWorkspace, importWorkspace, validateWorkspace } from '../src/core/storage';
import { trashCards, trashConnections, restoreTrashEntry, emptyTrash, permanentlyDeleteTrashEntry, purgeExpiredTrash, trashEntryExpiresAt, trashEntryValidationWorkspace, isValidTrashEntry } from '../src/core/trash';
import { createBoardShortcut } from '../src/core/shortcuts';
import { convertBoardToTemplate, revertTemplateToBoard, renameBoardTemplate, deleteBoardTemplate, instantiateBoardTemplate, saveBoardTemplate } from '../src/core/templates';

const note = (id: string, x = 0, y = 0): Card => ({ id, type: 'note', text: id, x, y, width: 270, height: 54, z: 1 });
function fixture(): Workspace {
  return { version: 1, id: 'trash', title: 'Trash test', rootBoardId: 'root', updatedAt: '2026-10-25T00:00:00Z', boards: {
    root: { id: 'root', title: 'Home', viewport: { x: 0, y: 0, zoom: 1 }, cards: [
      { id: 'column', type: 'column', title: 'References', x: 100, y: 100, width: 300, height: 250, z: 0, autoHeight: true },
      { ...note('member', 106.4, 162.2), parentId: 'column', width: 287.2, preColumnWidth: 270 },
      { id: 'owner', type: 'board', boardId: 'child', title: 'Child', x: 106.4, y: 222.2, width: 287.2, height: 160, z: 1, parentId: 'column', preColumnWidth: 160 },
      note('outside', 500, 100),
    ], connections: [
      { id: 'internal', from: 'member', to: 'owner', color: '#323b4a', style: 'solid' },
      { id: 'cross', from: 'member', to: 'outside', color: '#323b4a', style: 'solid' },
      { id: 'loose', from: '', to: '', start: { x: 10, y: 20 }, end: { x: 100, y: 80 }, color: '#323b4a', style: 'dashed' },
    ] },
    child: { id: 'child', title: 'Child', parentBoardId: 'root', cards: [note('inside'), { id: 'grand-owner', type: 'board', boardId: 'grand', title: 'Grandchild', x: 300, y: 0, width: 160, height: 160, z: 1 }], connections: [], viewport: { x: 0, y: 0, zoom: 1 } },
    grand: { id: 'grand', title: 'Grandchild', parentBoardId: 'child', cards: [note('deep')], connections: [], viewport: { x: 0, y: 0, zoom: 1 } },
  } };
}
const roundTrip = (workspace: Workspace) => expect(importWorkspace(exportWorkspace(workspace))).toEqual(workspace);

describe('persistent recoverable content deletion', () => {
  it('archives a column, every member, owned descendants and incident lines without mutating source', () => {
    const source = fixture(), before = structuredClone(source);
    const next = trashCards(source, 'root', ['column'], '2026-10-25');
    expect(source).toEqual(before);
    expect(next.boards.root.cards.map(card => card.id)).toEqual(['outside']);
    expect(next.boards.root.connections.map(line => line.id)).toEqual(['loose']);
    expect(Object.keys(next.boards)).toEqual(['root']);
    const entry = next.trash![0];
    expect(entry.rootIds).toEqual(['column']);
    expect(entry.cards.map(card => card.id)).toEqual(['column', 'member', 'owner']);
    expect(Object.keys(entry.boards)).toEqual(['child', 'grand']);
    expect(entry.connections.map(line => line.id)).toEqual(['internal', 'cross']);
    expect(isValidTrashEntry(entry)).toBe(true);
    expect(validateWorkspace(trashEntryValidationWorkspace(entry))).toBeTruthy();
    roundTrip(next);
    const restored = restoreTrashEntry(next, entry.id, {}, '2026-10-26');
    expect(restored.trash).toEqual([]);
    expect(restored.boards.child.parentBoardId).toBe('root');
    expect(restored.boards.grand.cards).toEqual(before.boards.grand.cards);
    expect(restored.boards.root.connections.map(line => line.id).sort()).toEqual(['cross', 'internal', 'loose']);
    roundTrip(restored);
  });
  it('restores a deleted child to its surviving column, or detaches and restores its prior width when the parent is gone', () => {
    const source = fixture(), next = trashCards(source, 'root', ['member'], '2026-10-25');
    const restored = restoreTrashEntry(next, next.trash![0].id, {}, '2026-10-26');
    expect(restored.boards.root.cards.find(card => card.id === 'member')).toMatchObject({ parentId: 'column', width: 287.2 });
    const noParent = structuredClone(next); noParent.boards.root.cards = noParent.boards.root.cards.filter(card => card.id !== 'column').map(card => ({ ...card, parentId: undefined }));
    const detached = restoreTrashEntry(noParent, next.trash![0].id, {}, '2026-10-26');
    expect(detached.boards.root.cards.find(card => card.id === 'member')).toMatchObject({ parentId: undefined, width: 270 });
    roundTrip(detached);
  });
  it('falls back to Home after the source board was deleted, preserves source trash order and can restore at an explicit location', () => {
    const source = fixture(), first = trashCards(source, 'child', ['inside'], '2026-10-25');
    const second = trashCards(first, 'root', ['owner'], '2026-10-26');
    const entry = second.trash!.find(entry => entry.sourceBoardId === 'child')!;
    const next = restoreTrashEntry(second, entry.id, { at: { x: 700, y: 200 } }, '2026-10-27');
    expect(next.boards.root.cards.find(card => card.id === 'inside')).toMatchObject({ x: 700, y: 200 });
    expect(next.trash).toHaveLength(1); expect(next.trash![0].sourceBoardId).toBe('root');
    roundTrip(next);
  });
  it('restores an explicitly deleted free line and skips unavailable old external endpoints', () => {
    const source = fixture(), next = trashConnections(source, 'root', ['loose'], '2026-10-25');
    expect(next.boards.root.connections.some(line => line.id === 'loose')).toBe(false);
    const restored = restoreTrashEntry(next, next.trash![0].id, { at: { x: 300, y: 200 } }, '2026-10-26');
    expect(restored.boards.root.connections.find(line => line.id === 'loose')).toMatchObject({ start: { x: 300, y: 200 }, end: { x: 390, y: 260 } });
    const removed = trashCards(source, 'root', ['member'], '2026-10-25'); removed.boards.root.cards = removed.boards.root.cards.filter(card => card.id !== 'outside');
    const missing = restoreTrashEntry(removed, removed.trash![0].id, {}, '2026-10-26');
    expect(missing.boards.root.connections.some(line => line.id === 'cross')).toBe(false);
    roundTrip(missing);
  });
  it('remaps ID collisions on restore without overwriting unrelated live content', () => {
    const deleted = trashCards(fixture(), 'root', ['owner'], '2026-10-25');
    const occupied = structuredClone(deleted);
    occupied.boards.root.cards.push(note('owner', 900, 900));
    occupied.boards.root.cards.push({ id: 'another-owner', type: 'board', boardId: 'child', title: 'New child', x: 900, y: 700, width: 160, height: 160, z: 1 });
    occupied.boards.child = { id: 'child', title: 'New child', parentBoardId: 'root', cards: [note('new-content')], connections: [], viewport: { x: 0, y: 0, zoom: 1 } };
    const next = restoreTrashEntry(occupied, deleted.trash![0].id, {}, '2026-10-26');
    expect(next.boards.child.title).toBe('New child');
    expect(next.boards.root.cards.find(card => card.id === 'owner')).toMatchObject({ type: 'note', text: 'owner', x: 900 });
    const restoredTile = next.boards.root.cards.find(card => card.type === 'board' && card.title === 'Child')!;
    expect(restoredTile.id).not.toBe('owner');
    if (restoredTile.type !== 'board') throw new Error('Expected a board');
    expect(restoredTile.boardId).not.toBe('child');
    expect(next.boards[restoredTile.boardId].cards.some(card => card.id === 'inside')).toBe(true);
    expect(next.boards.grand.parentBoardId).toBe(restoredTile.boardId);
    roundTrip(next);
  });
  it('does not resurrect globally deleted labels or stale global names on restore', () => {
    const source = fixture() as Workspace & { labels: Array<{ id: string; name: string; color: string }> };
    source.labels = [{ id: 'kept', name: 'Updated name', color: '#fff000' }];
    Object.assign(source.boards.root.cards.find(card => card.id === 'member')!, { labelIds: ['kept', 'deleted'], tags: ['Old name', 'Deleted label'] });
    const deleted = trashCards(source, 'root', ['member'], '2026-10-25');
    const next = restoreTrashEntry(deleted, deleted.trash![0].id, {}, '2026-10-26');
    expect(next.boards.root.cards.find(card => card.id === 'member')).toMatchObject({ labelIds: ['kept'], tags: ['Updated name'] });
  });
  it('uses three calendar months, purges expired records and makes Empty trash permanent', () => {
    expect(trashEntryExpiresAt({ deletedAt: '2026-01-31T12:34:56.000Z' })).toBe('2026-04-30T12:34:56.000Z');
    const deleted = trashCards(fixture(), 'root', ['member'], '2026-01-31T12:34:56Z');
    expect(purgeExpiredTrash(deleted, '2026-04-30T12:34:55Z')).toBe(deleted);
    expect(purgeExpiredTrash(deleted, '2026-04-30T12:34:56Z').trash).toEqual([]);
    expect(restoreTrashEntry(deleted, deleted.trash![0].id, {}, '2026-05-01')).toBe(deleted);
    expect(emptyTrash(deleted).trash).toEqual([]);
    expect(permanentlyDeleteTrashEntry(deleted, deleted.trash![0].id).trash).toEqual([]);
    expect(trashCards(deleted, 'missing', ['member'])).toBe(deleted);
    expect(trashCards(deleted, 'root', ['missing'])).toBe(deleted);
    expect(isValidTrashEntry({ id: 'bad' })).toBe(false);
    expect(isValidTrashEntry({ ...deleted.trash![0], rootIds: ['missing'] })).toBe(false);
  });
});

describe('editable custom-template lifecycle', () => {
  it('converts the original in place, reflects later source edits in new copies, renames all tiles and reverts without deleting content', () => {
    const source = fixture(), converted = convertBoardToTemplate(source, 'child');
    expect(converted.boards.child.isTemplate).toBe(true); expect(Object.keys(converted.boards)).toEqual(Object.keys(source.boards));
    const renamed = renameBoardTemplate(converted, 'child', 'Project template');
    expect(renamed.boards.root.cards.find(card => card.id === 'owner')).toMatchObject({ title: 'Project template' });
    const edited = structuredClone(renamed); Object.assign(edited.boards.child.cards[0], { text: 'Updated template content' });
    const instance = instantiateBoardTemplate(edited, 'child', 'root', 700, 700);
    expect(instance.workspace.boards[instance.boardId!].title).toBe('Project template');
    expect(instance.workspace.boards[instance.boardId!].cards[0]).toMatchObject({ text: 'Updated template content' });
    const reverted = revertTemplateToBoard(instance.workspace, 'child');
    expect(reverted.boards.child.isTemplate).toBeUndefined();
    expect(reverted.boards.child.cards).toEqual(edited.boards.child.cards);
    roundTrip(reverted);
  });
  it('can revert older detached snapshots by creating an owning Home tile, or delete templates recoverably', () => {
    const source = fixture(), saved = saveBoardTemplate(source, 'child');
    const snapshot = Object.values(saved.boards).find(board => board.isTemplate)!;
    const reverted = revertTemplateToBoard(saved, snapshot.id);
    expect(reverted.boards[snapshot.id].parentBoardId).toBe('root');
    expect(reverted.boards.root.cards.some(card => card.type === 'board' && card.boardId === snapshot.id)).toBe(true);
    roundTrip(reverted);
    const converted = convertBoardToTemplate(source, 'child');
    const deleted = deleteBoardTemplate(converted, 'child');
    expect(deleted.boards.child).toBeUndefined();
    expect((deleted as Workspace & { trash: unknown[] }).trash).toHaveLength(1);
    roundTrip(deleted);
  });
});
