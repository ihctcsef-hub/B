import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {chromium} from 'playwright-core';

const base=process.env.TEST_URL||'http://127.0.0.1:5279',artifacts=new URL('../artifacts/',import.meta.url),results=[],pageErrors=[];
await mkdir(artifacts,{recursive:true});
const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jP1sAAAAASUVORK5CYII=','base64');
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
const page=await browser.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});page.setDefaultTimeout(10000);page.on('pageerror',error=>pageErrors.push(error.message));
const popup=()=>page.getByRole('dialog',{name:'Add image',exact:true}),inbox=()=>page.getByRole('complementary',{name:'Unsorted items panel',exact:true});
const photo=id=>({id:String(id),width:800,height:600,src:`https://images.pexels.com/photos/${id}/image.jpeg`,thumbnail:`https://images.pexels.com/photos/${id}/image.jpeg?w=320`,alt:`Fixture ${id}`,photographer:'Fixture Author',photographerUrl:'https://www.pexels.com/@fixture/',pageUrl:`https://www.pexels.com/photo/${id}/`});
const fixture=()=>({version:1,id:'image-library-integration',title:'Images',rootBoardId:'root',updatedAt:'2026-10-25T00:00:00Z',labels:[{id:'keep',name:'Preserved',color:'#ad6fff'}],boards:{root:{id:'root',title:'Image library integration',cards:[{id:'labeled-note',type:'note',text:'Keep my label',x:100,y:120,width:270,height:54,z:1,labelIds:['keep'],tags:['Preserved']}],connections:[],viewport:{x:20,y:20,zoom:1}}}});
async function load(data=fixture()){
  await page.keyboard.press('Escape');await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'images.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(data))});
  await page.getByText('Workspace imported. Undo to return to your previous workspace.',{exact:true}).waitFor();await page.getByText('Saved on this device',{exact:true}).waitFor();
}
async function backup(name){
  await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();const pending=page.waitForEvent('download');pending.catch(()=>{});await page.getByRole('button',{name:/Workspace backup/}).click();const download=await pending,destination=new URL(name,artifacts);await download.saveAs(destination.pathname);await page.getByTitle('Close dialog',{exact:true}).click();return JSON.parse(await readFile(destination,'utf8'));
}
function assertLabel(data){assert.deepEqual(data.labels,[{id:'keep',name:'Preserved',color:'#ad6fff'}]);assert.deepEqual(data.boards.root.cards.find(card=>card.id==='labeled-note').labelIds,['keep']);}
async function check(name,source,callback){try{await callback();results.push({name,source,status:'passed'});console.log('PASS',name);}catch(error){results.push({name,source,status:'failed',error:error.stack});process.exitCode=1;console.error('FAIL',name,error.message);await page.screenshot({path:new URL(`image-library-app-failure-${results.length}.png`,artifacts).pathname}).catch(()=>{});await page.keyboard.press('Escape').catch(()=>{});}}
async function openLibrary(){await page.getByTitle('Add Image',{exact:true}).click();await popup().waitFor();}
try{
  await page.goto(base);await page.getByText('Saved on this device',{exact:true}).waitFor();
  await check('App opens the real unavailable library, uploads an image to Unsorted, and restores it to the canvas by HTML5 drag','real local unavailable API; local PNG upload',async()=>{
    await load();await openLibrary();await popup().getByRole('alert').waitFor();assert.equal(await popup().locator('figure').count(),0);
    const pending=page.waitForEvent('filechooser');await popup().getByRole('button',{name:'Upload your own',exact:true}).click();await(await pending).setFiles({name:'local-example.png',mimeType:'image/png',buffer:png});
    await inbox().locator('.inbox-item').waitFor();assert.equal(await page.locator('.world .card-image').count(),0);assert.equal(await inbox().getByRole('img',{name:'local-example.png',exact:true}).count(),1);
    await inbox().locator('.inbox-item').dragTo(page.locator('.stage'),{targetPosition:{x:550,y:400}});await page.locator('.world .card-image').waitFor();assert.equal(await inbox().locator('.inbox-item').count(),0);
    const data=await backup('image-library-app-upload.json'),image=data.boards.root.cards.find(card=>card.type==='image');assert.equal(image.unsorted,false);assert.equal(image.originalName,'local-example.png');assert.equal(image.width,270);assert.equal(image.height,305);assert.equal(image.src,`data:image/png;base64,${png.toString('base64')}`);assertLabel(data);
  });
  await page.route('https://images.pexels.com/**',route=>route.fulfill({contentType:'image/png',headers:{'Access-Control-Allow-Origin':'*'},body:png}));
  await page.route('**/api/images/search?**',route=>route.fulfill({contentType:'application/json',body:JSON.stringify({provider:'pexels',photos:[photo(201),photo(202)],page:1,totalResults:2,nextPage:null})}));
  await check('Clicking a fixture library photograph adds it to Unsorted with its original source and provider dimensions','explicit provider fixture, not live Pexels',async()=>{
    await load();await openLibrary();await popup().getByRole('button',{name:'Add photo: Fixture 201',exact:true}).click();await inbox().getByRole('img',{name:'Fixture 201',exact:true}).waitFor();assert.equal(await inbox().getByRole('img',{name:'Fixture 201',exact:true}).getAttribute('src'),photo(201).src);assert.equal(await page.locator('.world .card-image').count(),0);
    await page.keyboard.press('Escape');const data=await backup('image-library-app-click.json'),image=data.boards.root.cards.find(card=>card.type==='image');assert.equal(image.unsorted,true);assert.equal(image.originalName,'pexels-201.jpg');assert.equal(image.width,270);assert.equal(image.height,237.5);assert.equal(image.src,`data:image/png;base64,${png.toString('base64')}`);assertLabel(data);
  });
  await check('Dragging a library photograph places it directly on the board and survives backup import with global labels','explicit provider fixture, actual HTML5 drag',async()=>{
    await load();await openLibrary();await popup().getByRole('button',{name:'Add photo: Fixture 202',exact:true}).dragTo(page.locator('.stage'),{targetPosition:{x:650,y:450}});const image=page.locator('.world .card-image');await image.waitFor();assert.equal(await image.locator('img').getAttribute('src'),photo(202).src);await page.keyboard.press('Escape');
    const data=await backup('image-library-app-drag.json'),saved=data.boards.root.cards.find(card=>card.type==='image');assert.equal(saved.unsorted,false);assert.equal(saved.originalName,'pexels-202.jpg');assert.equal(saved.width,270);assert.equal(saved.height,237.5);assert.equal(saved.src,`data:image/png;base64,${png.toString('base64')}`);assertLabel(data);
    await load(data);assert.equal(await page.locator('.world .card-image').count(),1);assert.equal(await page.locator('[data-card-id="labeled-note"]').getByRole('button',{name:'Label Preserved',exact:true}).count(),1);
  });
  assert.deepEqual(pageErrors,[]);results.push({name:'No uncaught browser errors',source:'browser runtime',status:'passed'});
}finally{await writeFile(new URL('image-library-app-e2e-results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),base,livePexelsVerified:false,results,pageErrors},null,2));await browser.close();}
