import {describe,expect,it} from 'vitest';
import queries from '../src/data/boardIconQueryProvenance.json';
import {BOARD_ICON_CHARACTERS,BOARD_ICON_DIGITS,boardIconCatalogCoverage,boardIconCategory,boardIconSvg,boardIconDisplaySource,getBoardIcon,getReferenceBoardIcons,searchBoardIcons,selectedBoardIconId,withBoardIconIdentity} from '../src/core/boardIcons';

// Valid one-pixel PNG; identity chunks must not change its IDAT image bytes.
const png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/iZk9HQAAAABJRU5ErkJggg==';
describe('board icon reference inventory and local artwork',()=>{
 it('keeps the bounded reference inventory distinct from the open collection',()=>{
  expect(boardIconCatalogCoverage()).toEqual({referenceKnownCount:1910,freeArtworkCount:1895,availableCount:2945,referenceInventoryComplete:false});
  const known=getReferenceBoardIcons();expect(new Set(known.map(icon=>icon.id)).size).toBe(1910);expect(known.every(icon=>icon.referenceKnown)).toBe(true);
  for(const icon of known){const svg=boardIconSvg(icon.id);expect(svg,icon.id).toBeTruthy();expect(svg).toContain(`data-board-icon="${icon.id}"`);expect(svg).not.toMatch(/<script|foreignObject|(?:href|src)=["']https?:|onload=/);}
  expect(boardIconSvg('unknown-inventory-id')).toBeUndefined();
 });
 it('preserves measured category orders and recommended eight plus ten digits',()=>{
  expect(boardIconCategory('board')).toHaveLength(32);expect(boardIconCategory('new')).toHaveLength(32);
  expect(boardIconCategory('board').slice(0,5).map(icon=>icon.id)).toEqual(['chess-board','window-flip','game-board-simple','rectangles-mixed','sidebar-flip']);
  expect(boardIconCategory('new').slice(0,5).map(icon=>icon.id)).toEqual(['certificate','cloud-plus','baby','face-smile-plus','file-plus']);
  expect(boardIconCategory('recommended','New Board').map(icon=>icon.id)).toEqual(['square-star','square-arrow-up-right','chess-board','hacker-news','window-flip','game-board-simple','shapes','square-hacker-news']);
  expect(BOARD_ICON_DIGITS.join('')).toBe('1234567890');expect(BOARD_ICON_CHARACTERS.join('')).toBe('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ!#$%&=~');
 });
 it('uses captured semantic query order when known and a deterministic local search otherwise',()=>{
  expect(searchBoardIcons(' camera ').slice(0,2).map(icon=>icon.id)).toEqual(['camera-retro','camera']);
  expect(searchBoardIcons('')).toEqual([]);expect(searchBoardIcons('zzzx').map(icon=>icon.id)).toEqual(['snooze','face-sleeping']);
  expect(searchBoardIcons('campfire').some(icon=>icon.id==='campfire')).toBe(true);
  expect(searchBoardIcons('Beer mug').some(icon=>icon.id==='beer-mug')).toBe(true);
  expect(searchBoardIcons('arbitrary unlisted words no icon')).toEqual([]);
 });
 it('retains the captured lowercase32-result request order and empty responses without replacing it with artwork-name ranking',()=>{
  expect(queries.completeInventoryClaimed).toBe(false);expect(queries.queries.length).toBe(56);
  for(const row of queries.queries){const source=new URL(row.sourcePath,'https://app.milanote.com');expect(row.requestedCount,row.query).toBe(32);expect(source.searchParams.get('search'),row.query).toBe(row.query);expect(row.query,row.query).toBe(row.query.toLowerCase());expect(searchBoardIcons(row.query).map(icon=>icon.id),row.query).toEqual(row.ids.slice(0,32));}
  expect(searchBoardIcons('March').map(icon=>icon.id)).toEqual(['mn-calendar-month-march','equals','note','shirt-long-sleeve','bag-shopping','hat-winter','shirt-running','briefcase-blank','mug','notebook','shirt']);
 });
 it('keeps legacy template glyphs renderable without inventing current picker entries',()=>{
  expect(getBoardIcon('85883')?.templateOnly).toBe(true);expect(boardIconSvg('85883')).toContain('viewBox="0 0 24 24"');
  expect(searchBoardIcons('85883')).toEqual([]);expect(searchBoardIcons('Filled Circle').some(icon=>icon.id==='85883')).toBe(false);
  expect(getBoardIcon('hands-clapping')?.templateOnly).toBe(false);expect(boardIconSvg('hands-clapping')).toBeTruthy();
 });
 it('returns detached metadata so consumers cannot change later searches',()=>{
  const first=getBoardIcon('camera')!;first.name='Changed';first.terms.push('invented');expect(getBoardIcon('camera')!.name).toBe('camera');expect(getBoardIcon('camera')!.terms).not.toContain('invented');
 });
});
describe('durable raster icon identity',()=>{
 it('renders recognized backups as selected-palette vectors while preserving arbitrary uploads unchanged',()=>{
  const value=withBoardIconIdentity(png,'camera'),display=boardIconDisplaySource(value)!;
  expect(display).toMatch(/^data:image\/svg\+xml;base64,/);expect(atob(display.slice(display.indexOf(',')+1))).toContain('fill="#323b4a"');
  expect(selectedBoardIconId(value)).toBe('camera');expect(boardIconDisplaySource(png)).toBe(png);expect(boardIconDisplaySource('S')).toBe('S');expect(boardIconDisplaySource(undefined)).toBeUndefined();
 });
 it('survives a new value and JSON roundtrip, preserving the PNG image bytes',()=>{
  const value=withBoardIconIdentity(png,'camera');expect(value).toMatch(/^data:image\/png;base64,/);expect(value).not.toBe(png);expect(selectedBoardIconId(value)).toBe('camera');
  expect(selectedBoardIconId(JSON.parse(JSON.stringify({value})).value)).toBe('camera');
  const original=atob(png.slice(22)),tagged=atob(value.slice(22));expect(tagged).toContain(original.slice(8,-12));expect(tagged.endsWith(original.slice(-12))).toBe(true);expect(selectedBoardIconId(png)).toBeUndefined();expect(selectedBoardIconId(withBoardIconIdentity(value,'campfire'))).toBe('campfire');
 });
 it('does not accept corrupt data, invalid chunk metadata or arbitrary IDs',()=>{
  expect(()=>withBoardIconIdentity(png,'unlisted-icon')).toThrow('Unknown board icon');expect(()=>withBoardIconIdentity('data:image/png;base64,broken','camera')).toThrow();
  const value=withBoardIconIdentity(png,'camera'),binary=atob(value.slice(22)),offset=binary.indexOf('v1:camera');expect(offset).toBeGreaterThan(0);
  const corrupt=binary.slice(0,offset)+'v1:camero'+binary.slice(offset+9);expect(selectedBoardIconId(`data:image/png;base64,${btoa(corrupt)}`)).toBeUndefined();expect(selectedBoardIconId('data:image/svg+xml;base64,not-base64')).toBeUndefined();
 });
});
