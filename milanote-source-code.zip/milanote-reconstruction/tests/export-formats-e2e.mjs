import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import { chromium, webkit } from 'playwright-core';
import { PDFDocument, PDFName, PDFDict, decodePDFRawStream } from 'pdf-lib';
import { unzipSync, strFromU8 } from 'fflate';
import { installPdfRenderer } from './pdf-render-helpers.mjs';

const engine = process.env.BROWSER_ENGINE === 'webkit' ? 'webkit' : 'chromium';
const artifacts = new URL(engine === 'webkit' ? '../artifacts/webkit/' : '../artifacts/', import.meta.url);
await mkdir(artifacts, { recursive: true });
const browser = await (engine === 'webkit' ? webkit.launch({ headless: true, ...(process.env.WEBKIT_PATH ? { executablePath: process.env.WEBKIT_PATH } : {}) }) : chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] }));
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
const results = [], errors = [];
page.on('pageerror', error => errors.push(error.message));
page.setDefaultTimeout(20000);
async function check(name, test) {
  try { await test(); results.push({ name, status: 'passed' }); console.log('PASS', name); }
  catch (error) { results.push({ name, status: 'failed', message: error.stack }); process.exitCode = 1; console.error('FAIL', name, error.message); }
}
async function saveBlob(data, filename) {
  const bytes = Buffer.from(data); await writeFile(new URL(filename, artifacts), bytes); return bytes;
}
try {
  await page.goto(process.env.TEST_URL || 'http://127.0.0.1:5288', { waitUntil: 'networkidle' });
  await installPdfRenderer(page);
  await page.evaluate(async () => {
    const formats = await import('/src/core/exportFormats.ts');
    const { createCard } = await import('/src/core/model.ts');
    const image = color => {
      const canvas = document.createElement('canvas'); canvas.width = 80; canvas.height = 80;
      const ctx = canvas.getContext('2d'); ctx.fillStyle = color; ctx.fillRect(0, 0, 80, 80); return canvas.toDataURL();
    };
    const board = { id: 'binary-test', title: 'Binary export — تجربة', viewport: { x: -900, y: 500, zoom: .25 }, connections: [], cards: [
      { ...createCard('swatch', -80, -40), type: 'swatch', width: 120, height: 90, value: '#ff0000', label: '', showCaption: false, showValue: false },
      { ...createCard('note', 80, 100), type: 'note', html: '<h2>Readable content</h2><p>Bold <strong>text</strong> and مرحبا.</p>', text: '', width: 270, height: 110 },
      { ...createCard('image', 400, 100), type: 'image', src: image('#0000ff'), cutoutSrc: image('#00ff00'), useCutout: true, originalName: 'original.png', showCaption: false, width: 100, height: 100, caption: '' },
      { ...createCard('table', 80, 300), type: 'table', title: '', width: 270, height: 94, rows: [['10','20','=SUM(A1:B1)']], cellMeta: { '0:2': { color: '#ffcc00' } } },
    ] };
    window.binaryExport = { formats, board, async bytes(blob) { return [...new Uint8Array(await blob.arrayBuffer())]; }, async pixel(blob, x, y) {
      const bitmap = await createImageBitmap(blob), canvas = document.createElement('canvas'); canvas.width = bitmap.width; canvas.height = bitmap.height;
      const ctx = canvas.getContext('2d'); ctx.drawImage(bitmap, 0, 0); return { width: bitmap.width, height: bitmap.height, rgba: [...ctx.getImageData(x, y, 1, 1).data] };
    } };
  });
  await check('PNG includes negative board coordinates, processed cutout and full dimensions independently of viewport zoom', async () => {
    const output = await page.evaluate(async () => {
      const e = window.binaryExport, blob = await e.formats.exportBoardPng(e.board, { scale: 1, background: 'white' });
      return { bytes: await e.bytes(blob), red: await e.pixel(blob, 92, 77), green: await e.pixel(blob, 562, 222), corner: await e.pixel(blob, 5, 5), dimensions: e.formats.rasterDimensions(e.board, { scale: 1 }) };
    });
    await saveBlob(output.bytes, 'binary-export.png');
    assert.equal(output.red.width, output.dimensions.pixelWidth); assert.equal(output.red.height, output.dimensions.pixelHeight);
    assert.deepEqual(output.red.rgba, [255, 0, 0, 255]); assert.deepEqual(output.green.rgba, [0, 255, 0, 255]); assert.deepEqual(output.corner.rgba, [255, 255, 255, 255]);
  });
  await check('Actual DOM capture strips resize controls and current zoom while retaining rendered colors', async () => {
    const output = await page.evaluate(async () => {
      const e = window.binaryExport, source = document.createElement('div'); source.className = 'world';
      source.style.cssText = 'position:relative;transform:translate(100px,200px) scale(.25)';
      const item = document.createElement('div'); item.style.cssText = 'position:absolute;left:-80px;top:-40px;width:120px;height:90px;background:rgb(255,0,255)';
      const handle = document.createElement('div'); handle.className = 'resize-handle'; handle.style.cssText = 'position:absolute;inset:0;background:blue'; item.append(handle); source.append(item); document.body.append(source);
      try { const blob = await e.formats.exportBoardPng(e.board, { scale: 1, sourceElement: source, includeTitle: false, background: 'transparent' }); return { bytes: await e.bytes(blob), pink: await e.pixel(blob, 92, 77), corner: await e.pixel(blob, 5, 5) }; }
      finally { source.remove(); }
    });
    await saveBlob(output.bytes, 'binary-dom-capture.png'); assert.deepEqual(output.pink.rgba, [255, 0, 255, 255]); assert.equal(output.corner.rgba[3], 0);
  });
  await check('A small far-away table exports at the measured PNG/PDF dimensions with no title or canvas-origin whitespace', async () => {
    const output=await page.evaluate(async()=>{
      const e=window.binaryExport,table={...e.board.cards.find(card=>card.type==='table'),x:9000,y:-8000,width:270,height:94,rows:[['1','1','']]};
      const board={...e.board,background:'#123456',cards:[table],connections:[]};
      const png=await e.formats.exportBoardPng(board),pdf=await e.formats.exportBoardPdf(board);
      return {png:await e.bytes(png),corner:await e.pixel(png,0,0),pdf:await e.bytes(pdf)};
    });
    await saveBlob(output.png,'binary-tight-table.png');
    assert.equal(output.corner.width,668);assert.equal(output.corner.height,316);assert.deepEqual(output.corner.rgba,[255,255,255,255]);
    const pdf=await PDFDocument.load(await saveBlob(output.pdf,'binary-tight-table.pdf'));
    assert.deepEqual(pdf.getPage(0).getSize(),{width:251.04,height:119.04});
  });
  await check('PDF quality preserves odd board dimensions, omits the title, and uses white board-sized pages', async () => {
    const output = await page.evaluate(async () => {
      const e = window.binaryExport;
      const board = { ...e.board, background: '#123456', cards: [...e.board.cards, { ...e.board.cards[0], id: 'odd-edge', x: 900, y: 501, width: 101, height: 100 }] };
      const dimensions = e.formats.rasterDimensions(board, { includeTitle: false, scale: 1 });
      return { dimensions, standard: await e.bytes(await e.formats.exportBoardPdf(board, { format: 'standard' })), high: await e.bytes(await e.formats.exportBoardPdf(board, { format: 'large' })) };
    });
    const standard = await saveBlob(output.standard, 'binary-standard.pdf'), high = await saveBlob(output.high, 'binary-high-quality.pdf');
    const one = await PDFDocument.load(standard), two = await PDFDocument.load(high);
    assert.equal(one.getPageCount(), 1); assert.equal(two.getPageCount(), 1);
    assert.equal(output.dimensions.width % 2, 1); assert.equal(output.dimensions.height % 2, 1);
    assert.deepEqual(one.getPage(0).getSize(), two.getPage(0).getSize());
    assert.equal(output.dimensions.width,1145);assert.equal(output.dimensions.height,705);
    assert.deepEqual(one.getPage(0).getSize(),{width:859.44,height:529.44}); assert.ok(high.length > standard.length);
    for (const pdf of [one,two]) {
      const images = pdf.getPage(0).node.Resources().lookup(PDFName.of('XObject'), PDFDict);
      const image = images.entries().map(([,reference])=>pdf.context.lookup(reference)).find(object=>object.dict.get(PDFName.of('Subtype')).toString()==='/Image');
      const pixels = decodePDFRawStream(image).decode(), width = image.dict.get(PDFName.of('Width')).asNumber(), height = image.dict.get(PDFName.of('Height')).asNumber();
      assert.deepEqual([...pixels.subarray(0,3)],[255,255,255], 'The PDF background must be white even when the board has another color');
      const scale = width / output.dimensions.width;
      const offset = (Math.round(77*height/output.dimensions.height) * width + Math.round(92*scale))*3;
      assert.deepEqual([...pixels.subarray(offset,offset+3)],[255,0,0], 'The first card must retain its position without a title strip');
    }
  });
  await check('Explicit paper options keep fitted A4 and tiled Letter output available', async () => {
    const output=await page.evaluate(async()=>{const e=window.binaryExport;return {a4:await e.bytes(await e.formats.exportBoardPdf(e.board,{pageSize:'a4'})),letter:await e.bytes(await e.formats.exportBoardPdf(e.board,{pageSize:'letter',orientation:'portrait',pagination:'tile'}))};});
    const a4=await PDFDocument.load(await saveBlob(output.a4,'binary-explicit-a4.pdf')),letter=await PDFDocument.load(await saveBlob(output.letter,'binary-explicit-letter.pdf'));
    assert.deepEqual(a4.getPage(0).getSize(),{width:841.89,height:595.28});
    assert.ok(letter.getPageCount()>=1); for(const page of letter.getPages())assert.deepEqual(page.getSize(),{width:612,height:792});
  });
  await check('SVG image resources render visible original pixels without changing the editor source or leaving capture elements', async () => {
    const output = await page.evaluate(async () => {
      const e = window.binaryExport, { boardExportBounds } = await import('/src/export.ts');
      const source = document.createElement('div'); source.className = 'world';
      source.innerHTML = '<svg style="position:absolute;left:80px;top:100px" width="100" height="100"><image href="/assets/studio-objects.jpg" width="100" height="100" preserveAspectRatio="none"/></svg>';
      document.body.append(source);
      const original = source.querySelector('image'), reference = new Image(); reference.src = original.href.baseVal; await reference.decode();
      const expected = document.createElement('canvas'); expected.width = expected.height = 100;
      const context = expected.getContext('2d'); context.drawImage(reference, 0, 0, 100, 100);
      const area = boardExportBounds(e.board,{bounds:'content'});
      try {
        const blob = await e.formats.exportBoardPng(e.board, { scale: 1, sourceElement: source, includeTitle: false });
        return { bytes: await e.bytes(blob), pixel: await e.pixel(blob, 80 - area.x + 50, 100 - area.y + 50), expected: [...context.getImageData(50, 50, 1, 1).data], originalHref: original.href.baseVal, captures: document.querySelectorAll('.export-capture').length };
      } finally { source.remove(); }
    });
    await saveBlob(output.bytes, 'binary-svg-image.png');
    assert.equal(output.originalHref, '/assets/studio-objects.jpg'); assert.equal(output.captures, 0);
    for (let channel = 0; channel < 4; channel++) assert.ok(Math.abs(output.pixel.rgba[channel] - output.expected[channel]) <= 2, `Image pixel channel ${channel} must match the decoded resource`);
  });
  await check('Long document PDF paginates every paragraph and Word keeps the last paragraph editable', async () => {
    const output = await page.evaluate(async () => {
      const e = window.binaryExport, note = { ...e.board.cards[1], title: 'Long document', isDocument: true, html: Array.from({ length: 100 }, (_, i) => `<p>Paragraph ${i + 1}: complete content across multiple pages.</p>`).join('') };
      return { pdf: await e.bytes(await e.formats.exportDocumentFile(note, 'pdf')), word: await e.bytes(await e.formats.exportDocumentFile(note, 'word')) };
    });
    const pdf = await PDFDocument.load(await saveBlob(output.pdf, 'binary-long-document.pdf')); assert.ok(pdf.getPageCount() >= 3);
    for (const page of pdf.getPages()) { assert.equal(page.getWidth(), 595.28); assert.equal(page.getHeight(), 841.89); }
    const rendered=await page.evaluate(bytes=>window.inspectRenderedPdf(bytes),output.pdf);
    assert.equal(rendered.length,pdf.getPageCount());
    for(const item of rendered)assert.ok(item.ink>500,'Every actually rendered PDF page must contain visible text, including the last page');
    assert.match(rendered.at(-1).text.replace(/\s+/g,''),/Paragraph100:completecontentacrossmultiplepages\./);
    await writeFile(new URL('binary-long-document-last-page.png',artifacts),Buffer.from(rendered.at(-1).image.split(',')[1],'base64'));
    const entries = unzipSync(await saveBlob(output.word, 'binary-long-document.docx')); assert.ok(strFromU8(entries['word/document.xml']).includes('Paragraph 100: complete content across multiple pages.'));
  });
  await check('Attachments ZIP keeps original image bytes when the on-board preview uses a cutout', async () => {
    const output = await page.evaluate(async () => {
      const e = window.binaryExport; return { zip: await e.bytes(await e.formats.exportBoardAttachmentsZip(e.board)), original: await e.bytes(await (await fetch(e.board.cards[2].src)).blob()) };
    });
    const entries = unzipSync(await saveBlob(output.zip, 'binary-original-attachments.zip')); assert.deepEqual([...entries['original.png']], output.original);
  });
  await check('Word drawing uses its own bounds and retains stroke colors without board-sized whitespace', async () => {
    const bytes = await page.evaluate(async () => {
      const e = window.binaryExport, board = { ...e.board, cards: [{ id: 'drawing', type: 'sketch', x: 0, y: 0, width: 200, height: 100, z: 1, background: 'transparent', paths: [{ color: '#ff0000', width: 8, points: [{ x: 10, y: 50 }, { x: 190, y: 50 }] }] }] };
      return e.bytes(await e.formats.exportBoardWord(board));
    });
    const entries = unzipSync(await saveBlob(bytes, 'binary-drawing.docx'));
    const image = Object.entries(entries).find(([name]) => name.startsWith('word/media/') && name.endsWith('.png'))[1];
    const pixels = await page.evaluate(async bytes => {
      const blob = new Blob([new Uint8Array(bytes)], { type: 'image/png' }); return { center: await window.binaryExport.pixel(blob, 200, 100), corner: await window.binaryExport.pixel(blob, 0, 0) };
    }, [...image]);
    assert.equal(pixels.center.width, 400); assert.equal(pixels.center.height, 200); assert.deepEqual(pixels.center.rgba, [255,0,0,255]); assert.equal(pixels.corner.rgba[3], 0);
  });
  await check('Missing resources reject the export and leave no temporary DOM capture behind', async () => {
    const result = await page.evaluate(async () => {
      const e = window.binaryExport, source = document.createElement('div'), image = document.createElement('img'); image.src = '/deliberately-missing-export-image.png'; source.append(image); document.body.append(source);
      try { await e.formats.exportBoardPng(e.board, { sourceElement: source }); return { rejected: false }; }
      catch { return { rejected: true, captures: document.querySelectorAll('.export-capture').length }; }
      finally { source.remove(); }
    });
    assert.deepEqual(result, { rejected: true, captures: 0 });
  });
  assert.deepEqual(errors, []);
} finally {
  await writeFile(new URL('binary-export-results.json', artifacts), JSON.stringify({ checkedAt: new Date().toISOString(), results, errors }, null, 2));
  await browser.close();
}
