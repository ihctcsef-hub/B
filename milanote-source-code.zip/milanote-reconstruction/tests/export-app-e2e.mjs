import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { chromium,webkit } from 'playwright-core';
import { PDFDocument } from 'pdf-lib';
import { unzipSync, strFromU8 } from 'fflate';

const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium';
const artifacts = new URL(engine==='webkit'?'../artifacts/webkit/':'../artifacts/', import.meta.url); await mkdir(artifacts, { recursive: true });
const browser=await (engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] }));
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true }); page.setDefaultTimeout(15000);
const results = [], errors = []; page.on('pageerror', error => errors.push(error.message));
const card = id => page.locator(`[data-card-id="${id}"]`);
const base = { width: 270, height: 54, z: 1 };
function fixture() { return { version: 1, id: 'app-export-test', title: 'Export test workspace', rootBoardId: 'root', updatedAt: new Date().toISOString(), boards: {
  root: { id: 'root', title: 'App export study', cards: [
    { ...base, id: 'note', type: 'note', x: 60, y: 80, text: 'Visible note marker', html: '<p>Visible note marker</p>' },
    { ...base, id: 'image', type: 'image', x: 60, y: 210, width: 300, height: 220, src: '/assets/studio-objects.jpg', originalName: 'studio-objects.jpg', caption: 'Source photo', imageEdits: { rotation: 90, crop: { x: .1, y: .1, width: .8, height: .8 }, paths: [{ color: '#ed4b35', width: .012, points: [{ x: .25, y: .3 }, { x: .55, y: .3 }] }] } },
    { ...base, id: 'document', type: 'note', x: 440, y: 80, width: 270, height: 150, isDocument: true, title: 'Edited document', text: 'Initial document body', html: '<p>Initial document body</p>' },
    { ...base, id: 'nested-tile', type: 'board', boardId: 'nested', title: 'Child board', x: 440, y: 300, width: 160, height: 160 },
  ], connections: [], viewport: { x: 20, y: 20, zoom: 1 }, background: '#ebedee' },
  nested: { id: 'nested', title: 'Child board', parentBoardId: 'root', cards: [{ ...base, id: 'nested-note', type: 'note', x: 30, y: 40, text: 'Nested export content', html: '<p>Nested export content</p>' }, { ...base, id: 'nested-image', type: 'image', x: 30, y: 140, width: 270, height: 180, src: '/assets/studio-objects.jpg', originalName: 'nested-original.jpg', caption: 'Nested photo' }], connections: [], viewport: { x: 20, y: 20, zoom: 1 } },
} }; }
async function importFixture(data) {
  await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({ name: 'export-app.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(data)) });
  await page.getByText('Workspace imported. Undo to return to your previous workspace.', { exact: true }).waitFor();
  await page.getByText('Saved on this device', { exact: true }).waitFor();
}
async function advancedExport() {
  if (await page.locator('.modal-export').isVisible()) return;
  await page.getByTitle('More options', { exact: true }).click(); await page.getByRole('button', { name: 'Export board', exact: true }).click();
  await page.locator('.modal-export').waitFor();
}
async function download(button, filename) {
  const pending = page.waitForEvent('download', { timeout: 30000 }); await button.click(); const item = await pending;
  const target = new URL(filename, artifacts); await item.saveAs(target.pathname); return readFile(target);
}
async function backup(filename) {
  await advancedExport(); const bytes = await download(page.getByRole('button', { name: /Workspace backup/ }), filename);
  await page.getByTitle('Close dialog', { exact: true }).click(); return JSON.parse(bytes.toString());
}
async function check(name, test) { if (process.env.EXPORT_APP_CASE && !name.includes(process.env.EXPORT_APP_CASE)) return; try { await test(); results.push({ name, status: 'passed' }); console.log('PASS', name); } catch (error) { results.push({ name, status: 'failed', message: error.stack }); process.exitCode = 1; console.error('FAIL', name, error.message); await page.screenshot({ path: new URL(`app-export-failure-${results.length}.png`, artifacts).pathname }).catch(() => {}); await page.keyboard.press('Escape').catch(() => {}); } }
try {
  await page.goto(process.env.TEST_URL || 'http://127.0.0.1:5288', { waitUntil: 'networkidle' }); await page.getByText('Saved on this device', { exact: true }).waitFor();
  await check('Main export actions download real PNG/PDF/Word/ZIP and include selected nested boards in linear formats', async () => {
    await importFixture(fixture()); await page.getByRole('button', { name: 'Export', exact: true }).click();
    const menu = page.getByRole('menu', { name: 'Export board', exact: true }); assert.equal(await menu.getByRole('menuitem').count(), 7);
    const png = await download(menu.getByRole('menuitem', { name: 'PNG image', exact: true }), 'app-export.png'); assert.equal(png.subarray(1, 4).toString(), 'PNG');
    const pdf = await download(menu.getByRole('menuitem', { name: 'PDF standard (small file size)', exact: true }), 'app-export.pdf'); assert.equal((await PDFDocument.load(pdf)).getPageCount(), 1);
    const high = await download(menu.getByRole('menuitem', { name: 'PDF high quality (large file size)', exact: true }), 'app-export-high.pdf'); assert.deepEqual((await PDFDocument.load(high)).getPage(0).getSize(), (await PDFDocument.load(pdf)).getPage(0).getSize());
    await menu.getByRole('switch', { name: 'Include sub-boards', exact: true }).check();
    const word = unzipSync(await download(menu.getByRole('menuitem', { name: 'Word document', exact: true }), 'app-export.docx')); const xml = strFromU8(word['word/document.xml']); assert.ok(xml.includes('Visible note marker')); assert.ok(xml.includes('Nested export content'));
    const zip = unzipSync(await download(menu.getByRole('menuitem', { name: 'Generate ZIP file', exact: true }), 'app-attachments.zip')); assert.ok(zip['studio-objects.jpg']); assert.ok(zip['studio-objects.jpg'].length > 10000);
    const md = await download(menu.getByRole('menuitem', { name: 'Markdown', exact: true }), 'app-export.md'); assert.ok(md.toString().includes('Nested export content'));
    const text = await download(menu.getByRole('menuitem', { name: 'Plain text', exact: true }), 'app-export.txt'); assert.ok(text.toString().includes('Nested export content'));
    await page.keyboard.press('Escape');
  });
  await check('Document downloads contain current edits and editing continues after PDF and Word downloads', async () => {
    await importFixture(fixture()); await card('document').dblclick();
    const editor = page.getByRole('textbox', { name: 'Document text', exact: true }); await editor.fill('Current edit exported');
    const pdf = await download(page.getByTitle('Download document PDF', { exact: true }), 'app-edited-document.pdf'); assert.equal((await PDFDocument.load(pdf)).getPageCount(), 1);
    await editor.fill('Current edit exported with a second paragraph after PDF');
    const word = unzipSync(await download(page.getByTitle('Download document Word', { exact: true }), 'app-edited-document.docx')); assert.ok(strFromU8(word['word/document.xml']).includes('second paragraph after PDF'));
    await editor.fill('Final edit after both downloads'); await page.locator('.modal-document').getByTitle('Close dialog', { exact: true }).click();
    const saved = await backup('app-document-after-exports.json'); assert.equal(saved.boards.root.cards.find(card => card.id === 'document').text, 'Final edit after both downloads');
  });
  await check('JSON embeds deleted image originals and nested-board resources, reimports, restores and preserves editable image operations', async () => {
    await importFixture(fixture());
    for (const id of ['image', 'nested-tile']) { await card(id).click({ position: { x: 3, y: 3 } }); await page.keyboard.press('Delete'); await card(id).waitFor({ state: 'detached' }); }
    const saved = await backup('app-trash-portable-backup.json'); assert.equal(saved.trash.length, 2);
    const photo = saved.trash.flatMap(entry => entry.cards).find(card => card.id === 'image'); assert.ok(photo.src.startsWith('data:image/jpeg;base64,')); assert.equal(photo.imageEdits.rotation, 90); assert.equal(photo.imageEdits.paths.length, 1);
    const nested = saved.trash.flatMap(entry => Object.values(entry.boards)).find(board => board.id === 'nested'); assert.ok(nested.cards.find(card => card.id === 'nested-image').src.startsWith('data:image/jpeg;base64,'));
    await importFixture(saved); await page.getByTitle('Trash', { exact: true }).click(); const panel = page.getByRole('region', { name: 'Trash', exact: true });
    for (let i = 0; i < 2; i++) { const entry = panel.locator('[data-trash-id]').first(); await entry.focus(); await entry.press('Enter'); }
    await card('image').waitFor(); await card('nested-tile').waitFor(); await page.getByTitle('Close trash', { exact: true }).click();
    await page.getByText('Saved on this device', { exact: true }).waitFor();
    await page.reload({ waitUntil: 'networkidle' }); const restored = await backup('app-trash-restored.json'); assert.equal(restored.trash.length, 0);
    const restoredPhoto = restored.boards.root.cards.find(card => card.id === 'image'); assert.equal(restoredPhoto.src, photo.src); assert.deepEqual(restoredPhoto.imageEdits, photo.imageEdits); assert.ok(restored.boards.nested.cards.find(card => card.id === 'nested-image').src.startsWith('data:image/jpeg;base64,'));
  });
  assert.deepEqual(errors, []);
} finally { await writeFile(new URL(process.env.EXPORT_APP_CASE ? 'app-export-menu-results.json' : 'app-export-results.json', artifacts), JSON.stringify({ checkedAt: new Date().toISOString(), results, errors }, null, 2)); await browser.close(); }
