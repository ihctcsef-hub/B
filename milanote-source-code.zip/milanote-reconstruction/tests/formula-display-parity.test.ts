import {describe,it,expect}from'vitest';
import observed from './fixtures/native-numeric-display.json';
import {evaluateTableCellDetails}from'../src/core/spreadsheet';
import type{TableCellMetaMap}from'../src/core/spreadsheet';
describe('independently measured native numerical cell values and displays',()=>{
 it.each(observed.cases)('$caseId',source=>{
  const rows=observed.fixture.map(row=>[...row]);rows[4][0]=source.formula;
  const meta:TableCellMetaMap=source.requestedType==='Number'?{'4:0':{type:'number',thousandsSeparator:true}}:{};
  const actual=evaluateTableCellDetails(rows,4,0,meta);
  expect(actual.error).toBeUndefined();expect(actual.value).toBe(Number(source.resultValue));expect(actual.display).toBe(source.text);
 });
});
