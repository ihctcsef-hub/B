import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {chromium,webkit} from 'playwright-core';

const base=process.env.TEST_URL||'http://127.0.0.1:5290',artifacts=new URL('../artifacts/',import.meta.url);await mkdir(artifacts,{recursive:true});
const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium';
const browser=await (engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']}));
const page=await browser.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});page.setDefaultTimeout(15000);
const errors=[],external=[],results=[];page.on('pageerror',error=>errors.push(error.message));page.on('request',request=>{const url=new URL(request.url());if(['http:','https:'].includes(url.protocol)&&url.origin!==new URL(base).origin)external.push(url.origin);});
const image=()=>page.locator('[data-card-id="photo"]'),dialog=()=>page.getByRole('dialog',{name:'Remove image background',exact:true});
const fixture={version:1,id:'cutout-app',title:'Cutout',rootBoardId:'root',updatedAt:new Date().toISOString(),boards:{root:{id:'root',title:'Cutout',viewport:{x:20,y:20,zoom:1},connections:[],cards:[{id:'photo',type:'image',src:'/assets/studio-objects.jpg',caption:'Source photograph',originalName:'studio-objects.jpg',showCaption:false,x:100,y:100,width:360,height:241.2,z:1}]}}};
async function workspace(){return page.evaluate(()=>new Promise(resolve=>{const request=indexedDB.open('visual-workspace');request.onsuccess=()=>{const db=request.result,read=db.transaction('documents','readonly').objectStore('documents').get('workspace');read.onsuccess=()=>{resolve(read.result?.workspace);db.close();};};}));}
async function saved(check){for(let i=0;i<100;i++){const value=await workspace();if(value&&check(value.boards.root.cards[0]))return value.boards.root.cards[0];await page.waitForTimeout(50);}throw Error('Image change did not persist');}
async function open(){await image().click({position:{x:3,y:3}});await page.getByTitle('Remove image background',{exact:true}).click();await dialog().waitFor();}
async function run(name,action){try{await action();results.push({name,status:'passed'});console.log('PASS',name);}catch(error){results.push({name,status:'failed',message:error.stack});process.exitCode=1;await page.screenshot({path:new URL(`cutout-app-failure-${results.length}.png`,artifacts).pathname});throw error;}}
let cutout;
try{
  await page.goto(base,{waitUntil:'networkidle'});await page.getByText('Saved on this device',{exact:true}).waitFor();await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'cutout-app.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(fixture))});await page.getByText('Workspace imported. Undo to return to your previous workspace.',{exact:true}).waitFor();
  await run('Production background removal runs the bundled model locally and saves a real alpha matte without replacing the original',async()=>{
    await open();await dialog().getByRole('button',{name:'Remove background',exact:true}).click();await dialog().getByRole('button',{name:'Restore original',exact:true}).waitFor({timeout:60000});
    const preview=dialog().getByAltText('Image with background removed',{exact:true});cutout=await preview.getAttribute('src');assert.ok(cutout.startsWith('data:image/png;base64,'));
    const pixels=await preview.evaluate(async img=>{await img.decode();const canvas=document.createElement('canvas');canvas.width=img.naturalWidth;canvas.height=img.naturalHeight;const context=canvas.getContext('2d');context.drawImage(img,0,0);const rgba=context.getImageData(0,0,canvas.width,canvas.height).data;let transparent=0,opaque=0;for(let i=3;i<rgba.length;i+=4){if(rgba[i]<=5)transparent++;if(rgba[i]>=250)opaque++;}return {width:canvas.width,height:canvas.height,transparent,opaque};});
    assert.deepEqual([pixels.width,pixels.height],[900,603]);assert.ok(pixels.transparent>1000);assert.ok(pixels.opaque>1000);await dialog().getByRole('button',{name:'Save changes',exact:true}).click();const value=await saved(card=>card.useCutout===true);assert.equal(value.src,'/assets/studio-objects.jpg');assert.equal(value.cutoutSrc,cutout);results.push({name:'Actual model alpha measurements',status:'passed',...pixels});
  });
  await run('Restore Cancel keeps the saved cutout; Restore Save retains the cached matte and is undone in one step',async()=>{
    await open();await dialog().getByRole('button',{name:'Restore original',exact:true}).click();await dialog().getByRole('button',{name:'Cancel',exact:true}).click();assert.equal((await workspace()).boards.root.cards[0].useCutout,true);
    await open();await dialog().getByRole('button',{name:'Restore original',exact:true}).click();await dialog().getByRole('button',{name:'Save changes',exact:true}).click();let value=await saved(card=>card.useCutout===false);assert.equal(value.cutoutSrc,cutout);assert.equal(value.src,'/assets/studio-objects.jpg');
    await page.getByTitle('Undo (⌘Z)',{exact:true}).click();await saved(card=>card.useCutout===true);
  });
  await run('Portable backup and reload preserve both original image bytes and the editable cutout toggle',async()=>{
    await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();const pending=page.waitForEvent('download');await page.getByRole('button',{name:/Workspace backup/}).click();const download=await pending,file=new URL('cutout-app-workspace.json',artifacts);await download.saveAs(file.pathname);const value=JSON.parse(await readFile(file,'utf8')),card=value.boards.root.cards[0];assert.ok(card.src.startsWith('data:image/jpeg;base64,'));assert.equal(card.cutoutSrc,cutout);assert.equal(card.useCutout,true);await page.getByTitle('Close dialog',{exact:true}).click();
    await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles(file.pathname);await saved(card=>card.src.startsWith('data:image/jpeg'));await page.reload({waitUntil:'networkidle'});await saved(card=>card.useCutout===true);assert.equal((await workspace()).boards.root.cards[0].cutoutSrc,cutout);
  });
  assert.deepEqual(errors,[]);assert.deepEqual(external,[]);results.push({name:'No uncaught errors or external requests',status:'passed'});
}finally{await writeFile(new URL(engine==='webkit'?'background-removal-app-webkit-results.json':'background-removal-app-results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),base,engine,referenceMatteParityClaimed:false,results,errors,externalRequests:external},null,2));await browser.close();}
