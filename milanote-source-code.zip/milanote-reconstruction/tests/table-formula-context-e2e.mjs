import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {chromium,webkit} from 'playwright-core';
const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium',root=fileURLToPath(new URL('../',import.meta.url));
const artifacts=path.join(root,'artifacts','formula-context',engine);await mkdir(artifacts,{recursive:true});
const browser=await(engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']}));
const context=await browser.newContext({viewport:{width:1440,height:1000},acceptDownloads:true}),page=await context.newPage();page.setDefaultTimeout(10000);
const results=[],pageErrors=[];page.on('pageerror',error=>pageErrors.push(error.stack??error.message));
const first=()=>page.locator('[data-card-id="formula-first"]'),second=()=>page.locator('[data-card-id="formula-second"]');
const cell=(table,row,column)=>table.locator(`[data-cell="${String.fromCharCode(65+column)}${row+1}"]`);
const values=table=>table.locator('tr').first().locator('td').allTextContents();
function fixture(){const table=(id,x)=>({id,type:'table',title:'',rows:[['=SHEET()','=SHEETS()','=SHEET(A1:C3)'],['=1/0','=SHEETS(1)','=SHEETS(1,2)'],['=SHEETS(A1:C3)','','']],cellMeta:{},x,y:100,width:270,height:70,z:1});return{version:1,id:'formula-context-workspace',title:'Formula context workspace',rootBoardId:'formula-board',updatedAt:'2026-10-29T00:00:00.000Z',boards:{'formula-board':{id:'formula-board',title:'Formula context board',cards:[table('formula-first',100),table('formula-second',550)],connections:[],viewport:{x:35,y:40,zoom:1},background:'#ebedee',grid:true}}};}
async function load(data=fixture()){
  await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'formula-context.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(data))});
  await page.waitForFunction(()=>document.querySelector('input[type=file][accept="application/json,.json"]')?.value==='');
  await page.getByText('Workspace imported. Undo to return to your previous workspace.',{exact:true}).waitFor();
  await page.waitForFunction(()=>document.querySelector('[aria-label="Current board title"]')?.value==='Formula context board');
  await first().getByRole('grid',{name:'Table',exact:true}).waitFor();
}
async function run(name,fn){try{await fn();results.push({name,status:'passed'});console.log('PASS',name);}catch(error){process.exitCode=1;results.push({name,status:'failed',message:error.stack});console.error('FAIL',name,error.message);await page.screenshot({path:path.join(artifacts,`failure-${results.length}.png`),fullPage:true});await page.keyboard.press('Escape').catch(()=>{});}}
async function edit(table,row,column,text){await cell(table,row,column).dblclick();const input=table.getByLabel(`Edit Row ${row+1} column ${column+1}`,{exact:true});await input.fill(text);await input.press('Tab');}
async function htmlExport(){await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();const pending=page.waitForEvent('download');pending.catch(()=>{});await page.getByRole('button',{name:/Board as HTML/}).click();const item=await pending,destination=path.join(artifacts,'workbook-export.html');await item.saveAs(destination);await page.getByTitle('Close dialog',{exact:true}).click();return readFile(destination,'utf8');}
try{
  await page.goto(process.env.TEST_URL||'http://127.0.0.1:5306',{waitUntil:'domcontentloaded'});await page.getByText('Saved on this device',{exact:true}).waitFor();
  await run('Import establishes shared compact sheet identities, references do not evaluate referenced errors',async()=>{
    await load();assert.deepEqual(await values(first()),['1','2','1']);assert.deepEqual(await values(second()),['2','2','2']);assert.equal((await cell(first(),2,0).innerText()).trim(),'1');
  });
  await run('Invalid formulas show blank cell, 16px orange indicator and precise measured diagnostics',async()=>{
    for(const[column,message]of [[0,"Numbers can't be divided by zero"],[1,'Cell reference expected'],[2,'Wrong number of arguments']]){
      const target=cell(first(),1,column);assert.equal((await target.innerText()).trim(),'');const icon=target.getByRole('img',{name:`Formula error: ${message}`,exact:true});await icon.waitFor();
      assert.deepEqual(await icon.locator('svg').evaluate(element=>({width:element.getBoundingClientRect().width,height:element.getBoundingClientRect().height,color:element.querySelector('circle')?.getAttribute('fill')})),{width:16,height:16,color:'#ff8d22'});
      await icon.hover();const tooltip=page.getByRole('tooltip',{name:message,exact:true});await tooltip.waitFor();assert.equal(await tooltip.innerText(),message);await page.mouse.move(1200,900);await tooltip.waitFor({state:'hidden'});
    }
  });
  await run('Native creation retains transient slots through delete and Undo; HTML uses the same workbook snapshot',async()=>{
    await page.mouse.click(1150,850);await page.getByTitle('Add Table',{exact:true}).click();
    const all=page.locator('.card-table');await page.waitForFunction(()=>document.querySelectorAll('.card-table').length===3);
    const newId=await all.evaluateAll(elements=>elements.map(element=>element.dataset.cardId).find(id=>!['formula-first','formula-second'].includes(id)));
    const created=page.locator(`[data-card-id="${newId}"]`);await edit(created,0,0,'=SHEET()');await edit(created,0,1,'=SHEETS()');
    assert.deepEqual((await values(created)).slice(0,2),['4','4']);assert.equal((await values(first()))[1],'4');
    const html=await htmlExport(),exported=await context.newPage();await exported.setContent(html);assert.equal(await exported.locator('table').first().locator('tr').first().locator('th,td').nth(1).innerText(),'4');await exported.close();await page.bringToFront();
    await page.keyboard.press('Escape');await page.mouse.click(1150,850);await created.hover();await created.getByRole('button',{name:'Move table',exact:true}).click();await page.keyboard.press('Backspace');await created.waitFor({state:'detached'});assert.equal((await values(first()))[1],'4');
    await page.keyboard.press(process.platform==='darwin'?'Meta+z':'Control+z');await created.waitFor();assert.equal((await values(created))[0],'4');assert.equal((await values(first()))[1],'4');
    await page.getByTitle('Add Table',{exact:true}).click();await page.waitForFunction(()=>document.querySelectorAll('.card-table').length===4);
    const extraId=await all.evaluateAll((elements,known)=>elements.map(element=>element.dataset.cardId).find(id=>!known.includes(id)),['formula-first','formula-second',newId]);
    const extra=page.locator(`[data-card-id="${extraId}"]`);await edit(extra,0,0,'=SHEET()');assert.equal((await values(extra))[0],'5');assert.equal((await values(first()))[1],'5');
    await page.keyboard.press('Escape');await page.mouse.click(1150,850);await extra.hover();await extra.getByRole('button',{name:'Move table',exact:true}).click();await page.keyboard.press('Backspace');await extra.waitFor({state:'detached'});assert.equal((await values(first()))[1],'5');
    await page.getByText('Saved on this device',{exact:true}).waitFor();await page.reload({waitUntil:'domcontentloaded'});await first().waitFor();assert.equal((await values(first()))[1],'3');assert.equal((await values(created))[0],'3');
  });
  await run('Board navigation retains page-global loaded sheets while hard reload compacts the current board',async()=>{
    const data=fixture();data.boards['formula-board'].cards.push({id:'formula-nested-tile',type:'board',boardId:'formula-child',title:'Formula child',x:100,y:380,width:114,height:130,z:2});
    data.boards['formula-child']={id:'formula-child',title:'Formula child',parentBoardId:'formula-board',cards:[{...data.boards['formula-board'].cards[0],id:'formula-child-table'}],connections:[],viewport:{x:35,y:40,zoom:1}};
    await load(data);const origin=await page.evaluate(()=>performance.timeOrigin);assert.equal((await values(first()))[1],'2');
    await page.locator('[data-card-id="formula-nested-tile"]').dblclick();const child=page.locator('[data-card-id="formula-child-table"]');await child.waitFor();assert.deepEqual(await values(child),['3','3','3']);
    await page.getByRole('navigation',{name:'Board breadcrumb',exact:true}).getByRole('button',{name:'Formula context board',exact:true}).click();await first().waitFor();assert.equal((await values(first()))[1],'3');assert.equal(await page.evaluate(()=>performance.timeOrigin),origin);
    await page.getByText('Saved on this device',{exact:true}).waitFor();await page.reload({waitUntil:'domcontentloaded'});await first().waitFor();assert.deepEqual(await values(first()),['1','2','1']);
  });
  await run('Replacement import with reused identifiers resets transient context and retained raw source',async()=>{
    await load();assert.deepEqual(await values(first()),['1','2','1']);assert.deepEqual(await values(second()),['2','2','2']);
    await cell(second(),0,0).dblclick();assert.equal(await second().getByLabel('Edit Row 1 column 1',{exact:true}).inputValue(),'=SHEET()');await page.keyboard.press('Escape');
  });
  await run('Scalar compatibility corrections are applied through the actual editor, persist and reload',async()=>{
    const data=fixture(),rows=[['=TIMEVALUE("12:00")','=ERF(0,1)','=ATAN2(1,0)'],['=BASE(255,16)','=CHIDIST(2,2)','=CHIINV(.8,2)'],['=T.DIST(0,10,TRUE)','=SUBSTITUTE("a-b-a","a","x",2)','=FDIST(1,5,10)'],['=FINV(.8,5,10)','=TINV(.05,10)','']];data.boards['formula-board'].cards[0].rows=rows;data.boards['formula-board'].cards[0].height=94;await load(data);
    const expected=['0.5','0.84270079295','0','FF','0.36787944117','0.44628710263','0.5','a-b-x','0.46511942654','0.45633642866','2.2281388425',''];
    assert.deepEqual(await first().locator('td').allTextContents(),expected);await page.getByText('Saved on this device',{exact:true}).waitFor();await page.reload({waitUntil:'domcontentloaded'});await first().waitFor();assert.deepEqual(await first().locator('td').allTextContents(),expected);
    // These ten Auto/Number states were measured explicitly in the native UI.
    // Retain exact comparison and exercise Number's Auto decimal setting in
    // the real editor, then the shared HTML export and persistence paths.
    for(const [row,column] of [[1,1],[1,2],[2,2],[3,0],[3,1]]){
      await cell(first(),row,column).click();await page.getByTitle('Cell type',{exact:true}).click();await page.getByRole('menuitemradio',{name:'Number',exact:true}).click();await page.keyboard.press('Escape');
      assert.equal((await cell(first(),row,column).innerText()).trim(),expected[row*3+column]);
    }
    const html=await htmlExport(),exported=await context.newPage();await exported.setContent(html);assert.deepEqual(await exported.locator('table').first().locator('th,td').allTextContents(),expected);await exported.close();await page.bringToFront();
    await page.getByText('Saved on this device',{exact:true}).waitFor();await page.reload({waitUntil:'domcontentloaded'});await first().waitFor();assert.deepEqual(await first().locator('td').allTextContents(),expected);
  });
  await run('No uncaught browser errors',async()=>assert.deepEqual(pageErrors,[]));
}catch(error){process.exitCode=1;results.push({name:'Harness failure',status:'failed',message:error.stack});console.error(error);}
finally{await writeFile(path.join(artifacts,'results.json'),JSON.stringify({checkedAt:new Date().toISOString(),engine,results,pageErrors,referenceParityClaimed:false},null,2));await browser.close();}
