import { describe, expect, it } from "vitest";
import {
  cellAddress, cellKey, deleteTableColumn, deleteTableRow, evaluateTable, evaluateTableCell,
  formatTableCell, insertTableColumn, insertTableRow, isValidTableMeta, normalizeTableMeta,
  parseTableClipboard, pasteTableCells, tableFormulaNames, relocateTableFormula,
  moveTableRow,moveTableColumn,resizeTableGrid,
} from "../src/core/spreadsheet";

describe("spreadsheet formulas", () => {
  it("evaluates dependent formulas, arithmetic precedence, absolute refs, and ranges", () => {
    const rows = [["5", "=A1*2", "=SUM(A1:B2)"], ["3", "=($A$1+A2)^2/4", "=AVERAGE(A1:A2)"], ["=2^3^2", "=-2^2", "=50%*A1"]];
    expect(evaluateTable(rows)).toEqual([["5", "10", "34"], ["3", "16", "4"], ["64", "4", "2.5"]]);
    expect(evaluateTableCell(rows, 0, 2)).toBe(34);
    expect(cellAddress(0, 0)).toBe("A1");
    expect(cellAddress(26, 26)).toBe("AA27");
  });

  it("aggregates numbers while keeping plain text and blanks out of numeric counts", () => {
    const rows = [["2", "text"], ["", "8"], ["=COUNT(A1:B2)", "=MIN(A1:B2)+MAX(A1:B2)"], ["=SUM(2,3,4)", "=AVERAGE(A1:A2)"]];
    expect(evaluateTableCell(rows, 2, 0)).toBe(2);
    expect(evaluateTableCell(rows, 2, 1)).toBe(10);
    expect(evaluateTableCell(rows, 3, 0)).toBe(9);
    expect(evaluateTableCell(rows, 3, 1)).toBe(2);
  });

  it("reports cycles, malformed formulas, invalid refs, division by zero, and unknown functions", () => {
    const rows = [["=B1", "=A1", "=A1+1"], ["=1/0", "=Z999", "=SUM("], ["=UNKNOWN(1)", "=A1:A2", "=2+hello"], ["=AVERAGE(A2:A2)", "=2^9999", "=1+\"hello\""]];
    expect(evaluateTable(rows)).toEqual([
      ["#CYCLE!", "#CYCLE!", "#CYCLE!"],
      ["#DIV/0!", "", "#ERROR!"],
      ["#NAME?", "#VALUE!", "#NAME?"],
      ["#DIV/0!", "#NUM!", "#VALUE!"],
    ]);
    expect(evaluateTableCell([["=globalThis.process.exit()"]], 0, 0)).toBe("#NAME?");
    expect(evaluateTableCell([["=#REF!"]],0,0)).toBe("#REF!");
  });

  it("formats display values without replacing original formula source", () => {
    const rows = [["12.5", "=A1*2", "0.125", "true", "2026-10-25", "=A1+2"]];
    const meta = {
      "0:0": { type: "number" as const }, "0:1": { type: "currency" as const },
      "0:2": { type: "percentage" as const }, "0:3": { type: "checkbox" as const },
      "0:4": { type: "date" as const }, "0:5": { type: "text" as const },
    };
    expect(evaluateTable(rows, meta)).toEqual([["12.5", "$25.00", "12.5%", "☑", "Oct 25, 2026", "=A1+2"]]);
    expect(formatTableCell([["false"]], 0, 0, { "0:0": { type: "checkbox" } })).toBe("☐");
    expect(rows[0][1]).toBe("=A1*2");
    expect(rows[0][5]).toBe("=A1+2");
  });
});

describe('table formatting and structure acceptance',()=>{
  it('keeps raw numbers and formulas while displaying decimal grouping, currency accounting and percentage presets',()=>{
    const rows=[['12345.678','-12345','0.125']];
    expect(formatTableCell(rows,0,0,{'0:0':{type:'number',decimals:2,thousandsSeparator:false}})).toBe('12345.68');
    expect(formatTableCell(rows,0,1,{'0:1':{type:'currency',accounting:true}})).toBe('($12,345.00)');
    expect(formatTableCell(rows,0,0,{'0:0':{type:'currency',currency:'EUR',currencyDisplay:'code',decimals:0}}).replace(/\s/g,' ')).toBe('EUR 12,346');
    expect(formatTableCell(rows,0,2,{'0:2':{type:'percentage',decimals:2}})).toBe('12.50%');
    expect(rows).toEqual([['12345.678','-12345','0.125']]);
  });
  it('formats the observed date and time presets with fixed calendar components',()=>{
    const rows=[['2016-02-29T13:24:56']];
    expect(formatTableCell(rows,0,0,{'0:0':{type:'date',dateFormat:'wordsLong'}})).toBe('February 29, 2016');
    expect(formatTableCell(rows,0,0,{'0:0':{type:'date',dateFormat:'numericShort'}})).toBe('2/29/16');
    expect(formatTableCell(rows,0,0,{'0:0':{type:'date',dateFormat:'numericDashed',timeFormat:'twentyFourHourSeconds'}})).toBe('2-29-2016 (13:24:56)');
    expect(formatTableCell(rows,0,0,{'0:0':{type:'date',dateFormat:'weekday'}})).toBe('Monday, February 29, 2016');
    expect(formatTableCell(rows,0,0,{'0:0':{type:'date',dateFormat:'none',timeFormat:'twelveHour'}})).toBe('1:24 PM');
  });
  it('validates and preserves every new formatting option but excludes malformed values',()=>{
    const meta={'0:0':{type:'currency' as const,decimals:3,thousandsSeparator:false,currency:'SAR',currencyDisplay:'name' as const,accounting:true,dateFormat:'wordsLong' as const,timeFormat:'twentyFourHour' as const}};
    expect(isValidTableMeta(meta,[['0']])).toBe(true);expect(normalizeTableMeta(meta,[['0']])).toEqual(meta);
    expect(isValidTableMeta({'0:0':{decimals:-1}},[['0']])).toBe(false);
    expect(isValidTableMeta({'0:0':{currency:'bad code'}},[['0']])).toBe(false);
    expect(isValidTableMeta({'0:0':{dateFormat:'madeUp'}},[['0']])).toBe(false);
    expect(normalizeTableMeta({'0:0':{decimals:100,dateFormat:'bad',type:'number'}},[['0']])).toEqual({'0:0':{type:'number'}});
  });
  it('moves row content and cell formats and reproduces the observed partial-range contraction',()=>{
    const rows=[['Metric','10','=SUM(B1:B2)'],['Other','0',''],['End','5','=A1']];
    const moved=moveTableRow(rows,{'0:1':{type:'currency',decimals:1}},0,2);
    expect(moved.rows).toEqual([['Other','0',''],['End','5','=A3'],['Metric','10','=SUM(B1:B1)']]);
    expect(moved.meta).toEqual({'2:1':{type:'currency',decimals:1}});
    expect(formatTableCell(moved.rows,2,2,moved.meta)).toBe('0');
    expect(rows[0][2]).toBe('=SUM(B1:B2)');
  });
  it('moves columns with mixed references without rewriting quoted strings or digit-bearing function names',()=>{
    const rows=[['10','20','=LOG10(A1)+$B$1&"A1"']];
    const moved=moveTableColumn(rows,{'0:0':{color:'#ff0000'}},0,2);
    expect(moved.rows).toEqual([['20','=LOG10(C1)+$A$1&"A1"','10']]);expect(moved.meta).toEqual({'0:2':{color:'#ff0000'}});
  });
  it('corner resize grows empty cells and removes trailing data with reference errors and surviving formats',()=>{
    const rows=[['1','=B2'],['2','4']];
    const grown=resizeTableGrid(rows,{'0:0':{bold:true}},4,3);expect(grown.rows).toEqual([['1','=B2',''],['2','4',''],['','',''],['','','']]);
    const shrunk=resizeTableGrid(grown.rows,grown.meta,1,2);expect(shrunk.rows).toEqual([['1','=\#REF!']]);expect(shrunk.meta).toEqual({'0:0':{bold:true}});
    expect(resizeTableGrid([['a']],{},0,0).rows).toEqual([['a']]);
  });
});

describe("copied table formulas", () => {
  it("shifts relative axes while preserving mixed and absolute references, ranges and quoted strings", () => {
    expect(relocateTableFormula('=A1+$A1+A$1+$A$1+SUM(A1:B2)+"A1"', 2, 3)).toBe('=D3+$A3+D$1+$A$1+SUM(D3:E4)+"A1"');
    expect(relocateTableFormula('=LOG10(A1)+ATAN2(A1,1)+T.INV.2T(B2,5)', 1, 1)).toBe('=LOG10(B2)+ATAN2(B2,1)+T.INV.2T(C3,5)');
    expect(relocateTableFormula('=CONCAT("say ""A1""",A1)', 1, 1)).toBe('=CONCAT("say ""A1""",B2)');
  });
  it("reports references copied beyond row or column zero without altering plain text", () => {
    expect(relocateTableFormula('=A1+$A$1+SUM(A1:B2)', -1, 0)).toBe('=#REF!+$A$1+SUM(#REF!:B1)');
    expect(relocateTableFormula('=A1', 0, -1)).toBe('=#REF!');
    expect(relocateTableFormula('A1', 1, 1)).toBe('A1');
    expect(relocateTableFormula('=A1', 0, 0)).toBe('=A1');
  });
});

describe("spreadsheet structure and clipboard", () => {
  it("moves formatting and references when rows are inserted or removed", () => {
    const rows = [["2", "=SUM($A$1:A3)"], ["4", "=A2*2"], ["6", "=\"A2\""]];
    const meta = { "1:0": { color: "#f00", bold: true }, "2:1": { type: "text" as const } };
    const inserted = insertTableRow(rows, meta, 1);
    expect(inserted.rows).toEqual([["2", "=SUM($A$1:A4)"], ["", ""], ["4", "=A3*2"], ["6", "=\"A2\""]]);
    expect(inserted.meta).toEqual({ "2:0": { color: "#f00", bold: true }, "3:1": { type: "text" } });
    expect(deleteTableRow(inserted.rows, inserted.meta, 1)).toEqual({ rows, meta });
    const removed = deleteTableRow(rows, meta, 1);
    expect(removed.rows[0][1]).toBe("=SUM($A$1:A2)");
    expect(removed.meta).toEqual({ "1:1": { type: "text" } });
    expect(rows[0][1]).toBe("=SUM($A$1:A3)");
  });

  it("shrinks ranges and breaks a reference only when its referenced cell is deleted", () => {
    const rows = [["2", "=SUM(A1:A3)", "=A1"], ["4", "=SUM(A3:A1)", "=A2"], ["6", "=SUM(A1:A1)", "=A3"]];
    const removed = deleteTableRow(rows, {}, 0);
    expect(removed.rows).toEqual([["4", "=SUM(A2:A1)", "=A1"], ["6", "=SUM(#REF!)", "=A2"]]);
    expect(evaluateTableCell(removed.rows, 1, 1)).toBe("#REF!");
    const removedMiddle = deleteTableRow(rows, {}, 1);
    expect(removedMiddle.rows[0][1]).toBe("=SUM(A1:A2)");
  });

  it("keeps columns rectangular and preserves their formulas and formatting", () => {
    const rows = [["5", "=A1", "=SUM(A1:B1)"], ["3", "=B1", "=C1"]];
    const meta = { "1:1": { align: "right" as const, italic: true } };
    const inserted = insertTableColumn(rows, meta, 1);
    expect(inserted.rows).toEqual([["5", "", "=A1", "=SUM(A1:C1)"], ["3", "", "=C1", "=D1"]]);
    expect(inserted.meta).toEqual({ "1:2": { align: "right", italic: true } });
    expect(deleteTableColumn(inserted.rows, inserted.meta, 1)).toEqual({ rows, meta });
    const removed = deleteTableColumn(rows, meta, 0);
    expect(removed.rows[0]).toEqual(["=#REF!", "=SUM(A1:A1)"]);
    expect(evaluateTableCell(removed.rows, 0, 0)).toBe("#REF!");
    expect(deleteTableRow([["last"]], {}, 0)).toEqual({ rows: [[""]], meta: {} });
    expect(deleteTableColumn([["last"]], {}, 0)).toEqual({ rows: [[""]], meta: {} });
  });

  it("pastes rectangular spreadsheet data and retains formatting outside the pasted block", () => {
    expect(parseTableClipboard('name\t"notes\twith tab"\r\n"two\nlines"\t"say ""hi"""\r\n')).toEqual([["name", "notes\twith tab"], ["two\nlines", 'say "hi"']]);
    const original = [["existing", ""]];
    const result = pasteTableCells(original, { "0:0": { bold: true } }, 1, 1, [["1", "2"], ["=B2+C2", "4"]]);
    expect(result.rows).toEqual([["existing", "", ""], ["", "1", "2"], ["", "=B2+C2", "4"]]);
    expect(result.meta).toEqual({ "0:0": { bold: true } });
    expect(evaluateTableCell(result.rows, 2, 1)).toBe(3);
    expect(original).toEqual([["existing", ""]]);
  });

  it("validates imported cell metadata and removes unsafe or out of bounds entries", () => {
    const rows = [["", ""]];
    expect(cellKey(1, 2)).toBe("1:2");
    expect(isValidTableMeta({ "0:0": { type: "currency", color: "#aabbcc", align: "right", bold: true } }, rows)).toBe(true);
    expect(isValidTableMeta({ "1:0": { italic: true } }, rows)).toBe(false);
    expect(isValidTableMeta({ "0:0": { type: "script", color: "url(a)", bold: 1 } })).toBe(false);
    expect(isValidTableMeta({ "0:0": { color: "#1234" } })).toBe(false);
    expect(isValidTableMeta({ "0:0": { onclick: "run()" } })).toBe(false);
    expect(normalizeTableMeta({ "0:0": { color: "#abc", type: "number", bold: true }, "0:1": { color: "url(a)", align: "center" }, "1:0": { italic: true } }, rows)).toEqual({ "0:0": { color: "#abc", type: "number", bold: true }, "0:1": { align: "center" } });
  });
});

describe("extended spreadsheet expression families", () => {
  const formula = (expression: string) => evaluateTableCell([[`=${expression}`]], 0, 0);

  it("compares values and concatenates strings using spreadsheet precedence and case folding", () => {
    expect(formula('2+3*4=14')).toBe(true);
    expect(formula('2^3>=8')).toBe(true);
    expect(formula('"Alpha"="ALPHA"')).toBe(true);
    expect(formula('"a"<>"b"')).toBe(true);
    expect(formula('"total: "&ROUND(10/3,2)')).toBe("total: 3.33");
    expect(formula('"A"&1+2="a3"')).toBe(true);
    expect(formula('TRUE&"/"&FALSE')).toBe("TRUE/FALSE");
    expect(formula('"a"<"b"')).toBe(true);
  });

  it("evaluates conditional branches lazily, including errors in discarded branches", () => {
    expect(formula('IF(TRUE,12,1/0)')).toBe(12);
    expect(formula('IF(FALSE,Z999,24)')).toBe(24);
    expect(formula('IF(1>2,"no",IF(3>2,"yes","no"))')).toBe("yes");
    expect(formula('IFERROR(1/0,"fallback")')).toBe("fallback");
    expect(formula('IFERROR(2+3,1/0)')).toBe(5);
    expect(formula('IFNA(NA(),"missing")')).toBe("missing");
    expect(formula('IFNA(1/0,"missing")')).toBe("#DIV/0!");
    expect(formula('IFS(1>2,1/0,2<3,"ok",TRUE,"later")')).toBe("ok");
    expect(formula('SWITCH("b","a",1/0,"b",20,0)')).toBe(20);
    expect(formula('SWITCH("z","a",1,"b",2,"fallback")')).toBe("fallback");
    expect(formula('SWITCH("z","a",1)')).toBe("#N/A");
    expect(formula('IF(TRUE;9;1/0)')).toBe('#ERROR!');
  });

  it("supports logical and error-inspection functions without swallowing unrelated errors", () => {
    expect(formula('AND(TRUE,2>1,NOT(FALSE))')).toBe(true);
    expect(formula('OR(FALSE,0,3=3)')).toBe(true);
    expect(formula('XOR(TRUE,TRUE)')).toBe(false);
    expect(formula('ISERROR(1/0)')).toBe(true);
    expect(formula('ISERR(NA())')).toBe(false);
    expect(formula('ISNA(NA())')).toBe(true);
    expect(formula('ISERROR(42)')).toBe(false);
    expect(formula('ERROR.TYPE(1/0)')).toBe(2);
    expect(formula('ERROR.TYPE(42)')).toBe("#N/A");
    expect(formula('ISNUMBER("42")')).toBe(false);
    expect(formula('ISBLANK("")')).toBe(false);
    expect(formula('ISTEXT("42")')).toBe(true);
  });

  it("handles text transformations, escaped quotes, Unicode and formatting", () => {
    expect(formula('UPPER(TRIM("  Hello   world  "))')).toBe("HELLO WORLD");
    expect(formula('LEFT("Milanote",4)&RIGHT("Milanote",4)')).toBe("Milanote");
    expect(formula('MID("abcdefgh",3,4)')).toBe("cdef");
    expect(formula('SUBSTITUTE("a-b-b","b","c")')).toBe("a-c-c");
    expect(formula('CONCATENATE("hello ","""world""")')).toBe('#ERROR!');
    expect(formula('LEN("مرحبًا")')).toBe(6);
    expect(formula('TEXT(123.45,"0.0")')).toBe("123.5");
    expect(formula('FIND("n","Milanote")')).toBe(5);
  });

  it("supports numeric IDs, dotted namespaces, rounding, engineering, and statistical functions", () => {
    expect(formula('LOG10(1000)')).toBeCloseTo(3);
    expect(formula('ATAN2(1,1)')).toBeCloseTo(Math.PI / 4);
    expect(formula('ROUND(12.345,2)')).toBe(12.35);
    expect(formula('ROUNDUP(1.234,2)')).toBe(1.24);
    expect(formula('ROUNDDOWN(1.239,2)')).toBe(1.23);
    expect(formula('ABS(-9)+MOD(10,3)+SQRT(16)')).toBe(14);
    expect(formula('BIN2DEC("1010")')).toBe(10);
    expect(formula('DEC2HEX(255)')).toBe("FF");
    expect(formula('NORM.S.DIST(0,TRUE)')).toBeCloseTo(0.5);
    expect(formula('STDEV.S(2,4,6)')).toBe(2);
    expect(formula('STDEV(2,4,6)')).toBe(2);
    expect(formula('VAR.P(2,4,6)')).toBeCloseTo(8 / 3);
    expect(tableFormulaNames).toContain("LOG10");
    expect(tableFormulaNames).toContain("T.INV.2T");
    expect(tableFormulaNames).not.toContain("utils");
    expect(tableFormulaNames).not.toContain("MUNIT");
  });

  it("preserves ranges as separate 2D arguments for conditional aggregation and lookup", () => {
    const rows = [
      ["apples", "2", "=SUMIF(A1:A3,\"apples\",B1:B3)", "=VLOOKUP(\"pears\",A1:B3,2,FALSE)"],
      ["pears", "7", "=COUNTIF(B1:B3,\">3\")", "=INDEX(A1:B3,3,2)"],
      ["apples", "5", "=AVERAGEIF(A1:A3,\"apples\",B1:B3)", "=SUMPRODUCT(B1:B3,B1:B3)"],
      ["", "", "=ROWS(A1:B3)", "=COLUMNS(A1:B3)"],
    ];
    expect(evaluateTableCell(rows, 0, 2)).toBe(7);
    expect(evaluateTableCell(rows, 0, 3)).toBe(7);
    expect(evaluateTableCell(rows, 1, 2)).toBe(2);
    expect(evaluateTableCell(rows, 1, 3)).toBe(5);
    expect(evaluateTableCell(rows, 2, 2)).toBe(3.5);
    expect(evaluateTableCell(rows, 2, 3)).toBe(78);
    expect(evaluateTableCell(rows, 3, 2)).toBe(3);
    expect(evaluateTableCell(rows, 3, 3)).toBe(2);
    expect(evaluateTableCell([["=ROW()", "=COLUMN()"], ["=ROW(B1)", "=COLUMN(B1)"]], 1, 1)).toBe(2);
  });

  it("returns date serials that work with date display, arithmetic and component functions", () => {
    const rows = [["=DATE(2026,10,25)", "=YEAR(A1)", "=MONTH(A1)", "=DAY(A1)"], ["=DATE(2026,11,1)-A1", "=EDATE(A1,1)", "=EOMONTH(A1,0)", "=TIME(12,30,0)"]];
    expect(formatTableCell(rows, 0, 0, { "0:0": { type: "date" } })).toBe("Oct 25, 2026");
    expect(evaluateTableCell(rows, 0, 1)).toBe(2026);
    expect(evaluateTableCell(rows, 0, 2)).toBe(10);
    expect(evaluateTableCell(rows, 0, 3)).toBe(25);
    expect(evaluateTableCell(rows, 1, 0)).toBe(7);
    expect(formatTableCell(rows, 1, 1, { "1:1": { type: "date" } })).toBe("Nov 25, 2026");
    expect(formatTableCell(rows, 1, 2, { "1:2": { type: "date" } })).toBe("Oct 31, 2026");
    expect(evaluateTableCell(rows, 1, 3)).toBeCloseTo(12.5 / 24);
    expect(formula('NETWORKDAYS(DATE(2026,10,19),DATE(2026,10,23))')).toBe(5);
  });

  it("supports financial calculations and propagates library errors consistently", () => {
    expect(formula('PMT(0.05/12,12,1200)')).toBeCloseTo(-102.72897814616);
    expect(formula('NPV(0.1,100,200)')).toBeCloseTo(256.198347107438);
    expect(formula('SQRT(-1)')).toBe("#NUM!");
    expect(formula('VLOOKUP("missing",A1:A1,1,FALSE)')).toBe("#CYCLE!");
    expect(formula('IFERROR(SQRT(-1),"bad value")')).toBe("bad value");
  });

  it("keeps imported formula text inert and caps parser, range, spill and text allocation costs", () => {
    for (const source of ['globalThis.alert(1)', 'constructor.constructor("return 1")()', 'SUM.constructor("return 1")', '__proto__.pollute(1)', 'utils.date.useSerial()', 'fetch("https://example.invalid")']) {
      expect(["#NAME?", "#ERROR!"]).toContain(formula(source));
    }
    expect(formula('REPT("x",1000000000)')).toBe("#VALUE!");
    expect(formula('MUNIT(1000000000)')).toBe("#VALUE!");
    expect(formula('FACT(1e999)')).toBe("#NUM!");
    expect(formula('FACT(1000000000)')).toBe("#NUM!");
    expect(formula('FACT(-1)')).toBe("#NUM!");
    expect(formula('BASE(1,2,1000000000)')).toBe("#NUM!");
    expect(formula('ROMAN(1000000000)')).toBe("#NUM!");
    expect(formula('WORKDAY(40000,1000000000)')).toBe("#NUM!");
    expect(formula('NETWORKDAYS(40000,1000000000)')).toBe("#NUM!");
    expect(formula('"' + "x".repeat(9000) + '"')).toBe("#ERROR!");
    expect(formula('('.repeat(200) + '1' + ')'.repeat(200))).toBe("#ERROR!");
    expect(formula('SUM(A1:ZZ999999999)')).toBe("#REF!");
    expect(formula('"A1"')).toBe("A1");
  });
});


it("does not rewrite digit-bearing formula function names when the sheet structure changes", () => {
  const rows = [["10", "=LOG10(A1)+ATAN2(A1,1)"], ["20", "=LOG10($A$2)"]];
  expect(insertTableRow(rows, {}, 0).rows).toEqual([["", ""], ["10", "=LOG10(A2)+ATAN2(A2,1)"], ["20", "=LOG10($A$3)"]]);
  expect(insertTableColumn(rows, {}, 0).rows).toEqual([["", "10", "=LOG10(B1)+ATAN2(B1,1)"], ["", "20", "=LOG10($B$2)"]]);
});
