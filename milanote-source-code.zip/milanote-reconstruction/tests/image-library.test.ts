import { describe,expect,it } from 'vitest';
import {decodeLibraryPhoto,encodeLibraryPhoto,normalizeLibraryResult,searchLibraryPhotos} from '../src/core/imageLibrary';

describe('photo-library metadata',()=>{
  const photo={id:'123',width:800,height:600,src:'https://images.pexels.com/photos/123/image.jpeg',thumbnail:'https://images.pexels.com/photos/123/image.jpeg?w=320',alt:'Reference photo',photographer:'A photographer',photographerUrl:'https://www.pexels.com/@photographer/',pageUrl:'https://www.pexels.com/photo/123/'};
  it('preserves typed photo and source attribution through a drag payload',()=>{expect(decodeLibraryPhoto(encodeLibraryPhoto(photo))).toEqual(photo);});
  it('rejects executable URLs, lookalike photo hosts and malformed payloads',()=>{
    const result=normalizeLibraryResult({provider:'pexels',photos:[photo,{...photo,id:'bad',src:'javascript:alert(1)'},{...photo,id:'host',thumbnail:'https://images.pexels.com.evil.test/a.jpg'}],page:1,nextPage:2,totalResults:42});expect(result.photos).toEqual([photo]);expect(result.nextPage).toBe(2);expect(decodeLibraryPhoto('not JSON')).toBeNull();
  });
  it('rejects non-finite image dimensions and never serializes a non-finite result count',()=>{
    expect(normalizeLibraryResult({provider:'pexels',photos:[{...photo,width:Infinity},{...photo,height:NaN},photo],totalResults:Infinity}).photos).toEqual([photo]);
    expect(normalizeLibraryResult({provider:'pexels',photos:[photo],totalResults:Infinity}).totalResults).toBe(1);
  });
  it('requires the image search endpoint to remain on the current site',async()=>{
    await expect(searchLibraryPhotos('forest',1,undefined,'https://another-site.test/search')).rejects.toThrow(/on this site/);
    await expect(searchLibraryPhotos('forest',1,undefined,'//another-site.test/search')).rejects.toThrow(/on this site/);
  });
});
