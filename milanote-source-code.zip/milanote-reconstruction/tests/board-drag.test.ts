import {describe,it,expect} from 'vitest';
import {boardDragAnchor,boardDragGrab,canMoveDragToBoard} from '../src/core/boardDrag';
import type {Card,Workspace} from '../src/core/model';

const note:Card={id:'note',type:'note',text:'Payload',x:100,y:200,width:270,height:54,z:1};
const nested:Card={id:'nested-tile',type:'board',boardId:'nested',title:'Nested',x:400,y:200,width:160,height:160,z:2};
const workspace:Workspace={version:1,id:'drag',title:'Drag',rootBoardId:'root',updatedAt:'2026-10-26T00:00:00Z',boards:{root:{id:'root',title:'Root',cards:[note,nested],connections:[],viewport:{x:0,y:0,zoom:1}},target:{id:'target',title:'Target',parentBoardId:'root',cards:[],connections:[],viewport:{x:20,y:30,zoom:.5}},nested:{id:'nested',title:'Nested',parentBoardId:'root',cards:[],connections:[],viewport:{x:0,y:0,zoom:1}}}};
describe('hover board drag placement',()=>{
  it('retains the grabbed point of a multi-card group across destination zoom and stage offsets',()=>{
    const grab=boardDragGrab([note,nested],{x:115,y:210});expect(grab).toEqual({x:15,y:10});
    const anchor=boardDragAnchor({x:600,y:400},{left:63,top:80},{x:20,y:30,zoom:.5},grab);
    expect(anchor).toEqual({x:1019,y:570});
    expect(63+20+(anchor.x+grab.x)*.5).toBe(600);expect(80+30+(anchor.y+grab.y)*.5).toBe(400);
  });
  it('rejects missing, colliding and owned-descendant destinations using the actual atomic move rules',()=>{
    const before=structuredClone(workspace);expect(canMoveDragToBoard(workspace,'root','target',['note'])).toBe(true);
    expect(canMoveDragToBoard(workspace,'root','nested',['nested-tile'])).toBe(false);expect(canMoveDragToBoard(workspace,'root','missing',['note'])).toBe(false);
    const collision=structuredClone(workspace);collision.boards.target.cards.push({...note});expect(canMoveDragToBoard(collision,'root','target',['note'])).toBe(false);expect(workspace).toEqual(before);
  });
});
