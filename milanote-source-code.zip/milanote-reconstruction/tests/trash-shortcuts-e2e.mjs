import {openSavedTemplates} from './helpers/saved-templates.mjs';
import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { chromium, webkit } from 'playwright-core';

const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium';

const artifacts = new URL(engine==='webkit'?'../artifacts/webkit/':'../artifacts/', import.meta.url); await mkdir(artifacts, { recursive: true });
const browser=await (engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] }));
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true });
const page = await context.newPage(); page.setDefaultTimeout(10000);
const errors = [], results = []; page.on('pageerror', error => errors.push(error.stack || error.message));
const card = id => page.locator(`[data-card-id="${id}"]`);
function fixture() { return { version: 1, id: 'trash-browser', title: 'Trash test', rootBoardId: 'root', updatedAt: '2026-10-25T00:00:00Z', boards: {
  root: { id: 'root', title: 'Trash test board', viewport: { x: 20, y: 20, zoom: 1 }, cards: [
    { id: 'note', type: 'note', text: 'Trash parity note', x: 100, y: 100, width: 270, height: 54, z: 1 },
    { id: 'owner', type: 'board', boardId: 'child', title: 'Child', x: 600, y: 100, width: 160, height: 160, z: 1 },
  ], connections: [] },
  child: { id: 'child', title: 'Child', parentBoardId: 'root', viewport: { x: 20, y: 20, zoom: 1 }, cards: [{ id: 'inside', type: 'note', text: 'Original child content', x: 100, y: 100, width: 270, height: 54, z: 1 }], connections: [] },
} }; }
async function importFixture(value = fixture()) {
  const close = page.getByTitle('Close dialog', { exact: true }); if (await close.isVisible()) await close.click();
  if (await page.locator('.trashPanel').isVisible()) await page.getByTitle('Trash', { exact: true }).click();
  await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({ name: 'trash-test.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(value)) });
  await page.getByText('Workspace imported. Undo to return to your previous workspace.', { exact: true }).waitFor();
  await page.getByText('Saved on this device', { exact: true }).waitFor();
}
async function backup(name) {
  if (await page.locator('.trashPanel').isVisible()) await page.getByTitle('Trash', { exact: true }).click();
  await page.getByTitle('More options',{exact:true}).click();await page.getByRole('button',{name:'Export board',exact:true}).click();
  const pending = page.waitForEvent('download'); pending.catch(() => {});
  await page.getByRole('button', { name: /Workspace backup/ }).click();
  const download = await pending, path = new URL(name, artifacts); await download.saveAs(path.pathname);
  await page.getByTitle('Close dialog', { exact: true }).click();
  return JSON.parse(await readFile(path, 'utf8'));
}
async function run(name, action) {
  try { await action(); results.push({ name, status: 'passed' }); console.log('PASS', name); }
  catch (error) { results.push({ name, status: 'failed', message: error.stack }); process.exitCode = 1; console.error('FAIL', name, error.message); await page.screenshot({ path: new URL(`trash-shortcuts-failure-${results.length}.png`, artifacts).pathname, fullPage: true }).catch(() => {}); await page.keyboard.press('Escape').catch(() => {}); }
}
try {
  await page.goto(process.env.TEST_URL || 'http://127.0.0.1:5276', { waitUntil: 'networkidle' });
  await page.getByText('Saved on this device', { exact: true }).waitFor();
  await run('Trash popover matches observed geometry, persists after reload and restores by drag without losing content', async () => {
    await importFixture(); await card('note').click({ position: { x: 3, y: 3 } }); await page.getByTitle('Delete selected', { exact: true }).click();
    assert.equal(await card('note').count(), 0); await page.getByTitle('Trash', { exact: true }).click();
    const panel = page.locator('.trashPanel'), bounds = await panel.boundingBox();
    for (const [key, expected] of Object.entries({ x: 75, y: 590, width: 306, height: 384 })) assert.ok(Math.abs(bounds[key] - expected) < 1, `${key}: ${bounds[key]}`);
    assert.equal(await panel.locator('.trashPanel-day').innerText(), 'Today');
    assert.equal(await panel.locator('.trashPanel-card-note p').innerText(), 'Trash parity note');
    const stored = await backup('trash-before-restore.json'); assert.equal(stored.trash.length, 1); assert.equal(stored.trash[0].cards[0].id, 'note'); assert.equal(stored.trash[0].cards[0].text, 'Trash parity note');
    await page.getByText('Saved on this device', { exact: true }).waitFor(); await page.reload({ waitUntil: 'networkidle' }); await page.getByTitle('Trash', { exact: true }).click();
    const data = await page.evaluateHandle(() => new DataTransfer()); await panel.locator('[data-trash-id]').dispatchEvent('dragstart', { dataTransfer: data });
    const stage = page.locator('.stage'), rect = await stage.boundingBox(); await stage.dispatchEvent('drop', { dataTransfer: data, clientX: rect.x + 600, clientY: rect.y + 400 });
    await card('note').waitFor(); assert.equal((await card('note').innerText()).trimEnd(), 'Trash parity note'); assert.equal(await panel.locator('[data-trash-id]').count(), 0); assert.match(await panel.innerText(), /Your trash is empty/);
    const after = await backup('trash-after-restore.json'); assert.deepEqual(after.trash, []); assert.equal(after.boards.root.cards.find(card => card.id === 'note').text, 'Trash parity note'); assert.ok(after.boards.root.cards.find(card => card.id === 'note').x > 500);
  });
  await run('Shortcuts share one board; original deletion breaks aliases and original restoration reactivates them', async () => {
    await importFixture(); await card('owner').click({ position: { x: 3, y: 3 } }); await page.getByTitle('Create a Shortcut to This Board', { exact: true }).click();
    const alias = page.locator('.card-board').filter({ has: page.locator('.shortcut-indicator') }); assert.equal(await alias.count(), 1); const aliasId = await alias.getAttribute('data-card-id');
    let saved = await backup('shortcuts-created.json'); assert.equal(Object.keys(saved.boards).length, 2); assert.equal(saved.boards.root.cards.find(card => card.id === aliasId).boardId, 'child'); assert.equal(saved.boards.child.parentBoardId, 'root');
    await card('owner').click({ position: { x: 3, y: 3 } }); await page.getByTitle('Delete selected', { exact: true }).click(); assert.match(await alias.innerText(), /Original board deleted/);
    saved = await backup('shortcuts-broken.json'); assert.equal(saved.boards.child, undefined); assert.equal(saved.trash[0].boards.child.cards[0].id, 'inside');
    await page.getByText('Saved on this device', { exact: true }).waitFor(); await page.reload({ waitUntil: 'networkidle' }); assert.match(await alias.innerText(), /Original board deleted/); await page.getByTitle('Trash', { exact: true }).click(); await page.locator('[data-trash-id]').focus(); await page.keyboard.press('Enter');
    await card('owner').waitFor(); assert.doesNotMatch(await alias.innerText(), /Original board deleted/); await page.getByTitle('Trash', { exact: true }).click(); await alias.dblclick({ position: { x: 10, y: 10 } });
    await page.waitForFunction(() => document.querySelector('[aria-label="Current board title"]')?.value === 'Child'); assert.equal(await card('inside').count(), 1);
  });
  await run('Converting the original board to a template preserves ownership and creates independent editable copies', async () => {
    await importFixture(); await card('owner').click({ position: { x: 3, y: 3 } }); await page.getByTitle('Convert to Template', { exact: true }).click(); assert.match(await card('owner').innerText(), /Template/);
    let saved = await backup('template-converted.json'); assert.equal(saved.boards.child.isTemplate, true); assert.equal(saved.boards.child.parentBoardId, 'root');
    await openSavedTemplates(page); await page.getByRole('button',{name:'Use template Child',exact:true}).click();
    saved = await backup('template-instantiated.json'); const copy = Object.values(saved.boards).find(board => board.id !== 'child' && board.id !== 'root'); assert.ok(copy); assert.equal(copy.isTemplate, undefined); assert.equal(copy.cards[0].text, 'Original child content'); assert.notEqual(copy.cards[0].id, 'inside'); assert.equal(saved.boards.child.isTemplate, true);
  });
  assert.deepEqual(errors, []); await page.screenshot({ path: new URL('trash-shortcuts-preview.png', artifacts).pathname, fullPage: true });
} finally { await writeFile(new URL('trash-shortcuts-results.json', artifacts), JSON.stringify({ checkedAt: new Date().toISOString(), engine, url: process.env.TEST_URL, results, errors }, null, 2)); await browser.close(); }
