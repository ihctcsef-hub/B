import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
import {chromium,webkit} from 'playwright-core';

const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium',url=process.env.TEST_URL||'http://127.0.0.1:5306';
const artifacts=new URL(`../artifacts/media-providers-${engine}/`,import.meta.url);await mkdir(artifacts,{recursive:true});
const browser=await(engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']}));
const context=await browser.newContext({viewport:{width:1440,height:1000}}),origin=new URL(url).origin;
const results=[],errors=[],blockedProviderRequests=[],metadataRequests=[];
await context.route('**/*',async route=>{
  const target=new URL(route.request().url());
  if(['http:','https:'].includes(target.protocol)&&target.origin!==origin){blockedProviderRequests.push(target.href);return route.abort();}
  if(target.pathname==='/api/links/metadata'){metadataRequests.push(target.href);return route.fulfill({status:503,contentType:'application/json',body:JSON.stringify({error:'Metadata disabled in this URL conversion fixture.'})});}
  return route.continue();
});
const page=await context.newPage();page.setDefaultTimeout(10000);page.on('pageerror',error=>errors.push(error.message));
const card=()=>page.locator('[data-card-id="media-link"]');let serial=0;
function fixture(source,extra={}){const title=`Media provider study ${++serial}`;return {version:1,id:'media-provider-browser-study',title,rootBoardId:'root',updatedAt:new Date().toISOString(),boards:{root:{id:'root',title,cards:[{id:'media-link',type:'link',url:source,title:'Manual title before preview',description:'Manual description remains editable',previewSrc:'/assets/studio-objects.jpg',showMedia:false,showPreview:true,showInfo:true,x:100,y:100,width:330,height:280,z:1,...extra}],connections:[],viewport:{x:20,y:20,zoom:1}}}};}
async function workspace(){return page.evaluate(()=>new Promise(resolve=>{const open=indexedDB.open('visual-workspace');open.onerror=()=>resolve(null);open.onsuccess=()=>{const db=open.result;try{const request=db.transaction('documents','readonly').objectStore('documents').get('workspace');request.onsuccess=()=>{resolve(request.result?.workspace);db.close();};request.onerror=()=>{resolve(null);db.close();};}catch{db.close();resolve(null);}};}));}
const savedCard=doc=>doc?.boards.root.cards.find(item=>item.id==='media-link');
async function persisted(check){for(let i=0;i<120;i++){const doc=await workspace();if(doc?.id==='media-provider-browser-study'&&check(doc))return doc;await page.waitForTimeout(50);}throw Error('Expected media fixture state did not persist.');}
async function load(data){await page.keyboard.press('Escape');await page.locator('input[type=file][accept="application/json,.json"]').setInputFiles({name:'media-provider-study.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(data))});await page.waitForFunction(()=>document.querySelector('input[type=file][accept="application/json,.json"]')?.value==='');await persisted(doc=>doc.boards.root.title===data.boards.root.title);await card().locator('.link-content strong').waitFor();}
async function check(name,run){try{await run();results.push({name,status:'passed'});console.log('PASS',name);}catch(error){process.exitCode=1;results.push({name,status:'failed',message:error.stack});console.error('FAIL',name,error.message);await page.screenshot({path:new URL(`failure-${results.length}.png`,artifacts).pathname}).catch(()=>{});await page.keyboard.press('Escape').catch(()=>{});}}
const providers=[
 ['YouTube Music','https://music.youtube.com/watch?v=dQw4w9WgXcQ&si=source-tracking','https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ'],
 ['Mixcloud','https://www.mixcloud.com/artist-name/show-name/?utm_campaign=source-tracking','https://www.mixcloud.com/widget/iframe/?hide_cover=1&feed=%2Fartist-name%2Fshow-name%2F'],
 ['Apple Music','https://music.apple.com/us/album/example-album/123456?i=987654&at=source-affiliate','https://embed.music.apple.com/us/album/example-album/123456?i=987654'],
 ['Deezer','https://www.deezer.com/en/track/123456?utm_source=source-tracking','https://widget.deezer.com/widget/dark/track/123456'],
 ['CodePen','https://codepen.io/example-user/pen/AbCdE?default-tab=js&editable=true','https://codepen.io/example-user/embed/AbCdE?default-tab=result'],
 ['Airtable classic public view','https://airtable.com/shrAbCdEfGhIjKlMn?viewControls=off','https://airtable.com/embed/shrAbCdEfGhIjKlMn'],
 ['Vimeo unlisted','https://vimeo.com/123456/abc987?share=copy','https://player.vimeo.com/video/123456?h=abc987'],
 ['SoundCloud set','https://soundcloud.com/artist-name/sets/album-name?si=source-tracking','https://w.soundcloud.com/player/?url=https%3A%2F%2Fsoundcloud.com%2Fartist-name%2Fsets%2Falbum-name&auto_play=false'],
 ['Spotify localized share','https://open.spotify.com/intl-ar/track/AbC123?si=source-tracking','https://open.spotify.com/embed/track/AbC123'],
];
try{
 await page.goto(url,{waitUntil:'networkidle'});await page.getByText('Saved on this device',{exact:true}).waitFor();
 for(const [name,source,expected] of providers)await check(`${name}: native Media toggle, manual title editing and reload preserve the source URL and chosen player identity`,async()=>{
  await load(fixture(source));await card().locator('.link-content').click({position:{x:2,y:2}});assert.equal(await card().locator('.link-preview img').getAttribute('src'),'/assets/studio-objects.jpg');
  const toggle=page.getByTitle('Show media',{exact:true});assert.equal(await toggle.getAttribute('aria-pressed'),'false');await toggle.click();
  const frame=card().locator('iframe');await frame.waitFor();assert.equal(await frame.getAttribute('src'),expected);assert.match(await frame.getAttribute('sandbox'),/allow-scripts/);assert.equal(await frame.getAttribute('allow'), 'fullscreen; encrypted-media; picture-in-picture');
  await persisted(doc=>savedCard(doc)?.showMedia===true);await page.getByTitle('Rename link',{exact:true}).click();const editor=card().getByLabel('Link title',{exact:true});await editor.fill(`Edited manual ${name}`);await card().getByRole('button',{name:'Done',exact:true}).click();
  let stored=savedCard(await persisted(doc=>savedCard(doc)?.title===`Edited manual ${name}`));assert.equal(stored.url,source);assert.equal(stored.description,'Manual description remains editable');assert.equal(stored.showMedia,true);
  await page.reload({waitUntil:'networkidle'});await card().locator('iframe').waitFor();assert.equal(await card().locator('iframe').getAttribute('src'),expected);assert.equal(await card().locator('.link-content strong').innerText(),`Edited manual ${name}`);assert.equal(await card().locator('.link-content .link-source-url').getAttribute('href'),source);
  stored=savedCard(await workspace());assert.equal(stored.url,source);assert.equal(stored.title,`Edited manual ${name}`);assert.equal(stored.showMedia,true);
  await card().locator('.link-content').click({position:{x:2,y:2}});await page.getByTitle('Show media',{exact:true}).click();await card().locator('.link-preview img').waitFor();assert.equal(await card().locator('iframe').count(),0);assert.equal(await card().locator('.link-preview img').getAttribute('src'),'/assets/studio-objects.jpg');await persisted(doc=>savedCard(doc)?.showMedia===false);
 });
 await check('Unsupported and unresolved sources keep the editable image preview and source without offering an unsafe player',async()=>{
  for(const source of ['https://on.soundcloud.com/opaque-share','https://artist.bandcamp.com/track/example','https://music.amazon.com/albums/ASIN123','https://airtable.com/appAbCdEfGhIjKlMn/tblAbCdEfGhIjKlMn','https://codepen.io.evil.test/example/pen/AbCdE']){
   await load(fixture(source,{showMedia:true}));await card().locator('.link-content').click({position:{x:2,y:2}});assert.equal(await page.getByTitle('Show media',{exact:true}).count(),0);assert.equal(await card().locator('iframe').count(),0);assert.equal(await card().locator('.link-preview img').count(),1);assert.equal(await card().locator('.link-content .link-source-url').getAttribute('href'),source);assert.equal(savedCard(await workspace()).url,source);
  }
  await page.reload({waitUntil:'networkidle'});await card().locator('.link-preview img').waitFor();assert.equal(await card().locator('iframe').count(),0);await page.screenshot({path:new URL('unsupported-preview.png',artifacts).pathname});
 });
 await check('Media conversions make no metadata request, block every attempted provider load, and raise no uncaught browser errors',async()=>{
  assert.ok(blockedProviderRequests.length>=providers.length,'At least one native iframe load was blocked for each tested provider.');for(const [, ,expected] of providers)assert.ok(blockedProviderRequests.includes(expected),`Expected browser request was intercepted: ${expected}`);assert.deepEqual(metadataRequests,[]);assert.deepEqual(errors,[]);
 });
}finally{await writeFile(new URL('results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),url,engine,source:'Independent synthetic public-route fixtures; no authenticated Milanote comparison.',providerNetwork:'Every external browser request was aborted; player URLs and UI state were inspected, not live playback.',physicalIPadVerified:false,referenceVisualParityClaimed:false,results,errors,blockedProviderRequests,metadataRequests},null,2));await browser.close();}
