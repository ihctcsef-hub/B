import assert from 'node:assert/strict';
import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {chromium,webkit} from 'playwright-core';

const engine=process.env.BROWSER_ENGINE==='webkit'?'webkit':'chromium',url=process.env.TEST_URL||'http://127.0.0.1:5306';
const artifacts=new URL(`../artifacts/board-icon-catalog/${engine}/`,import.meta.url);await mkdir(artifacts,{recursive:true});
const browser=await(engine==='webkit'?webkit.launch({headless:true,...(process.env.WEBKIT_PATH?{executablePath:process.env.WEBKIT_PATH}:{})}):chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']}));
const page=await browser.newPage(),errors=[];page.on('pageerror',error=>errors.push(error.message));
const results=[];
try{
 await page.goto(url,{waitUntil:'networkidle'});
 const audit=await page.evaluate(async()=>{
  const icons=await import('/src/core/boardIcons.ts'),known=icons.getReferenceBoardIcons(),results=[];
  async function decode(source){const image=new Image();await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=reject;image.src=source;});return image;}
  for(const icon of known){
   const source=icons.boardIconSvgUrl(icon.id),image=await decode(source),canvas=document.createElement('canvas');canvas.width=canvas.height=160;const context=canvas.getContext('2d');context.drawImage(image,0,0);
   const pixels=context.getImageData(0,0,160,160).data;let ink=0;for(let i=3;i<pixels.length;i+=4)if(pixels[i])ink++;
   const tagged=icons.withBoardIconIdentity(canvas.toDataURL('image/png'),icon.id),raster=await decode(tagged);
   results.push({id:icon.id,ink,width:raster.naturalWidth,height:raster.naturalHeight,persistedId:icons.selectedBoardIconId(JSON.parse(JSON.stringify({icon:tagged})).icon),templateOnly:icon.templateOnly===true,searchable:icons.searchBoardIcons(icon.id).some(choice=>choice.id===icon.id)});
  }
  return {coverage:icons.boardIconCatalogCoverage(),results};
 });
 assert.equal(audit.results.length,1910);assert.equal(audit.coverage.referenceInventoryComplete,false);
 for(const icon of audit.results){assert.ok(icon.ink>0,`${icon.id}: empty glyph`);assert.equal(icon.width,160);assert.equal(icon.height,160);assert.equal(icon.persistedId,icon.id);assert.equal(icon.searchable,!icon.templateOnly,`${icon.id}: no exact-ID search result`);}
 results.push({name:'All 1910 captured identities decode, rasterize and retain identity; the 1865 observed picker identities remain searchable and 45 legacy template-only identities stay separate',status:'passed'});
 await writeFile(new URL('render-audit.json',artifacts),JSON.stringify(audit,null,2));
 // Optional reference-only fixture comparison. Every mismatch is retained; it
 // is not converted to visual acceptance with a threshold or a mask.
 if(process.env.ICON_REFERENCE_DIR){
  const fixture=await Promise.all(audit.results.map(async icon=>{try{return {id:icon.id,png:`data:image/png;base64,${(await readFile(`${process.env.ICON_REFERENCE_DIR}/${icon.id}.png`)).toString('base64')}`};}catch{return {id:icon.id,png:null};}}));
  const comparison=await page.evaluate(async fixture=>{
   const icons=await import('/src/core/boardIcons.ts'),rows=[];
   const load=source=>new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>resolve(image);image.onerror=reject;image.src=source;});
   function pixels(image){const canvas=document.createElement('canvas');canvas.width=canvas.height=48;const context=canvas.getContext('2d');context.drawImage(image,0,0,48,48);return context.getImageData(0,0,48,48).data;}
   for(const item of fixture){if(!item.png){rows.push({id:item.id,status:'reference-missing'});continue;}const local=pixels(await load(icons.boardIconSvgUrl(item.id))),reference=pixels(await load(item.png));let different=0,error=0;for(let i=0;i<local.length;i+=4){let mismatch=false;for(let channel=0;channel<4;channel++){const delta=Math.abs(local[i+channel]-reference[i+channel]);if(delta)mismatch=true;error+=delta;}if(mismatch)different++;}rows.push({id:item.id,status:different?'different':'exact',differentPixels:different,pixelCount:48*48,channelAbsoluteError:error});}
   return {acceptance:'Exact RGBA comparison, no threshold or mask. Rendering support does not establish per-icon parity.',rows};
  },fixture);
  await writeFile(new URL('reference-comparison.json',artifacts),JSON.stringify(comparison,null,2));
 }
 if(process.env.ICON_REFERENCE_SVG_DIR){
  const provenance=JSON.parse(await readFile(new URL('../src/data/boardIconReferenceProvenance.json',import.meta.url),'utf8'));
  const {createHash}=await import('node:crypto');
  const sources=await Promise.all(provenance.assets.map(async asset=>{const bytes=await readFile(`${process.env.ICON_REFERENCE_SVG_DIR}/${asset.id}.svg`);assert.equal(createHash('sha256').update(bytes).digest('hex'),asset.svg.sha256,`${asset.id}: source SVG changed`);return {id:asset.id,svg:bytes.toString('utf8')};}));
  const comparison=await page.evaluate(async sources=>{
   const icons=await import('/src/core/boardIcons.ts'),rows=[];
   const load=source=>new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>resolve(image);image.onerror=reject;image.src=source;});
   const pixels=(image,size)=>{const canvas=document.createElement('canvas');canvas.width=canvas.height=58;const context=canvas.getContext('2d');context.drawImage(image,(58-size)/2,(58-size)/2,size,size);return context.getImageData(0,0,58,58).data;};
   for(const source of sources){
    for(const {state,size,color} of [{state:'popup',size:21.9375,color:'#5f6672'},{state:'selected-board',size:28.796875,color:'#323b4a'}]){
     // The source contains only the visual asset. Runtime layout/palette were
     // measured independently in the actual picker and selected board icon.
     const parsed=new DOMParser().parseFromString(source.svg,'image/svg+xml'),svg=parsed.documentElement;
     svg.setAttribute('width','160');svg.setAttribute('height','160');svg.setAttribute('fill',color);
     const reference=pixels(await load(`data:image/svg+xml;base64,${btoa(new XMLSerializer().serializeToString(svg))}`),size);
     const local=pixels(await load(icons.boardIconSvgUrl(source.id,{color})),size);
     let different=0,error=0;for(let index=0;index<local.length;index+=4){let mismatch=false;for(let channel=0;channel<4;channel++){const delta=Math.abs(local[index+channel]-reference[index+channel]);if(delta)mismatch=true;error+=delta;}if(mismatch)different++;}
     rows.push({id:source.id,state,size,color,status:different?'different':'exact',differentPixels:different,pixelCount:58*58,channelAbsoluteError:error});
    }
   }
   return {acceptance:'Exact unmasked RGBA against captured SVG visual assets at independently measured runtime glyph sizes and palettes; not full popup/board screenshot parity or catalog-boundary acceptance.',rows};
  },sources);
  await writeFile(new URL('reference-svg-comparison.json',artifacts),JSON.stringify(comparison,null,2));
  assert.equal(comparison.rows.length,3820);for(const row of comparison.rows)assert.equal(row.differentPixels,0,`${row.id} ${row.state}: unmasked asset difference`);
  results.push({name:'All1910 captured SVG assets retain exact RGBA at observed popup and selected-board glyph sizes and palettes (3820 comparisons)',status:'passed'});
 }
 assert.deepEqual(errors,[]);
}catch(error){results.push({name:'Known identity render audit',status:'failed',message:error.stack});process.exitCode=1;console.error(error);}finally{await writeFile(new URL('results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),url,engine,results,errors,limitation:'This verifies the bounded known inventory. Pixel comparison differences and complete catalog boundaries remain separate open acceptance rows.'},null,2));await browser.close();}
