import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
import {chromium} from 'playwright-core';

const base=process.env.TEST_URL||'http://127.0.0.1:5279',artifacts=new URL('../artifacts/',import.meta.url),results=[],pageErrors=[];
await mkdir(artifacts,{recursive:true});
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
const page=await browser.newPage({viewport:{width:1440,height:1000}});page.setDefaultTimeout(10000);page.on('pageerror',error=>pageErrors.push(error.message));
const popup=()=>page.getByRole('dialog',{name:'Add image',exact:true});
const photo=id=>({id:String(id),width:800,height:600,src:`https://images.pexels.com/photos/${id}/image.jpeg`,thumbnail:`https://images.pexels.com/photos/${id}/image.jpeg?w=320`,alt:`Fixture ${id}`,photographer:'Fixture Author',photographerUrl:'https://www.pexels.com/@fixture/',pageUrl:`https://www.pexels.com/photo/${id}/`});
async function check(name,source,callback){try{await callback();results.push({name,source,status:'passed'});console.log('PASS',name);}catch(error){results.push({name,source,status:'failed',error:error.stack});process.exitCode=1;console.error('FAIL',name,error.message);}}
try{
  await check('Unconfigured local endpoint returns 503 and the UI offers upload without pretending to return photos','real local server without PEXELS_API_KEY',async()=>{
    const response=await page.request.get(`${base}/api/images/search?query=forest&page=1`);assert.equal(response.status(),503);assert.deepEqual(await response.json(),{error:'Image search is unavailable right now.'});
    await page.goto(`${base}/tests/fixtures/image-library.html`);await popup().getByRole('alert').waitFor();assert.equal(await popup().locator('figure').count(),0);await popup().getByRole('button',{name:'Upload your own',exact:true}).click();assert.equal(await page.getByLabel('Upload requested').textContent(),'true');
  });
  const requests=[];
  await page.route('https://images.pexels.com/**',route=>route.fulfill({contentType:'image/svg+xml',body:'<svg xmlns="http://www.w3.org/2000/svg" width="80" height="60"><rect width="80" height="60" fill="#ccddee"/></svg>'}));
  await page.route('**/api/images/search?**',route=>{
    const url=new URL(route.request().url()),query=url.searchParams.get('query'),number=Number(url.searchParams.get('page'));requests.push({query,page:number});
    return route.fulfill({contentType:'application/json',body:JSON.stringify({provider:'pexels',photos:[photo(number===1?101:102)],page:number,totalResults:2,nextPage:number===1?2:null})});
  });
  await check('Search input requests typed metadata; paginated results append without replacing earlier photos','explicit browser API fixture (no live provider)',async()=>{
    await page.reload();await popup().getByRole('button',{name:'Add photo: Fixture 101',exact:true}).waitFor();await popup().getByLabel('Search images',{exact:true}).fill('forest');
    await page.waitForFunction(()=>document.querySelector('[aria-label="Search images"]')?.value==='forest');
    await page.waitForTimeout(400);assert.ok(requests.some(request=>request.query==='forest'&&request.page===1));
    await popup().getByRole('button',{name:'Load more',exact:true}).click();await popup().getByRole('button',{name:'Add photo: Fixture 102',exact:true}).waitFor();assert.equal(await popup().locator('figure').count(),2);assert.ok(requests.some(request=>request.query==='forest'&&request.page===2));
    await popup().getByRole('button',{name:'Add photo: Fixture 102',exact:true}).click();assert.equal(await page.getByLabel('Selected photo').textContent(),'102');
  });
  await check('HTML5 drag payload decodes the original typed photo metadata','explicit browser API fixture (no live provider)',async()=>{
    await popup().getByRole('button',{name:'Add photo: Fixture 101',exact:true}).dragTo(page.getByLabel('Photo drop target',{exact:true}));assert.equal(await page.getByLabel('Dropped photo').textContent(),'101');
  });
  await check('Escape and outside click close the library; the image trigger opens it again','browser component behavior',async()=>{
    await popup().getByLabel('Search images',{exact:true}).focus();await page.keyboard.press('Escape');assert.equal(await popup().count(),0);await page.getByRole('button',{name:'Open image library',exact:true}).click();await popup().waitFor();await page.getByLabel('Photo drop target',{exact:true}).click();assert.equal(await popup().count(),0);
  });
  assert.deepEqual(pageErrors,[]);results.push({name:'No uncaught browser errors',source:'browser runtime',status:'passed'});
}finally{await writeFile(new URL('image-library-e2e-results.json',artifacts),JSON.stringify({checkedAt:new Date().toISOString(),base,livePexelsVerified:false,reason:'No PEXELS_API_KEY supplied; provider responses in success checks are explicit fixtures.',results,pageErrors},null,2));await browser.close();}
