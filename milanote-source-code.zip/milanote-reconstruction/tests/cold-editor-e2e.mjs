/** Exercise the first lazy editor against a real, empty Vite dependency cache. */
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {PDFDocument,rgb} from 'pdf-lib';
import{mkdtemp,mkdir,rm,writeFile}from'node:fs/promises';
import{tmpdir}from'node:os';import path from'node:path';import{fileURLToPath}from'node:url';
import{createServer}from'vite';import{chromium}from'playwright-core';
const root=fileURLToPath(new URL('../',import.meta.url)),cacheDir=await mkdtemp(path.join(tmpdir(),'canvas-cold-editor-')),out=new URL('../artifacts/cold-editor/',import.meta.url);await mkdir(out,{recursive:true});
const errors=[],requests=[],results=[],navigations=[];const pdf=await PDFDocument.create(),paper=pdf.addPage([360,480]);paper.drawRectangle({x:0,y:0,width:360,height:480,color:rgb(1,0,0)});const pdfBytes=Buffer.from(await pdf.save()),pdfDigest=createHash('sha256').update(pdfBytes).digest('hex');let server,browser,page,failure;
try{
 server=await createServer({root,cacheDir,server:{host:'127.0.0.1',port:0,strictPort:true,hmr:false},clearScreen:false,logLevel:'error'});await server.listen();const address=server.httpServer.address();assert.ok(address&&typeof address==='object');
 browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']});page=await browser.newPage({viewport:{width:1440,height:1000}});page.setDefaultTimeout(15000);page.on('pageerror',error=>errors.push(error.stack||error.message));page.on('request',request=>{if(/react|tiptap|NoteEditor|pdfjs|hash\.js/.test(request.url()))requests.push(request.url());});page.on('framenavigated',frame=>{if(frame===page.mainFrame())navigations.push(frame.url());});
 await page.goto(`http://127.0.0.1:${address.port}`,{waitUntil:'domcontentloaded'});await page.getByText('Saved on this device',{exact:true}).waitFor();
 await page.getByTitle('Add Note',{exact:true}).click();const editor=page.getByLabel('Note text',{exact:true});await editor.fill('First cold editor — النص العربي');await page.getByLabel('Current board title').click();await page.locator('.world .card-note').filter({hasText:'First cold editor'}).waitFor();
 results.push({name:'The first lazy note editor mounts, edits and saves from a truly empty optimizer cache without reload or warmup',status:'passed'});
 const versions=new Set(requests.filter(url=>/\/(?:react|react-dom(?:_client)?|react_jsx(?:-dev)?-runtime)\.js(?:\?|$)/.test(url)).map(url=>new URL(url).searchParams.get('v')));assert.equal(versions.size,1,`React runtime requests must retain one dependency generation: ${JSON.stringify([...versions])}`);assert.ok(requests.some(url=>url.includes('/src/components/NoteEditor.tsx')),'The actual lazy source module must load');assert.deepEqual(errors,[]);
 results.push({name:'React and JSX runtimes keep the same dependency generation across the lazy import and no hook-dispatcher error occurs',status:'passed'});await page.screenshot({path:new URL('first-note.png',out).pathname});
 await page.keyboard.press('Escape');
 const chooser=await Promise.all([page.waitForEvent('filechooser'),page.getByTitle('Add File',{exact:true}).click()]).then(([fileChooser])=>fileChooser);await chooser.setFiles({name:'first-cold-paper.pdf',mimeType:'application/pdf',buffer:pdfBytes});
 await page.getByTitle('Place on board',{exact:true}).click();
 const preview=page.locator('.world .card-file .pdf-thumbnail');await preview.locator('img').waitFor();assert.equal(await preview.getAttribute('data-preview-digest'),pdfDigest);assert.deepEqual(await preview.locator('img').evaluate(async img=>{await img.decode();const canvas=document.createElement('canvas');canvas.width=canvas.height=1;canvas.getContext('2d').drawImage(img,0,0,1,1);return [...canvas.getContext('2d').getImageData(0,0,1,1).data];}),[255,0,0,255]);
 results.push({name:'The first native PDF upload renders the real first page from the same empty-cache session without conversion warmup',status:'passed'});
 const afterPdfVersions=new Set(requests.filter(url=>/\/(?:react|react-dom(?:_client)?|react_jsx(?:-dev)?-runtime)\.js(?:\?|$)/.test(url)).map(url=>new URL(url).searchParams.get('v')));assert.deepEqual([...afterPdfVersions],[...versions]);assert.equal(navigations.length,1,'Opening the first PDF must not trigger a dependency-optimizer page reload');assert.ok(requests.some(url=>url.includes('pdfjs-dist')),'The actual PDF.js dependency must load');assert.deepEqual(errors,[]);
 results.push({name:'React keeps one generation and the first PDF introduces no reload or uncaught browser error',status:'passed'});await page.screenshot({path:new URL('first-pdf.png',out).pathname});
}catch(error){failure=error;results.push({name:'Cold editor regression',status:'failed',message:error.stack});await page?.screenshot({path:new URL('failure.png',out).pathname}).catch(()=>{});process.exitCode=1;
}finally{await browser?.close();await server?.close();await rm(cacheDir,{recursive:true,force:true});await writeFile(new URL('results.json',out),JSON.stringify({checkedAt:new Date().toISOString(),isolatedEmptyDependencyCache:true,hmr:false,cacheRemoved:true,results,errors,requests,navigations},null,2));}
for(const result of results)console.log(result.status==='passed'?'PASS':'FAIL',result.name);if(failure)console.error(failure.message);
