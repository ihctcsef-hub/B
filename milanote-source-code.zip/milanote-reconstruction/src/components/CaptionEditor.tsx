import { lazy, Suspense, useEffect, useRef, useState } from 'react';
import { Bold, Italic, Strikethrough, Underline, Link, Check } from 'lucide-react';
import type { NoteEditorHandle, NoteEditorCommand } from './NoteEditor';
import { noteContentHtml } from '../core/richText';
import './caption-editor.css';

const NoteEditor=lazy(()=>import('./NoteEditor').then(module=>({default:module.NoteEditor})));
export interface CaptionEditorProps {
  text:string;
  html?:string;
  active?:boolean;
  autoFocus?:boolean;
  ariaLabel:string;
  onChange:(content:{text:string;html:string;height:number})=>void;
  onFinish?:()=>void;
  readOnly?:boolean;
}

/** Captions use the same sanitized rich document as notes, with their own selection. */
export function CaptionEditor({text,html,active=false,autoFocus=false,ariaLabel,onChange,onFinish,readOnly=false}:CaptionEditorProps){
  const [open,setOpen]=useState(active);
  const [linkOpen,setLinkOpen]=useState(false);
  const [url,setUrl]=useState('');
  const ref=useRef<NoteEditorHandle>(null);
  const root=useRef<HTMLDivElement>(null);
  useEffect(()=>{setOpen(active);},[active]);
  function finish(){setOpen(false);setLinkOpen(false);onFinish?.();}
  function run(command:NoteEditorCommand,value?:string){ref.current?.run(command,value);}
  return <div ref={root} className={`captionEditor${open?' captionEditor-active':''}`} onPointerDown={event=>event.stopPropagation()} onDoubleClick={event=>{event.stopPropagation();if(!readOnly)setOpen(true);}}
    onKeyDown={event=>{event.stopPropagation();if(event.key==='Escape'&&open){event.preventDefault();finish();}}}>
    {open&&!readOnly?<>
      <div className="captionEditor-tools" role="toolbar" aria-label={`${ariaLabel} formatting`}>
        {([{command:'bold',label:'Bold',Icon:Bold},{command:'italic',label:'Italic',Icon:Italic},{command:'underline',label:'Underline',Icon:Underline},{command:'strike',label:'Strikethrough',Icon:Strikethrough}] as const).map(({command,label,Icon})=><button key={command} title={`Caption ${label}`} type="button" onPointerDown={event=>event.preventDefault()} onClick={()=>run(command)}><Icon size={13}/></button>)}
        <button title="Caption text link" type="button" onPointerDown={event=>event.preventDefault()} onClick={()=>setLinkOpen(!linkOpen)}><Link size={13}/></button>
        <button title="Finish caption" type="button" onPointerDown={event=>event.preventDefault()} onClick={finish}><Check size={13}/></button>
      </div>
      {linkOpen&&<div className="captionEditor-link"><input aria-label="Caption link URL" placeholder="https://example.com" value={url} onChange={event=>setUrl(event.target.value)}/><button type="button" onClick={()=>{run('link',url);setLinkOpen(false);}}>Apply</button><button type="button" onClick={()=>{run('unsetLink');setLinkOpen(false);}}>Remove</button></div>}
      <Suspense fallback={<span>Loading…</span>}><NoteEditor ref={ref} text={text} html={html} autoFocus={autoFocus||open} ariaLabel={ariaLabel} onRequestLink={()=>setLinkOpen(true)} onChange={({text,html,height})=>onChange({text,html,height})} onBlur={event=>{const next=event.relatedTarget;if(next instanceof Node&&root.current?.contains(next))return;queueMicrotask(()=>{if(!root.current?.contains(document.activeElement))finish();});}}/></Suspense>
    </>:<div className="captionEditor-view" role={readOnly?undefined:'button'} tabIndex={readOnly?undefined:0} aria-label={`Edit ${ariaLabel.toLowerCase()}`} onClick={()=>{if(!readOnly)setOpen(true);}} onKeyDown={event=>{if(!readOnly&&event.key==='Enter'){event.preventDefault();setOpen(true);}}} dangerouslySetInnerHTML={{__html:text||html?noteContentHtml(text,html):'<p class="captionEditor-placeholder">Write a caption…</p>'}}/>}
  </div>;
}
