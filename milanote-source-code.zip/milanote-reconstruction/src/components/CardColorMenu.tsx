import { useEffect,useRef,useState } from 'react';
import { createPortal } from 'react-dom';
import { CARD_COLORS } from '../core/cardAppearance';
import { swatchInk } from '../core/colors';
import './card-color-menu.css';

export function CardColorMenu({background='#ffffff',strip,customColors=[],allowStrip=true,onChange,onClose}:{background?:string;strip?:string;customColors?:string[];allowStrip?:boolean;onChange:(value:{background?:string;strip?:string|null;remember?:string})=>void;onClose:()=>void}){
  const [mode,setMode]=useState<'background'|'strip'>('background');
  const root=useRef<HTMLDivElement>(null),close=useRef(onClose);close.current=onClose;
  useEffect(()=>{
    const outside=(event:PointerEvent)=>{if((event.target as Element).closest?.('[data-card-color-trigger]'))return;if(!root.current?.contains(event.target as Node))close.current();};
    const key=(event:KeyboardEvent)=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close.current();}};
    document.addEventListener('pointerdown',outside,true);document.addEventListener('keydown',key,true);
    return()=>{document.removeEventListener('pointerdown',outside,true);document.removeEventListener('keydown',key,true);};
  },[]);
  const selected=mode==='strip'?strip||'transparent':background;
  function choose(color:string,remember=false){onChange({...mode==='strip'?{strip:color==='transparent'?null:color}:{background:color},...(remember?{remember:color}:{})});}
  function button(color:string,text=false){return <button type="button" key={color} aria-label={`${mode==='strip'?'Top strip':'Background'} ${color}`} aria-pressed={selected===color} className={color==='transparent'?'card-color-transparent':''} style={{backgroundColor:color,color:swatchInk(color)}} onClick={()=>choose(color)}>{text?'A':''}</button>;}
  return createPortal(<div ref={root} className="card-color-menu" role="dialog" aria-label="Card color" style={{left:Math.max(6,Math.min(60.5,window.innerWidth-166)),top:80}} onPointerDown={event=>event.stopPropagation()}>
    {allowStrip&&<div className="card-color-modes"><button type="button" aria-pressed={mode==='background'} onClick={()=>setMode('background')}><span className="card-color-background-icon"/>Background</button><button type="button" aria-pressed={mode==='strip'} onClick={()=>setMode('strip')}><span className="card-color-strip-icon"/>Top strip</button></div>}
    <div className="card-color-grid card-color-base">{[...CARD_COLORS,'transparent'].map(color=>button(color))}</div>
    {!!customColors.length&&<><div className="card-color-grid card-color-recent">{customColors.map(color=>button(color,true))}</div><div className="card-color-grid card-color-recent">{customColors.map(color=>button(color))}</div></>}
    <label className="card-color-custom"><span>🌈</span>Custom color…<input type="color" aria-label="Custom card color" value={/^#[\da-f]{6}$/i.test(selected)?selected:'#ffffff'} onChange={event=>choose(event.target.value,true)}/></label>
  </div>,document.body);
}
