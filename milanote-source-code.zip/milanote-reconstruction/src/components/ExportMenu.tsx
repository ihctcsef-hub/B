import { useEffect,useRef } from 'react';
import { createPortal } from 'react-dom';
import './export-menu.css';

export type ExportMenuKind='pdf'|'pdf-high'|'png'|'docx'|'md'|'txt'|'zip';
export interface ExportMenuProps {
  anchor?:{left:number;top:number};
  includeSubBoards:boolean;
  onIncludeSubBoardsChange:(include:boolean)=>void;
  busy:boolean;
  onExport:(kind:ExportMenuKind)=>void;
  onClose:()=>void;
  zipSizeLabel?:string;
}

/** The observed board export popup; callers own export work and persisted options. */
export function ExportMenu({anchor,includeSubBoards,onIncludeSubBoardsChange,busy,onExport,onClose,zipSizeLabel}:ExportMenuProps){
  const root=useRef<HTMLDivElement>(null);
  const close=useRef(onClose);close.current=onClose;
  const position={
    left:Math.max(6,Math.min(anchor?.left??window.innerWidth-290,window.innerWidth-238)),
    top:Math.max(6,Math.min(anchor?.top??74,window.innerHeight-361)),
  };
  useEffect(()=>{
    function outside(event:PointerEvent){if((event.target as Element).closest?.('[data-export-trigger]'))return;if(!root.current?.contains(event.target as Node))close.current();}
    function key(event:KeyboardEvent){if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close.current();}}
    document.addEventListener('pointerdown',outside,true);document.addEventListener('keydown',key,true);
    return()=>{document.removeEventListener('pointerdown',outside,true);document.removeEventListener('keydown',key,true);};
  },[]);
  const item=(kind:ExportMenuKind,label:string)=><button type="button" role="menuitem" disabled={busy} onClick={()=>onExport(kind)}>{label}</button>;
  return createPortal(<div ref={root} className="board-export-menu" role="menu" aria-label="Export board" aria-busy={busy} style={position} onPointerDown={event=>event.stopPropagation()} onKeyDown={event=>event.stopPropagation()}>
    <section className="board-export-layout">
      <h2>Export the current board layout</h2>
      {item('pdf','PDF standard (small file size)')}
      {item('pdf-high','PDF high quality (large file size)')}
      {item('png','PNG image')}
    </section>
    <section className="board-export-linear">
      <h2>Convert to a linear document</h2>
      <label className="board-export-subboards"><span>Include sub-boards</span><input type="checkbox" role="switch" aria-label="Include sub-boards" checked={includeSubBoards} disabled={busy} onChange={event=>onIncludeSubBoardsChange(event.target.checked)}/></label>
      {item('docx','Word document')}
      {item('md','Markdown')}
      {item('txt','Plain text')}
    </section>
    <section className="board-export-files">
      <h2>Download all images and files</h2>
      <button type="button" role="menuitem" disabled={busy} onClick={()=>onExport('zip')}><span>Generate ZIP file</span>{zipSizeLabel&&<span className="board-export-zip-size">{zipSizeLabel}</span>}</button>
    </section>
  </div>,document.body);
}
