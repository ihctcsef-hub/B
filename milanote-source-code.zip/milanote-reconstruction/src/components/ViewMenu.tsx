import { useEffect,useRef } from 'react';
import { createPortal } from 'react-dom';
import { Minus,Plus } from 'lucide-react';
import './view-menu.css';

export function ViewMenu({zoom,onZoom,onFit,onPresent,onClose}:{zoom:number;onZoom:(zoom:number)=>void;onFit:()=>void;onPresent:()=>void;onClose:()=>void}){
  const root=useRef<HTMLDivElement>(null),close=useRef(onClose);close.current=onClose;
  useEffect(()=>{
    function outside(event:PointerEvent){if((event.target as Element).closest?.('[data-view-trigger]'))return;if(!root.current?.contains(event.target as Node))close.current();}
    function key(event:KeyboardEvent){if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close.current();}}
    document.addEventListener('pointerdown',outside,true);document.addEventListener('keydown',key,true);
    return()=>{document.removeEventListener('pointerdown',outside,true);document.removeEventListener('keydown',key,true);};
  },[]);
  return createPortal(<div ref={root} className="board-view-menu" role="menu" aria-label="Board view" style={{left:Math.max(6,window.innerWidth-237.2),top:Math.min(74.4,Math.max(6,window.innerHeight-294))}} onPointerDown={event=>event.stopPropagation()}>
    <section><h2>Zoom</h2><p>Tip: hold ctrl and use mouse wheel to zoom</p><div className="board-view-zoom"><button type="button" aria-label="Zoom out" onClick={()=>onZoom(zoom/1.2)}><Minus size={14}/></button><div><input aria-label="Board zoom" type="range" min="15" max="250" value={Math.round(zoom*100)} onChange={event=>onZoom(Number(event.target.value)/100)}/><button type="button" title="Reset zoom to 100%" onClick={()=>onZoom(1)}>{Math.round(zoom*100)}%</button></div><button type="button" aria-label="Zoom in" onClick={()=>onZoom(zoom*1.2)}><Plus size={14}/></button></div><button className="board-view-fit" type="button" role="menuitem" onClick={onFit}>Scale to fit</button></section>
    <section><h2>Presentation mode</h2><p>Go full-screen &amp; hide toolbar, dot grid etc.</p><button className="board-view-present" type="button" role="menuitem" title="Present" onClick={onPresent}>Present</button></section>
  </div>,document.body);
}
