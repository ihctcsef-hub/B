import { useEffect, useRef, useState } from 'react';
import { CalendarDays, Check, ChevronRight, SquareCheck } from 'lucide-react';
import type { TableAction } from './TableEditor';
import type { TableCellMeta, TableCellType } from '../core/spreadsheet';
import './cell-type-menu.css';

export interface CellTypeMenuProps {
  meta?:TableCellMeta;
  value?:string;
  onRun:(action:TableAction,value?:string|boolean)=>void;
  onClose:()=>void;
  anchor?:{left:number;top:number};
}
const types:Array<{type:TableCellType;label:string;icon:string}>=[{type:'auto',label:'Auto',icon:'A'},{type:'number',label:'Number',icon:'¹²³'},{type:'currency',label:'Currency',icon:'$'},{type:'percentage',label:'Percentage',icon:'%'},{type:'text',label:'Text',icon:'ᴬᴮᶜ'},{type:'date',label:'Date & Time',icon:''},{type:'checkbox',label:'Checkbox',icon:''}];
const currencyCodes=(()=>{try{return (Intl as unknown as {supportedValuesOf?:(key:string)=>string[]}).supportedValuesOf?.('currency')||['USD','EUR','GBP','JPY','CNY','CAD','AUD','CHF','INR','SAR','AED'];}catch{return ['USD','EUR','GBP','JPY','CNY','CAD','AUD','CHF','INR','SAR','AED'];}})();
const currencyNames=new Intl.DisplayNames(['en'],{type:'currency'});
const dateFormats=[['none','None'],['wordsLong','February 29, 2016'],['wordsShort','Feb 29, 2016'],['numericLong','2/29/2016'],['numericShort','2/29/16'],['numericDashed','2-29-2016'],['weekday','Monday, February 29, 2016']];
const timeFormats=[['none','None'],['twelveHourSeconds','1:24:56 PM'],['twelveHour','1:24 PM'],['twentyFourHourSeconds','13:24:56'],['twentyFourHour','13:24']];

/** Cell formatting controls measured in the authenticated table tool. */
export function CellTypeMenu({meta={},value='',onRun,onClose,anchor={left:60.5,top:80}}:CellTypeMenuProps){
  const root=useRef<HTMLDivElement>(null);
  const [active,setActive]=useState<TableCellType|null>(['number','currency','percentage','date'].includes(meta.type||'')?meta.type!:null);
  const selected=meta.type||'auto';
  const numeric=value.trim()!==''&&(/^[\s$€£+-]*[\d,.]+\s*%?$/.test(value)||value.trimStart().startsWith('='));
  useEffect(()=>{
    function outside(event:PointerEvent){if(event.target instanceof Node&&!root.current?.contains(event.target)&&!(event.target as Element).closest?.('[data-table-cell-type]'))onClose();}
    function key(event:KeyboardEvent){if(event.key==='Escape'){event.preventDefault();event.stopPropagation();onClose();}}
    document.addEventListener('pointerdown',outside);window.addEventListener('keydown',key,true);
    return()=>{document.removeEventListener('pointerdown',outside);window.removeEventListener('keydown',key,true);};
  },[onClose]);
  const decimals=meta.decimals===undefined?(active==='currency'?'2':''):String(meta.decimals);
  const submenuIndex=types.findIndex(item=>item.type===active);
  const submenuTop=Math.min(8+submenuIndex*32,Math.max(0,window.innerHeight-anchor.top-(active==='currency'?174:active==='date'?92:94)-8));
  function choose(type:TableCellType){onRun('setType',type);setActive(['number','currency','percentage','date'].includes(type)?type:null);}
  return <div ref={root} className="cellTypeMenu" role="dialog" aria-label="Cell type" style={{left:anchor.left,top:anchor.top}} onPointerDown={event=>event.stopPropagation()} onKeyDown={event=>event.stopPropagation()}>
    <div className="cellTypeMenu-types" role="menu" aria-label="Cell types">{types.map(item=>{
      const disabled=numeric&&(item.type==='date'||item.type==='checkbox')&&selected!==item.type;
      const hasSubmenu=['number','currency','percentage','date'].includes(item.type);
      return <button key={item.type} type="button" role="menuitemradio" aria-checked={selected===item.type} disabled={disabled} className={active===item.type?'cellTypeMenu-active':''} onPointerEnter={()=>{if(!disabled)setActive(hasSubmenu?item.type:null);}} onClick={()=>choose(item.type)}>
        <span className="cellTypeMenu-icon" aria-hidden="true">{item.type==='date'?<CalendarDays size={13}/>:item.type==='checkbox'?<SquareCheck size={13}/>:item.icon}</span><span>{item.label}</span>{selected===item.type?<Check size={14}/>:hasSubmenu?<ChevronRight size={12}/>:null}
      </button>;
    })}</div>
    {active&&['number','currency','percentage','date'].includes(active)&&<div className={`cellTypeMenu-options cellTypeMenu-options-${active}`} style={{top:submenuTop}} aria-label={`${types.find(item=>item.type===active)?.label} options`}>
      {active==='date'?<>
        <label className="cellTypeMenu-field"><span>Date format:</span><select aria-label="Date format" value={meta.dateFormat||'wordsShort'} onChange={event=>onRun('setDateFormat',event.target.value)}>{dateFormats.map(([key,label])=><option value={key} key={key}>{label}</option>)}</select></label>
        <label className="cellTypeMenu-field"><span>Time format:</span><select aria-label="Time format" value={meta.timeFormat||'none'} onChange={event=>onRun('setTimeFormat',event.target.value)}>{timeFormats.map(([key,label])=><option value={key} key={key}>{label}</option>)}</select></label>
      </>:<>
        <label className="cellTypeMenu-field"><span>Decimals:</span><input type="number" min={0} max={10} step={1} placeholder="Auto" aria-label="Decimals" value={decimals} onChange={event=>onRun('setDecimals',event.target.value)}/></label>
        <label className="cellTypeMenu-check"><input type="checkbox" aria-label="Thousands separator" checked={meta.thousandsSeparator!==false} onChange={event=>onRun('setThousandsSeparator',event.target.checked)}/><span>Thousands separator</span></label>
        {active==='currency'&&<>
          <label className="cellTypeMenu-check"><input type="checkbox" aria-label="Accounting style" checked={!!meta.accounting} onChange={event=>onRun('setAccounting',event.target.checked)}/><span>Accounting style</span></label>
          <label className="cellTypeMenu-field"><span>Currency:</span><select aria-label="Currency" value={meta.currency||'USD'} onChange={event=>onRun('setCurrency',event.target.value)}>{currencyCodes.map(code=><option key={code} value={code}>{currencyNames.of(code)||code} ({code})</option>)}</select></label>
          <label className="cellTypeMenu-field"><span className="cellTypeMenu-emptyLabel"/><select aria-label="Currency display" value={meta.currencyDisplay||'symbol'} onChange={event=>onRun('setCurrencyDisplay',event.target.value)}>{(['symbol','code','name'] as const).map(display=><option key={display} value={display}>{new Intl.NumberFormat('en-US',{style:'currency',currency:meta.currency||'USD',currencyDisplay:display}).format(12345)}</option>)}</select></label>
        </>}
      </>}
    </div>}
  </div>;
}
