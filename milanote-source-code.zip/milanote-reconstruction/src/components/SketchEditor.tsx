import { useEffect,useRef,useState } from 'react';
import type { CSSProperties,KeyboardEvent,PointerEvent,ReactNode } from 'react';
import { Check,ChevronDown,Eraser,MousePointer2,Pencil,Redo2,Trash2,Undo2,X } from 'lucide-react';
import type { Point,SketchPath } from '../core/model';
import { commitDrawing,drawingBounds,drawingHistory,drawingPathData,drawingPathsInRect,hitDrawingPath,redoDrawing,translateDrawingPaths,undoDrawing } from '../core/drawing';
import './sketch-editor.css';

export interface SketchEditorValue {paths:SketchPath[];width:number;height:number;background:string}
export interface SketchEditorProps extends SketchEditorValue {
  onSave:(value:SketchEditorValue)=>void;
  onCancel:()=>void;
  mode?:'sketch'|'board';
  underlay?:ReactNode;
}
type DrawingTool='pen'|'select'|'eraser';
type Gesture=
  |{type:'pen';pointer:number;points:Point[]}
  |{type:'erase';pointer:number;before:SketchPath[];after:SketchPath[]}
  |{type:'move';pointer:number;before:SketchPath[];start:Point;selected:number[]}
  |{type:'marquee';pointer:number;start:Point;selected:number[]};
const COLORS=['#323b4a','#ed4b35','#f2bf35','#55a462','#3f8bc9','#9359b4','#ffffff'];
const SIZES=[1,2,4,8];
const bounded=(n:number,min:number,max:number)=>Math.max(min,Math.min(max,n));

/** One drawing session owns its history; Save is the only document mutation. */
export function SketchEditor({paths,width,height,background,onSave,onCancel,mode='sketch',underlay}:SketchEditorProps){
  const [history,setHistory]=useState(()=>drawingHistory(paths));
  const [tool,setTool]=useState<DrawingTool>('pen');
  const [color,setColor]=useState(COLORS[0]);
  const previousColor=useRef(COLORS[1]);
  const [size,setSize]=useState(2);
  const [selected,setSelected]=useState<number[]>([]);
  const [draft,setDraft]=useState<SketchPath[]|null>(null);
  const draftRef=useRef<SketchPath[]|null>(null);
  const [penPath,setPenPath]=useState<SketchPath|null>(null);
  const [marquee,setMarquee]=useState<{from:Point;to:Point}|null>(null);
  const [palette,setPalette]=useState(false);
  const [weights,setWeights]=useState(false);
  const [canvasSize,setCanvasSize]=useState({width:1,height:1});
  const dialog=useRef<HTMLDivElement>(null),workspace=useRef<HTMLDivElement>(null),svg=useRef<SVGSVGElement>(null);
  const gesture=useRef<Gesture|null>(null);
  const present=draft||history.present;
  const presentRef=useRef(present);presentRef.current=present;
  const latestSave=useRef(onSave);latestSave.current=onSave;
  const dimensions={width:Math.max(1,width),height:Math.max(1,height)};
  useEffect(()=>{
    const previous=document.activeElement;dialog.current?.focus();
    return()=>{if(previous instanceof HTMLElement&&previous.isConnected)previous.focus();};
  },[]);
  useEffect(()=>{
    const element=workspace.current;if(!element)return;
    function measure(){
      const rect=element!.getBoundingClientRect(),padding=mode==='board'?0:48;
      const zoom=Math.min((rect.width-padding)/dimensions.width,(rect.height-padding)/dimensions.height);
      setCanvasSize({width:Math.max(1,dimensions.width*zoom),height:Math.max(1,dimensions.height*zoom)});
    }
    measure();const observer=new ResizeObserver(measure);observer.observe(element);return()=>observer.disconnect();
  },[width,height,mode]);
  function commit(value:SketchPath[]){setHistory(state=>commitDrawing(state,value));clearWorking();}
  function clearWorking(){gesture.current=null;draftRef.current=null;setDraft(null);setPenPath(null);setMarquee(null);}
  function setWorking(value:SketchPath[]){draftRef.current=value;setDraft(value);}
  function undo(){clearWorking();setSelected([]);setHistory(undoDrawing);dialog.current?.focus({preventScroll:true});}
  function redo(){clearWorking();setSelected([]);setHistory(redoDrawing);dialog.current?.focus({preventScroll:true});}
  function save(){
    const active=gesture.current;
    const next=active?.type==='pen'&&active.points.length?[...history.present,{points:active.points,color,width:size}]:draftRef.current||history.present;
    latestSave.current({paths:structuredClone(next),width:dimensions.width,height:dimensions.height,background});
  }
  function point(event:{clientX:number;clientY:number}):Point{
    const rect=svg.current!.getBoundingClientRect();
    return {x:bounded((event.clientX-rect.left)/rect.width*dimensions.width,0,dimensions.width),y:bounded((event.clientY-rect.top)/rect.height*dimensions.height,0,dimensions.height)};
  }
  function tolerance(){return 5*dimensions.width/Math.max(1,svg.current?.getBoundingClientRect().width||dimensions.width);}
  function erase(at:Point,before:SketchPath[]){const hit=hitDrawingPath(before,at,tolerance());return hit===null?before:before.filter((_,index)=>index!==hit);}
  function begin(event:PointerEvent<SVGSVGElement>){
    if(event.button!==0||gesture.current)return;
    event.preventDefault();event.stopPropagation();dialog.current?.focus();event.currentTarget.setPointerCapture(event.pointerId);
    const at=point(event);setPalette(false);setWeights(false);
    if(tool==='pen'){
      gesture.current={type:'pen',pointer:event.pointerId,points:[at]};setSelected([]);setPenPath({color,width:size,points:[at]});
    }else if(tool==='eraser'){
      const after=erase(at,history.present);gesture.current={type:'erase',pointer:event.pointerId,before:history.present,after};setSelected([]);setWorking(after);
    }else{
      const hit=hitDrawingPath(history.present,at,tolerance());
      if(hit===null){gesture.current={type:'marquee',pointer:event.pointerId,start:at,selected:event.shiftKey?selected:[]};if(!event.shiftKey)setSelected([]);setMarquee({from:at,to:at});}
      else{
        const next=event.shiftKey?(selected.includes(hit)?selected.filter(index=>index!==hit):[...selected,hit]):selected.includes(hit)?selected:[hit];
        setSelected(next);
        if(next.includes(hit))gesture.current={type:'move',pointer:event.pointerId,before:history.present,start:at,selected:next};
        else event.currentTarget.releasePointerCapture(event.pointerId);
      }
    }
  }
  function move(event:PointerEvent<SVGSVGElement>){
    const active=gesture.current;if(!active||active.pointer!==event.pointerId)return;
    event.preventDefault();const at=point(event);
    if(active.type==='pen'){
      const last=active.points.at(-1)!;if(Math.hypot(at.x-last.x,at.y-last.y)<.15)return;
      active.points.push(at);setPenPath({points:[...active.points],color,width:size});
    }else if(active.type==='erase'){active.after=erase(at,active.after);setWorking(active.after);}
    else if(active.type==='move')setWorking(translateDrawingPaths(active.before,active.selected,{x:at.x-active.start.x,y:at.y-active.start.y},dimensions));
    else setMarquee({from:active.start,to:at});
  }
  function end(event:PointerEvent<SVGSVGElement>){
    const active=gesture.current;if(!active||active.pointer!==event.pointerId)return;
    event.preventDefault();event.stopPropagation();
    if(active.type==='pen')commit([...history.present,{points:active.points,color,width:size}]);
    else if(active.type==='move'||active.type==='erase')commit(draftRef.current||history.present);
    else{
      const to=point(event),inside=drawingPathsInRect(history.present,{x:active.start.x,y:active.start.y,width:to.x-active.start.x,height:to.y-active.start.y});
      setSelected([...new Set([...active.selected,...inside])]);clearWorking();
    }
    try{event.currentTarget.releasePointerCapture(event.pointerId);}catch{/* An interrupted pointer may already be released. */}
  }
  function removeSelected(){if(!selected.length)return;const chosen=new Set(selected);commit(history.present.filter((_,index)=>!chosen.has(index)));setSelected([]);dialog.current?.focus({preventScroll:true});}
  function chooseColor(value:string){if(value!==color)previousColor.current=color;setColor(value);setTool('pen');}
  function keyDown(event:KeyboardEvent<HTMLDivElement>){
    event.stopPropagation();
    const target=event.target as HTMLElement;
    if(target.closest('input,textarea,select,[contenteditable=true]'))return;
    if(event.key==='Escape'){event.preventDefault();save();return;}
    if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='z'){event.preventDefault();event.shiftKey?redo():undo();return;}
    if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='a'){event.preventDefault();setTool('select');setSelected(history.present.map((_,index)=>index));return;}
    if(event.key==='Delete'||event.key==='Backspace'){event.preventDefault();removeSelected();return;}
    if(event.key.toLowerCase()==='d'){event.preventDefault();setTool('pen');}
    if(event.key.toLowerCase()==='v'){event.preventDefault();setTool('select');}
    if(event.key.toLowerCase()==='e'){event.preventDefault();setTool('eraser');}
    if(event.key.toLowerCase()==='x'){event.preventDefault();const previous=previousColor.current;previousColor.current=color;setColor(previous);}
    if(/^[1-4]$/.test(event.key)){event.preventDefault();setSize(SIZES[Number(event.key)-1]);}
    if(selected.length&&['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)){
      event.preventDefault();const step=event.shiftKey?10:1;
      commit(translateDrawingPaths(history.present,selected,{x:event.key==='ArrowLeft'?-step:event.key==='ArrowRight'?step:0,y:event.key==='ArrowUp'?-step:event.key==='ArrowDown'?step:0},dimensions));
    }
    if(event.key==='Tab'){
      const fields=dialog.current?.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled)');if(!fields?.length)return;
      const first=fields[0],last=fields[fields.length-1];
      if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
      else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
    }
  }
  const bounds=tool==='select'?drawingBounds(present,selected):null;
  return <div className={`sketch-editor-backdrop sketch-editor-${mode}`}>
    <div ref={dialog} className="sketch-editor-dialog" role="dialog" aria-modal="true" aria-label={mode==='board'?'Draw on board':'Edit sketch'} tabIndex={-1} onKeyDown={keyDown}>
      <header className="sketch-editor-header"><strong>{mode==='board'?'Draw':'Sketch'}</strong><button type="button" title="Cancel drawing" aria-label="Cancel drawing" onClick={onCancel}><X size={18}/></button></header>
      <div ref={workspace} className="sketch-editor-workspace">
        <div className="sketch-editor-sheet" style={{width:canvasSize.width,height:canvasSize.height,background}}>
          {underlay&&<div className="sketch-editor-underlay">{underlay}</div>}
          <svg ref={svg} className={`sketch-editor-canvas sketch-editor-tool-${tool}`} viewBox={`0 0 ${dimensions.width} ${dimensions.height}`} aria-label="Drawing canvas" onPointerDown={begin} onPointerMove={move} onPointerUp={end} onPointerCancel={()=>clearWorking()}>
            {present.map((path,index)=><path key={index} d={drawingPathData(path.points)} stroke={path.color} strokeWidth={path.width} fill="none" strokeLinecap="round" strokeLinejoin="round"/>)}
            {penPath&&<path d={drawingPathData(penPath.points)} stroke={penPath.color} strokeWidth={penPath.width} fill="none" strokeLinecap="round" strokeLinejoin="round"/>}
            {bounds&&<rect data-drawing-selection="true" x={bounds.x-3} y={bounds.y-3} width={bounds.width+6} height={bounds.height+6} fill="rgba(88,130,248,.05)" stroke="#5882f8" strokeWidth={1.2} strokeDasharray="4 3" vectorEffect="non-scaling-stroke" pointerEvents="none"/>}
            {marquee&&<rect x={Math.min(marquee.from.x,marquee.to.x)} y={Math.min(marquee.from.y,marquee.to.y)} width={Math.abs(marquee.to.x-marquee.from.x)} height={Math.abs(marquee.to.y-marquee.from.y)} fill="rgba(88,130,248,.08)" stroke="#5882f8" strokeWidth={1} vectorEffect="non-scaling-stroke" pointerEvents="none"/>}
          </svg>
        </div>
      </div>
      <div className="sketch-editor-tools" role="toolbar" aria-label="Drawing tools">
        <button type="button" title="Pen (D)" aria-label="Pen" aria-pressed={tool==='pen'} onClick={()=>{clearWorking();setTool('pen');}}><Pencil size={18}/></button>
        <button type="button" title="Selection tool (V)" aria-label="Selection tool" aria-pressed={tool==='select'} onClick={()=>{clearWorking();setTool('select');}}><MousePointer2 size={18}/></button>
        <button type="button" title="Eraser (E)" aria-label="Eraser" aria-pressed={tool==='eraser'} onClick={()=>{clearWorking();setTool('eraser');}}><Eraser size={18}/></button>
        <i/>
        <div className="sketch-editor-popover-owner"><button type="button" title="Color" aria-label="Drawing color" aria-expanded={palette} onClick={()=>{setPalette(!palette);setWeights(false);}}><span className="sketch-editor-color" style={{background:color}}/><ChevronDown size={11}/></button>
          {palette&&<div className="sketch-editor-palette">{COLORS.map(value=><button key={value} type="button" title={`Color ${value}`} aria-label={`Drawing color ${value}`} aria-pressed={color===value} style={{background:value}} onClick={()=>chooseColor(value)}/>)}<input type="color" aria-label="Custom drawing color" value={color} onChange={event=>chooseColor(event.target.value)}/></div>}
        </div>
        <div className="sketch-editor-popover-owner"><button type="button" title="Line weight" aria-label="Line weight" aria-expanded={weights} onClick={()=>{setWeights(!weights);setPalette(false);}}><span className="sketch-editor-weight" style={{height:size}}/><ChevronDown size={11}/></button>
          {weights&&<div className="sketch-editor-weights">{SIZES.map((value,index)=><button key={value} type="button" aria-label={`Line weight ${index+1}`} aria-pressed={size===value} onClick={()=>setSize(value)}><span style={{height:value}}/></button>)}</div>}
        </div>
        <i/>
        <button type="button" title="Undo drawing" aria-label="Undo drawing" disabled={!history.past.length} onClick={undo}><Undo2 size={17}/></button>
        <button type="button" title="Redo drawing" aria-label="Redo drawing" disabled={!history.future.length} onClick={redo}><Redo2 size={17}/></button>
        {tool==='select'&&<button type="button" title="Delete selected drawing" aria-label="Delete selected drawing" disabled={!selected.length} onClick={removeSelected}><Trash2 size={17}/></button>}
        <i/>
        <button type="button" className="sketch-editor-clear" title="Clear drawing" onClick={()=>{commit([]);setSelected([]);}} disabled={!history.present.length}>Clear</button>
        <button type="button" className="sketch-editor-cancel" onClick={onCancel}>Cancel</button>
        <button type="button" className="sketch-editor-save" onClick={save}><Check size={16}/>Save</button>
      </div>
    </div>
  </div>;
}
