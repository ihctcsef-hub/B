import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { ChevronDown, Pipette, SlidersHorizontal, X } from "lucide-react";
import { displayColor, hexToRgb, hslToRgb, parseColor, rgbToHex, rgbToHsl, swatchInk } from "../core/colors";
import type { ColorSpace } from "../core/colors";
import { CaptionEditor } from "./CaptionEditor";
import { nearestNamedColor } from "../core/namedColors";
import { noteContentHtml } from "../core/richText";
import "./color-swatch.css";

export interface ColorSwatchValues {
  value: string;
  label: string;
  captionHtml?: string;
  captionHeight?: number;
  showCaption?: boolean;
  showValue?: boolean;
  colorSpace?: ColorSpace;
}
export interface ColorSwatchProps extends ColorSwatchValues {
  onChange: (values: Partial<ColorSwatchValues>) => void;
  readOnly?: boolean;
  onSampleImage?: () => Promise<string | null>;
}
export interface ColorSwatchHandle { openPicker: () => void }
interface EyeDropperInstance { open: () => Promise<{ sRGBHex: string }> }
type ColorWindow = Window & { EyeDropper?: new () => EyeDropperInstance };
const CHANNELS = ["r", "g", "b"] as const;

/** Local color values are canonical opaque HEX; display preferences do not alter them. */
export const ColorSwatch = forwardRef<ColorSwatchHandle, ColorSwatchProps>(function ColorSwatch(
  { value, label, captionHtml, captionHeight = 48, showCaption = true, showValue = true, colorSpace = "hex", onChange, readOnly = false, onSampleImage }, ref,
) {
  const rootRef = useRef<HTMLDivElement>(null);
  const dialogRef = useRef<HTMLDivElement>(null);
  const nativeRef = useRef<HTMLInputElement>(null);
  const hexRef = useRef<HTMLInputElement>(null);
  const focusBefore = useRef<HTMLElement | null>(null);
  const [open, setOpen] = useState(false);
  const [position, setPosition] = useState({ left: 80, top: 100 });
  const [draft, setDraft] = useState(value);
  const [error, setError] = useState("");
  const [sampling, setSampling] = useState(false);
  const canonical = parseColor(value) || "#b7c3a5";
  const rgb = hexToRgb(canonical)!;
  const hsl = rgbToHsl(rgb);
  const eyeDropperAvailable = typeof window !== "undefined" && !!(window as ColorWindow).EyeDropper;
  useEffect(() => { setDraft(value); setError(""); }, [value]);

  function openPicker() {
    if (readOnly || !nativeRef.current) return;
    setOpen(false); setError("");
    const input=nativeRef.current;input.value=canonical;
    try { if (typeof input.showPicker === 'function') input.showPicker(); else input.click(); }
    catch { input.click(); }
  }
  function openSettings() {
    if (readOnly) return;
    const rect = rootRef.current?.getBoundingClientRect();
    const left = rect ? Math.min(Math.max(8, rect.right + 12), window.innerWidth - 292) : 80;
    const top = rect ? Math.min(Math.max(8, rect.top), Math.max(8, window.innerHeight - 450)) : 100;
    focusBefore.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    setPosition({ left: Math.max(8, left), top });
    setError(""); setDraft(canonical); setOpen(true);
  }
  function closePicker() {
    setOpen(false);
    focusBefore.current?.focus({ preventScroll: true });
  }
  useImperativeHandle(ref, () => ({ openPicker }));
  useEffect(() => {
    if (!open) return;
    hexRef.current?.focus();
    hexRef.current?.select();
    function outside(event: PointerEvent) {
      if (sampling) return;
      const target = event.target as Node | null;
      if (target && !dialogRef.current?.contains(target) && !rootRef.current?.contains(target)) setOpen(false);
    }
    document.addEventListener("pointerdown", outside, true);
    return () => document.removeEventListener("pointerdown", outside, true);
  }, [open, sampling]);

  function apply(next: string) {
    if (readOnly) return;
    const parsed = parseColor(next);
    if (!parsed) { setError("Enter a valid HEX, RGB or HSL color."); return; }
    setDraft(parsed); setError("");
    if(parsed===canonical)return;
    const automatic=(!captionHtml||captionHtml===noteContentHtml(label))&&(label===nearestNamedColor(canonical)?.name||(canonical==='#b7c3a5'&&label==='Sage'));
    if(automatic){
      const nextLabel=nearestNamedColor(parsed)?.name||label;
      const measure=document.createElement('div');
      Object.assign(measure.style,{position:'fixed',left:'-100000px',top:'0',width:`${rootRef.current?.clientWidth||134}px`,boxSizing:'border-box',padding:'16px 15px',minHeight:'48px',font:'11.2px/16px Inter,Arial,sans-serif',overflowWrap:'anywhere',whiteSpace:'pre-wrap'});
      measure.textContent=nextLabel;document.body.append(measure);const nextHeight=Math.max(48,Math.ceil(measure.getBoundingClientRect().height));measure.remove();
      onChange({value:parsed,label:nextLabel,captionHtml:undefined,captionHeight:nextHeight});
    }else onChange({value:parsed});
  }
  useEffect(()=>{
    const input=nativeRef.current;if(!input)return;
    const commit=()=>apply(input.value);
    // The native change event commits the chosen color once; continuous input
    // previews inside the browser's chooser do not create workspace history.
    input.addEventListener('change',commit);return()=>input.removeEventListener('change',commit);
  },[canonical,label,captionHtml,onChange,readOnly]);
  useEffect(()=>{if(nativeRef.current)nativeRef.current.value=canonical;},[canonical]);
  async function sampleColor() {
    const EyeDropper = (window as ColorWindow).EyeDropper;
    if ((!EyeDropper && !onSampleImage) || readOnly) return;
    setSampling(true); setError("");
    try { const color=onSampleImage?await onSampleImage():EyeDropper?(await new EyeDropper().open()).sRGBHex:null;if(color)apply(color); }
    catch (exception) {
      if (!(exception instanceof DOMException && exception.name === "AbortError")) setError("The eyedropper could not pick a color. Try the color fields.");
    } finally { setSampling(false); }
  }

  return <div ref={rootRef} className={`colorSwatch${showCaption ? " colorSwatch-caption" : ""}`} tabIndex={0}
    aria-label="Color swatch" onDoubleClick={event => { event.stopPropagation(); if(!(event.target as Element).closest('button,input,.captionEditor'))openPicker(); }}
    onKeyDown={event => {
      if (event.target !== event.currentTarget) return;
      if (event.key === "Enter") { event.preventDefault(); event.stopPropagation(); openPicker(); }
    }}
    onPaste={event => {
      if (readOnly || (event.target as Element).closest('input,textarea,[contenteditable="true"]')) return;
      const pasted = parseColor(event.clipboardData.getData("text/plain"));
      if (pasted) { event.preventDefault(); event.stopPropagation(); apply(pasted); }
    }}>
    <input ref={nativeRef} type="color" className="colorSwatch-native" aria-label="Native swatch color" tabIndex={-1} defaultValue={canonical} disabled={readOnly}/>
    <div className="colorSwatch-block" style={{ backgroundColor: canonical, color: swatchInk(canonical) }}>
      {showValue && <span className="colorSwatch-code">{displayColor(canonical, colorSpace)}</span>}
      {!readOnly && <button className="colorSwatch-open" type="button" title="Edit color" aria-label="Edit color" onClick={event => { event.stopPropagation(); openPicker(); }}><ChevronDown size={13} /></button>}
      {!readOnly && <button className="colorSwatch-open colorSwatch-settings" type="button" title="Color settings" aria-label="Color settings" onClick={event=>{event.stopPropagation();openSettings();}}><SlidersHorizontal size={13}/></button>}
    </div>
    {showCaption && <div className="colorSwatch-footer" style={{height:captionHeight}}><CaptionEditor text={label} html={captionHtml} ariaLabel="Swatch caption" readOnly={readOnly} onChange={({text,html,height})=>onChange({label:text,captionHtml:html,captionHeight:Math.max(48,height)})}/></div>}
    {open && createPortal(<div className="colorSwatch-picker" ref={dialogRef} role="dialog" aria-label="Edit swatch color" style={position}
      onPointerDown={event => event.stopPropagation()} onDoubleClick={event => event.stopPropagation()} onKeyDown={event => {
        event.stopPropagation();
        if (event.key === "Escape") { event.preventDefault(); closePicker(); }
        if (event.key === "Tab") {
          const fields = dialogRef.current?.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),select:not(:disabled)');
          if (!fields?.length) return;
          const first = fields[0], last = fields[fields.length - 1];
          if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
          else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
        }
      }}>
      <header><strong>Color</strong><button type="button" aria-label="Close color picker" onClick={closePicker}><X size={15} /></button></header>
      <div className="colorSwatch-picker-preview" style={{ backgroundColor: canonical }}>
        <input aria-label="Color picker" type="color" value={canonical} onChange={event => apply(event.target.value)} />
      </div>
      <div className="colorSwatch-hex"><label htmlFor="swatch-color-value">Color value</label><div><input id="swatch-color-value" ref={hexRef} aria-label="Swatch color value" value={draft} aria-invalid={!!error} spellCheck={false}
        onChange={event => { setDraft(event.target.value); setError(""); }} onBlur={() => { if (draft !== canonical) apply(draft); }}
        onKeyDown={event => { if (event.key === "Enter") { event.preventDefault(); apply(draft); } }} />
        <button type="button" title={onSampleImage ? "Pick a color from an image" : eyeDropperAvailable ? "Pick a color from your screen" : "Eyedropper is unavailable in this browser"} aria-label="Eyedropper" disabled={(!eyeDropperAvailable && !onSampleImage) || sampling} onClick={() => void sampleColor()}><Pipette size={16} /></button></div></div>
      <div className="colorSwatch-rgb" aria-label="RGB channels">{CHANNELS.map(channel => <label key={channel}>{channel.toUpperCase()}<input type="number" aria-label={`Color ${channel === "r" ? "red" : channel === "g" ? "green" : "blue"}`} min={0} max={255} value={rgb[channel]}
        onChange={event => { if (event.target.value !== "") apply(rgbToHex({ ...rgb, [channel]: Number(event.target.value) })); }} /></label>)}</div>
      <div className="colorSwatch-sliders">{([{ key: "h", label: "Hue", max: 360 }, { key: "s", label: "Saturation", max: 100 }, { key: "l", label: "Lightness", max: 100 }] as const).map(channel => <label key={channel.key}><span>{channel.label}</span><input type="range" aria-label={`Color ${channel.label.toLowerCase()}`} min={0} max={channel.max} step={1} value={Math.round(hsl[channel.key])}
        onChange={event => apply(rgbToHex(hslToRgb({ ...hsl, [channel.key]: Number(event.target.value) })))} /><output>{Math.round(hsl[channel.key])}{channel.key === "h" ? "°" : "%"}</output></label>)}</div>
      <label className="colorSwatch-display">Display<select aria-label="Color display" value={showValue ? colorSpace : "off"} onChange={event => onChange(event.target.value === "off" ? { showValue: false } : { showValue: true, colorSpace: event.target.value as ColorSpace })}>
        <option value="hex">HEX</option><option value="rgb">RGB</option><option value="hsl">HSL</option><option value="off">Off</option>
      </select></label>
      <label className="colorSwatch-caption-toggle"><input aria-label="Show color caption" type="checkbox" checked={showCaption} onChange={event => onChange({ showCaption: event.target.checked })} /> Caption</label>
      {error && <p role="alert" className="colorSwatch-error">{error}</p>}
    </div>, document.body)}
  </div>;
});
