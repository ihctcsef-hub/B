import {useEffect,useRef,useState} from 'react';
import type {Card} from '../core/model';

type LinkCard=Extract<Card,{type:'link'}>;
type Field='title'|'url'|'description'|'previewSrc';
const values=(card:LinkCard)=>({title:card.title,url:card.url,description:card.description,previewSrc:card.previewSrc||''});
export function LinkDetailsEditor({card,busy,onChange,onUrlChange,onRefresh,onDone}:{card:LinkCard;busy:boolean;onChange:(patch:Partial<LinkCard>)=>void;onUrlChange:(url:string)=>boolean;onRefresh:()=>void;onDone:()=>void}){
  const [draft,setDraft]=useState(()=>values(card));
  const dirty=useRef(new Set<Field>());
  useEffect(()=>{if(card.locked)dirty.current.clear();const next=values(card);setDraft(previous=>Object.fromEntries((Object.keys(next) as Field[]).map(key=>[key,dirty.current.has(key)?previous[key]:next[key]])) as typeof next);},[card.id,card.title,card.url,card.description,card.previewSrc,card.locked]);
  const edit=(field:Field,value:string)=>{dirty.current.add(field);setDraft(previous=>({...previous,[field]:value}));};
  const save=(field:Field)=>{
    if(card.locked)return;
    if(!dirty.current.delete(field))return;
    if(field==='url'){if(!onUrlChange(draft.url))setDraft(previous=>({...previous,url:card.url}));}
    else onChange({[field]:draft[field]});
  };
  return <div className="link-edit">
    <label>Title<input aria-label="Link title" value={draft.title} readOnly={card.locked} onChange={event=>edit('title',event.target.value)} onBlur={()=>save('title')}/></label>
    <label>URL<input aria-label="Link URL" value={draft.url} readOnly={card.locked} onChange={event=>edit('url',event.target.value)} onBlur={()=>save('url')}/></label>
    <label>Description<textarea aria-label="Link description" value={draft.description} readOnly={card.locked} onChange={event=>edit('description',event.target.value)} onBlur={()=>save('description')}/></label>
    <label>Preview image URL<input aria-label="Link preview image URL" value={draft.previewSrc} readOnly={card.locked} onChange={event=>edit('previewSrc',event.target.value)} onBlur={()=>save('previewSrc')}/></label>
    <div className="link-edit-actions"><button type="button" disabled={busy||!card.url||card.locked} onClick={onRefresh}>{busy?'Loading preview…':'Refresh preview'}</button><button type="button" onClick={onDone}>Done</button></div>
  </div>;
}
