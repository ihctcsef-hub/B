import assets from '../data/noteControlAssets.json';

type Shape={tag:string;d?:string;width?:string;height?:string;rx?:string;fill?:string;'fill-opacity'?:string;'fill-rule'?:string};
function Shapes({shapes}:{shapes:Shape[]}){return <>{shapes.map((shape,index)=>shape.tag==='path'?<path key={index} d={shape.d} fill={shape.fill} fillOpacity={shape['fill-opacity']} fillRule={shape['fill-rule']==='evenodd'?'evenodd':undefined}/>:<rect key={index} width={shape.width} height={shape.height} rx={shape.rx} fill={shape.fill} fillRule={shape['fill-rule']==='evenodd'?'evenodd':undefined}/>)}</>;}
/** Static visual assets observed in the reference DOM. The import contains
 * whitelisted path/rectangle attributes; no runtime SVG markup is interpreted. */
export function NoteConnectionMarker(){return <><svg className="note-quick-line-circle" viewBox={assets.quickCircle.viewBox} aria-hidden="true"><Shapes shapes={assets.quickCircle.shapes}/></svg><svg className="note-quick-line-arrow" viewBox={assets.quickArrow.viewBox} aria-hidden="true"><Shapes shapes={assets.quickArrow.shapes}/></svg></>;}
export function NoteResizeMarker(){return <svg className="note-resize-marker" viewBox={assets.resize.viewBox} aria-hidden="true"><g fill="none" fillRule="evenodd"><Shapes shapes={assets.resize.shapes}/></g></svg>;}
