import { useEffect, useRef, useState } from "react";
import type { KeyboardEvent, PointerEvent } from "react";
import type { Card, Connection, Point } from "../core/model";
import { attachConnectionHandle, connectionAnchorAt, connectionGeometry, connectionTargetAt, constrainConnectionPoint, moveConnectionHandle, straightenConnection } from "../core/lines";
import type { EditableConnection } from "../core/lines";
import "./connection-layer.css";

export interface ConnectionLayerProps {
  connections: Connection[];
  cards: Card[];
  selectedId: string | null;
  anchorHint?: Point | null;
  onSelect: (id: string) => void;
  onPreview: (connections: Connection[]) => void;
  onCommit: (before: Connection[], after: Connection[]) => void;
}
type Handle = "start" | "end" | "control" | "move";

export function ConnectionLayer(props: ConnectionLayerProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [dragging, setDragging] = useState(false);
  const [anchorHint, setAnchorHint] = useState<Point | null>(null);
  const current = useRef(props);
  current.current = props;
  const cleanupRef = useRef<(() => void) | null>(null);
  useEffect(() => () => cleanupRef.current?.(), []);

  function localPoint(clientX: number, clientY: number): Point | null {
    const svg = svgRef.current, matrix = svg?.getScreenCTM();
    if (!svg || !matrix) return null;
    const point = svg.createSVGPoint();
    point.x = clientX; point.y = clientY;
    try { const local = point.matrixTransform(matrix.inverse()); return { x: local.x, y: local.y }; }
    catch { return null; }
  }
  function begin(event: PointerEvent<SVGElement>, id: string, handle: Handle) {
    if (event.button !== 0) return;
    event.preventDefault(); event.stopPropagation();
    current.current.onSelect(id);
    const startPoint = localPoint(event.clientX, event.clientY);
    if (!startPoint) return;
    cleanupRef.current?.();
    const before = current.current.connections;
    const source = before.find(line => line.id === id) as EditableConnection | undefined;
    if (!source) return;
    const cards = current.current.cards;
    const initialGeometry = connectionGeometry(source, cards);
    if (!initialGeometry) return;
    setDragging(true);
    let anchorTimer: ReturnType<typeof setTimeout> | undefined;
    let hover: { card: Card; point: Point; ready: boolean; shifted: boolean } | undefined;
    let after = before;
    let changed = false;
    const pointerId = event.pointerId;
    const capture = event.currentTarget;
    try { capture.setPointerCapture(pointerId); } catch { /* Window handlers still receive this pointer. */ }
    function move(event: globalThis.PointerEvent) {
      if (event.pointerId !== pointerId) return;
      event.preventDefault(); event.stopPropagation();
      let point = localPoint(event.clientX, event.clientY);
      if (!point) return;
      if (event.shiftKey && (handle === "start" || handle === "end")) point = constrainConnectionPoint(handle === "start" ? initialGeometry!.end : initialGeometry!.start, point);
      const dx = point.x - startPoint!.x, dy = point.y - startPoint!.y;
      if (!changed && Math.hypot(dx, dy) < 0.8) return;
      let next: EditableConnection;
      if (handle === "move") {
        if (!source!.start || !source!.end || source!.from || source!.to) return;
        next = { ...source!, start: { x: source!.start.x + dx, y: source!.start.y + dy }, end: { x: source!.end.x + dx, y: source!.end.y + dy }, ...(source!.control ? { control: { x: source!.control.x + dx, y: source!.control.y + dy } } : {}) };
      } else {
        next = moveConnectionHandle(source!, cards, handle, point);
        if (handle === "start" || handle === "end") {
          const target = connectionTargetAt(point, cards, handle === "start" ? source!.to : source!.from);
          if (!target || hover?.card.id !== target.id || Math.hypot(point.x - hover.point.x, point.y - hover.point.y) > 3 || hover.shifted !== event.shiftKey) {
            clearTimeout(anchorTimer); setAnchorHint(null);
            hover = target ? { card: target, point: { ...point }, ready: event.shiftKey, shifted: event.shiftKey } : undefined;
            if (hover && !hover.ready) {
              const held = hover;
              anchorTimer = setTimeout(() => {
                if (hover !== held) return;
                held.ready = true;
                setAnchorHint(held.point);
                const anchored = attachConnectionHandle(moveConnectionHandle(source!, cards, handle, held.point), handle, held.card, connectionAnchorAt(held.card, held.point));
                after = before.map(line => line.id === id ? anchored : line);
                current.current.onPreview(after);
              }, 450);
            }
          }
          if (hover) {
            next = attachConnectionHandle(next, handle, hover.card, hover.ready ? connectionAnchorAt(hover.card, hover.point) : undefined);
            if (hover.ready) setAnchorHint(hover.point);
          }
        }
      }
      after = before.map(line => line.id === id ? next : line);
      changed = true;
      current.current.onPreview(after);
    }
    function end(event: globalThis.PointerEvent) {
      if (event.pointerId !== pointerId) return;
      event.preventDefault(); event.stopPropagation();
      cleanup();
      if (changed) current.current.onCommit(before, after);
    }
    function cancel(event: globalThis.PointerEvent | globalThis.KeyboardEvent) {
      // Board navigation and deletion must wait until this pointer gesture ends.
      if (event instanceof globalThis.KeyboardEvent && event.key !== "Escape") { event.stopPropagation(); return; }
      if (event instanceof globalThis.PointerEvent && event.pointerId !== pointerId) return;
      event.preventDefault(); event.stopPropagation();
      cleanup();
      if (changed) current.current.onPreview(before);
    }
    function cleanup() {
      clearTimeout(anchorTimer); setDragging(false); setAnchorHint(null);
      window.removeEventListener("pointermove", move, true); window.removeEventListener("pointerup", end, true); window.removeEventListener("pointercancel", cancel, true); window.removeEventListener("keydown", cancel, true);
      try { if (capture.hasPointerCapture(pointerId)) capture.releasePointerCapture(pointerId); } catch { /* Detached handle. */ }
      cleanupRef.current = null;
    }
    cleanupRef.current = cleanup;
    window.addEventListener("pointermove", move, { capture: true, passive: false }); window.addEventListener("pointerup", end, true); window.addEventListener("pointercancel", cancel, true); window.addEventListener("keydown", cancel, true);
  }
  function keyHandle(event: KeyboardEvent<SVGCircleElement>, line: EditableConnection, handle: Exclude<Handle, "move">) {
    if (!["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(event.key)) return;
    event.preventDefault(); event.stopPropagation();
    const geometry = connectionGeometry(line, current.current.cards);
    if (!geometry) return;
    const point = handle === "start" ? geometry.start : handle === "end" ? geometry.end : geometry.midpoint;
    const amount = event.shiftKey ? 10 : 1;
    const next = moveConnectionHandle(line, current.current.cards, handle, { x: point.x + (event.key === "ArrowRight" ? amount : event.key === "ArrowLeft" ? -amount : 0), y: point.y + (event.key === "ArrowDown" ? amount : event.key === "ArrowUp" ? -amount : 0) });
    const before = current.current.connections, after = before.map(item => item.id === line.id ? next : item);
    current.current.onPreview(after); current.current.onCommit(before, after);
  }
  function straighten(event: React.MouseEvent<SVGCircleElement>, line: EditableConnection) {
    event.preventDefault(); event.stopPropagation();
    const before = current.current.connections, after = before.map(item => item.id === line.id ? straightenConnection(item) : item);
    current.current.onPreview(after); current.current.onCommit(before, after);
  }
  return <svg ref={svgRef} className={`connections connectionLayer${dragging ? " dragging-line" : ""}`} style={props.selectedId ? { zIndex: Math.max(2, ...props.cards.map(card => card.z + 2)) } : undefined} width="10000" height="10000" aria-label="Board lines">
    {props.connections.map(raw => {
      const line = raw as EditableConnection;
      const geometry = connectionGeometry(line, props.cards);
      if (!geometry) return null;
      const selected = props.selectedId === line.id;
      const width = Math.max(0.8, Math.min(12, line.width ?? 1.6));
      const color = line.color || "#323b4a";
      const free = !line.from && !line.to;
      const selectLine = (event: PointerEvent<SVGGElement>) => {
        if (event.button !== 0) return;
        if (free) begin(event, line.id, "move");
        else { event.stopPropagation(); current.current.onSelect(line.id); }
      };
      return <g key={line.id} data-line-id={line.id} className={`connection${selected ? " selected-line" : ""}`} onPointerDown={selectLine} role="button" tabIndex={0} aria-label={line.label ? `Line ${line.label}` : "Line"}
        onKeyDown={event => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); event.stopPropagation(); current.current.onSelect(line.id); } }}>
        <path className="connection-hit" d={geometry.path} fill="none" stroke="transparent" strokeWidth={18} />
        <path className="connection-stroke" d={geometry.path} fill="none" stroke={color} strokeWidth={width} strokeLinecap={line.style === "dashed" ? "butt" : "round"} strokeDasharray={line.style === "dashed" ? "5 5" : undefined} />
        {line.startArrow ? <polygon className="connection-cap" points={arrowPoints(geometry.start, { x: -geometry.startTangent.x, y: -geometry.startTangent.y }, width)} fill={color} /> : <circle className="connection-cap" cx={geometry.start.x} cy={geometry.start.y} r={Math.max(0.8, width / 2)} fill={color} />}
        {line.endArrow !== false ? <polygon className="connection-cap" points={arrowPoints(geometry.end, geometry.endTangent, width)} fill={color} /> : <circle className="connection-cap" cx={geometry.end.x} cy={geometry.end.y} r={Math.max(0.8, width / 2)} fill={color} />}
        {line.label && <g className="connection-label"><rect x={geometry.midpoint.x - Math.max(24, line.label.length * 3.5 + 8)} y={geometry.midpoint.y - 12} width={Math.max(48, line.label.length * 7 + 16)} height={24} rx={3} fill="#ebedee" /><text x={geometry.midpoint.x} y={geometry.midpoint.y + 4} textAnchor="middle" fill={color} fontSize={11.2} fontFamily="Inter,Arial,sans-serif">{line.label}</text></g>}
        {selected && ([{ name: "start", point: geometry.start }, { name: "end", point: geometry.end }, { name: "control", point: geometry.midpoint }] as const).map(handle => <circle key={handle.name} data-line-handle={handle.name} className={`connection-handle connection-handle-${handle.name}`} cx={handle.point.x} cy={handle.point.y} r={handle.name === "control" ? 4 : 4.5} role="button" tabIndex={0} aria-label={`Line ${handle.name === "control" ? "curve" : handle.name} handle`}
          onPointerDown={event => begin(event, line.id, handle.name)} onDoubleClick={handle.name === "control" ? event => straighten(event, line) : undefined} onKeyDown={event => keyHandle(event, line, handle.name)} />)}
      </g>;
    })}
    {(anchorHint||props.anchorHint) && <circle className="connection-anchor-hint" data-line-anchor-hint cx={(anchorHint||props.anchorHint)!.x} cy={(anchorHint||props.anchorHint)!.y} r={5} />}
  </svg>;
}

function arrowPoints(tip: Point, tangent: Point, width: number) {
  const length = Math.hypot(tangent.x, tangent.y) || 1;
  const dx = length === 1 && tangent.x === 0 && tangent.y === 0 ? 1 : tangent.x / length, dy = tangent.y / length;
  const size = 6.4 + width * 1.2, half = 3 + width * 0.45;
  const base = { x: tip.x - dx * size, y: tip.y - dy * size };
  return `${tip.x},${tip.y} ${base.x - dy * half},${base.y + dx * half} ${base.x + dy * half},${base.y - dx * half}`;
}
