import { useEffect,useRef,useState } from 'react';
import { ChevronLeft,ChevronRight,Clock } from 'lucide-react';
import './table-date-picker.css';

export interface TableDatePickerProps {
  value:string;
  hasTime?:boolean;
  anchor:{left:number;top:number;width:number;height:number};
  onSave:(value:string,hasTime:boolean)=>void;
  onCancel:()=>void;
  onPreview?:(value:string,hasTime:boolean)=>void;
}
const months=Array.from({length:12},(_,month)=>new Date(Date.UTC(2024,month,1)).toLocaleDateString('en-US',{month:'long',timeZone:'UTC'}));
function parseDate(value:string){
  if(!value)return null;
  const numeric=Number(value);if(Number.isFinite(numeric)&&value.trim())return new Date(Date.UTC(1899,11,30)+numeric*86400000);
  const iso=/^(\d{4})-(\d\d)-(\d\d)(?:[T ](\d\d):(\d\d)(?::(\d\d))?)?$/.exec(value);
  const date=iso?new Date(Date.UTC(+iso[1],+iso[2]-1,+iso[3],+(iso[4]||0),+(iso[5]||0),+(iso[6]||0))):new Date(value);
  return Number.isFinite(date.getTime())?date:null;
}
const pad=(value:number)=>String(value).padStart(2,'0');
function serialized(date:Date|null,includeTime:boolean){return date?`${date.getUTCFullYear()}-${pad(date.getUTCMonth()+1)}-${pad(date.getUTCDate())}${includeTime?`T${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}:00`:''}`:'';}

export function TableDatePicker({value,hasTime=false,anchor,onSave,onCancel,onPreview}:TableDatePickerProps){
  const initial=parseDate(value),today=new Date();
  const [selected,setSelected]=useState<Date|null>(initial),[month,setMonth]=useState(initial?.getUTCMonth()??today.getMonth()),[year,setYear]=useState(initial?.getUTCFullYear()??today.getFullYear());
  const [withTime,setWithTime]=useState(hasTime||!!value.includes('T'));
  const root=useRef<HTMLDivElement>(null),current=useRef({selected,withTime});current.current={selected,withTime};
  const callbacks=useRef({onSave,onCancel,onPreview});callbacks.current={onSave,onCancel,onPreview};
  useEffect(()=>{
    function outside(event:PointerEvent){if(event.target instanceof Node&&!root.current?.contains(event.target)){const currentValue=current.current;callbacks.current.onSave(serialized(currentValue.selected,currentValue.withTime),currentValue.withTime);}}
    function key(event:KeyboardEvent){if(event.key==='Escape'){event.preventDefault();event.stopPropagation();callbacks.current.onCancel();}else if(event.key==='Enter'&&!(event.target instanceof HTMLSelectElement)){event.preventDefault();event.stopPropagation();const currentValue=current.current;callbacks.current.onSave(serialized(currentValue.selected,currentValue.withTime),currentValue.withTime);}}
    document.addEventListener('pointerdown',outside);window.addEventListener('keydown',key,true);
    return()=>{document.removeEventListener('pointerdown',outside);window.removeEventListener('keydown',key,true);};
  },[]);
  function draft(date:Date|null,includeTime=withTime){setSelected(date);setWithTime(includeTime);current.current={selected:date,withTime:includeTime};callbacks.current.onPreview?.(serialized(date,includeTime),includeTime);}
  function chooseDay(day:number){const date=new Date(Date.UTC(year,month,day,selected?.getUTCHours()||0,selected?.getUTCMinutes()||0));draft(date);}
  function changeTime(hour:number,minute:number){const date=selected?new Date(selected):new Date(Date.UTC(today.getFullYear(),today.getMonth(),today.getDate()));date.setUTCHours(hour,minute,0,0);draft(date,true);}
  const hour=selected?.getUTCHours()||0,minute=selected?.getUTCMinutes()||0;
  const firstDay=new Date(Date.UTC(year,month,1)).getUTCDay(),dayCount=new Date(Date.UTC(year,month+1,0)).getUTCDate();
  const left=Math.max(6,Math.min(window.innerWidth-238,anchor.left+(anchor.width-232)/2)),top=anchor.top>=318?anchor.top-318:Math.min(window.innerHeight-318,anchor.top+anchor.height+8);
  function step(direction:number){const date=new Date(Date.UTC(year,month+direction,1));setMonth(date.getUTCMonth());setYear(date.getUTCFullYear());}
  return <div ref={root} role="dialog" aria-label="Choose table date" className="tableDatePicker" style={{left,top}} onPointerDown={event=>event.stopPropagation()} onKeyDown={event=>event.stopPropagation()}>
    <div className="tableDatePicker-heading"><button type="button" aria-label="Previous month" onClick={()=>step(-1)}><ChevronLeft size={14}/></button><button type="button" disabled>{months[month]} {year}</button><button type="button" aria-label="Next month" onClick={()=>step(1)}><ChevronRight size={14}/></button></div>
      <div className="tableDatePicker-weekdays">{['S','M','T','W','T','F','S'].map((day,index)=><span key={index}>{day}</span>)}</div>
      <div className="tableDatePicker-days">{Array.from({length:42},(_,index)=>{const day=index-firstDay+1,inMonth=day>0&&day<=dayCount,checked=selected?.getUTCFullYear()===year&&selected?.getUTCMonth()===month&&selected?.getUTCDate()===day;return inMonth?<button type="button" key={index} aria-label={new Date(Date.UTC(year,month,day)).toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric',timeZone:'UTC'})} aria-pressed={checked} className={checked?'tableDatePicker-selected':''} onClick={()=>chooseDay(day)}>{day}</button>:<span key={index}/>;})}</div>
    <div className="tableDatePicker-time"><Clock size={13}/>{withTime?<><select aria-label="Table time hour" value={hour%12||12} onChange={event=>changeTime(Number(event.target.value)%12+(hour>=12?12:0),minute)}>{Array.from({length:12},(_,index)=>index||12).map(hour=><option key={hour} value={hour}>{pad(hour)}</option>)}</select><span>:</span><select aria-label="Table time minute" value={minute} onChange={event=>changeTime(hour,Number(event.target.value))}>{Array.from(new Set([minute,...Array.from({length:12},(_,index)=>index*5)])).sort((a,b)=>a-b).map(value=><option key={value} value={value}>{pad(value)}</option>)}</select><select aria-label="Table time period" value={hour>=12?'pm':'am'} onChange={event=>changeTime(hour%12+(event.target.value==='pm'?12:0),minute)}><option value="am">am</option><option value="pm">pm</option></select><button className="tableDatePicker-clear" type="button" onClick={()=>draft(selected,false)}>Clear</button></>:<button type="button" className="tableDatePicker-addTime" onClick={()=>draft(selected,true)}>Add time…</button>}</div>
  </div>;
}
