import { useEffect, useRef, useState } from 'react';
import { ArrowUpLeft, FileText, Folder, RotateCcw, Trash2, X } from 'lucide-react';
import type { Card } from '../core/model';
import type { TrashEntry } from '../core/trash';
import { trashEntryExpiresAt } from '../core/trash';
import { ImagePreview } from './ImageEditor';
import './trash-panel.css';

export interface TrashPanelProps {
  entries: TrashEntry[];
  open: boolean;
  onClose: () => void;
  onRestore: (id: string) => void;
  onEmpty: () => void;
  onDelete?: (id: string) => void;
  /** The observed popover has no visible management row; explicit tools can expose it separately. */
  showManagement?: boolean;
}
function cardTitle(card: Card): string {
  if (card.type === 'note') return card.isDocument ? card.title || 'Untitled document' : card.text || 'Empty note';
  if (card.type === 'image') return card.caption || 'Image';
  if (card.type === 'file') return card.name || 'File';
  if (card.type === 'swatch') return card.label || card.value;
  if (card.type === 'sketch') return 'Drawing';
  if (card.type === 'label') return card.text || 'Label';
  if (card.type === 'todo') return card.title || card.items.find(item => item.text)?.text || 'To-do list';
  return card.title || (card.type === 'table' ? 'Table' : 'Untitled board');
}
function Preview({ card }: { card: Card }) {
  if (card.type === 'image') return <div className="trashPanel-image"><ImagePreview src={card.src} edits={card.imageEdits} alt={card.caption || 'Deleted image'} /></div>;
  if (card.type === 'swatch') return <div className="trashPanel-swatch" style={{ backgroundColor: /^#[0-9a-f]{3}(?:[0-9a-f]{3})?$/i.test(card.value) ? card.value : '#b7c3a5' }} />;
  if (card.type === 'board') return <Folder size={22} />;
  if (card.type === 'file' || (card.type === 'note' && card.isDocument)) return <FileText size={22} />;
  if (card.type === 'todo') return <div className="trashPanel-tasks">{card.items.slice(0, 3).map(item => <span key={item.id}>{item.done ? '☑' : '☐'} {item.text || 'Add a task…'}</span>)}</div>;
  if (card.type === 'table') return <div className="trashPanel-table">{card.rows.slice(0, 3).map((row, ri) => <div key={ri}>{row.slice(0, 3).map((text, ci) => <span key={ci}>{text}</span>)}</div>)}</div>;
  return <p>{cardTitle(card)}</p>;
}

/** Deleted content stays separate from the editable board until an explicit restore. */
export function TrashPanel({ entries, open, onClose, onRestore, onEmpty, onDelete, showManagement = false }: TrashPanelProps) {
  const panel = useRef<HTMLElement>(null);
  const [confirmEmpty, setConfirmEmpty] = useState(false);
  useEffect(() => { if (!open) setConfirmEmpty(false); }, [open]);
  useEffect(() => {
    if (!open) return;
    function key(event: KeyboardEvent) {
      if (event.key !== 'Escape') return;
      event.preventDefault(); event.stopPropagation();
      if (confirmEmpty) setConfirmEmpty(false); else onClose();
    }
    function outside(event: PointerEvent) {
      const target = event.target as Element | null;
      if (!target || panel.current?.contains(target) || target.closest('[data-trash-toggle],[title="Trash"],[aria-label="Open trash"]')) return;
      onClose();
    }
    window.addEventListener('keydown', key, true);
    document.addEventListener('pointerdown', outside, true);
    return () => { window.removeEventListener('keydown', key, true); document.removeEventListener('pointerdown', outside, true); };
  }, [open, confirmEmpty, onClose]);
  if (!open) return null;
  return <aside className={`trashPanel${showManagement ? ' trashPanel-management' : ''}`} ref={panel} role="region" aria-label="Trash" onPointerDown={event => event.stopPropagation()} onKeyDown={event => event.stopPropagation()}>
    <button type="button" className="trashPanel-close" title="Close trash" aria-label="Close trash" onClick={onClose}><X size={14} /></button>
    <div className="trashPanel-content">
      {!entries.length ? <div className="trashPanel-empty"><Trash2 size={31} strokeWidth={1.2}/><strong>Your trash is empty</strong><p>Deleted items will appear here.</p></div> : entries.map(entry => {
        const roots = entry.rootIds.map(id => entry.cards.find(card => card.id === id)).filter((card): card is Card => !!card);
        const day = new Date(entry.deletedAt), today = new Date();
        const dayName = day.toLocaleDateString() === today.toLocaleDateString() ? 'Today' : day.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
        const previous = entries[entries.indexOf(entry) - 1];
        const showDay = !previous || new Date(previous.deletedAt).toLocaleDateString() !== day.toLocaleDateString();
        return <div className="trashPanel-dayEntry" key={entry.id}>{showDay && <div className="trashPanel-day">{dayName}</div>}<section className="trashPanel-entry" data-trash-id={entry.id} tabIndex={0} aria-label={`Deleted ${roots.length ? roots.map(cardTitle).join(', ').slice(0, 100) : 'line'}`} draggable
          onKeyDown={event => { if (event.key === 'Enter') { event.preventDefault(); onRestore(entry.id); } }}
          onDragStart={event => { event.dataTransfer.setData('application/canvas-trash-id', entry.id); event.dataTransfer.effectAllowed = 'move'; }}
          title={`Drag to restore · Deleted ${new Date(entry.deletedAt).toLocaleDateString()} · Kept until ${new Date(trashEntryExpiresAt(entry)).toLocaleDateString()}`}>
          <div className="trashPanel-preview">{roots.length ? roots.slice(0, 3).map(card => <div key={card.id} className={`trashPanel-card trashPanel-card-${card.type}`}><Preview card={card}/></div>) : <div className="trashPanel-line">↗</div>}</div>
          {showManagement && <><div className="trashPanel-entryInfo"><strong>{roots.length === 1 ? cardTitle(roots[0]) : roots.length ? `${roots.length} items` : `${entry.connections.length} line${entry.connections.length === 1 ? '' : 's'}`}</strong><small>{entry.sourceBoardTitle}</small></div><div className="trashPanel-actions"><button type="button" title="Restore deleted item" aria-label="Restore deleted item" onClick={() => onRestore(entry.id)}><RotateCcw size={14}/></button>{onDelete && <button type="button" title="Delete permanently" aria-label="Delete permanently" onClick={() => onDelete(entry.id)}><Trash2 size={14}/></button>}</div></>}
        </section></div>;
      })}
      {!!entries.length && <div className="trashPanel-older">Nothing older in trash</div>}
    </div>
    {showManagement && <footer className="trashPanel-footer"><p><ArrowUpLeft size={13}/> Drag items back onto your board to restore them.</p><small>Items remain in the trash for 3 months.</small><button type="button" className="trashPanel-emptyButton" disabled={!entries.length} onClick={() => setConfirmEmpty(true)}><Trash2 size={14}/>Empty trash</button></footer>}
    {confirmEmpty && <div className="trashPanel-confirmBackdrop"><div className="trashPanel-confirm" role="alertdialog" aria-labelledby="trash-empty-title" aria-describedby="trash-empty-description"><strong id="trash-empty-title">Empty trash?</strong><p id="trash-empty-description">These items will be permanently deleted.</p><div><button type="button" onClick={() => setConfirmEmpty(false)}>Cancel</button><button type="button" className="trashPanel-danger" onClick={() => { onEmpty(); setConfirmEmpty(false); }}>Empty trash</button></div></div></div>}
  </aside>;
}
