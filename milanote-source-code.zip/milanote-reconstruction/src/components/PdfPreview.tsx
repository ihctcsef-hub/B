import {useEffect,useMemo,useState} from 'react';
import {loadPdfThumbnail,type PdfThumbnail} from '../core/pdfPreview';
import './pdf-preview.css';

export interface PdfPreviewProps {
  dataUrl:string;
  name:string;
  cachedThumbnail?:PdfThumbnail;
  className?:string;
  onReady?:(info:PdfThumbnail)=>void;
  onError?:(message:string)=>void;
}
/** The cached bitmap is never displayed until the original PDF's digest has
 * been checked. Download/Open continue to use the original document. */
export function PdfPreview({dataUrl,name,cachedThumbnail,className='',onReady,onError}:PdfPreviewProps){
  const [state,setState]=useState<{source:string;cache?:PdfThumbnail;preview?:PdfThumbnail;error?:string}>({source:dataUrl});
  const image=cachedThumbnail?.imageDataUrl,digest=cachedThumbnail?.sourceDigest,width=cachedThumbnail?.width,height=cachedThumbnail?.height,pages=cachedThumbnail?.pageCount;
  const cache=useMemo(()=>image&&digest&&width&&height&&pages?{imageDataUrl:image,sourceDigest:digest,width,height,pageCount:pages}:undefined,[image,digest,width,height,pages]);
  useEffect(()=>{
    // A completion belongs to the request which started it. Updating callbacks
    // during a render must not redirect an old attachment into a new workspace.
    const readyForRequest=onReady,errorForRequest=onError;
    const controller=new AbortController();setState({source:dataUrl,cache});
    loadPdfThumbnail(dataUrl,{signal:controller.signal,cachedThumbnail:cache}).then(({thumbnail,fromCache})=>{
      if(controller.signal.aborted)return;setState({source:dataUrl,cache,preview:thumbnail});if(!fromCache)readyForRequest?.(thumbnail);
    }).catch(()=>{
      if(controller.signal.aborted)return;
      const message='Preview unavailable';setState({source:dataUrl,cache,error:message});errorForRequest?.(message);
    });
    return()=>controller.abort();
  },[dataUrl,cache]);
  const current=state.source===dataUrl&&state.cache===cache?state:undefined;
  return <div className={`pdf-thumbnail ${className}`} data-page-count={current?.preview?.pageCount} data-preview-digest={current?.preview?.sourceDigest}>
    {current?.preview?<img src={current.preview.imageDataUrl} alt={`${name||'PDF'} — page 1 of ${current.preview.pageCount}`} draggable={false}/>:<span className="pdf-thumbnail-status" role="status">{current?.error||'Loading preview…'}</span>}
  </div>;
}
