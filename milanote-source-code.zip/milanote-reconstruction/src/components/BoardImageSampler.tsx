import {useEffect,useRef,useState} from 'react';
import {createPortal} from 'react-dom';
import {X} from 'lucide-react';
import type {BoardColorImage,ColorImageRect} from '../core/imageColors';
import {imagePixelColor,imagePointAt,readImageColors} from '../core/imageColors';
import './board-image-sampler.css';

export function BoardImageSampler({images,clip,onFinish}:{images:BoardColorImage[];clip:ColorImageRect;onFinish:(value:string|null)=>void}){
  const root=useRef<HTMLDivElement>(null),finish=useRef(onFinish),active=useRef(true),press=useRef<{id:number;x:number;y:number}|null>(null);
  const [busy,setBusy]=useState(false),[error,setError]=useState(''),[hover,setHover]=useState<string|null>(null);finish.current=onFinish;
  useEffect(()=>{
    active.current=true;root.current?.focus();const resize=()=>finish.current(null);
    const key=(event:KeyboardEvent)=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();finish.current(null);}};
    window.addEventListener('resize',resize);document.addEventListener('keydown',key,true);
    const element=root.current;const wheel=(event:WheelEvent)=>event.preventDefault();element?.addEventListener('wheel',wheel,{passive:false});
    return()=>{active.current=false;window.removeEventListener('resize',resize);document.removeEventListener('keydown',key,true);element?.removeEventListener('wheel',wheel);};
  },[]);
  function hit(x:number,y:number){
    if(x<clip.x||y<clip.y||x>=clip.x+clip.width||y>=clip.y+clip.height)return undefined;
    const element=root.current,previous=element?.style.pointerEvents;if(element)element.style.pointerEvents='none';
    try{const id=document.elementFromPoint(x,y)?.closest('[data-card-id]')?.getAttribute('data-card-id');return images.find(image=>image.id===id&&x>=image.rect.x&&y>=image.rect.y&&x<image.rect.x+image.rect.width&&y<image.rect.y+image.rect.height);}
    finally{if(element)element.style.pointerEvents=previous||'';}
  }
  async function sample(x:number,y:number){
    const image=hit(x,y);if(!image){setError('Choose a point on an image.');return;}setBusy(true);setError('');
    try{const pixels=await readImageColors(image.source,image.edits,2048),point=imagePointAt(image.rect,pixels.width,pixels.height,x,y);if(active.current&&point)finish.current(imagePixelColor(pixels,point,image.background));}
    catch(exception){if(active.current)setError(exception instanceof Error?exception.message:'This image could not be sampled.');}
    finally{if(active.current)setBusy(false);}
  }
  const hovered=images.find(image=>image.id===hover);
  return createPortal(<div ref={root} className={`boardImageSampler${busy?' boardImageSampler-busy':''}`} role="dialog" aria-modal="true" aria-label="Pick a color from an image" tabIndex={-1}
    onKeyDown={event=>{event.stopPropagation();if(event.key==='Tab'){event.preventDefault();root.current?.querySelector<HTMLButtonElement>('button')?.focus();}}}
    onPointerDown={event=>{if((event.target as Element).closest('.boardImageSampler-message'))return;event.preventDefault();event.stopPropagation();press.current=event.isPrimary?{id:event.pointerId,x:event.clientX,y:event.clientY}:null;}}
    onPointerCancel={()=>{press.current=null;}}
    onPointerMove={event=>setHover(hit(event.clientX,event.clientY)?.id||null)}
    onPointerUp={event=>{const start=press.current;press.current=null;if(!busy&&start&&start.id===event.pointerId&&Math.hypot(event.clientX-start.x,event.clientY-start.y)<5){event.preventDefault();event.stopPropagation();void sample(event.clientX,event.clientY);}}}>
    {hovered&&<div className="boardImageSampler-outline" style={{left:Math.max(clip.x,hovered.rect.x),top:Math.max(clip.y,hovered.rect.y),width:Math.min(clip.x+clip.width,hovered.rect.x+hovered.rect.width)-Math.max(clip.x,hovered.rect.x),height:Math.min(clip.y+clip.height,hovered.rect.y+hovered.rect.height)-Math.max(clip.y,hovered.rect.y)}}/>}
    <div className="boardImageSampler-message"><span>{busy?'Picking color…':error||'Pick a color from an image'}</span><button type="button" onPointerDown={event=>event.stopPropagation()} onClick={()=>finish.current(null)} aria-label="Cancel color sampling"><X size={14}/>Cancel</button></div>
  </div>,document.body);
}
