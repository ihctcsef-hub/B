import { useEffect, useRef, useState } from "react";
import type { CSSProperties, KeyboardEvent, PointerEvent } from "react";
import { Check, Crop, Eraser, FlipHorizontal2, FlipVertical2, MousePointer2, Pencil, Redo2, RotateCcw, RotateCw, Trash2, Undo2, X } from "lucide-react";
import type { Point, SketchPath } from "../core/model";
import {
  defaultImageEdits, flipImageEdits, hasImageEdits, imageCropBounds, imagePathToSvg,
  imageEditsTransform, inverseImagePoint, loadImageDimensions, normalizeImageEdits,
  rotateImageEdits, rotatedImageSize, hitTestImagePath, imagePathsBounds, translateImagePaths,
} from "../core/imageEditing";
import type { ImageCrop, ImageEdits, ImageSize } from "../core/imageEditing";
import "./image-editor.css";

export interface ImageEditorProps {
  src: string;
  edits?: ImageEdits;
  initialMode?: "crop" | "markup";
  onSave: (edits: ImageEdits, dimensions: ImageSize) => void;
  onCancel: () => void;
}

export interface ImagePreviewProps {
  src: string;
  edits?: ImageEdits;
  alt?: string;
  className?: string;
  style?: CSSProperties;
}

function useImageSize(src: string) {
  const [state, setState] = useState<{ src: string; size?: ImageSize; error?: string }>({ src });
  useEffect(() => {
    let active = true;
    setState({ src });
    loadImageDimensions(src).then(
      (size) => { if (active) setState({ src, size }); },
      (error: unknown) => { if (active) setState({ src, error: error instanceof Error ? error.message : "Unable to load this image." }); },
    );
    return () => { active = false; };
  }, [src]);
  return state.src === src ? state : { src };
}

function ImageArtwork({ src, size, edits }: { src: string; size: ImageSize; edits: ImageEdits }) {
  return (
    <g transform={imageEditsTransform(size.width, size.height, edits)}>
      <image href={src} width={size.width} height={size.height} />
      {edits.paths.map((path, index) => <path
        key={index}
        d={imagePathToSvg(path.points.map((point) => ({ x: point.x * size.width, y: point.y * size.height })))}
        fill="none"
        stroke={path.color}
        strokeWidth={path.width * Math.min(size.width, size.height)}
        strokeLinecap="round"
        strokeLinejoin="round"
      />)}
    </g>
  );
}

/** Uses the stored source and vector edits directly, so reopening an image never
 * loses image quality or the ability to change its crop. */
export function ImagePreview({ src, edits: value, alt = "Board image", className = "", style }: ImagePreviewProps) {
  const { size } = useImageSize(src);
  if (!hasImageEdits(value) || !size)
    return <img className={className} style={style} src={src} alt={alt} draggable={false} />;
  const edits = normalizeImageEdits(value), crop = imageCropBounds(size.width, size.height, edits);
  return <svg
    className={`edited-image-preview ${className}`}
    style={style}
    role="img"
    aria-label={alt}
    viewBox={`${crop.x} ${crop.y} ${crop.width} ${crop.height}`}
    preserveAspectRatio="xMidYMid slice"
  ><ImageArtwork src={src} size={size} edits={edits} /></svg>;
}

type CropHandle = "new" | "move" | "n" | "s" | "e" | "w" | "nw" | "ne" | "sw" | "se";
type Gesture =
  | { type: "crop"; pointer: number; start: Point; crop: ImageCrop; handle: CropHandle }
  | { type: "pen"; pointer: number; points: Point[]; color: string; width: number }
  | { type: "move-paths"; pointer: number; start: Point; edits: ImageEdits; selected: number[] }
  | { type: "erase"; pointer: number };
type EditHistory = { past: ImageEdits[]; present: ImageEdits; future: ImageEdits[] };
const PEN_COLORS = ["#ed4b35", "#f2bf35", "#55a462", "#3f8bc9", "#9359b4", "#272727", "#ffffff"];
const bound = (value: number, min = 0, max = 1) => Math.max(min, Math.min(max, value));

function moveCrop(start: ImageCrop, from: Point, to: Point, handle: CropHandle): ImageCrop {
  const minimum = 0.02;
  if (handle === "new") {
    const left = Math.min(from.x, to.x), top = Math.min(from.y, to.y);
    return {
      x: Math.min(left, 1 - minimum), y: Math.min(top, 1 - minimum),
      width: Math.max(minimum, Math.abs(to.x - from.x)),
      height: Math.max(minimum, Math.abs(to.y - from.y)),
    };
  }
  const dx = to.x - from.x, dy = to.y - from.y;
  if (handle === "move") return {
    ...start, x: bound(start.x + dx, 0, 1 - start.width), y: bound(start.y + dy, 0, 1 - start.height),
  };
  let left = start.x, right = start.x + start.width, top = start.y, bottom = start.y + start.height;
  if (handle.includes("w")) left = bound(start.x + dx, 0, right - minimum);
  if (handle.includes("e")) right = bound(start.x + start.width + dx, left + minimum, 1);
  if (handle.includes("n")) top = bound(start.y + dy, 0, bottom - minimum);
  if (handle.includes("s")) bottom = bound(start.y + start.height + dy, top + minimum, 1);
  return { x: left, y: top, width: right - left, height: bottom - top };
}

function distanceToSegment(point: Point, start: Point, end: Point): number {
  const dx = end.x - start.x, dy = end.y - start.y;
  const t = dx || dy ? bound(((point.x - start.x) * dx + (point.y - start.y) * dy) / (dx * dx + dy * dy)) : 0;
  return Math.hypot(point.x - start.x - t * dx, point.y - start.y - t * dy);
}

export function ImageEditor({ src, edits: initialEdits, initialMode = "crop", onSave, onCancel }: ImageEditorProps) {
  const [history, setHistory] = useState<EditHistory>(() => ({ past: [], present: normalizeImageEdits(initialEdits), future: [] }));
  const [mode, setMode] = useState(initialMode);
  const [pen, setPen] = useState<"pen" | "eraser" | "select">("pen");
  const [selectedPaths, setSelectedPaths] = useState<number[]>([]);
  const [penColor, setPenColor] = useState(PEN_COLORS[0]);
  const [penWidth, setPenWidth] = useState(4);
  const [draft, setDraft] = useState<ImageEdits | null>(null);
  const [draftPath, setDraftPath] = useState<SketchPath | null>(null);
  const { size, error } = useImageSize(src);
  const dialogRef = useRef<HTMLDivElement>(null);
  const workspaceRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const [canvasSize, setCanvasSize] = useState<ImageSize | null>(null);
  const gesture = useRef<Gesture | null>(null);
  const currentEdits = draft || history.present;
  const currentRef = useRef(currentEdits);
  currentRef.current = currentEdits;
  const draftRef = useRef<ImageEdits | null>(null);
  const rotated = size ? rotatedImageSize(size.width, size.height, currentEdits.rotation) : { width: 1, height: 1 };
  const crop = currentEdits.crop;

  useEffect(() => {
    const previous = document.activeElement;
    dialogRef.current?.focus();
    return () => { if (previous instanceof HTMLElement && previous.isConnected) previous.focus(); };
  }, []);

  useEffect(() => {
    const element = workspaceRef.current;
    if (!element || !size) return;
    const update = () => {
      const style = getComputedStyle(element);
      const availableWidth = element.clientWidth - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight);
      const availableHeight = element.clientHeight - parseFloat(style.paddingTop) - parseFloat(style.paddingBottom);
      const ratio = rotated.width / rotated.height;
      const width = Math.max(1, Math.min(availableWidth, availableHeight * ratio));
      setCanvasSize({ width, height: width / ratio });
    };
    update();
    const observer = new ResizeObserver(update);
    observer.observe(element);
    return () => observer.disconnect();
  }, [size, rotated.width, rotated.height]);

  function commit(next: ImageEdits, keepSelection = false) {
    if (!keepSelection) setSelectedPaths([]);
    setHistory((state) => JSON.stringify(state.present) === JSON.stringify(next) ? state : {
      past: [...state.past.slice(-99), state.present], present: normalizeImageEdits(next), future: [],
    });
  }
  function undo() {
    cancelWorking();
    setSelectedPaths([]);
    setHistory((state) => state.past.length ? {
      past: state.past.slice(0, -1), present: state.past[state.past.length - 1], future: [state.present, ...state.future],
    } : state);
  }
  function redo() {
    cancelWorking();
    setSelectedPaths([]);
    setHistory((state) => state.future.length ? {
      past: [...state.past, state.present], present: state.future[0], future: state.future.slice(1),
    } : state);
  }
  function keyboard(event: KeyboardEvent<HTMLDivElement>) {
    event.stopPropagation();
    if (event.key === "Escape") {
      event.preventDefault();
      if (gesture.current || selectedPaths.length) { cancelWorking(); setSelectedPaths([]); }
      else onCancel();
    }
    else if (mode === "markup" && pen === "select" && (event.key === "Delete" || event.key === "Backspace") &&
      !(event.target as HTMLElement).closest('input,textarea,select,[contenteditable="true"]')) {
      if (selectedPaths.length) { event.preventDefault(); deleteSelection(); }
    }
    else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z") {
      event.preventDefault(); event.shiftKey ? redo() : undo();
    } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "y") {
      event.preventDefault(); redo();
    } else if (event.key === "Tab") {
      const focusable = Array.from(dialogRef.current?.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), [tabindex="0"]') || []);
      const first = focusable[0], last = focusable[focusable.length - 1];
      if (event.shiftKey && (document.activeElement === first || document.activeElement === dialogRef.current)) {
        event.preventDefault(); last?.focus();
      } else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    }
  }
  function position(event: PointerEvent<SVGSVGElement>): Point {
    const rect = event.currentTarget.getBoundingClientRect();
    return { x: bound((event.clientX - rect.left) / rect.width), y: bound((event.clientY - rect.top) / rect.height) };
  }
  function originalPoint(event: PointerEvent<SVGSVGElement>): Point {
    return inverseImagePoint(position(event), currentRef.current);
  }
  function setWorking(next: ImageEdits) {
    draftRef.current = next;
    currentRef.current = next;
    setDraft(next);
  }
  function cancelWorking() {
    const pointer = gesture.current?.pointer;
    gesture.current = null;
    draftRef.current = null;
    currentRef.current = history.present;
    setDraft(null);
    setDraftPath(null);
    if (pointer !== undefined && svgRef.current?.hasPointerCapture(pointer)) svgRef.current.releasePointerCapture(pointer);
  }
  function choosePen(next: "pen" | "eraser" | "select") {
    cancelWorking(); setPen(next); setSelectedPaths([]);
  }
  function chooseMode(next: "crop" | "markup") {
    cancelWorking(); setMode(next); setSelectedPaths([]);
  }
  function deleteSelection() {
    cancelWorking();
    const selected = new Set(selectedPaths);
    commit({ ...history.present, paths: history.present.paths.filter((_, index) => !selected.has(index)) });
    dialogRef.current?.focus({ preventScroll: true });
  }
  function eraseAt(point: Point) {
    if (!size || !svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect(), scale = rect.width / rotated.width;
    const local = { x: point.x * size.width, y: point.y * size.height };
    const next = currentRef.current.paths.filter((path) => {
      const radius = 8 / scale + path.width * Math.min(size.width, size.height) / 2;
      const points = path.points.map((p) => ({ x: p.x * size.width, y: p.y * size.height }));
      return !points.some((p, index) => distanceToSegment(local, p, points[Math.max(0, index - 1)]) <= radius);
    });
    if (next.length !== currentRef.current.paths.length) setWorking({ ...currentRef.current, paths: next });
  }
  function pointerDown(event: PointerEvent<SVGSVGElement>) {
    if (!size || error || gesture.current || (event.pointerType === "mouse" && event.button !== 0)) return;
    event.preventDefault(); event.stopPropagation();
    dialogRef.current?.focus({ preventScroll: true });
    event.currentTarget.setPointerCapture(event.pointerId);
    if (mode === "crop") {
      const target = event.target as Element;
      const handle = (target.closest("[data-crop-handle]")?.getAttribute("data-crop-handle") || "new") as CropHandle;
      gesture.current = { type: "crop", pointer: event.pointerId, start: position(event), crop: { ...crop }, handle };
    } else if (pen === "select") {
      const rect = event.currentTarget.getBoundingClientRect();
      const index = hitTestImagePath(currentRef.current, position(event), size, rect);
      if (index === null) { setSelectedPaths([]); event.currentTarget.releasePointerCapture(event.pointerId); return; }
      const selected = event.shiftKey
        ? selectedPaths.includes(index) ? selectedPaths.filter(value => value !== index) : [...selectedPaths, index]
        : selectedPaths.includes(index) ? selectedPaths : [index];
      setSelectedPaths(selected);
      if (!selected.includes(index)) { event.currentTarget.releasePointerCapture(event.pointerId); return; }
      gesture.current = { type: "move-paths", pointer: event.pointerId, start: originalPoint(event), edits: currentRef.current, selected };
    } else if (pen === "eraser") {
      setSelectedPaths([]);
      gesture.current = { type: "erase", pointer: event.pointerId };
      eraseAt(originalPoint(event));
    } else {
      setSelectedPaths([]);
      const point = originalPoint(event), rect = event.currentTarget.getBoundingClientRect();
      const width = penWidth / Math.min(rect.width, rect.height);
      gesture.current = { type: "pen", pointer: event.pointerId, points: [point], color: penColor, width };
      setDraftPath({ points: [point], color: penColor, width });
    }
  }
  function pointerMove(event: PointerEvent<SVGSVGElement>) {
    const active = gesture.current;
    if (!active || active.pointer !== event.pointerId) return;
    event.preventDefault(); event.stopPropagation();
    if (active.type === "crop") setWorking({ ...currentRef.current, crop: moveCrop(active.crop, active.start, position(event), active.handle) });
    else if (active.type === "erase") eraseAt(originalPoint(event));
    else if (active.type === "move-paths") {
      const point = inverseImagePoint(position(event), active.edits);
      setWorking(translateImagePaths(active.edits, active.selected, { x: point.x - active.start.x, y: point.y - active.start.y }));
    }
    else {
      const point = originalPoint(event), last = active.points[active.points.length - 1];
      if (Math.hypot(point.x - last.x, point.y - last.y) < 0.0008) return;
      active.points.push(point);
      setDraftPath({ points: [...active.points], color: active.color, width: active.width });
    }
  }
  function pointerEnd(event: PointerEvent<SVGSVGElement>, cancel = false) {
    const active = gesture.current;
    if (!active || active.pointer !== event.pointerId) return;
    event.preventDefault(); event.stopPropagation();
    if (!cancel) {
      if (active.type === "pen") commit({ ...currentRef.current, paths: [...currentRef.current.paths, {
        color: active.color, width: active.width, points: active.points,
      }] });
      else if (draftRef.current) commit(draftRef.current, active.type === "move-paths");
    }
    gesture.current = null;
    draftRef.current = null;
    setDraft(null);
    setDraftPath(null);
    if (cancel) currentRef.current = history.present;
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
  }

  const withDraft = draftPath ? { ...currentEdits, paths: [...currentEdits.paths, draftPath] } : currentEdits;
  const viewWidth = rotated.width, viewHeight = rotated.height;
  const cx = crop.x * viewWidth, cy = crop.y * viewHeight, cw = crop.width * viewWidth, ch = crop.height * viewHeight;
  const handleSize = Math.max(viewWidth, viewHeight) / 65;
  const selectionBounds = mode === "markup" && pen === "select" ? imagePathsBounds(currentEdits, selectedPaths) : null;
  const selectionPadding = canvasSize ? 5 * viewWidth / canvasSize.width : handleSize / 2;
  const handles: { handle: CropHandle; x: number; y: number }[] = [
    { handle: "nw", x: cx, y: cy }, { handle: "n", x: cx + cw / 2, y: cy }, { handle: "ne", x: cx + cw, y: cy },
    { handle: "w", x: cx, y: cy + ch / 2 }, { handle: "e", x: cx + cw, y: cy + ch / 2 },
    { handle: "sw", x: cx, y: cy + ch }, { handle: "s", x: cx + cw / 2, y: cy + ch }, { handle: "se", x: cx + cw, y: cy + ch },
  ];
  return <div className="image-editor-backdrop" onPointerDown={(event) => event.stopPropagation()} onWheel={(event) => event.stopPropagation()}>
    <div
      className="image-editor-dialog"
      ref={dialogRef}
      role="dialog"
      aria-modal="true"
      aria-labelledby="image-editor-title"
      tabIndex={-1}
      onKeyDown={keyboard}
      onPaste={(event) => event.stopPropagation()}
      onCopy={(event) => event.stopPropagation()}
      onCut={(event) => event.stopPropagation()}
    >
      <header className="image-editor-header">
        <h2 id="image-editor-title">Edit image</h2>
        <div className="image-editor-tabs" role="group" aria-label="Image editing mode">
          <button type="button" aria-pressed={mode === "crop"} onClick={() => chooseMode("crop")}><Crop size={16} />Crop & rotate</button>
          <button type="button" aria-pressed={mode === "markup"} onClick={() => chooseMode("markup")}><Pencil size={16} />Draw on image</button>
        </div>
        <button type="button" className="image-editor-icon" title="Close image editor" aria-label="Close image editor" onClick={onCancel}><X size={19} /></button>
      </header>
      <div className="image-editor-toolbar">
        {mode === "crop" ? <>
          <button type="button" disabled={!size} onClick={() => commit(rotateImageEdits(history.present, -1))}><RotateCcw size={17} />Rotate left</button>
          <button type="button" disabled={!size} onClick={() => commit(rotateImageEdits(history.present, 1))}><RotateCw size={17} />Rotate right</button>
          <span className="image-editor-toolbar-divider" />
          <button type="button" disabled={!size} onClick={() => commit(flipImageEdits(history.present, "horizontal"))}><FlipHorizontal2 size={17} />Flip horizontal</button>
          <button type="button" disabled={!size} onClick={() => commit(flipImageEdits(history.present, "vertical"))}><FlipVertical2 size={17} />Flip vertical</button>
          <span className="image-editor-toolbar-divider" />
          <button type="button" disabled={!size || (crop.width === 1 && crop.height === 1)} onClick={() => commit({ ...history.present, crop: defaultImageEdits().crop })}>Reset crop</button>
        </> : <>
          <button type="button" className="image-editor-icon" title="Pen" aria-label="Pen" aria-pressed={pen === "pen"} onClick={() => choosePen("pen")}><Pencil size={17} /></button>
          <button type="button" className="image-editor-icon" title="Selection tool" aria-label="Selection tool" aria-pressed={pen === "select"} onClick={() => choosePen("select")}><MousePointer2 size={17} /></button>
          <button type="button" className="image-editor-icon" title="Eraser" aria-label="Eraser" aria-pressed={pen === "eraser"} onClick={() => choosePen("eraser")}><Eraser size={18} /></button>
          {pen === "select" && <button type="button" className="image-editor-icon" title="Delete selected annotations" aria-label="Delete selected annotations" disabled={!selectedPaths.length} onClick={deleteSelection}><Trash2 size={17} /></button>}
          <span className="image-editor-toolbar-divider" />
          <div className="image-editor-colors" role="group" aria-label="Pen color">
            {PEN_COLORS.map((color) => <button type="button" key={color} title={`Pen color ${color}`} aria-label={`Pen color ${color}`} aria-pressed={color === penColor} style={{ "--pen-color": color } as CSSProperties} onClick={() => { setPenColor(color); choosePen("pen"); }} />)}
          </div>
          <label className="image-editor-width">Size <input aria-label="Pen width" type="range" min="2" max="16" step="1" value={penWidth} onChange={(event) => setPenWidth(Number(event.target.value))} /><span>{penWidth}</span></label>
        </>}
        <div className="image-editor-history">
          <button type="button" className="image-editor-icon" title="Undo image edit" aria-label="Undo image edit" disabled={!history.past.length} onClick={undo}><Undo2 size={17} /></button>
          <button type="button" className="image-editor-icon" title="Redo image edit" aria-label="Redo image edit" disabled={!history.future.length} onClick={redo}><Redo2 size={17} /></button>
        </div>
      </div>
      <div ref={workspaceRef} className={`image-editor-workspace image-editor-mode-${mode} image-editor-tool-${pen}`}>
        {!size ? <div className="image-editor-loading" role={error ? "alert" : "status"}>{error || "Loading image…"}</div> : <svg
          className="image-editor-canvas"
          ref={svgRef}
          viewBox={`0 0 ${viewWidth} ${viewHeight}`}
          style={{ aspectRatio: `${viewWidth} / ${viewHeight}`, width: canvasSize?.width, height: canvasSize?.height, cursor: mode === "markup" && pen === "select" ? "default" : undefined }}
          aria-label={mode === "crop" ? "Crop image: drag handles to adjust the crop" : pen === "select" ? "Select and move image annotations" : "Draw on image"}
          onPointerDown={pointerDown}
          onPointerMove={pointerMove}
          onPointerUp={(event) => pointerEnd(event)}
          onPointerCancel={(event) => pointerEnd(event, true)}
        >
          <ImageArtwork src={src} size={size} edits={withDraft} />
          {mode === "crop" ? <g className="image-editor-crop-overlay">
            <path d={`M 0 0 H ${viewWidth} V ${viewHeight} H 0 Z M ${cx} ${cy} V ${cy + ch} H ${cx + cw} V ${cy} Z`} fill="rgba(0,0,0,.53)" fillRule="evenodd" />
            <rect data-crop-handle="move" x={cx} y={cy} width={cw} height={ch} fill="transparent" stroke="#fff" strokeWidth={1.5} vectorEffect="non-scaling-stroke" />
            {[1 / 3, 2 / 3].map((ratio) => <g key={ratio} pointerEvents="none" stroke="rgba(255,255,255,.5)" strokeWidth={1} vectorEffect="non-scaling-stroke">
              <line x1={cx + cw * ratio} x2={cx + cw * ratio} y1={cy} y2={cy + ch} />
              <line x1={cx} x2={cx + cw} y1={cy + ch * ratio} y2={cy + ch * ratio} />
            </g>)}
            {handles.map(({ handle, x, y }) => <rect key={handle} data-crop-handle={handle} x={x - handleSize / 2} y={y - handleSize / 2} width={handleSize} height={handleSize} fill="#fff" stroke="#444" strokeWidth={1} vectorEffect="non-scaling-stroke" />)}
          </g> : (crop.width < 1 || crop.height < 1) && <path
            d={`M 0 0 H ${viewWidth} V ${viewHeight} H 0 Z M ${cx} ${cy} V ${cy + ch} H ${cx + cw} V ${cy} Z`}
            fill="rgba(0,0,0,.55)" fillRule="evenodd" pointerEvents="none"
          />}
          {selectionBounds && <g pointerEvents="none" role="img" aria-label={`${selectedPaths.length} selected annotation${selectedPaths.length === 1 ? "" : "s"}`}>
            <rect data-annotation-selection="true" x={selectionBounds.x * viewWidth - selectionPadding} y={selectionBounds.y * viewHeight - selectionPadding}
              width={selectionBounds.width * viewWidth + 2 * selectionPadding} height={selectionBounds.height * viewHeight + 2 * selectionPadding}
              fill="rgba(78,137,228,.05)" stroke="#4e89e4" strokeWidth={1.5} strokeDasharray="4 3" vectorEffect="non-scaling-stroke" />
          </g>}
        </svg>}
      </div>
      <footer className="image-editor-footer">
        <p>{mode === "crop" ? "Drag the corners to crop. Drag inside to move the crop." : pen === "eraser" ? "Drag over a mark to erase it." : pen === "select" ? "Click a mark to select it, then drag to move. Shift-click adds marks. Delete removes selected marks." : "Draw over your image. Your original image is always preserved."}</p>
        <button type="button" className="image-editor-reset" disabled={!hasImageEdits(history.present)} onClick={() => commit(defaultImageEdits())}>Reset image</button>
        <button type="button" className="image-editor-cancel" onClick={onCancel}>Cancel</button>
        <button type="button" className="image-editor-save" disabled={!size || !!error} onClick={() => {
          if (!size) return;
          const bounds = imageCropBounds(size.width, size.height, history.present);
          onSave(normalizeImageEdits(history.present), { width: bounds.width, height: bounds.height });
        }}><Check size={16} />Save changes</button>
      </footer>
    </div>
  </div>;
}
