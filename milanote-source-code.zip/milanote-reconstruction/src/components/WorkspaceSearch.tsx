import { useEffect, useMemo, useRef, useState } from 'react';
import { ChevronDown, FileText, Folder, Search, X } from 'lucide-react';
import type { Card, Workspace } from '../core/model';
import { searchBoardAncestors, searchMatchRange, searchSnippet, searchWorkspace, type SearchSort } from '../core/search';
import './workspace-search.css';

interface Props {
  workspace: Workspace;
  query: string;
  labelId?: string | null;
  anchorRight?: number;
  onQuery: (value: string) => void;
  onChoose: (boardId: string, card?: Card) => void;
  onClose: () => void;
}
const SORT_KEY = 'canvas-search-sort-v1';
const labels: Record<SearchSort, string> = { viewed: 'Last viewed', modified: 'Last modified', relevance: 'Relevance' };
function initialSort(): SearchSort { try { const value = localStorage.getItem(SORT_KEY); return value === 'modified' || value === 'relevance' ? value : 'viewed'; } catch { return 'viewed'; } }
function Highlight({ text, query }: { text: string; query: string }) {
  const match = searchMatchRange(text, query);
  return !match ? <>{text}</> : <>{text.slice(0, match.start)}<mark>{text.slice(match.start, match.end)}</mark>{text.slice(match.end)}</>;
}
export function WorkspaceSearch({ workspace, query, labelId, anchorRight, onQuery, onChoose, onClose }: Props) {
  const [sort, setSort] = useState<SearchSort>(initialSort), [selected, setSelected] = useState<string|null>(null);
  const root = useRef<HTMLDivElement>(null), input = useRef<HTMLInputElement>(null), close = useRef(onClose); close.current = onClose;
  const results = useMemo(() => searchWorkspace(workspace, query, sort, labelId), [workspace, query, sort, labelId]);
  const selectedIndex=Math.max(0,results.findIndex(result=>result.board.id===selected));
  useEffect(() => { setSelected(null); }, [query, labelId, sort]);
  useEffect(() => {
    input.current?.focus();
    function outside(event: PointerEvent) { const target = event.target as Element | null; if (!target || root.current?.contains(target) || target.closest('[data-search-trigger]')) return; close.current(); }
    function key(event: KeyboardEvent) {
      if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); close.current(); }
      if ((event.ctrlKey || event.metaKey) && ['f', 'k'].includes(event.key.toLowerCase())) { event.preventDefault(); event.stopPropagation(); input.current?.focus(); input.current?.select(); }
    }
    document.addEventListener('pointerdown', outside, true); document.addEventListener('keydown', key, true);
    return () => { document.removeEventListener('pointerdown', outside, true); document.removeEventListener('keydown', key, true); };
  }, []);
  const top = Math.max(6, Math.min(47, window.innerHeight - 125));
  const left = Math.max(6, Math.min((anchorRight ?? window.innerWidth - 90.8) - 320, window.innerWidth - 326));
  return <div ref={root} className="workspace-search modal-search" role="dialog" aria-label="Search workspace" style={{ left, top, maxHeight: Math.max(110, window.innerHeight - top - 10) }} onPointerDown={event => event.stopPropagation()} onKeyDown={event => {
    event.stopPropagation();
    if (event.target instanceof HTMLSelectElement) return;
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') { event.preventDefault(); setSelected(results[Math.max(0,Math.min(results.length-1,selectedIndex+(event.key==='ArrowDown'?1:-1)))]?.board.id||null); }
    if (event.key === 'Enter' && event.target === input.current && results[selectedIndex]) { event.preventDefault(); onChoose(results[selectedIndex].board.id); }
  }}>
    <div className="workspace-search-form">
      <div className="workspace-search-input"><Search size={14}/><input ref={input} type="search" aria-label="Search workspace" value={query} onChange={event => onQuery(event.target.value)} autoComplete="off"/>{query && <button type="button" aria-label="Clear search" onClick={() => { onQuery(''); input.current?.focus(); }}><X size={13}/></button>}</div>
      <div className="workspace-search-modifiers"><label className="workspace-search-sort"><span>{labels[sort]}</span><ChevronDown size={12}/><select aria-label="Sort search results" value={sort} onChange={event => { const value = event.target.value as SearchSort; setSort(value); try { localStorage.setItem(SORT_KEY, value); } catch { /* Sorting remains usable when storage is unavailable. */ } }}>{Object.entries(labels).map(([value, text]) => <option key={value} value={value}>{text}</option>)}</select></label><span className="workspace-search-status">{(query||labelId)&&results.length?`${results.length} ${results.length===1?'match':'matches'}`:''}</span></div>
    </div>
    <div className="workspace-search-status workspace-search-recent">{!query&&!labelId?'Recently viewed':''}</div>
    <div className="search-results workspace-search-results">
      {results.map((result, index) => {
        const board = result.board, ancestors = searchBoardAncestors(workspace, board), boardCount = board.cards.filter(card => card.type === 'board').length, cardCount = board.cards.filter(card => card.type !== 'board' && card.type !== 'column').length;
        const counts = [boardCount ? `${boardCount} ${boardCount === 1 ? 'board' : 'boards'}` : '', `${cardCount} ${cardCount === 1 ? 'card' : 'cards'}`].filter(Boolean).join(' and ');
        return <section key={board.id} className={`workspace-search-entry${index === selectedIndex ? ' selected' : ''}`} data-search-board={board.id}>
          {!!ancestors.length && <div className="workspace-search-ancestors">{ancestors.join(' / ')}</div>}
          <button type="button" className="workspace-search-board" aria-label={`Open board ${board.title}`} onFocus={() => setSelected(board.id)} onClick={() => { setSelected(board.id); onChoose(board.id); }}>
            <span className="workspace-search-icon">{board.icon ? /^data:image\//i.test(board.icon) ? <img src={board.icon} alt=""/> : <span>{board.icon}</span> : <Folder size={23}/>}</span>
            <span><strong><Highlight text={board.title} query={labelId ? '' : query}/></strong><small>{counts}</small></span>
          </button>
          {!!result.hits.length && <div className="workspace-search-hits">{result.hits.map(card => <button type="button" className="search-inner-hit" key={card.id} data-search-card={card.id} onClick={() => { setSelected(board.id); onChoose(board.id, card); }}><FileText size={14}/><span><Highlight text={searchSnippet(card, query, workspace)} query={query}/></span></button>)}</div>}
        </section>;
      })}
      {!results.length && <p className="workspace-search-empty">{query || labelId ? `No results found for '${query.length > 15 ? `${query.slice(0, 12)}...` : query}'` : 'Boards you open will appear here.'}</p>}
    </div>
  </div>;
}
