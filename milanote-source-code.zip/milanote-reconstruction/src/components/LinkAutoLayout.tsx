import {useLayoutEffect,useRef,type ReactNode} from 'react';

/** Content geometry is derived without adding a separate user Undo action. */
export function LinkAutoLayout({automatic,blocked,onHeight,children}:{automatic:boolean;blocked:boolean;onHeight:(height:number)=>void;children:ReactNode}){
  const root=useRef<HTMLDivElement>(null);
  useLayoutEffect(()=>{
    const element=root.current;if(!element||blocked)return;
    const report=()=>{
      if(!element.isConnected)return;
      const rect=element.getBoundingClientRect(),width=parseFloat(getComputedStyle(element).width);
      if(!width||!rect.width)return;
      const scale=rect.width/width,frame=getComputedStyle(element.parentElement!);
      const edges=[frame.borderTopWidth,frame.borderBottomWidth,frame.paddingTop,frame.paddingBottom].reduce((sum,value)=>sum+(parseFloat(value)||0),0);
      onHeight(Math.ceil(rect.height/scale+edges));
    };
    report();const observer=new ResizeObserver(report);observer.observe(element);return()=>observer.disconnect();
  },[automatic,blocked,onHeight]);
  return automatic?<div ref={root} className="link-auto-content">{children}</div>:children;
}
