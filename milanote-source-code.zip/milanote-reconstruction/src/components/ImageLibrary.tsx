import { useEffect,useRef,useState } from 'react';
import { ImagePlus,LoaderCircle,Search,Upload,X } from 'lucide-react';
import { encodeLibraryPhoto,LIBRARY_DRAG_TYPE,searchLibraryPhotos } from '../core/imageLibrary';
import type { LibraryPhoto,LibrarySearchResult } from '../core/imageLibrary';
import './image-library.css';

export interface ImageLibraryProps {
  onSelect:(photo:LibraryPhoto)=>void;
  onUpload:()=>void;
  onClose:()=>void;
  endpoint?:string;
  anchor?:{left:number;top:number};
}

export function ImageLibrary({onSelect,onUpload,onClose,endpoint,anchor}:ImageLibraryProps){
  const [query,setQuery]=useState(''),[result,setResult]=useState<LibrarySearchResult|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState('');
  const controller=useRef<AbortController|null>(null),generation=useRef(0),input=useRef<HTMLInputElement>(null),root=useRef<HTMLElement>(null);
  const current=useRef({query,result,busy});current.current={query,result,busy};
  async function load(page=1){
    const token=++generation.current;controller.current?.abort();const abort=new AbortController();controller.current=abort;setBusy(true);setError('');
    try{const response=await searchLibraryPhotos(current.current.query,page,abort.signal,endpoint);if(token!==generation.current)return;setResult(previous=>page===1?response:{...response,photos:[...(previous?.photos||[]),...response.photos.filter(photo=>!previous?.photos.some(old=>old.id===photo.id))]});}
    catch(exception){if(!abort.signal.aborted&&token===generation.current)setError(exception instanceof Error?exception.message:'Image search is unavailable.');}
    finally{if(!abort.signal.aborted&&token===generation.current)setBusy(false);}
  }
  useEffect(()=>{input.current?.focus();return()=>controller.current?.abort();},[]);
  useEffect(()=>{const timer=setTimeout(()=>void load(1),300);return()=>{clearTimeout(timer);controller.current?.abort();};},[query,endpoint]);
  useEffect(()=>{function outside(event:PointerEvent){if(event.target instanceof Node&&!root.current?.contains(event.target)&&!(event.target as Element).closest?.('[data-tool="image"]'))onClose();}document.addEventListener('pointerdown',outside);return()=>document.removeEventListener('pointerdown',outside);},[onClose]);
  return <aside ref={root} className="imageLibrary" role="dialog" aria-label="Add image" style={anchor?{left:anchor.left,top:anchor.top}:undefined} onPointerDown={event=>event.stopPropagation()} onKeyDown={event=>{event.stopPropagation();if(event.key==='Escape'){event.preventDefault();onClose();}}}>
    <header><strong>Add image</strong><button type="button" aria-label="Close image library" onClick={onClose}><X size={15}/></button></header>
    <form className="imageLibrary-search" onSubmit={event=>{event.preventDefault();void load(1);}}><Search size={15}/><input ref={input} aria-label="Search images" placeholder="Search for images…" value={query} onChange={event=>setQuery(event.target.value)}/>{query&&<button type="button" aria-label="Clear image search" onClick={()=>setQuery('')}><X size={12}/></button>}</form>
    <div className="imageLibrary-results" onScroll={event=>{const el=event.currentTarget;if(el.scrollHeight-el.scrollTop-el.clientHeight<120&&!current.current.busy&&current.current.result?.nextPage)void load(current.current.result.nextPage);}}>
      {result?.photos.length?<div className="imageLibrary-grid">{result.photos.map(photo=><figure key={photo.id}><button type="button" className="imageLibrary-photo" aria-label={`Add photo: ${photo.alt||photo.id}`} title={photo.alt||`Photo by ${photo.photographer}`} onClick={()=>onSelect(photo)} draggable onDragStart={event=>{event.dataTransfer.setData(LIBRARY_DRAG_TYPE,encodeLibraryPhoto(photo));event.dataTransfer.effectAllowed='copy';}}><img src={photo.thumbnail} alt={photo.alt} loading="lazy" draggable={false}/><ImagePlus size={16}/></button>{photo.photographer&&<figcaption><a href={photo.photographerUrl||photo.pageUrl} target="_blank" rel="noreferrer">{photo.photographer}</a></figcaption>}</figure>)}</div>:!busy&&!error&&<p className="imageLibrary-empty">No images found. Try a different search.</p>}
      {busy&&<div className="imageLibrary-loading" role="status"><LoaderCircle size={19}/><span>Loading images…</span></div>}
      {error&&<div className="imageLibrary-error" role="alert"><p>{error}</p><button type="button" onClick={()=>void load(result?.nextPage||1)}>Try again</button></div>}
      {!busy&&!error&&result?.nextPage&&<button type="button" className="imageLibrary-more" onClick={()=>void load(result.nextPage!)}>Load more</button>}
    </div>
    <footer><a href="https://www.pexels.com/" target="_blank" rel="noreferrer">Photos provided by Pexels</a><button type="button" onClick={onUpload}><Upload size={14}/>Upload your own</button></footer>
  </aside>;
}
