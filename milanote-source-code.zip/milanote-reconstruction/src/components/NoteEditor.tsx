import { forwardRef, useEffect, useImperativeHandle, useMemo, useRef } from "react";
import { EditorContent, useEditor } from "@tiptap/react";
import './note-blocks.css';
import { Node } from "@tiptap/core";
import type { Editor } from "@tiptap/core";
import StarterKit from "@tiptap/starter-kit";
import Link from "@tiptap/extension-link";
import TextAlign from "@tiptap/extension-text-align";
import Underline from "@tiptap/extension-underline";
import { FontSize, TextStyle } from "@tiptap/extension-text-style";
import Color from "@tiptap/extension-color";
import Highlight from "@tiptap/extension-highlight";
import { TextSelection } from "@tiptap/pm/state";
import type { EditorView } from "@tiptap/pm/view";
import {
  noteContentHtml,
  richHtmlToMarkdown,
  richHtmlToPlainText,
  safeNoteColor,
  safeCalloutIcon,
  safeNoteLink,
  sanitizeNoteHtml,
} from "../core/richText";

export type NoteEditorCommand =
  | "bold" | "italic" | "strike" | "underline"
  | "bulletList" | "orderedList" | "heading" | "paragraph"
  | "alignLeft" | "alignCenter" | "alignRight"
  | "code" | "codeBlock" | "blockquote" | "callout" | "calloutIcon" | "horizontalRule"
  | "link" | "unsetLink" | "undo" | "redo" | "selectAll"
  | "textColor" | "unsetTextColor" | "highlight" | "unsetHighlight" | "smallText";

export interface NoteEditorHandle {
  focus: () => void;
  run: (command: NoteEditorCommand, value?: string | number) => boolean;
  getHTML: () => string;
  getText: () => string;
  getMarkdown: () => string;
  isActive: (command: NoteEditorCommand, value?: string | number) => boolean;
}

export interface NoteEditorProps {
  text: string;
  html?: string;
  onChange: (value: { text: string; html: string; height: number }) => void;
  onBlur?: (event: FocusEvent) => void;
  onReady?: () => void;
  /** Open the host's link editor while retaining the current text selection. */
  onRequestLink?: () => void;
  autoFocus?: boolean;
  readOnly?: boolean;
  ariaLabel?: string;
}

// Keep Callout separate from Quote block in both the editing schema and saved
// HTML. The optional icon is a sanitized text grapheme, not arbitrary markup.
const Callout = Node.create({
  name: "callout",
  group: "block",
  content: "block+",
  defining: true,
  addAttributes:()=>({icon:{default:null,parseHTML:(element:HTMLElement)=>safeCalloutIcon(element.getAttribute('data-note-callout-icon'))??null,renderHTML:()=>({})}}),
  parseHTML: () => [{ tag: 'aside[data-note-callout="true"]' }],
  renderHTML: ({node}) => ["aside", { "data-note-callout": "true",...(safeCalloutIcon(node.attrs.icon)?{'data-note-callout-icon':node.attrs.icon}:{}) }, 0],
  addKeyboardShortcuts() {
    return { "Mod-Shift-6": () => {
      normalizeBlockSelection(this.editor);
      return this.editor.commands.toggleWrap("callout",{icon:'⚠️'});
    } };
  },
});

function normalizeBlockSelection(editor: Editor) {
  // Select All can include the wrapper's outer boundaries. Lift commands need
  // the selected inner blocks, otherwise an existing callout cannot be toggled
  // off even though all its visible text is selected.
  const { selection, doc } = editor.state;
  if (selection.$from.depth === 0 || selection.$to.depth === 0) {
    editor.commands.setTextSelection({ from: TextSelection.atStart(doc).anchor, to: TextSelection.atEnd(doc).head });
  }
}

function syncNativeSelection(view: EditorView) {
  const selection = view.dom.ownerDocument.getSelection();
  if (!selection?.anchorNode || !selection.focusNode || !view.dom.contains(selection.anchorNode) || !view.dom.contains(selection.focusNode)) return;
  try {
    const anchor = view.posAtDOM(selection.anchorNode, selection.anchorOffset);
    const head = view.posAtDOM(selection.focusNode, selection.focusOffset);
    if (anchor !== view.state.selection.anchor || head !== view.state.selection.head) {
      view.dispatch(view.state.tr.setSelection(TextSelection.create(view.state.doc, anchor, head)));
    }
  } catch {
    // A toolbar/modal can detach its previous DOM range between event turns.
    // In that case ProseMirror's saved selection remains the correct fallback.
  }
}

/** A persistent ProseMirror selection lets toolbar actions format the selected range. */
export const NoteEditor = forwardRef<NoteEditorHandle, NoteEditorProps>(function NoteEditor(
  { text, html, onChange, onBlur, onReady, onRequestLink, autoFocus = false, readOnly = false, ariaLabel = "Note text" },
  ref,
) {
  const callbacks = useRef({ onChange, onBlur, onReady, onRequestLink });
  callbacks.current = { onChange, onBlur, onReady, onRequestLink };
  const instanceRef = useRef<Editor | null>(null);
  const lastEmission = useRef("");
  const pendingEchoes = useRef<string[]>([]);
  const initialContent = useRef(noteContentHtml(text, html));
  function publish(richHtml: string, height: number) {
    const key = `${richHtml}\u0000${height}`;
    if (key === lastEmission.current) return;
    lastEmission.current = key;
    if (pendingEchoes.current.at(-1) !== richHtml) pendingEchoes.current.push(richHtml);
    if (pendingEchoes.current.length > 128) pendingEchoes.current.shift();
    callbacks.current.onChange({ text: richHtmlToPlainText(richHtml), html: richHtml, height });
  }
  // Parent document updates are frequent. Replacing editorProps/extensions on
  // every echo makes useEditor reconfigure its view while native selections
  // are changing. Event callbacks already read current props through refs.
  const options = useMemo(() => ({
    // The component is lazy-loaded inside Suspense. Creating an Editor during
    // a speculative render lets its teardown timer run before React commits
    // the effects (and StrictMode may replay those effects). Create it after
    // mount instead, so no effect can receive an already destroyed schema.
    immediatelyRender: false,
    extensions: [
      StarterKit.configure({ link: false, underline: false, trailingNode: false }),
      Callout,
      Link.configure({
        openOnClick: false,
        autolink: true,
        linkOnPaste: true,
        defaultProtocol: "https",
        protocols: ["http", "https"],
        isAllowedUri: (url) => !!safeNoteLink(url),
        HTMLAttributes: { target: "_blank", rel: "noopener noreferrer" },
      }),
      Underline,
      TextStyle,
      Color,
      FontSize,
      Highlight.configure({ multicolor: true }),
      TextAlign.configure({ types: ["heading", "paragraph"], alignments: ["left", "center", "right"] }),
    ],
    content: initialContent.current || "<p></p>",
    editable: !readOnly,
    autofocus: false,
    editorProps: {
      attributes: {
        class: "note-tiptap",
        role: "textbox",
        "aria-label": ariaLabel,
        "aria-multiline": "true",
        spellcheck: "true",
      },
      // Sanitizing before ProseMirror parses paste also protects future schema additions.
      transformPastedHTML: sanitizeNoteHtml,
      handleKeyDown: (view: EditorView, event: KeyboardEvent) => {
        const instance = instanceRef.current;
        if (!instance?.isEditable || event.isComposing) return false;
        if (event.key === "Tab" && !event.ctrlKey && !event.metaKey && !event.altKey) {
          syncNativeSelection(view);
          if (instance.isActive("listItem")) {
            return event.shiftKey ? instance.commands.liftListItem("listItem") : instance.commands.sinkListItem("listItem");
          }
        }
        if ((event.ctrlKey || event.metaKey) && !event.altKey) {
          const key = event.key.toLowerCase();
          const digit = /^Digit[0-9]$/.test(event.code) ? event.code.slice(-1) : key;
          const blockStyle = event.shiftKey ? ({ "1": 1, "2": 2, "0": 0, "9": 9 } as Record<string, number>)[digit] : undefined;
          if (blockStyle !== undefined) {
            syncNativeSelection(view);
            const chain = instance.chain();
            if (blockStyle === 0) return chain.unsetFontSize().setParagraph().run();
            if (blockStyle === 9) return instance.isActive("textStyle", { fontSize: "9.6px" }) ? chain.unsetFontSize().run() : chain.setFontSize("9.6px").run();
            return chain.unsetFontSize().toggleHeading({ level: blockStyle as 1 | 2 }).run();
          }
          if (event.shiftKey && ["u", "o", "x"].includes(key)) {
            syncNativeSelection(view);
            return key === "u" ? instance.commands.toggleBulletList() : key === "o" ? instance.commands.toggleOrderedList() : instance.commands.toggleStrike();
          }
          if (!event.shiftKey && key === "j") {
            syncNativeSelection(view);
            return instance.commands.toggleHighlight({ color: "#fff3bc" });
          }
          if (!event.shiftKey && key === "k" && callbacks.current.onRequestLink) {
            syncNativeSelection(view);
            callbacks.current.onRequestLink();
            return true;
          }
          if (key === ">" || (event.shiftKey && event.code === "Period")) {
            syncNativeSelection(view);
            return instance.commands.toggleCodeBlock();
          }
          if (["\"", "“", "”"].includes(key) || (event.shiftKey && event.code === "Quote")) {
            syncNativeSelection(view);
            normalizeBlockSelection(instance);
            return instance.commands.toggleBlockquote();
          }
          if (!event.shiftKey && (key === "\\" || event.code === "Backslash")) {
            syncNativeSelection(view);
            return instance.commands.setTextAlign("center");
          }
        }
        if ((event.ctrlKey || event.metaKey) && !event.altKey && (event.key === "Home" || event.key === "End")) {
          syncNativeSelection(view);
          const position = event.key === "Home" ? TextSelection.atStart(view.state.doc).anchor : TextSelection.atEnd(view.state.doc).head;
          const anchor = event.shiftKey ? view.state.selection.anchor : position;
          view.dispatch(view.state.tr.setSelection(TextSelection.create(view.state.doc, anchor, position)).scrollIntoView());
          return true;
        }
        // ProseMirror owns native arrow navigation and its selection observer.
        // Dispatching a selection transaction before every arrow races that
        // observer when inline marks split a text node between rapid keys.
        if ((event.ctrlKey || event.metaKey) && !event.altKey && /^[biu]$/i.test(event.key)) syncNativeSelection(view);
        return false;
      },
    },
    onUpdate: ({ editor: instance }: { editor: Editor }) => {
      const richHtml = sanitizeNoteHtml(instance.getHTML());
      const height = Math.ceil(instance.view.dom.scrollHeight);
      publish(richHtml, height);
    },
    onBlur: ({ event }: { event: FocusEvent }) => callbacks.current.onBlur?.(event),
  }), []);
  const editor = useEditor(options);
  instanceRef.current = editor;

  useEffect(() => {
    if (!editor || editor.isDestroyed) return;
    const next = noteContentHtml(text, html) || "<p></p>";
    const canonicalNext = sanitizeNoteHtml(next);
    const echo = pendingEchoes.current.lastIndexOf(canonicalNext);
    if (echo >= 0) {
      // React can commit an earlier echo after another local transaction. It
      // acknowledges that update; it must not overwrite the newer document.
      pendingEchoes.current.splice(0, echo + 1);
      return;
    }
    // A parent echo must not replace the document or reset its cursor/history.
    if (sanitizeNoteHtml(editor.getHTML()) !== canonicalNext) {
      pendingEchoes.current = [];
      editor.commands.setContent(next, { emitUpdate: false });
    }
  }, [editor, text, html]);

  useEffect(() => {
    if (editor && !editor.isDestroyed) editor.setEditable(!readOnly);
  }, [editor, readOnly]);

  useEffect(() => {
    if (!editor || editor.isDestroyed) return;
    editor.view.dom.setAttribute("aria-label", ariaLabel);
  }, [editor, ariaLabel]);

  useEffect(() => {
    if (!editor || editor.isDestroyed || typeof ResizeObserver === "undefined") return;
    const observer = new ResizeObserver(() => {
      if (editor.isDestroyed) return;
      const richHtml = sanitizeNoteHtml(editor.getHTML());
      const height = Math.ceil(editor.view.dom.scrollHeight);
      publish(richHtml, height);
    });
    observer.observe(editor.view.dom);
    return () => observer.disconnect();
  }, [editor]);

  useImperativeHandle(ref, () => ({
    focus: () => { if (editor && !editor.isDestroyed) editor.commands.focus(); },
    getHTML: () => sanitizeNoteHtml(editor && !editor.isDestroyed ? editor.getHTML() : initialContent.current),
    getText: () => richHtmlToPlainText(editor && !editor.isDestroyed ? editor.getHTML() : initialContent.current),
    getMarkdown: () => richHtmlToMarkdown(editor && !editor.isDestroyed ? editor.getHTML() : initialContent.current),
    isActive: (command, value) => {
      if (!editor || editor.isDestroyed) return false;
      if (command === "heading") return editor.isActive("heading", { level: Number(value) || 2 });
      if (command === "alignLeft") return editor.isActive({ textAlign: "left" });
      if (command === "alignCenter") return editor.isActive({ textAlign: "center" });
      if (command === "alignRight") return editor.isActive({ textAlign: "right" });
      if (command === "textColor") return editor.isActive("textStyle", value ? { color: String(value) } : undefined);
      if (command === "smallText") return editor.isActive("textStyle", { fontSize: "9.6px" });
      if (command === "highlight") return editor.isActive("highlight", value ? { color: String(value) } : undefined);
      if(command==='calloutIcon')return editor.isActive('callout',value?{icon:String(value)}:undefined);
      return editor.isActive(command === "unsetLink" ? "link" : command);
    },
    run: (command, value) => {
      if (!editor || editor.isDestroyed || !editor.isEditable) return false;
      if (command !== "undo" && command !== "redo" && command !== "selectAll") syncNativeSelection(editor.view);
      if (command === "callout" || command === "blockquote") normalizeBlockSelection(editor);
      const chain = editor.chain().focus();
      switch (command) {
        case "bold": return chain.toggleBold().run();
        case "italic": return chain.toggleItalic().run();
        case "strike": return chain.toggleStrike().run();
        case "underline": return chain.toggleUnderline().run();
        case "bulletList": return chain.toggleBulletList().run();
        case "orderedList": return chain.toggleOrderedList().run();
        case "heading": {
          const level = Number(value ?? 2);
          if (![1, 2, 3, 4, 5, 6].includes(level)) return false;
          return chain.unsetFontSize().toggleHeading({ level: level as 1 | 2 | 3 | 4 | 5 | 6 }).run();
        }
        case "paragraph": return chain.unsetFontSize().setParagraph().run();
        case "alignLeft": return chain.setTextAlign("left").run();
        case "alignCenter": return chain.setTextAlign("center").run();
        case "alignRight": return chain.setTextAlign("right").run();
        case "code": return chain.toggleCode().run();
        case "codeBlock": return chain.toggleCodeBlock().run();
        case "blockquote": return chain.toggleBlockquote().run();
        case "callout": return chain.toggleWrap("callout",{icon:'⚠️'}).run();
        case "calloutIcon": {
          const icon=safeCalloutIcon(value);if(!icon)return false;
          return editor.isActive('callout')?chain.updateAttributes('callout',{icon}).run():chain.wrapIn('callout',{icon}).run();
        }
        case "horizontalRule": return chain.setHorizontalRule().run();
        case "link": {
          const entered = String(value ?? "").trim();
          const href = safeNoteLink(/^[a-z][a-z\d+.-]*:/i.test(entered) ? entered : `https://${entered}`);
          return href ? chain.extendMarkRange("link").setLink({ href }).run() : false;
        }
        case "unsetLink": return chain.extendMarkRange("link").unsetLink().run();
        case "undo": return chain.undo().run();
        case "redo": return chain.redo().run();
        case "selectAll": return chain.selectAll().run();
        case "textColor": {
          const color = safeNoteColor(String(value ?? ""));
          return color ? chain.setColor(color).run() : false;
        }
        case "unsetTextColor": return chain.unsetColor().run();
        case "highlight": {
          const color = safeNoteColor(String(value ?? "#fff3bc"));
          return color ? chain.setHighlight({ color }).run() : false;
        }
        case "unsetHighlight": return chain.unsetHighlight().run();
        case "smallText": return editor.isActive("textStyle", { fontSize: "9.6px" })
          ? chain.unsetFontSize().run()
          : chain.setFontSize("9.6px").run();
      }
    },
  }), [editor]);

  useEffect(() => {
    if (!editor || editor.isDestroyed) return;
    let cancelled = false;
    // StrictMode replays initial effects. Notify only after its cleanup/setup and
    // the forwarded handle have settled, so a queued toolbar action runs once.
    queueMicrotask(() => {
      if (cancelled || editor.isDestroyed) return;
      // Never overwrite a selection the user placed while this effect was
      // pending. StrictMode must finish replaying the DOM before focus runs.
      if (autoFocus && editor.isEditable && !editor.view.hasFocus()) {
        editor.view.focus();
      }
      callbacks.current.onReady?.();
    });
    return () => { cancelled = true; };
  }, [editor]);

  return <EditorContent editor={editor} className="note-editor" />;
});
