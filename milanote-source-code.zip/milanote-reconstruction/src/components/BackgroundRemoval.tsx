import { useEffect,useRef,useState } from 'react';
import { Check,Download,LoaderCircle,RotateCcw,Scissors,X } from 'lucide-react';
import { removeImageBackground } from '../core/backgroundRemoval';
import type { BackgroundRemovalProgress } from '../core/backgroundRemoval';
import type { ImageEdits } from '../core/imageEditing';
import { ImagePreview } from './ImageEditor';
import './background-removal.css';

export interface BackgroundRemovalValue {cutoutSrc?:string;useCutout:boolean}
export interface BackgroundRemovalProps {
  src:string;
  cutoutSrc?:string;
  useCutout?:boolean;
  edits?:ImageEdits;
  onSave:(value:BackgroundRemovalValue)=>void;
  onCancel:()=>void;
  /** The reference can apply a finished cutout immediately; explicit Save remains available otherwise. */
  autoApply?:boolean;
}

export function BackgroundRemoval({src,cutoutSrc,useCutout=false,edits,onSave,onCancel,autoApply=false}:BackgroundRemovalProps){
  const [result,setResult]=useState(cutoutSrc),[enabled,setEnabled]=useState(useCutout&&!!cutoutSrc),[busy,setBusy]=useState(false),[error,setError]=useState('');
  const [progress,setProgress]=useState<BackgroundRemovalProgress>({stage:'loading-image',progress:0});
  const controller=useRef<AbortController|null>(null),dialog=useRef<HTMLDivElement>(null),priorFocus=useRef<HTMLElement|null>(null);
  useEffect(()=>{priorFocus.current=document.activeElement instanceof HTMLElement?document.activeElement:null;dialog.current?.focus();return()=>{controller.current?.abort();priorFocus.current?.focus({preventScroll:true});};},[]);
  function cancel(){controller.current?.abort();onCancel();}
  async function remove(){
    if(busy)return;setError('');
    if(result){setEnabled(true);if(autoApply)onSave({cutoutSrc:result,useCutout:true});return;}
    const abort=new AbortController();controller.current=abort;setBusy(true);
    try{
      const output=await removeImageBackground(src,{signal:abort.signal,onProgress:setProgress});
      if(abort.signal.aborted)return;setResult(output.src);setEnabled(true);if(autoApply)onSave({cutoutSrc:output.src,useCutout:true});
    }catch(exception){if(!abort.signal.aborted)setError(exception instanceof Error?exception.message:'The background could not be removed. Try again.');}
    finally{if(!abort.signal.aborted)setBusy(false);}
  }
  function restore(){setEnabled(false);if(autoApply)onSave({cutoutSrc:result,useCutout:false});}
  return <div className="cutout-backdrop" onPointerDown={event=>{if(event.target===event.currentTarget)cancel();}}>
    <div ref={dialog} className="cutout-dialog" role="dialog" aria-modal="true" aria-label="Remove image background" tabIndex={-1} onKeyDown={event=>{
      event.stopPropagation();if(event.key==='Escape'){event.preventDefault();cancel();}
      if(event.key==='Tab'){const fields=dialog.current?.querySelectorAll<HTMLElement>('button:not(:disabled),a[href]');if(!fields?.length)return;const first=fields[0],last=fields[fields.length-1];if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}
    }}>
      <header><strong>Cut out</strong><button type="button" aria-label="Close background removal" title="Close" onClick={cancel}><X size={18}/></button></header>
      <div className="cutout-preview"><ImagePreview src={enabled&&result?result:src} edits={edits} alt={enabled?'Image with background removed':'Original image'}/>{busy&&<div className="cutout-progress" role="status"><LoaderCircle size={23}/><span>Removing background…</span><progress aria-label="Background removal progress" max={1} value={progress.progress}/></div>}</div>
      {error&&<p className="cutout-error" role="alert">{error}</p>}
      <footer>
        {enabled?<button type="button" className="cutout-restore" disabled={busy} onClick={restore}><RotateCcw size={16}/>Restore original</button>:<button type="button" className="cutout-remove" disabled={busy} onClick={()=>void remove()}><Scissors size={16}/>Remove background</button>}
        {result&&enabled&&<a className="cutout-download" href={result} download="cutout.png"><Download size={16}/>Download</a>}
        <span/>
        <button type="button" className="cutout-cancel" onClick={cancel}>Cancel</button>
        {!autoApply&&<button type="button" className="cutout-save" disabled={busy||!result} onClick={()=>onSave({cutoutSrc:result,useCutout:enabled})}><Check size={16}/>Save changes</button>}
      </footer>
    </div>
  </div>;
}
