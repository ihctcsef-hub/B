import { lazy,Suspense,useEffect,useRef,useState } from 'react';
import type { CSSProperties,PointerEvent,ReactNode } from 'react';
import { ChevronDown,FileText,Folder,Minus,Plus,X } from 'lucide-react';
import type { Board,Card,Point } from '../core/model';
import type { WorkspaceLabel } from '../core/labels';
import { noteContentHtml } from '../core/richText';
import {evaluateTable,createFormulaWorkbook,reconcileFormulaWorkbook,formulaContextForTable} from '../core/spreadsheet';
import type {FormulaWorkbookContext} from '../core/spreadsheet';
import { displayColor,swatchInk } from '../core/colors';
import { drawingPathData } from '../core/drawing';
import { connectionBounds,connectionGeometry } from '../core/lines';
import { ImagePreview } from './ImageEditor';
import { LabelBadges } from './LabelManager';
import {FileCardView} from './FileCardView';
import {boardIconDisplaySource,selectedBoardIconId} from '../core/boardIcons';
import {LinkPreview} from './LinkPreview';
import {LinkInfo} from './LinkInfo';
import {fileDetailHeight,pdfPreviewHeight} from '../core/filePreview';
import './presentation.css';

export interface PresentationPreferences { hideComments:boolean; preventEditing:boolean; focusCards:boolean }
export interface PresentationProps {
  formulaWorkbook?:FormulaWorkbookContext;
  board:Board;
  labels?:WorkspaceLabel[];
  boards?:Record<string,Board>;
  onClose:()=>void;
  renderCard?:(card:Card,options:{readOnly:boolean})=>ReactNode;
  onCardDoubleClick?:(card:Card)=>void;
  onCardMove?:(id:string,point:Point)=>void;
  onCardChange?:(id:string,values:Partial<Card>)=>void;
}
type Viewport={x:number;y:number;zoom:number};
type Gesture={kind:'pan';from:Point;viewport:Viewport}|{kind:'card';id:string;from:Point;position:Point;moved:boolean};
const KEY='canvas-presentation-preferences-v1';
const defaults:PresentationPreferences={hideComments:false,preventEditing:false,focusCards:true};
const PresentationNoteEditor=lazy(()=>import('./NoteEditor').then(module=>({default:module.NoteEditor})));
function preferences():PresentationPreferences {
  try{const value=JSON.parse(localStorage.getItem(KEY)||'null');return value?{hideComments:typeof value.hideComments==='boolean'?value.hideComments:false,preventEditing:typeof value.preventEditing==='boolean'?value.preventEditing:false,focusCards:typeof value.focusCards==='boolean'?value.focusCards:true}:defaults;}catch{return defaults;}
}
const bound=(value:number,min:number,max:number)=>Math.max(min,Math.min(max,value));
const height=(card:Card)=>card.type==='column'&&card.collapsed?62.2:card.height;
function safeHref(value:string){try{const url=new URL(value,location.href);return ['http:','https:'].includes(url.protocol)?url.href:undefined;}catch{return undefined;}}
function visible(board:Board):Card[]{
  return board.cards.filter(card=>{
    if(card.unsorted)return false;
    const seen=new Set<string>();let parent=card.parentId;
    while(parent){if(seen.has(parent))return false;seen.add(parent);const owner=board.cards.find(item=>item.id===parent);if(!owner||owner.unsorted||owner.collapsed)return false;parent=owner.parentId;}
    return true;
  });
}
function boardBounds(cards:Card[],board:Board){
  const lines=board.connections.flatMap(line=>{const bounds=connectionBounds(line,cards,12);return bounds?[bounds]:[];});
  const left=Math.min(...cards.map(card=>card.x),...lines.map(line=>line.x));
  const top=Math.min(...cards.map(card=>card.y),...lines.map(line=>line.y));
  const right=Math.max(...cards.map(card=>card.x+card.width),...lines.map(line=>line.x+line.width));
  const bottom=Math.max(...cards.map(card=>card.y+height(card)),...lines.map(line=>line.y+line.height));
  return Number.isFinite(left)?{x:left,y:top,width:Math.max(1,right-left),height:Math.max(1,bottom-top)}:{x:0,y:0,width:800,height:500};
}

/** Presentation owns only view state; all editable document actions are explicit callbacks. */
export function Presentation({board,labels=[],boards,formulaWorkbook,onClose,renderCard,onCardDoubleClick,onCardMove,onCardChange}:PresentationProps){
  const [prefs,setPrefs]=useState(preferences);
  const [menu,setMenu]=useState(true);
  const [viewport,setViewport]=useState<Viewport>(()=>({...board.viewport}));
  const [focused,setFocused]=useState<string|null>(null);
  const [moves,setMoves]=useState<Record<string,Point>>({});
  const [editing,setEditing]=useState<string|null>(null);
  const stage=useRef<HTMLDivElement>(null),root=useRef<HTMLDivElement>(null),viewRef=useRef(viewport),gesture=useRef<Gesture|null>(null);
  const enteredFullscreen=useRef(false),skipClick=useRef(false);
  const [stageSize,setStageSize]=useState({width:window.innerWidth,height:Math.max(1,window.innerHeight-80)});
  const moveRef=useRef<Record<string,Point>>({});
  viewRef.current=viewport;
  const cards=visible(board).filter(card=>!prefs.hideComments||(card.type as string)!=='comment');
  const navigable=cards.filter(card=>card.type!=='column');
  const currentBoard=useRef(board);currentBoard.current=board;
  const closeRef=useRef(onClose);closeRef.current=onClose;
  function updatePrefs(next:Partial<PresentationPreferences>){setPrefs(value=>{const result={...value,...next};try{localStorage.setItem(KEY,JSON.stringify(result));}catch{/* View preferences remain usable when browser storage is unavailable. */}return result;});}
  function fit(card?:Card){
    const element=stage.current;if(!element)return;
    const bounds=card?{x:card.x,y:card.y,width:card.width,height:height(card)}:boardBounds(cards,board);
    const padding=card?70:55,availableWidth=Math.max(1,element.clientWidth-padding*2),availableHeight=Math.max(1,element.clientHeight-padding*2);
    const zoom=bound(Math.min(availableWidth/bounds.width,availableHeight/bounds.height),.1,card?3:1.25);
    setViewport({x:(element.clientWidth-bounds.width*zoom)/2-bounds.x*zoom,y:(element.clientHeight-bounds.height*zoom)/2-bounds.y*zoom,zoom});
  }
  function focus(card:Card){
    if(skipClick.current){skipClick.current=false;return;}
    if(!prefs.focusCards)return;
    setFocused(value=>value===card.id?null:card.id);setMenu(false);
  }
  function zoomTo(zoom:number){
    const element=stage.current;if(!element)return;zoom=bound(zoom,.1,3);
    const view=viewRef.current,cx=element.clientWidth/2,cy=element.clientHeight/2;
    setViewport({zoom,x:cx-(cx-view.x)/view.zoom*zoom,y:cy-(cy-view.y)/view.zoom*zoom});
  }
  useEffect(()=>{
    root.current?.focus();
    // Called from a user initiated Present action. Browsers may require a second
    // explicit gesture, in which case the Full screen control remains available.
    if(!document.fullscreenElement&&root.current?.requestFullscreen)root.current.requestFullscreen().then(()=>{enteredFullscreen.current=true;}).catch(()=>{});
    const exitedFullscreen=()=>{if(enteredFullscreen.current&&!document.fullscreenElement){enteredFullscreen.current=false;closeRef.current();}};
    document.addEventListener('fullscreenchange',exitedFullscreen);
    return()=>{document.removeEventListener('fullscreenchange',exitedFullscreen);if(enteredFullscreen.current&&document.fullscreenElement)document.exitFullscreen().catch(()=>{});};
  },[]);
  useEffect(()=>{
    const observer=new ResizeObserver(()=>{const element=stage.current;if(element)setStageSize({width:element.clientWidth,height:element.clientHeight});});
    if(stage.current)observer.observe(stage.current);return()=>observer.disconnect();
  },[]);
  useEffect(()=>{
    const key=(event:globalThis.KeyboardEvent)=>{
      if((event.target as HTMLElement)?.closest('input,textarea,select,[contenteditable=true]'))return;
      if(event.key==='Escape'){event.preventDefault();event.stopPropagation();closeRef.current();}
      else if(event.key.toLowerCase()==='z'||event.key==='0'){event.preventDefault();setFocused(null);fit();}
      else if((event.ctrlKey||event.metaKey)&&['+','=','-'].includes(event.key)){event.preventDefault();zoomTo(viewRef.current.zoom*(event.key==='-'?1/1.2:1.2));}
    };
    root.current?.addEventListener('keydown',key);return()=>root.current?.removeEventListener('keydown',key);
  },[focused,prefs.focusCards,board]);
  useEffect(()=>{
    const element=stage.current;if(!element)return;
    const wheel=(event:globalThis.WheelEvent)=>{event.preventDefault();if(event.ctrlKey||event.metaKey)zoomTo(viewRef.current.zoom*Math.exp(-event.deltaY*.002));else setViewport(view=>({...view,x:view.x-event.deltaX,y:view.y-event.deltaY}));};
    element.addEventListener('wheel',wheel,{passive:false});return()=>element.removeEventListener('wheel',wheel);
  },[]);
  function begin(event:PointerEvent<HTMLDivElement>,card?:Card){
    if(event.button!==0)return;
    if((event.target as HTMLElement).closest('input,textarea,select,button,a,audio,video,iframe,[contenteditable=true]'))return;
    event.preventDefault();event.stopPropagation();root.current?.focus();
    if(card&&!prefs.focusCards&&!prefs.preventEditing&&onCardMove&&!card.locked)gesture.current={kind:'card',id:card.id,from:{x:event.clientX,y:event.clientY},position:{x:card.x,y:card.y},moved:false};
    else if(!card)gesture.current={kind:'pan',from:{x:event.clientX,y:event.clientY},viewport:viewRef.current};
    if(gesture.current)event.currentTarget.setPointerCapture(event.pointerId);
  }
  function move(event:PointerEvent<HTMLDivElement>){
    const active=gesture.current;if(!active)return;
    const dx=event.clientX-active.from.x,dy=event.clientY-active.from.y;
    if(active.kind==='pan')setViewport({...active.viewport,x:active.viewport.x+dx,y:active.viewport.y+dy});
    else if(Math.hypot(dx,dy)>2){active.moved=true;const next={[active.id]:{x:active.position.x+dx/viewRef.current.zoom,y:active.position.y+dy/viewRef.current.zoom}};moveRef.current=next;setMoves(next);}
  }
  function end(){
    const active=gesture.current;gesture.current=null;
    if(active?.kind==='card'&&active.moved){const at=moveRef.current[active.id];if(at)onCardMove?.(active.id,at);skipClick.current=true;}
    moveRef.current={};setMoves({});
  }
  return <div ref={root} className="canvas-presentation" role="dialog" aria-modal="true" aria-label="Presentation mode" tabIndex={-1} onKeyDown={event=>event.stopPropagation()}>
    <header className="presentation-header"><div className="presentation-breadcrumb"><span className="presentation-home-icon">M</span><span>Home</span><span className="presentation-breadcrumb-slash">/</span><span className="presentation-board-chip"/>{board.title}</div><div className="presentation-board-heading"><strong>{board.title}</strong><button type="button" className="presentation-view" aria-expanded={menu} onClick={()=>setMenu(!menu)}>View<ChevronDown size={10}/></button></div></header>
    <div ref={stage} className="presentation-stage" style={{backgroundColor:board.background||'#ebedee',backgroundImage:'none',backgroundSize:`${8*viewport.zoom}px ${8*viewport.zoom}px`,backgroundPosition:`${viewport.x}px ${viewport.y}px`}} onPointerDown={event=>begin(event)} onPointerMove={move} onPointerUp={end} onPointerCancel={()=>{gesture.current=null;setMoves({});}} onClick={event=>{if(event.target===event.currentTarget)setMenu(false);}} >
      <div className="presentation-world" style={{transform:`translate(${viewport.x}px,${viewport.y}px) scale(${viewport.zoom})`}}>
        <svg className="presentation-lines" width="10000" height="10000"><defs><marker id="presentation-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="context-stroke"/></marker></defs>{board.connections.map(line=>{const geometry=connectionGeometry(line,cards);return geometry?<g key={line.id}><path d={geometry.path} fill="none" stroke={line.color} strokeWidth={line.width||1.6} strokeDasharray={line.style==='dashed'?'5 5':undefined} markerStart={line.startArrow?'url(#presentation-arrow)':undefined} markerEnd={line.endArrow!==false?'url(#presentation-arrow)':undefined}/>{line.label&&<text x={geometry.midpoint.x} y={geometry.midpoint.y-8} fill={line.color} textAnchor="middle" fontSize={11.2} paintOrder="stroke" stroke={board.background||'#ebedee'} strokeWidth={5}>{line.label}</text>}</g>:null;})}</svg>
        {[...cards].sort((a,b)=>a.type==='column'?-1:b.type==='column'?1:a.z-b.z).map(card=>{
          const moved=moves[card.id];return <div key={card.id} data-presentation-card={card.id} className={`presentation-card presentation-card-${card.type}`} style={{left:moved?.x??card.x,top:moved?.y??card.y,width:card.width,height:height(card),background:card.type==='label'?'transparent':card.color||undefined,paddingTop:card.stripColor?4:0,zIndex:card.type==='column'?0:card.z+1} as CSSProperties} onPointerDown={event=>begin(event,card)} onClick={event=>{event.stopPropagation();if(editing!==card.id)focus(card);}} onDoubleClick={event=>{event.stopPropagation();if(!prefs.focusCards&&!prefs.preventEditing){if(card.type==='note'&&onCardChange&&!card.locked)setEditing(card.id);else onCardDoubleClick?.(card);}}}>
            {card.stripColor&&<div className="card-top-strip" style={{background:card.stripColor}}/>}
            <div className="presentation-card-content">{editing===card.id&&card.type==='note'&&onCardChange&&!prefs.preventEditing?<div className="presentation-note-editor" onPointerDown={event=>event.stopPropagation()} onDoubleClick={event=>event.stopPropagation()}><Suspense fallback={<span>Loading editor…</span>}><PresentationNoteEditor text={card.text} html={card.html} autoFocus ariaLabel="Presentation note text" onChange={({text,html,height})=>onCardChange(card.id,{text,html,height:height+(card.stripColor?4:0)} as Partial<Card>)} onBlur={()=>setEditing(null)}/></Suspense></div>:renderCard?renderCard(card,{readOnly:prefs.preventEditing}):<PresentationCard card={card} board={board} boards={boards} formulaWorkbook={formulaWorkbook} canEditCaption={!prefs.focusCards&&!prefs.preventEditing&&!card.locked&&!!onCardChange} captionEditing={editing===`caption:${card.id}`} onCaptionEdit={()=>setEditing(`caption:${card.id}`)} onCaptionFinish={()=>setEditing(null)} onCaptionChange={({text,html,height:nextHeight})=>{if(!onCardChange)return;if(card.type==='image'){const captionHeight=Math.max(30,Math.min(600,nextHeight));onCardChange(card.id,{caption:text,captionHtml:html,captionHeight,height:card.height-(card.captionHeight||35)+captionHeight} as Partial<Card>);}else if(card.type==='link')onCardChange(card.id,{caption:text,captionHtml:html} as Partial<Card>);}} onTaskToggle={card.type==='todo'&&!prefs.focusCards&&!card.locked&&onCardChange?id=>onCardChange(card.id,{items:card.items.map(item=>item.id===id?{...item,done:!item.done}:item)} as Partial<Card>):undefined}/>}</div>
            <LabelBadges labels={labels} labelIds={card.labelIds} readOnly/>
          </div>;
        })}
      </div>
      {!cards.length&&!board.connections.length&&<div className="presentation-empty">This board is empty.</div>}
    </div>
    {focused&&(()=>{const card=cards.find(item=>item.id===focused);if(!card)return null;const scale=Math.max(.1,Math.min(2,(stageSize.width-80)/card.width,(stageSize.height-80)/height(card)));return <div className="presentation-focus-mask" aria-label="Focused card" onPointerDown={event=>event.stopPropagation()} onClick={()=>setFocused(null)}><div className={`presentation-focus-card presentation-card-${card.type}`} data-presentation-focus={card.id} style={{width:card.width*scale,height:height(card)*scale,background:card.color||'#fff'}} onClick={event=>event.stopPropagation()}><div className="presentation-focus-content" style={{width:card.width,height:height(card),paddingTop:card.stripColor?4:0,boxSizing:'border-box',transform:`scale(${scale})`,transformOrigin:'0 0'}}>{card.stripColor&&<div className="card-top-strip" style={{background:card.stripColor}}/>}<div className="presentation-card-content">{renderCard?renderCard(card,{readOnly:true}):<PresentationCard card={card} board={board} boards={boards} formulaWorkbook={formulaWorkbook}/>}</div><LabelBadges labels={labels} labelIds={card.labelIds} readOnly/></div></div></div>;})()}
    {menu&&<div className="presentation-menu" role="menu" aria-label="Presentation settings"><strong>Zoom</strong><p className="presentation-zoom-tip">Tip: hold ctrl and use mouse wheel to zoom</p><div className="presentation-zoom"><button type="button" title="Zoom out" aria-label="Presentation zoom out" onClick={()=>zoomTo(viewport.zoom/1.2)}><Minus size={14}/></button><input type="range" min={10} max={300} step={1} aria-label="Presentation zoom" value={Math.round(viewport.zoom*100)} onChange={event=>zoomTo(Number(event.target.value)/100)}/><button className="presentation-reset-zoom" type="button" title="Reset zoom to 100%" onClick={()=>zoomTo(1)}>{Math.round(viewport.zoom*100)}%</button><button type="button" title="Zoom in" aria-label="Presentation zoom in" onClick={()=>zoomTo(viewport.zoom*1.2)}><Plus size={14}/></button></div><button type="button" className="presentation-fit" role="menuitem" onClick={()=>{setFocused(null);fit();}}>Scale to fit</button><div className="presentation-menu-divider"/><strong>Presentation mode</strong><p>Go full-screen &amp; hide toolbar, dot grid etc.</p><button type="button" className="presentation-stop" role="menuitem" onClick={onClose}>Stop presenting <span>(Esc)</span></button><label><span>Focus on selected cards</span><input role="switch" aria-label="Focus on selected cards" type="checkbox" checked={prefs.focusCards} onChange={event=>{updatePrefs({focusCards:event.target.checked});setEditing(null);if(!event.target.checked)setFocused(null);}}/></label><label><span>Hide comments</span><input role="switch" aria-label="Hide comments" type="checkbox" checked={prefs.hideComments} onChange={event=>updatePrefs({hideComments:event.target.checked})}/></label><label><span>Prevent editing</span><input role="switch" aria-label="Prevent editing" type="checkbox" checked={prefs.preventEditing} onChange={event=>{updatePrefs({preventEditing:event.target.checked});if(event.target.checked)setEditing(null);}}/></label></div>}
  </div>;
}

interface PresentationCardProps {
  card:Card; board:Board; boards?:Record<string,Board>;formulaWorkbook?:FormulaWorkbookContext;
  canEditCaption?:boolean; captionEditing?:boolean;
  onCaptionEdit?:()=>void; onCaptionFinish?:()=>void;
  onCaptionChange?:(content:{text:string;html:string;height:number})=>void;
  onTaskToggle?:(id:string)=>void;
}
function PresentationCaption({text,html,label,editable,active,onEdit,onFinish,onChange}:{text:string;html?:string;label:string;editable?:boolean;active?:boolean;onEdit?:()=>void;onFinish?:()=>void;onChange?:PresentationCardProps['onCaptionChange']}){
  return <div className={`presentation-caption${active&&editable?' presentation-caption-editor':''}`} onDoubleClick={event=>{if(!editable)return;event.stopPropagation();onEdit?.();}} onPointerDown={event=>{if(editable)event.stopPropagation();}} onClick={event=>{if(active&&editable)event.stopPropagation();}} onKeyDown={event=>{if(active&&editable&&event.key==='Escape'){event.preventDefault();event.stopPropagation();onFinish?.();}}}>
    {active&&editable&&onChange?<Suspense fallback={<span>Loading editor…</span>}><PresentationNoteEditor text={text} html={html} ariaLabel={label} autoFocus onChange={onChange} onBlur={()=>onFinish?.()}/></Suspense>:<div dangerouslySetInnerHTML={{__html:noteContentHtml(text,html)}}/>}
  </div>;
}
/** The focused duplicate remains read-only. Editing callbacks are supplied only
 * for the interaction paths observed in the normal presentation canvas. */
export function PresentationCard({card,board,boards,formulaWorkbook,canEditCaption,captionEditing,onCaptionEdit,onCaptionFinish,onCaptionChange,onTaskToggle}:PresentationCardProps){
  const caption=(text:string,html:string|undefined,label:string)=><PresentationCaption text={text} html={html} label={label} editable={canEditCaption} active={captionEditing} onEdit={onCaptionEdit} onFinish={onCaptionFinish} onChange={onCaptionChange}/>;
  switch(card.type){
    case 'note':return <div className={`presentation-note${card.isDocument?' presentation-document':''}`} dir="auto" style={{textAlign:card.align||'start'}}>{card.isDocument&&<><FileText size={30}/><h2>{card.title||'Untitled document'}</h2></>}<div dangerouslySetInnerHTML={{__html:noteContentHtml(card.text,card.html)}}/></div>;
    case 'label':return <div className="presentation-label" dir="auto">{card.text}</div>;
    case 'column':return <div className="presentation-column-title"><strong>{card.title}</strong><small>{board.cards.filter(item=>item.parentId===card.id).length} cards</small></div>;
    case 'image':return <div className="presentation-image"><ImagePreview src={card.useCutout&&card.cutoutSrc?card.cutoutSrc:card.src} edits={card.imageEdits} alt={card.caption} style={{height:card.showCaption===false?'100%':`calc(100% - ${card.captionHeight||35}px)`}}/>{card.showCaption!==false&&caption(card.caption,card.captionHtml,'Presentation image caption')}</div>;
    case 'link':return <>{card.showPreview!==false&&card.previewSrc&&<LinkPreview className="presentation-link-preview" automatic={card.autoHeight===true} src={card.previewSrc}/>} {card.showInfo!==false&&<><LinkInfo url={card.url} title={card.title} description={card.description} className="presentation-link-info"/>{card.showCaption&&caption(card.caption||'',card.captionHtml,'Presentation link caption')}</>}</>;
    case 'board':{const target=boards?.[card.boardId];return <div className="presentation-board">{target?.icon?/^data:image\//.test(target.icon)?<img className="presentation-board-icon" data-board-icon-id={selectedBoardIconId(target.icon)} style={selectedBoardIconId(target.icon)?{width:28.796875,height:28.796875}:undefined} src={boardIconDisplaySource(target.icon)} alt="Board icon"/>:<span className="presentation-board-icon">{target.icon}</span>:<Folder size={32}/>}<strong>{target?.title||card.title}</strong><small>{boards&&!target?'Original board deleted':target?.isTemplate?'Template':card.isShortcut?'↗ Shortcut':'Board'}</small></div>;}
    case 'todo':return <div className="presentation-todo">{card.title&&<strong>{card.title}</strong>}{card.items.map(item=><div key={item.id} className={item.done?'presentation-task-done':''} style={{marginInlineStart:(item.indent||0)*18}}>{onTaskToggle?<button type="button" className="presentation-checkbox" role="checkbox" aria-checked={item.done} aria-label={`Complete task ${item.text}`} onClick={event=>{event.stopPropagation();onTaskToggle(item.id);}}>{item.done?'✓':''}</button>:<span className="presentation-checkbox">{item.done?'✓':''}</span>}<span>{item.text}{item.dueDate&&<small>{item.dueDate}{item.reminderTime?' · '+item.reminderTime:''}</small>}</span></div>)}</div>;
    case 'table':{const tables=board.cards.filter(item=>item.type==='table'),registry=formulaWorkbook?reconcileFormulaWorkbook(formulaWorkbook,tables):createFormulaWorkbook(tables);const rows=evaluateTable(card.rows,card.cellMeta,formulaContextForTable(registry,card.id,{errorDisplay:'blank'}));return <div className="presentation-table">{card.title&&<strong>{card.title}</strong>}<table>{card.columnWidths&&<colgroup>{card.columnWidths.map((value,index)=><col key={index} style={{width:value/card.columnWidths!.reduce((sum,item)=>sum+item,0)*100+'%'}}/>)}</colgroup>}<tbody>{rows.map((row,r)=><tr key={r}>{row.map((cell,c)=>{const style=card.cellMeta?.[`${r}:${c}`];return <td key={c} style={{background:style?.color,textAlign:style?.align,verticalAlign:style?.verticalAlign,fontWeight:style?.bold?700:400,fontStyle:style?.italic?'italic':'normal'}}>{cell}</td>;})}</tr>)}</tbody></table></div>;}
    case 'file':return <FileCardView file={card} readOnly previewHeight={card.autoHeight===true&&card.previewWidth&&card.previewHeight?pdfPreviewHeight(card.width,card.previewWidth,card.previewHeight):Math.max(6,card.height-fileDetailHeight(0,card))}/>;
    case 'swatch':return <div className="presentation-swatch"><div style={{background:card.value,color:swatchInk(card.value)}}>{card.showValue!==false&&displayColor(card.value,card.colorSpace)}</div>{card.showCaption!==false&&<span>{card.label}</span>}</div>;
    case 'sketch':return <svg className="presentation-sketch" viewBox={`0 0 ${card.width} ${card.height}`} style={{background:card.background||'#fff'}}>{card.paths.map((path,index)=><path key={index} d={drawingPathData(path.points)} fill="none" stroke={path.color} strokeWidth={path.width} strokeLinecap="round" strokeLinejoin="round"/>)}</svg>;
  }
}
