import {useEffect,useLayoutEffect,useRef,useState,useId} from 'react';
import type {CSSProperties} from 'react';
import {PdfPreview} from './PdfPreview';
import type {PdfThumbnail} from '../core/pdfPreview';
import {attachmentSizeLabel,filePreviewKind} from '../core/filePreview';
import {observedFileIconAsset} from '../core/fileIcons';
import {CaptionEditor} from './CaptionEditor';
import './file-card-view.css';

export interface FileCardData {
  name:string;
  mime:string;
  size:number;
  dataUrl?:string;
  sourceUrl?:string;
  poster?:string;
  showPreview?:boolean;
  showFileInfo?:boolean;
  showCaption?:boolean;
  caption?:string;
  captionHtml?:string;
  previewSrc?:string;
  previewDigest?:string;
  previewWidth?:number;
  previewHeight?:number;
  pageCount?:number;
  autoplay?:boolean;
  loop?:boolean;
}
export interface FileCardLayout { previewHeight:number;metadataHeight:number;captionHeight:number }
export interface FileCardViewProps {
  file:FileCardData;
  /** The host owns persistent card geometry and manual resize policy. */
  previewHeight?:number;
  editingName?:boolean;
  readOnly?:boolean;
  onRename?:(name:string)=>void;
  onRequestRename?:()=>void;
  onFinishRename?:()=>void;
  onCaptionChange?:(content:{text:string;html:string;height:number})=>void;
  onReady?:(info:PdfThumbnail)=>void;
  onError?:(message:string)=>void;
  onOpen?:()=>void;
  onLayout?:(layout:FileCardLayout)=>void;
}

function safePublicSource(source:string|undefined):string|undefined{
  if(!source)return;try{const url=new URL(source);return ['http:','https:'].includes(url.protocol)&&!url.username&&!url.password?url.href:undefined;}catch{return;}
}

/** Render only whitelisted visual path data; never interpret runtime markup. */
function FileGlyph({file}:{file:Pick<FileCardData,'name'|'mime'>}){
  const asset=observedFileIconAsset(file);
  if(asset)return <svg className={`file-card-glyph ${asset.id}`} viewBox={asset.viewBox} aria-hidden="true">{asset.paths.map((path,index)=><path key={index} d={path.d} fill={path.fill} fillRule={path.fillRule==='evenodd'?'evenodd':'nonzero'}/>)}</svg>;
  return <svg className="file-card-glyph" viewBox="0 0 32 40" aria-hidden="true">
    <path d="M1 1h21l9 9v29H1z" fill="#fff" stroke="#c9cdd3" strokeWidth="1.5" strokeLinejoin="round"/>
    <path d="M22 1v9h9" fill="#e8e9eb" stroke="#c9cdd3" strokeWidth="1.5" strokeLinejoin="round"/>
    <path d="M8 19h16M8 24h16M8 29h11" stroke="#a2a8b0" strokeWidth="1.5"/>
  </svg>;
}

/** Observed folded paper asset behind compact file glyphs. Its fixed SVG
 * filter/paths are local visual data; a unique ID prevents cross-card filters. */
function FilePaper(){
  const id=`file-paper-${useId().replace(/[^a-z\d_-]/gi,'')}`;
  return <svg className="file-card-paper" width="47" height="60" viewBox="0 0 47 60" aria-hidden="true">
    <defs><filter id={id} width="300%" height="300%" x="-100%" y="-87.5%" filterUnits="objectBoundingBox">
      <feOffset dy="2" in="SourceAlpha" result="offset1"/><feGaussianBlur in="offset1" result="blur1" stdDeviation="5"/><feColorMatrix in="blur1" result="matrix1" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 .05 0"/>
      <feOffset dy="1" in="SourceAlpha" result="offset2"/><feGaussianBlur in="offset2" result="blur2" stdDeviation="1.5"/><feColorMatrix in="blur2" result="matrix2" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 .15 0"/>
      <feMerge><feMergeNode in="matrix1"/><feMergeNode in="matrix2"/></feMerge>
    </filter></defs><g fill="none" fillRule="evenodd">
      <path fill="#fff" shapeRendering="crispEdges" d="M1 1h32l13 13v45H1z"/>
      <path filter={`url(#${id})`} shapeRendering="crispEdges" fill="#000" d="M33 1l13 13H33z"/>
      <path fill="#fdfdfd" shapeRendering="crispEdges" d="M33 1l13 13H33z"/>
      <path className="file-card-paper-selection" stroke="#323b4a" strokeWidth="2" d="M1 1h32l13 13v45H1z"/>
    </g></svg>;
}

export function FileCardView({file,previewHeight,editingName=false,readOnly=false,onRename,onRequestRename,onFinishRename,onCaptionChange,onReady,onError,onOpen,onLayout}:FileCardViewProps){
  const source=file.dataUrl||safePublicSource(file.sourceUrl);
  const kind=filePreviewKind(file),detail=!!source&&file.showPreview!==false&&(kind!=='icon'||!!file.previewSrc);
  const cachedThumbnail=file.previewSrc&&file.previewDigest&&file.previewWidth&&file.previewHeight&&file.pageCount?{imageDataUrl:file.previewSrc,sourceDigest:file.previewDigest,width:file.previewWidth,height:file.previewHeight,pageCount:file.pageCount}:undefined;
  const info=file.showFileInfo!==false,root=useRef<HTMLDivElement>(null),preview=useRef<HTMLDivElement>(null),metadata=useRef<HTMLDivElement>(null),caption=useRef<HTMLDivElement>(null);
  const callback=useRef(onLayout);callback.current=onLayout;
  const [draft,setDraft]=useState(file.name),cancelName=useRef(false);
  useEffect(()=>{if(!editingName){setDraft(file.name);cancelName.current=false;}},[file.name,editingName]);
  useLayoutEffect(()=>{
    const element=root.current;if(!element)return;
    const report=()=>{
      if(!element.isConnected)return;
      const width=element.getBoundingClientRect().width,logicalWidth=parseFloat(getComputedStyle(element).width);if(!width||!logicalWidth)return;
      const scale=width/logicalWidth,part=(node:HTMLElement|null)=>node?node.getBoundingClientRect().height/scale:0;
      callback.current?.({previewHeight:part(preview.current),metadataHeight:detail?part(metadata.current):part(element),captionHeight:part(caption.current)});
    };
    report();const observer=new ResizeObserver(report);observer.observe(element);for(const node of [preview.current,metadata.current,caption.current])if(node)observer.observe(node);
    return()=>observer.disconnect();
  },[detail,info,file.showCaption,file.name,previewHeight]);
  const name=editingName&&!readOnly?<input className="file-card-name-input" aria-label="File name" value={draft} autoFocus onPointerDown={event=>event.stopPropagation()}
    onChange={event=>setDraft(event.target.value)} onBlur={()=>{if(!cancelName.current)onRename?.(draft);cancelName.current=false;onFinishRename?.();}}
    onKeyDown={event=>{event.stopPropagation();if(event.key==='Enter'){event.preventDefault();event.currentTarget.blur();}else if(event.key==='Escape'){event.preventDefault();cancelName.current=true;setDraft(file.name);event.currentTarget.blur();}}}/>:<strong className="file-card-name" title={file.name} onDoubleClick={event=>{event.stopPropagation();if(!readOnly)onRequestRename?.();}}>{file.name||'File attachment'}</strong>;
  const frameStyle:CSSProperties|undefined=previewHeight===undefined?undefined:{height:previewHeight};
  return <div ref={root} className={`file-card-view ${detail?'file-detail-view':'file-icon-view'}`} data-file-preview-kind={kind}>
    {detail?<>
      <div ref={preview} className="file-card-preview" style={frameStyle}>
        {kind==='pdf'?<PdfPreview dataUrl={source!} name={file.name} cachedThumbnail={cachedThumbnail} onReady={onReady} onError={onError}/>:file.previewSrc?<img className="file-card-static-preview" src={file.previewSrc} alt={`${file.name||'File'} preview`} draggable={false}/>:kind==='video'?<video controls src={source} poster={file.poster} autoPlay={file.autoplay} loop={file.loop}/>:<audio controls src={source} autoPlay={file.autoplay} loop={file.loop}/>}
      </div>
      {info&&<><div ref={metadata} className="file-card-metadata">
        <div className="file-card-icon-container"><FileGlyph file={file}/></div>
        <div className="file-card-details"><div className="file-card-title-block">{name}</div><div className="file-card-secondary">
          <span><a href={source} download={file.name} onPointerDown={event=>event.stopPropagation()}>Download</a></span>
          <span> - {onOpen?<button type="button" onPointerDown={event=>event.stopPropagation()} onClick={onOpen}>Open</button>:<a href={source} target="_blank" rel="noopener noreferrer" onPointerDown={event=>event.stopPropagation()}>Open</a>}</span>
          <span> - {attachmentSizeLabel(file.size)}</span>
        </div></div>
      </div>{file.showCaption&&<div ref={caption} className="file-card-caption"><CaptionEditor text={file.caption||''} html={file.captionHtml} ariaLabel="File caption" readOnly={readOnly||!onCaptionChange} onChange={content=>onCaptionChange?.(content)}/></div>}</>}
    </>:<><div className="file-card-icon-large"><FilePaper/><FileGlyph file={file}/></div><div className="file-card-icon-details"><div className="file-card-icon-title">{name}</div><span className="file-card-icon-size">{attachmentSizeLabel(file.size)}</span></div></>}
  </div>;
}
