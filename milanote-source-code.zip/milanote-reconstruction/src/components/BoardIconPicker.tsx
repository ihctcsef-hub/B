import { useEffect,useRef,useState } from 'react';
import type { ChangeEvent } from 'react';
import { createPortal } from 'react-dom';
import {Search} from 'lucide-react';
import {BOARD_ICON_CHARACTERS,BOARD_ICON_DIGITS,boardIconCategory,boardIconPngUrl,boardIconSvgUrl,searchBoardIcons,selectedBoardIconId,withBoardIconIdentity} from '../core/boardIcons';
import type {BoardIconChoice} from '../core/boardIcons';
import './board-icon-picker.css';

export interface BoardIconPickerProps {
  value?:string;
  boardTitle?:string;
  onChange:(value:string)=>void;
  onClose:()=>void;
  anchor?:{left:number;top:number};
}
type Category='recommended'|'new'|'board'|'letters'|'upload';
function imageData(file:File):Promise<string>{return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onerror=()=>reject(new Error('Unable to read this image.'));reader.onload=()=>resolve(String(reader.result));reader.readAsDataURL(file);});}
function validateImage(src:string):Promise<void>{return new Promise((resolve,reject)=>{const image=new window.Image();image.onload=()=>image.naturalWidth&&image.naturalHeight?resolve():reject(new Error('Choose a valid image.'));image.onerror=()=>reject(new Error('Choose a valid image.'));image.src=src;});}
/** Observed visual assets and identities, plus a separate open icon collection. */
export function BoardIconPicker({value,boardTitle='New Board',onChange,onClose,anchor={left:60.5,top:80}}:BoardIconPickerProps){
  const root=useRef<HTMLDivElement>(null),upload=useRef<HTMLInputElement>(null),search=useRef<HTMLInputElement>(null);
  const close=useRef(onClose);close.current=onClose;
  const lifetime=useRef(0);
  const [category,setCategory]=useState<Category>('recommended'),[query,setQuery]=useState(''),[submittedQuery,setSubmittedQuery]=useState(''),[error,setError]=useState(''),[loading,setLoading]=useState(false);
  const position={left:Math.max(6,Math.min(anchor.left,window.innerWidth-462)),top:Math.max(6,Math.min(anchor.top,window.innerHeight-243))};
  const term=submittedQuery.trim().toLowerCase(),selected=selectedBoardIconId(value);
  const choices=term?searchBoardIcons(term):category==='recommended'||category==='new'||category==='board'?boardIconCategory(category,boardTitle):[];
  const characters=term?BOARD_ICON_CHARACTERS.filter(letter=>letter.toLowerCase()===term):category==='letters'?BOARD_ICON_CHARACTERS:category==='recommended'?BOARD_ICON_DIGITS:[];
  useEffect(()=>{
    const generation=++lifetime.current;
    const previous=document.activeElement;search.current?.focus({preventScroll:true});
    function outside(event:PointerEvent){if(event.target instanceof Element&&event.target.closest('[data-board-icon-trigger]'))return;if(!root.current?.contains(event.target as Node))close.current();}
    function key(event:KeyboardEvent){if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close.current();}}
    document.addEventListener('pointerdown',outside,true);document.addEventListener('keydown',key,true);
    return()=>{if(lifetime.current===generation)lifetime.current++;document.removeEventListener('pointerdown',outside,true);document.removeEventListener('keydown',key,true);if(previous instanceof HTMLElement&&previous.isConnected)previous.focus({preventScroll:true});};
  },[]);
  async function chooseIcon(choice:BoardIconChoice){
    const source=boardIconSvgUrl(choice.id,{color:'#323b4a'});if(!source)return;
    const generation=lifetime.current;setLoading(true);setError('');
    try{const image=new window.Image();await new Promise<void>((resolve,reject)=>{image.onload=()=>resolve();image.onerror=()=>reject(new Error('Unable to prepare this icon.'));image.src=source;});
      const canvas=document.createElement('canvas');canvas.width=160;canvas.height=160;const context=canvas.getContext('2d');if(!context)throw new Error('Unable to prepare this icon.');context.drawImage(image,0,0,160,160);if(lifetime.current!==generation)return;onChange(withBoardIconIdentity(canvas.toDataURL('image/png'),choice.id));
    }catch(problem){if(lifetime.current===generation)setError(problem instanceof Error?problem.message:'Unable to prepare this icon.');}finally{if(lifetime.current===generation)setLoading(false);}
  }
  async function uploadImage(event:ChangeEvent<HTMLInputElement>){
    const file=event.target.files?.[0];event.target.value='';if(!file)return;
    if(!file.type.startsWith('image/')){setError('Choose an image file.');return;}
    const generation=lifetime.current;setLoading(true);setError('');
    try{const src=await imageData(file);await validateImage(src);if(lifetime.current!==generation)return;onChange(src);}catch(problem){if(lifetime.current===generation)setError(problem instanceof Error?problem.message:'Unable to read this image.');}finally{if(lifetime.current===generation)setLoading(false);}
  }
  const changeCategory=(next:Category)=>{setCategory(next);setQuery('');setSubmittedQuery('');setError('');root.current?.querySelector('.board-icon-grid')?.scrollTo(0,0);};
  return createPortal(<div ref={root} className="board-icon-picker" role="dialog" aria-label="Choose board icon" style={position} aria-busy={loading} onPointerDown={event=>event.stopPropagation()} onKeyDown={event=>event.stopPropagation()}>
    <div className="board-icon-sidebar">
      <nav aria-label="Icon categories">{([['recommended','Recommended'],['new','New'],['board','Board'],['letters','Letters & numbers'],['upload','Upload an image']] as const).map(([id,label])=><button key={id} type="button" aria-pressed={category===id&&!term} disabled={loading} onClick={()=>changeCategory(id)}>{label}</button>)}</nav>
      <div className="board-icon-search"><input ref={search} placeholder="Search icons..." aria-label="Search icons" value={query} onChange={event=>{setQuery(event.target.value);setError('');}} onKeyDown={event=>{if(event.key==='Enter'){event.preventDefault();event.stopPropagation();setSubmittedQuery(query);root.current?.querySelector('.board-icon-grid')?.scrollTo(0,0);}}}/><Search size={10}/></div>
    </div>
    {category==='upload'&&!term?<div className="board-icon-upload"><div className="board-icon-upload-preview">{value?.startsWith('data:image/')&&<img src={value} alt="Current board icon"/>}</div><button type="button" disabled={loading} onClick={()=>upload.current?.click()}>Choose an image</button><p>Tip: 160 x160px works best.</p></div>:<div className="board-icon-grid" role="group" aria-label={term?'Matching icons':category==='letters'?'Letters and numbers':'Board icons'}>
      {(category!=='letters'||term)&&choices.map(choice=><button key={choice.id} type="button" title={choice.name} aria-label={`Icon ${choice.name}`} aria-pressed={selected===choice.id} disabled={loading} data-icon-id={choice.id} data-reference-known={choice.referenceKnown} onClick={()=>chooseIcon(choice)}><img src={boardIconSvgUrl(choice.id)} alt="" aria-hidden="true" draggable={false} onError={event=>{const fallback=boardIconPngUrl(choice.id);if(fallback&&event.currentTarget.getAttribute('src')!==fallback)event.currentTarget.src=fallback;}}/></button>)}
      {characters.map(letter=><button key={letter} type="button" className="board-icon-character" title={letter} aria-label={`Icon ${letter}`} aria-pressed={value===letter} disabled={loading} onClick={()=>onChange(letter)}>{letter}</button>)}
      {term&&!choices.length&&!characters.length&&<p className="board-icon-no-results">No icons found</p>}
    </div>}
    {error&&<div className="board-icon-error" role="alert">{error}</div>}
    {loading&&<div className="board-icon-loading" role="status">Loading image…</div>}
    <input ref={upload} type="file" accept="image/*" aria-label="Upload board icon image" hidden onChange={uploadImage}/>
  </div>,document.body);
}
