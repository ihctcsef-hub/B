import { forwardRef, useEffect, useId, useImperativeHandle, useMemo, useRef, useState } from "react";
import type { ClipboardEvent, CSSProperties, KeyboardEvent, PointerEvent } from "react";
import { createPortal } from "react-dom";
import { Check } from "lucide-react";
import { TableDatePicker } from './TableDatePicker';
import {
  cellAddress, cellKey, deleteTableColumn, deleteTableRow, evaluateTable, evaluateTableDetails,
  formatTableCell, insertTableColumn, insertTableRow, normalizeTableMeta,
  parseTableClipboard, pasteTableCells, relocateTableFormula, moveTableAxis, resizeTableGrid,
  TABLE_DATE_FORMATS,TABLE_TIME_FORMATS,
} from "../core/spreadsheet";
import type { TableCellMeta, TableCellMetaMap, TableCellType, TableData, TableSelection, TableEvaluationContext } from "../core/spreadsheet";
import "./table-editor.css";

export type TableAction =
  | "addRow" | "addColumn" | "deleteRow" | "deleteColumn"
  | "addRowAbove" | "addRowBelow" | "addColumnLeft" | "addColumnRight"
  | "setType" | "setColor" | "setAlign" | "setVerticalAlign" | "setBold" | "setItalic"
  | "setDecimals" | "setThousandsSeparator" | "setCurrency" | "setCurrencyDisplay" | "setAccounting" | "setDateFormat" | "setTimeFormat"
  | "edit" | "formula" | "clear" | "cut" | "copy" | "paste" | "pasteValues";

export interface TableEditorHandle {
  run: (action: TableAction, value?: string | boolean) => void;
  getSelection: () => TableSelection;
  focus: () => void;
}
export interface TableEditorProps {
  rows: string[][];
  meta?: TableCellMetaMap;
  onChange: (rows: string[][], meta: TableCellMetaMap, columnWidths?: number[]) => void;
  columnWidths?: number[];
  onColumnWidthsChange?: (widths: number[]) => void;
  onSelectionChange?: (selection: TableSelection) => void;
  autoFocus?: boolean;
  readOnly?: boolean;
  evaluationContext?:TableEvaluationContext;
}

interface Cell { row: number; column: number }
interface Editing extends Cell { value: string; select: boolean }
interface TableClipboard { text: string; rows: string[][]; display: string[][]; meta: TableCellMetaMap; sourceRow: number; sourceColumn: number; cut?: boolean }
let copiedCells: TableClipboard | null = null;
const bounds = (selection: TableSelection) => ({
  top: Math.min(selection.row, selection.endRow ?? selection.row),
  bottom: Math.max(selection.row, selection.endRow ?? selection.row),
  left: Math.min(selection.column, selection.endColumn ?? selection.column),
  right: Math.max(selection.column, selection.endColumn ?? selection.column),
});
const sameCell = (a: Cell, b: Cell) => a.row === b.row && a.column === b.column;
const clamp = (n: number, min: number, max: number) => Math.max(min, Math.min(max, n));
const toTsv = (rows: string[][]) => rows.map((row) => row.map((cell) => /[\t\r\n"]/g.test(cell)
  ? `"${cell.replace(/"/g, '""')}"` : cell).join("\t")).join("\n");

/** Raw formulas remain in the document; only the cell display is calculated. */
export const TableEditor = forwardRef<TableEditorHandle, TableEditorProps>(function TableEditor(
  { rows, meta = {}, onChange, onSelectionChange, columnWidths, onColumnWidthsChange, autoFocus = false, readOnly = false,evaluationContext }, ref,
) {
  const rootRef = useRef<HTMLDivElement>(null);
  const contextRef=useRef(evaluationContext);contextRef.current=evaluationContext;
  const evaluations=useMemo(()=>evaluateTableDetails(rows,meta,{...evaluationContext,errorDisplay:'blank'}),[rows,meta,evaluationContext?.workbook,evaluationContext?.tableId]);
  const errorTooltipId=useId(),errorTooltipTimer=useRef<ReturnType<typeof setTimeout>|null>(null);
  const [errorTooltip,setErrorTooltip]=useState<{message:string;left:number;top:number}|null>(null);
  function hideErrorTooltip(){if(errorTooltipTimer.current)clearTimeout(errorTooltipTimer.current);errorTooltipTimer.current=null;setErrorTooltip(null);}
  function showErrorTooltip(element:HTMLElement,message:string,immediate=false){
    hideErrorTooltip();const rect=element.getBoundingClientRect(),value={message,left:rect.left+rect.width/2,top:rect.bottom+7};
    if(immediate)setErrorTooltip(value);else errorTooltipTimer.current=setTimeout(()=>setErrorTooltip(value),500);
  }
  useEffect(()=>()=>{if(errorTooltipTimer.current)clearTimeout(errorTooltipTimer.current);},[]);
  useEffect(()=>{hideErrorTooltip();},[rows,meta,evaluationContext?.workbook,evaluationContext?.tableId]);
  const inputRef = useRef<HTMLInputElement>(null);
  const documentRef = useRef<TableData>({ rows, meta });
  documentRef.current = { rows, meta };
  const callbacks = useRef({ onChange, onSelectionChange, onColumnWidthsChange });
  callbacks.current = { onChange, onSelectionChange, onColumnWidthsChange };
  const [selection, setSelection] = useState<TableSelection>({ row: 0, column: 0 });
  const selectionRef = useRef(selection);
  const [hasSelection, setHasSelection] = useState(autoFocus);
  const [editing, setEditing] = useState<Editing | null>(null);
  const editingRef = useRef<Editing | null>(null);
  const [menu, setMenu] = useState<{ x: number; y: number } | null>(null);
  const [dateSession,setDateSession]=useState<(Cell&{value:string;hasTime:boolean;anchor:{left:number;top:number;width:number;height:number}})|null>(null);
  const dragging = useRef<Cell | null>(null);
  const columns = Math.max(1, ...rows.map((row) => row.length));
  const [previewWidths, setPreviewWidths] = useState<number[] | null>(null);
  const [axisDrop,setAxisDrop]=useState<{axis:'row'|'column';position:number}|null>(null);
  const [gridPreview,setGridPreview]=useState<{rowCount:number;columnCount:number;width:number;height:number}|null>(null);
  const resizeCleanup = useRef<(() => void) | null>(null);
  const widthRef = useRef(columnWidths);
  widthRef.current = columnWidths;
  const normalizedWidths = (count = columns) => Array.from({ length: count }, (_, index) => {
    const width = widthRef.current?.[index];
    return typeof width === "number" && Number.isFinite(width) ? clamp(width, 40, 2400) : (rootRef.current?.clientWidth || count * 90) / count;
  });
  const explicitWidths = previewWidths || (columnWidths?.length ? normalizedWidths() : null);

  function publish(next: TableData, nextWidths?: number[]) {
    const oldCount = Math.max(1, ...documentRef.current.rows.map(row => row.length));
    const nextCount = Math.max(1, ...next.rows.map(row => row.length));
    if (!nextWidths && columnWidths?.length && oldCount !== nextCount) {
      const currentWidths = normalizedWidths(oldCount);
      nextWidths = Array.from({ length: nextCount }, (_, index) => currentWidths[index] ?? 90);
    }
    documentRef.current = next;
    callbacks.current.onChange(next.rows, next.meta, nextWidths);
    return next;
  }
  function select(next: TableSelection, focus = true) {
    const current = documentRef.current.rows;
    const count = Math.max(1, ...current.map((row) => row.length));
    const value = {
      row: clamp(next.row, 0, Math.max(0, current.length - 1)),
      column: clamp(next.column, 0, count - 1),
      ...(next.endRow !== undefined ? { endRow: clamp(next.endRow, 0, Math.max(0, current.length - 1)) } : {}),
      ...(next.endColumn !== undefined ? { endColumn: clamp(next.endColumn, 0, count - 1) } : {}),
    };
    selectionRef.current = value;
    setSelection(value);
    setHasSelection(true);
    callbacks.current.onSelectionChange?.(value);
    if (focus) rootRef.current?.focus({ preventScroll: true });
  }
  function stopEditing(commit = true) {
    const active = editingRef.current;
    editingRef.current = null;
    setEditing(null);
    if (active && commit) {
      const current = documentRef.current;
      if (current.rows[active.row]?.[active.column] !== active.value) {
        const next = current.rows.map((row) => [...row]);
        if (next[active.row]) next[active.row][active.column] = active.value;
        return publish({ rows: next, meta: current.meta });
      }
    }
    return documentRef.current;
  }
  function beginEditing(cell = selectionRef.current, value?: string) {
    if (readOnly) return;
    stopEditing();
    select({ row: cell.row, column: cell.column }, false);
    if(value===undefined&&documentRef.current.meta[cellKey(cell.row,cell.column)]?.type==='date'){openDatePicker(cell);return;}
    const next = { row: cell.row, column: cell.column,
      value: value ?? documentRef.current.rows[cell.row]?.[cell.column] ?? "", select: value === undefined };
    editingRef.current = next;
    setEditing(next);
    setMenu(null);
  }
  function clearSelection() {
    if (readOnly) return;
    const current = stopEditing(), area = bounds(selectionRef.current);
    publish({ ...current, rows: current.rows.map((row, ri) => row.map((value, ci) =>
      ri >= area.top && ri <= area.bottom && ci >= area.left && ci <= area.right ? "" : value)) });
  }
  function clipboardSelection(): TableClipboard {
    const current = stopEditing(), area = bounds(selectionRef.current);
    const raw = current.rows.slice(area.top, area.bottom + 1).map((row) => row.slice(area.left, area.right + 1));
    const display = evaluateTable(current.rows, current.meta,{...contextRef.current,errorDisplay:'blank'}).slice(area.top, area.bottom + 1).map((row) => row.slice(area.left, area.right + 1));
    const cellMeta: TableCellMetaMap = {};
    for (let row = area.top; row <= area.bottom; row++) for (let column = area.left; column <= area.right; column++) {
      const value = current.meta[cellKey(row, column)];
      if (value) cellMeta[cellKey(row - area.top, column - area.left)] = { ...value };
    }
    return { text: toTsv(raw), rows: raw, display, meta: cellMeta, sourceRow: area.top, sourceColumn: area.left };
  }
  async function copy(cut = false, event?: ClipboardEvent<HTMLDivElement>) {
    const source = clipboardSelection();
    source.cut = cut;
    copiedCells = source;
    if (event) {
      event.preventDefault();
      event.clipboardData.setData("text/plain", source.text);
    } else {
      try { await navigator.clipboard.writeText(source.text); }
      catch {
        const field = document.createElement("textarea");
        field.value = source.text;
        field.style.cssText = "position:fixed;left:-9999px;top:0";
        document.body.append(field); field.select();
        document.execCommand("copy"); field.remove();
      }
    }
    if (cut) clearSelection();
    rootRef.current?.focus({ preventScroll: true });
  }
  function pasteText(text: string, valuesOnly = false) {
    if (readOnly || !text) return;
    const current = stopEditing(), selected = selectionRef.current;
    const source = copiedCells?.text === text ? copiedCells : null;
    const data = source ? (valuesOnly ? source.display : source.rows.map((row, ri) => row.map((value, ci) =>
      source.cut || source.meta[cellKey(ri, ci)]?.type === "text" ? value : relocateTableFormula(value, selected.row - source.sourceRow, selected.column - source.sourceColumn)))) : parseTableClipboard(text);
    const pasted = pasteTableCells(current.rows, current.meta, selected.row, selected.column, data);
    if (source && !valuesOnly) {
      for (let r = 0; r < data.length; r++) for (let c = 0; c < data[r].length; c++) {
        const key = cellKey(selected.row + r, selected.column + c);
        delete pasted.meta[key];
        const style = source.meta[cellKey(r, c)];
        if (style) pasted.meta[key] = { ...style };
      }
    }
    publish(pasted);
    select({ row: selected.row, column: selected.column,
      endRow: selected.row + data.length - 1,
      endColumn: selected.column + Math.max(1, ...data.map((row) => row.length)) - 1 });
  }
  async function paste(valuesOnly = false) {
    try { const text=await navigator.clipboard.readText(); pasteText(text || copiedCells?.text || "", valuesOnly); }
    catch { if (copiedCells) pasteText(copiedCells.text, valuesOnly); }
  }
  function structural(action: TableAction, value?: string | boolean) {
    if (readOnly) return;
    const current = stopEditing(), selected = selectionRef.current;
    let next: TableData = current, target = { row: selected.row, column: selected.column };
    switch (action) {
      case "addRowAbove": next = insertTableRow(current.rows, current.meta, selected.row); break;
      case "addRow": case "addRowBelow": {
        const index = value === "above" ? selected.row : selected.row + 1;
        next = insertTableRow(current.rows, current.meta, index); target.row = index; break;
      }
      case "addColumnLeft": next = insertTableColumn(current.rows, current.meta, selected.column); break;
      case "addColumn": case "addColumnRight": {
        const index = value === "left" ? selected.column : selected.column + 1;
        next = insertTableColumn(current.rows, current.meta, index); target.column = index; break;
      }
      case "deleteRow": next = deleteTableRow(current.rows, current.meta, selected.row); break;
      case "deleteColumn": next = deleteTableColumn(current.rows, current.meta, selected.column); break;
    }
    let nextWidths: number[] | undefined;
    if (columnWidths?.length) {
      const count = Math.max(1, ...current.rows.map(row => row.length));
      const afterCount = Math.max(1, ...next.rows.map(row => row.length));
      if (count !== afterCount) {
        nextWidths = normalizedWidths(count);
        if (afterCount < count) nextWidths.splice(selected.column, 1);
        else nextWidths.splice(action === "addColumnLeft" || value === "left" ? selected.column : selected.column + 1, 0, nextWidths[selected.column] || 90);
      }
    }
    publish(next, nextWidths); select(target);
  }
  function run(action: TableAction, value?: string | boolean) {
    setMenu(null);
    if (["addRow", "addColumn", "addRowAbove", "addRowBelow", "addColumnLeft", "addColumnRight", "deleteRow", "deleteColumn"].includes(action)) {
      structural(action, value); return;
    }
    if (action === "copy" || action === "cut") { void copy(action === "cut"); return; }
    if (action === "paste" || action === "pasteValues") { void paste(action === "pasteValues"); return; }
    if (action === "clear") { clearSelection(); rootRef.current?.focus(); return; }
    if (action === "edit" || action === "formula") {
      beginEditing(selectionRef.current, action === "formula" ? (typeof value === "string" ? value : "=") : undefined); return;
    }
    if (readOnly) return;
    const current = stopEditing(), area = bounds(selectionRef.current);
    const next = { ...current.meta };
    const first = current.meta[cellKey(selectionRef.current.row, selectionRef.current.column)] || {};
    for (let row = area.top; row <= area.bottom; row++) for (let column = area.left; column <= area.right; column++) {
      const key = cellKey(row, column), style: TableCellMeta = { ...next[key] };
      if (action === "setType" && ["auto", "number", "currency", "percentage", "text", "date", "checkbox"].includes(String(value))) style.type = value as TableCellType;
      if (action === "setColor") { if (typeof value === "string" && /^#[\da-f]{3}(?:[\da-f]{3})?$/i.test(value)) style.color = value; else delete style.color; }
      if (action === "setAlign" && ["left", "center", "right"].includes(String(value))) style.align = value as TableCellMeta["align"];
      if (action === "setVerticalAlign" && ["top", "middle", "bottom"].includes(String(value))) style.verticalAlign = value as TableCellMeta["verticalAlign"];
      if (action === "setBold") style.bold = typeof value === "boolean" ? value : !first.bold;
      if (action === "setItalic") style.italic = typeof value === "boolean" ? value : !first.italic;
      if (action === 'setDecimals') {if(value===''||value===undefined)delete style.decimals;else if(Number.isInteger(Number(value))&&Number(value)>=0&&Number(value)<=10)style.decimals=Number(value);}
      if (action === 'setThousandsSeparator') style.thousandsSeparator=typeof value==='boolean'?value:!first.thousandsSeparator;
      if (action === 'setCurrency'&&typeof value==='string'&&/^[A-Z]{3}$/.test(value))style.currency=value;
      if (action === 'setCurrencyDisplay'&&['symbol','code','name'].includes(String(value)))style.currencyDisplay=value as TableCellMeta['currencyDisplay'];
      if (action === 'setAccounting')style.accounting=typeof value==='boolean'?value:!first.accounting;
      if (action === 'setDateFormat'&&TABLE_DATE_FORMATS.includes(value as TableCellMeta['dateFormat']&string))style.dateFormat=value as TableCellMeta['dateFormat'];
      if (action === 'setTimeFormat'&&TABLE_TIME_FORMATS.includes(value as TableCellMeta['timeFormat']&string))style.timeFormat=value as TableCellMeta['timeFormat'];
      next[key] = style;
    }
    publish({ rows: current.rows, meta: normalizeTableMeta(next, current.rows) });
    if(action==='setType'&&value==='date')openDatePicker(selectionRef.current);
    setHasSelection(true); rootRef.current?.focus({ preventScroll: true });
  }
  useImperativeHandle(ref, () => ({ run, getSelection: () => ({ ...selectionRef.current }), focus: () => rootRef.current?.focus() }));

  useEffect(() => {
    if (autoFocus) { rootRef.current?.focus(); callbacks.current.onSelectionChange?.(selectionRef.current); }
  }, [autoFocus]);
  useEffect(() => {
    if (!editing) return;
    inputRef.current?.focus({ preventScroll: true });
    if (editing.select) inputRef.current?.select();
    else inputRef.current?.setSelectionRange(editing.value.length, editing.value.length);
  }, [editing?.row, editing?.column, !!editing]);
  useEffect(() => {
    const end = () => { dragging.current = null; };
    window.addEventListener("pointerup", end);
    return () => window.removeEventListener("pointerup", end);
  }, []);
  useEffect(() => () => resizeCleanup.current?.(), []);
  useEffect(() => {
    if (!menu) return;
    const dismiss = () => setMenu(null);
    window.addEventListener("pointerdown", dismiss);
    window.addEventListener("resize", dismiss);
    window.addEventListener("scroll", dismiss, true);
    return () => { window.removeEventListener("pointerdown", dismiss); window.removeEventListener("resize", dismiss); window.removeEventListener("scroll", dismiss, true); };
  }, [menu]);

  function resizeColumn(event: PointerEvent<HTMLSpanElement>, index: number) {
    if (readOnly || !callbacks.current.onColumnWidthsChange || event.button !== 0) return;
    event.preventDefault(); event.stopPropagation(); stopEditing();
    resizeCleanup.current?.();
    const original = normalizedWidths(), firstX = event.clientX, pointerId = event.pointerId;
    const table = rootRef.current?.querySelector<HTMLTableElement>("table");
    const scale = table && table.offsetWidth ? table.getBoundingClientRect().width / table.offsetWidth : 1;
    let next = original;
    let changed = false;
    const target = event.currentTarget;
    try { target.setPointerCapture(pointerId); } catch { /* Window listeners cover detached handles. */ }
    function move(event: globalThis.PointerEvent) {
      if (event.pointerId !== pointerId) return;
      event.preventDefault(); event.stopPropagation();
      const width = Math.round(clamp(original[index] + (event.clientX - firstX) / scale, 40, 2400) * 10) / 10;
      next = original.map((value, column) => column === index ? width : value);
      changed = Math.abs(width - original[index]) > 0.1;
      setPreviewWidths(next);
    }
    function end(event: globalThis.PointerEvent) {
      if (event.pointerId !== pointerId) return;
      event.preventDefault(); event.stopPropagation(); cleanup();
      if (changed) callbacks.current.onColumnWidthsChange?.(next);
      setPreviewWidths(null);
    }
    function cancel(event: globalThis.PointerEvent | globalThis.KeyboardEvent) {
      if (event instanceof globalThis.KeyboardEvent ? event.key !== "Escape" : event.pointerId !== pointerId) return;
      event.preventDefault(); event.stopPropagation(); cleanup(); setPreviewWidths(null);
    }
    function cleanup() {
      window.removeEventListener("pointermove", move, true); window.removeEventListener("pointerup", end, true);
      window.removeEventListener("pointercancel", cancel, true); window.removeEventListener("keydown", cancel, true);
      try { if (target.hasPointerCapture(pointerId)) target.releasePointerCapture(pointerId); } catch { /* Unmounted handle. */ }
      resizeCleanup.current = null;
    }
    resizeCleanup.current = cleanup;
    window.addEventListener("pointermove", move, { capture: true, passive: false }); window.addEventListener("pointerup", end, true);
    window.addEventListener("pointercancel", cancel, true); window.addEventListener("keydown", cancel, true);
  }

  function resizeByKeyboard(event: KeyboardEvent<HTMLSpanElement>, index: number) {
    if (!["ArrowLeft", "ArrowRight"].includes(event.key) || readOnly || !callbacks.current.onColumnWidthsChange) return;
    event.preventDefault(); event.stopPropagation();
    const widths = normalizedWidths(), step = event.shiftKey ? 10 : 1;
    widths[index] = clamp(widths[index] + (event.key === "ArrowRight" ? step : -step), 40, 2400);
    callbacks.current.onColumnWidthsChange(widths);
  }

  function dragHeader(event:PointerEvent<HTMLDivElement>,axis:'row'|'column',index:number){
    if(event.button!==0)return;
    event.preventDefault();event.stopPropagation();
    const before=bounds(selectionRef.current),canMove=axis==='column'
      ?before.left===index&&before.right===index&&before.top===0&&before.bottom===rows.length-1
      :before.top===index&&before.bottom===index&&before.left===0&&before.right===columns-1;
    const current=stopEditing();
    select(axis==='column'?{row:0,column:index,endRow:rows.length-1}:{row:index,column:0,endColumn:columns-1});
    if(readOnly)return;
    resizeCleanup.current?.();
    const root=rootRef.current!,rect=root.getBoundingClientRect(),scale=rect.width/root.offsetWidth||1,originalWidths=normalizedWidths(),pointerId=event.pointerId;
    const sizes=axis==='column'?originalWidths:rows.map((_,i)=>i===0||i===rows.length-1?23:24),boundaries=[0];
    sizes.forEach(size=>boundaries.push(boundaries[boundaries.length-1]+size));
    let target=index,moved=false,drop=false;
    const origin=axis==='column'?event.clientX:event.clientY;
    function move(event:globalThis.PointerEvent){
      if(event.pointerId!==pointerId)return;
      event.preventDefault();event.stopPropagation();
      const position=((axis==='column'?event.clientX-rect.left:event.clientY-rect.top))/scale;
      moved ||= Math.abs((axis==='column'?event.clientX:event.clientY)-origin)>4;
      if(!moved)return;
      const nearest=boundaries.reduce((best,value,i)=>Math.abs(value-position)<Math.abs(boundaries[best]-position)?i:best,0);
      const over=Math.max(0,Math.min(sizes.length-1,boundaries.findIndex((value,i)=>i>0&&position<value)-1));
      drop=canMove&&Math.abs(boundaries[nearest]-position)<=8;
      if(drop){target=Math.max(0,Math.min(sizes.length-1,nearest>index?nearest-1:nearest));setAxisDrop({axis,position:boundaries[nearest]});}
      else {setAxisDrop(null);select(axis==='column'?{row:0,column:index,endRow:rows.length-1,endColumn:over}:{row:index,column:0,endRow:over,endColumn:columns-1},false);}
    }
    function end(event:globalThis.PointerEvent){
      if(event.pointerId!==pointerId)return;
      event.preventDefault();event.stopPropagation();cleanup();
      if(moved&&drop&&target!==index){
        const next=moveTableAxis(current.rows,current.meta,axis,index,target);
        let widths:number[]|undefined;
        if(axis==='column'){widths=[...originalWidths];widths.splice(target,0,...widths.splice(index,1));}
        publish(next,widths);select(axis==='column'?{row:0,column:target,endRow:current.rows.length-1}:{row:target,column:0,endColumn:columns-1});
      }
    }
    function cancel(event:globalThis.PointerEvent|globalThis.KeyboardEvent){if(event instanceof globalThis.KeyboardEvent?event.key!=='Escape':event.pointerId!==pointerId)return;event.preventDefault();event.stopPropagation();cleanup();}
    function cleanup(){window.removeEventListener('pointermove',move,true);window.removeEventListener('pointerup',end,true);window.removeEventListener('pointercancel',cancel,true);window.removeEventListener('keydown',cancel,true);setAxisDrop(null);resizeCleanup.current=null;}
    resizeCleanup.current=cleanup;window.addEventListener('pointermove',move,{capture:true,passive:false});window.addEventListener('pointerup',end,true);window.addEventListener('pointercancel',cancel,true);window.addEventListener('keydown',cancel,true);
  }

  function resizeGrid(event:PointerEvent<HTMLSpanElement>){
    if(readOnly||event.button!==0)return;
    event.preventDefault();event.stopPropagation();
    const current=stopEditing(),originalWidths=normalizedWidths(),rowCount=current.rows.length,columnCount=originalWidths.length;
    const table=rootRef.current?.querySelector('table');if(!table)return;
    const rect=table.getBoundingClientRect(),scale=rect.width/table.offsetWidth||1,firstX=event.clientX,firstY=event.clientY,pointerId=event.pointerId;
    const extraWidth=originalWidths[originalWidths.length-1]||90;
    let nextRows=rowCount,nextColumns=columnCount,widths=originalWidths;
    resizeCleanup.current?.();
    function move(event:globalThis.PointerEvent){
      if(event.pointerId!==pointerId)return;
      event.preventDefault();event.stopPropagation();
      nextRows=clamp(rowCount+Math.round((event.clientY-firstY)/scale/24),1,1000);
      nextColumns=clamp(columnCount+Math.round((event.clientX-firstX)/scale/extraWidth),1,100);
      widths=Array.from({length:nextColumns},(_,index)=>originalWidths[index]||extraWidth);
      setGridPreview({rowCount:nextRows,columnCount:nextColumns,width:widths.reduce((sum,width)=>sum+width,0),height:nextRows*24-2});
    }
    function end(event:globalThis.PointerEvent){if(event.pointerId!==pointerId)return;event.preventDefault();event.stopPropagation();cleanup();if(nextRows!==rowCount||nextColumns!==columnCount){publish(resizeTableGrid(current.rows,current.meta,nextRows,nextColumns),widths);select(selectionRef.current);}}
    function cancel(event:globalThis.PointerEvent|globalThis.KeyboardEvent){if(event instanceof globalThis.KeyboardEvent?event.key!=='Escape':event.pointerId!==pointerId)return;event.preventDefault();event.stopPropagation();cleanup();}
    function cleanup(){window.removeEventListener('pointermove',move,true);window.removeEventListener('pointerup',end,true);window.removeEventListener('pointercancel',cancel,true);window.removeEventListener('keydown',cancel,true);setGridPreview(null);resizeCleanup.current=null;}
    resizeCleanup.current=cleanup;window.addEventListener('pointermove',move,{capture:true,passive:false});window.addEventListener('pointerup',end,true);window.addEventListener('pointercancel',cancel,true);window.addEventListener('keydown',cancel,true);
  }

  function navigate(dr: number, dc: number, extend = false, wrap = false) {
    const current = stopEditing(), from = selectionRef.current;
    const count = Math.max(1, ...current.rows.map((row) => row.length));
    let row = extend ? from.endRow ?? from.row : from.row;
    let column = extend ? from.endColumn ?? from.column : from.column;
    row += dr; column += dc;
    if (wrap && column >= count) { column = 0; row++; }
    if (wrap && column < 0) { column = count - 1; row--; }
    if (row >= current.rows.length && !readOnly) publish(insertTableRow(current.rows, current.meta, current.rows.length));
    select(extend ? { ...from, endRow: row, endColumn: column } : { row, column });
  }
  function keyDown(event: KeyboardEvent<HTMLDivElement>) {
    event.stopPropagation();
    const modifier = event.metaKey || event.ctrlKey;
    if (menu && event.key === "Escape") { event.preventDefault(); setMenu(null); return; }
    if (modifier && event.key.toLowerCase() === "a" && !editingRef.current) {
      event.preventDefault(); select({ row: 0, column: 0, endRow: rows.length - 1, endColumn: columns - 1 }); return;
    }
    // WebKit does not emit a native copy/cut event for a focused grid whose
    // selection is represented by cells rather than a DOM text selection.
    if (modifier && !editingRef.current && ["c", "x"].includes(event.key.toLowerCase())) {
      event.preventDefault();
      if (event.key.toLowerCase() === "c" || !readOnly) void copy(event.key.toLowerCase() === "x");
      return;
    }
    if (modifier && (event.key.toLowerCase() === "b" || event.key.toLowerCase() === "i")) {
      event.preventDefault(); run(event.key.toLowerCase() === "b" ? "setBold" : "setItalic"); return;
    }
    if (event.key === "Escape") { event.preventDefault(); stopEditing(false); rootRef.current?.focus(); return; }
    if (event.key === "Tab") { event.preventDefault(); navigate(0, event.shiftKey ? -1 : 1, false, true); return; }
    if (event.key === "Enter") {
      event.preventDefault();
      if (!editingRef.current && !readOnly) beginEditing(); else navigate(event.shiftKey ? -1 : 1, 0);
      return;
    }
    if (editingRef.current) {
      if (event.key === "ArrowDown" || event.key === "ArrowUp") { event.preventDefault(); navigate(event.key === "ArrowDown" ? 1 : -1, 0); }
      return;
    }
    if (event.altKey && event.key.startsWith("Arrow") && !readOnly) { event.preventDefault(); run(event.key==="ArrowUp"?"addRowAbove":event.key==="ArrowDown"?"addRowBelow":event.key==="ArrowLeft"?"addColumnLeft":"addColumnRight"); return; }
    if (event.key.startsWith("Arrow")) {
      event.preventDefault(); navigate(event.key === "ArrowDown" ? 1 : event.key === "ArrowUp" ? -1 : 0,
        event.key === "ArrowRight" ? 1 : event.key === "ArrowLeft" ? -1 : 0, event.shiftKey); return;
    }
    if (event.key === "Backspace" || event.key === "Delete") { event.preventDefault(); clearSelection(); return; }
    if (event.key === "F2") { event.preventDefault(); beginEditing(); return; }
    if (event.key === " " && meta[cellKey(selection.row, selection.column)]?.type === "checkbox") {
      event.preventDefault(); toggleCheckbox(selection); return;
    }
    if (!modifier && !event.altKey && event.key.length === 1 && !readOnly) { event.preventDefault(); beginEditing(selectionRef.current, event.key); }
  }
  function pointerDown(event: PointerEvent<HTMLTableCellElement>, cell: Cell) {
    event.stopPropagation();
    if (event.button !== 0 || event.target instanceof HTMLInputElement) return;
    event.preventDefault();
    stopEditing(); setMenu(null);
    const anchor = event.shiftKey ? selectionRef.current : cell;
    select(event.shiftKey ? { ...anchor, endRow: cell.row, endColumn: cell.column } : cell);
    dragging.current = { row: anchor.row, column: anchor.column };
  }
  function toggleCheckbox(cell: Cell) {
    if (readOnly) return;
    const current = stopEditing(), next = current.rows.map((row) => [...row]);
    next[cell.row][cell.column] = /^(?:true|1|yes|checked)$/i.test(next[cell.row][cell.column]) ? "false" : "true";
    publish({ rows: next, meta: current.meta }); select(cell);
  }
  function openDatePicker(cell:Cell){
    const element=rootRef.current?.querySelector<HTMLElement>(`[data-cell="${cellAddress(cell.row,cell.column)}"]`),rect=element?.getBoundingClientRect();
    if(!rect)return;
    const current=documentRef.current,style=current.meta[cellKey(cell.row,cell.column)];
    setDateSession({...cell,value:current.rows[cell.row]?.[cell.column]||'',hasTime:!!style?.timeFormat&&style.timeFormat!=='none',anchor:{left:rect.left,top:rect.top,width:rect.width,height:rect.height}});
  }
  function saveDate(value:string,hasTime:boolean){
    const session=dateSession;if(!session)return;
    const current=documentRef.current,next=current.rows.map(row=>[...row]),key=cellKey(session.row,session.column),style={...current.meta[key],type:'date' as const,timeFormat:hasTime?(current.meta[key]?.timeFormat&&current.meta[key]?.timeFormat!=='none'?current.meta[key]!.timeFormat:'twelveHour' as const):'none' as const};
    if(next[session.row])next[session.row][session.column]=value;
    if(current.rows[session.row]?.[session.column]!==value||JSON.stringify(current.meta[key])!==JSON.stringify(style))publish({rows:next,meta:{...current.meta,[key]:style}});
    setDateSession(null);
  }
  const area = bounds(selection);
  const contextItems: Array<{ label?: string; action?: TableAction; shortcut?: string; disabled?: boolean }> = [
    { label: "Cut", action: "cut", shortcut: "⌘X", disabled: readOnly }, { label: "Copy", action: "copy", shortcut: "⌘C" },
    { label: "Paste", action: "paste", shortcut: "⌘V", disabled: readOnly }, { label: "Paste Values", action: "pasteValues", disabled: readOnly }, {},
    { label: "Add Row Above", action: "addRowAbove", disabled: readOnly }, { label: "Add Row Below", action: "addRowBelow", disabled: readOnly },
    { label: "Add Column Left", action: "addColumnLeft", disabled: readOnly }, { label: "Add Column Right", action: "addColumnRight", disabled: readOnly }, {},
    { label: "Clear Cell", action: "clear", disabled: readOnly }, {},
    { label: "Delete Row", action: "deleteRow", disabled: readOnly || rows.length <= 1 },
    { label: "Delete Column", action: "deleteColumn", disabled: readOnly || columns <= 1 },
  ];
  return <div
    ref={rootRef} className={`tableGrid${hasSelection ? " tableGrid-hasSelection" : ""}`} role="grid" aria-label="Table" tabIndex={0}
    style={previewWidths ? { width: previewWidths.reduce((sum, width) => sum + width, 0) } : undefined}
    aria-rowcount={rows.length} aria-colcount={columns} onKeyDown={keyDown}
    onPointerDown={(event) => event.stopPropagation()}
    onDoubleClick={(event) => event.stopPropagation()}
    onCopy={(event) => { event.stopPropagation(); if (!editingRef.current) void copy(false, event); }}
    onCut={(event) => { event.stopPropagation(); if (!editingRef.current && !readOnly) void copy(true, event); }}
    onPaste={(event) => {
      event.stopPropagation();
      const text = event.clipboardData.getData("text/plain");
      if (!editingRef.current || /[\t\r\n]/.test(text)) { event.preventDefault(); pasteText(text); }
    }}
    onContextMenu={(event) => event.stopPropagation()}
  >
    {hasSelection && <>
      <div className="tableGrid-columnHeaders" aria-label="Table columns">
        {Array.from({ length: columns }, (_, index) => {
          const label = cellAddress(0, index).replace(/\d+$/, "");
          return <div key={index} className={`tableGrid-columnHeader${index >= area.left && index <= area.right ? " tableGrid-header-active" : ""}`} role="columnheader"
            aria-label={`Column ${label}`} style={{ width: explicitWidths ? explicitWidths[index] : `${100 / columns}%` }}
            onPointerDown={event => dragHeader(event,'column',index)}>
            {label}
            {!readOnly && onColumnWidthsChange && <span role="separator" tabIndex={0} aria-label={`Resize column ${label}`} aria-orientation="vertical" aria-valuemin={40} aria-valuemax={2400} aria-valuenow={Math.round(explicitWidths?.[index] || normalizedWidths()[index])}
              className="tableGrid-columnResize" onPointerDown={event => resizeColumn(event, index)} onKeyDown={event => resizeByKeyboard(event, index)} />}
          </div>;
        })}
      </div>
      <div className="tableGrid-rowHeaders" aria-label="Table rows">
        {rows.map((_, index) => <div key={index} role="rowheader" aria-label={`Row ${index + 1}`} className={`tableGrid-rowHeader${index >= area.top && index <= area.bottom ? " tableGrid-header-active" : ""}`}
          style={{ height: index === 0 || index === rows.length - 1 ? 23 : 24 }}
          onPointerDown={event => dragHeader(event,'row',index)}>{index + 1}</div>)}
      </div>
    </>}
    <table className="tableGrid-table" role="presentation">
      {explicitWidths && <colgroup>{explicitWidths.map((width, index) => <col key={index} style={{ width }} />)}</colgroup>}
      <tbody>
      {rows.map((row, ri) => <tr key={ri} role="row">{Array.from({ length: columns }, (_, ci) => {
        const cell = { row: ri, column: ci }, style = meta[cellKey(ri, ci)] || {};
        const active = selection.row === ri && selection.column === ci;
        const selected = hasSelection && ri >= area.top && ri <= area.bottom && ci >= area.left && ci <= area.right;
        const isEditing = !!editing && sameCell(editing, cell);
        const raw = row[ci] || "",evaluation=evaluations[ri]?.[ci];
        const numeric = style.type === "number" || style.type === "currency" || style.type === "percentage" || ((!style.type || style.type === "auto") && /^[-+]?\d/.test(raw));
        return <td key={ci} role="gridcell" aria-label={`Row ${ri + 1} column ${ci + 1}`} aria-selected={selected}
          data-cell={cellAddress(ri, ci)} title={!evaluation?.error&&raw.startsWith("=") ? raw : undefined}
          className={`tableGrid-cell${selected ? " tableGrid-cell-selected" : ""}${active && hasSelection ? " tableGrid-cell-active" : ""}${isEditing ? " tableGrid-cell-editing" : ""}`}
          style={{ backgroundColor: style.color, textAlign: style.align || (numeric ? "right" : "left"), verticalAlign: style.verticalAlign || "top", fontWeight: style.bold ? 700 : 400, fontStyle: style.italic ? "italic" : "normal" } as CSSProperties}
          onPointerDown={(event) => pointerDown(event, cell)}
          onPointerEnter={(event) => { if (dragging.current && event.buttons === 1) select({ ...dragging.current, endRow: ri, endColumn: ci }, false); }}
          onDoubleClick={(event) => { event.preventDefault(); event.stopPropagation(); beginEditing(cell); }}
          onContextMenu={(event) => {
            event.preventDefault(); event.stopPropagation(); stopEditing();
            if (!selected) select(cell);
            setMenu({ x: Math.min(event.clientX, window.innerWidth - 202), y: Math.min(event.clientY, window.innerHeight - 375) });
          }}
        >{isEditing ? <input ref={inputRef} className="tableGrid-input" aria-label={`Edit Row ${ri + 1} column ${ci + 1}`} spellCheck={false}
          value={editing.value} onChange={(event) => { const next = { ...editing, value: event.target.value }; editingRef.current = next; setEditing(next); }}
          onBlur={() => stopEditing()} onPointerDown={(event) => event.stopPropagation()} />
          : style.type === "checkbox" ? <button type="button" className="tableGrid-checkbox" role="checkbox" aria-label={`Toggle Row ${ri + 1} column ${ci + 1}`}
            aria-checked={/^(?:true|1|yes|checked)$/i.test(raw)} disabled={readOnly} onClick={(event) => { event.stopPropagation(); toggleCheckbox(cell); }}>
            {/^(?:true|1|yes|checked)$/i.test(raw) && <Check size={12} strokeWidth={2.5} />}</button>
          : evaluation?.error?<span className="tableGrid-formulaError" role="img" tabIndex={0} aria-label={`Formula error: ${evaluation.error.message}`} aria-describedby={errorTooltip?errorTooltipId:undefined}
            data-formula-error={evaluation.error.code} onPointerEnter={event=>showErrorTooltip(event.currentTarget,evaluation.error!.message)} onPointerLeave={hideErrorTooltip}
            onFocus={event=>showErrorTooltip(event.currentTarget,evaluation.error!.message,true)} onBlur={hideErrorTooltip}>
            <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="8" fill="#ff8d22"/><path d="M8 3v6" stroke="#fff" strokeWidth="2" strokeLinecap="round"/><circle cx="8" cy="12" r="1" fill="#fff"/></svg>
          </span>: <span className="tableGrid-value">{dateSession&&sameCell(dateSession,cell)?formatTableCell([[dateSession.value]],0,0,{'0:0':{...style,type:'date',timeFormat:dateSession.hasTime?(style.timeFormat&&style.timeFormat!=='none'?style.timeFormat:'twelveHour'):'none'}}):evaluation?.display??formatTableCell(rows, ri, ci, meta,{...evaluationContext,errorDisplay:'blank'})}</span>}</td>;
      })}</tr>)}
    </tbody></table>
    {axisDrop&&<span className={`tableGrid-axisDrop tableGrid-axisDrop-${axisDrop.axis}`} style={axisDrop.axis==='column'?{left:axisDrop.position}:{top:axisDrop.position}}/>}
    {hasSelection&&!readOnly&&<span role="button" tabIndex={0} aria-label="Resize table grid" title="Drag to add or remove rows and columns" className="tableGrid-resizeGrid" onPointerDown={resizeGrid} onKeyDown={event=>{if(!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(event.key))return;event.preventDefault();event.stopPropagation();const next=resizeTableGrid(rows,meta,rows.length+(event.key==='ArrowDown'?1:event.key==='ArrowUp'?-1:0),columns+(event.key==='ArrowRight'?1:event.key==='ArrowLeft'?-1:0));publish(next);}}/>}
    {gridPreview&&<div className="tableGrid-resizePreview" style={{width:gridPreview.width,height:gridPreview.height}}><span>{gridPreview.columnCount} columns × {gridPreview.rowCount} rows</span></div>}
    {dateSession&&createPortal(<TableDatePicker value={documentRef.current.rows[dateSession.row]?.[dateSession.column]||''} hasTime={dateSession.hasTime} anchor={dateSession.anchor} onCancel={()=>setDateSession(null)} onSave={saveDate} onPreview={(value,hasTime)=>setDateSession(session=>session?{...session,value,hasTime}:null)}/>,document.body)}
    {errorTooltip&&createPortal(<div id={errorTooltipId} role="tooltip" className="tableGrid-errorTooltip" style={{left:errorTooltip.left,top:errorTooltip.top}}>{errorTooltip.message}</div>,document.body)}
    {menu && createPortal(<div className="tableGrid-context" role="menu" aria-label="Cell actions"
      style={{ left: Math.max(4, menu.x), top: Math.max(4, menu.y) }} onPointerDown={(event) => { event.preventDefault(); event.stopPropagation(); }}
      onContextMenu={(event) => { event.preventDefault(); event.stopPropagation(); }} onKeyDown={(event) => { if (event.key === "Escape") setMenu(null); event.stopPropagation(); }}>
      {contextItems.map((item, index) => item.action ? <button key={item.action} type="button" role="menuitem" disabled={item.disabled} onClick={() => run(item.action!)}>
        <span>{item.label}</span>{item.shortcut && <kbd>{item.shortcut}</kbd>}</button> : <div className="tableGrid-context-divider" key={index} role="separator" />)}
    </div>, document.body)}
  </div>;
});
