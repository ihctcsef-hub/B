import {useLayoutEffect,useRef,useState,type CSSProperties,type ReactNode} from 'react';
import {linkPreviewHeight} from '../core/linkPreview';

export interface LinkPreviewProps {
  src?:string;
  automatic?:boolean;
  className?:string;
  placeholder?:ReactNode;
  overlay?:ReactNode;
  alt?:string;
}
interface ImageSize {source:string;generation:number;width:number;height:number;failed?:boolean}

/** Uses the actual rendered column width, not a hard-coded 270px assumption.
 * The state is scoped to the image source. A removed or stale image cannot
 * resize the next attachment when it finishes loading later. */
export function LinkPreview({src,automatic=false,className='link-preview',placeholder,overlay,alt='Link preview'}:LinkPreviewProps){
  const root=useRef<HTMLDivElement>(null),source=useRef(src),lifetime=useRef(0);
  if(source.current!==src){source.current=src;lifetime.current++;}
  const generation=lifetime.current;
  const [width,setWidth]=useState(0),[image,setImage]=useState<ImageSize>();
  const current=image&&image.source===src&&image.generation===generation?image:undefined;
  useLayoutEffect(()=>{
    const element=root.current;if(!element||!automatic)return;
    const measure=()=>{
      if(!element.isConnected)return;
      // getBoundingClientRect includes the canvas transform. Computed width
      // remains the card's logical width at every zoom level.
      const next=parseFloat(getComputedStyle(element).width);
      if(Number.isFinite(next)&&next>0)setWidth(previous=>previous===next?previous:next);
    };
    measure();const observer=new ResizeObserver(measure);observer.observe(element);return()=>observer.disconnect();
  },[automatic,src]);
  const visibleSource=src&&!current?.failed?src:undefined;
  const style:CSSProperties={position:'relative',overflow:'hidden',borderRadius:0};
  if(visibleSource){style.padding=0;if(automatic){style.aspectRatio='auto';if(width>0&&current?.width&&current.height)style.height=linkPreviewHeight(width,current.width,current.height);}}
  return <div ref={root} className={className} style={style} data-link-preview-state={!src?'empty':current?.failed?'error':current?.width?'ready':'loading'}>
    {visibleSource?<img key={visibleSource} src={visibleSource} alt={alt} className="link-preview-image" referrerPolicy="no-referrer" draggable={false}
      style={{position:'absolute',inset:0,display:'block',width:'100%',height:'100%',objectFit:'cover'}}
      onLoad={event=>{const img=event.currentTarget;if(source.current!==visibleSource||lifetime.current!==generation||!root.current?.contains(img))return;if(img.naturalWidth>0&&img.naturalHeight>0)setImage({source:visibleSource,generation,width:img.naturalWidth,height:img.naturalHeight});}}
      onError={event=>{if(source.current!==visibleSource||lifetime.current!==generation||!root.current?.contains(event.currentTarget))return;setImage({source:visibleSource,generation,width:0,height:0,failed:true});}}/>:placeholder}
    {overlay}
  </div>;
}
