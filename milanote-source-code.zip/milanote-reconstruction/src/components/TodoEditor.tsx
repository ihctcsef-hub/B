import { forwardRef, useEffect, useImperativeHandle, useLayoutEffect, useRef, useState } from "react";
import type { KeyboardEvent, PointerEvent } from "react";
import { createPortal } from "react-dom";
import { ArrowDown, ArrowUp, CalendarDays, Check, ChevronLeft, ChevronRight, GripVertical, MoreHorizontal, Plus, Trash2, X } from "lucide-react";
import { indentTodoTask, isTodoDate, isTodoTime, moveTodoTask, removeTodoTask, taskIndent } from "../core/todo";
import type { TodoTask } from "../core/todo";
import "./todo-editor.css";

export type TodoItem = TodoTask;
export type TodoAction = "toggleTitle" | "dueDate" | "indent" | "outdent" | "addTask" | "deleteTask" | "moveUp" | "moveDown";
export interface TodoEditorHandle {
  run: (action: TodoAction) => void;
  getSelectedId: () => string | null;
  focus: () => void;
}
export interface TodoEditorProps {
  title: string;
  items: TodoItem[];
  onChange: (value: { title: string; items: TodoItem[]; height: number }) => void;
  onSelectionChange?: (id: string) => void;
  readOnly?: boolean;
}
type Popup = { kind: "menu" | "date"; id: string; x: number; y: number };
const makeId = () => globalThis.crypto?.randomUUID?.() ?? `task-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
const minimumHeight = (items: TodoItem[], title: string) => 30 + Math.max(1, items.length) * 24 + items.filter(item => item.dueDate).length * 20 + (title ? 30 : 0);

export const TodoEditor = forwardRef<TodoEditorHandle, TodoEditorProps>(function TodoEditor(
  { title, items, onChange, onSelectionChange, readOnly = false }, ref,
) {
  const rootRef = useRef<HTMLDivElement>(null);
  const popupRef = useRef<HTMLDivElement>(null);
  const fields = useRef(new Map<string, HTMLTextAreaElement>());
  const current = useRef({ title, items, onChange, onSelectionChange, readOnly });
  current.current = { title, items, onChange, onSelectionChange, readOnly };
  const selectedRef = useRef<string | null>(items[0]?.id || null);
  const [selected, setSelected] = useState<string | null>(null);
  const [popup, setPopup] = useState<Popup | null>(null);
  const [dragging, setDragging] = useState<string | null>(null);
  const [dropBefore, setDropBefore] = useState<string | null | undefined>();
  const lastHeight = useRef(minimumHeight(items, title));
  const pendingFocus = useRef<{ frame: number; cancel: () => void } | null>(null);

  function select(id: string) {
    selectedRef.current = id;
    setSelected(id);
    current.current.onSelectionChange?.(id);
  }
  function cancelPendingFocus() { pendingFocus.current?.cancel(); }
  function scheduleFocus(target: () => HTMLInputElement | HTMLTextAreaElement | null | undefined, cursor?: number) {
    cancelPendingFocus();
    const request = { frame: 0, cancel: () => {
      if (pendingFocus.current === request) pendingFocus.current = null;
      cancelAnimationFrame(request.frame);
      document.removeEventListener("focusin", request.cancel, true);
      document.removeEventListener("pointerdown", request.cancel, true);
    } };
    pendingFocus.current = request;
    // A later user choice wins over the focus requested by an earlier edit.
    document.addEventListener("focusin", request.cancel, true);
    document.addEventListener("pointerdown", request.cancel, true);
    request.frame = requestAnimationFrame(() => {
      if (pendingFocus.current !== request) return;
      request.cancel();
      const field = target();
      if (current.current.readOnly || !field?.isConnected) return;
      field.focus({ preventScroll: true });
      if (cursor !== undefined) field.setSelectionRange(cursor, cursor);
    });
  }
  function focus(id: string, cursor?: number) { scheduleFocus(() => fields.current.get(id), cursor); }
  function publish(nextItems: TodoItem[], nextTitle = current.current.title) {
    lastHeight.current = minimumHeight(nextItems, nextTitle);
    current.current.onChange({ title: nextTitle, items: nextItems, height: lastHeight.current });
  }
  function updateTask(id: string, value: Partial<TodoItem>) {
    publish(current.current.items.map(item => item.id === id ? { ...item, ...value } : item));
  }
  function add(afterId = selectedRef.current, text = "", cursor = 0) {
    if (current.current.readOnly) return;
    const next = [...current.current.items];
    const index = next.findIndex(item => item.id === afterId);
    const id = makeId();
    next.splice(index < 0 ? next.length : index + 1, 0, { id, text, done: false, indent: index < 0 ? 0 : taskIndent(next[index]) });
    publish(next);
    select(id);
    focus(id, cursor);
  }
  function remove(id: string) {
    const source = current.current.items;
    const index = source.findIndex(item => item.id === id);
    const next = removeTodoTask(source, id);
    publish(next);
    const target = next[Math.max(0, Math.min(index - 1, next.length - 1))];
    if (target) { select(target.id); focus(target.id, target.text.length); }
    setPopup(null);
  }
  function showDate(id: string) {
    const row = fields.current.get(id)?.closest<HTMLElement>(".todoEditor-row");
    const rect = row?.getBoundingClientRect() || rootRef.current?.getBoundingClientRect();
    if (!rect) return;
    select(id);
    setPopup({ kind: "date", id, x: Math.max(8, Math.min(rect.left, window.innerWidth - 280)), y: Math.max(8, Math.min(rect.bottom + 6, window.innerHeight - 240)) });
  }
  function move(id: string, direction: -1 | 1) {
    const source = current.current.items;
    const index = source.findIndex(item => item.id === id);
    if (index < 0) return;
    const depth = taskIndent(source[index]);
    let target = index + direction;
    if (direction < 0) {
      while (target > 0 && taskIndent(source[target]) > depth) target--;
      if (target < 0) return;
    } else {
      while (target < source.length && taskIndent(source[target]) > depth) target++;
      if (target >= source.length) return;
      target++;
      while (target < source.length && taskIndent(source[target]) > depth) target++;
    }
    const next = moveTodoTask(source, id, source[target]?.id || null);
    if (next !== source) publish(next);
    focus(id);
  }
  function run(action: TodoAction) {
    if (current.current.readOnly) return;
    const id = selectedRef.current || current.current.items[0]?.id;
    if (action === "toggleTitle") { publish(current.current.items, current.current.title ? "" : "To-do list"); scheduleFocus(() => rootRef.current?.querySelector<HTMLInputElement>(".todoEditor-title")); return; }
    if (action === "addTask") { add(id); return; }
    if (!id) return;
    if (action === "dueDate") { showDate(id); return; }
    if (action === "deleteTask") { remove(id); return; }
    if (action === "moveUp" || action === "moveDown") { move(id, action === "moveUp" ? -1 : 1); return; }
    if (action === "indent" || action === "outdent") {
      const next = indentTodoTask(current.current.items, id, action === "indent" ? 1 : -1);
      if (next !== current.current.items) publish(next);
      focus(id);
    }
  }
  useImperativeHandle(ref, () => ({ run, getSelectedId: () => selectedRef.current, focus: () => { const id = selectedRef.current || current.current.items[0]?.id; if (id) focus(id); } }));

  useLayoutEffect(() => {
    for (const field of fields.current.values()) {
      field.style.height = "16px";
      field.style.height = `${Math.max(16, field.scrollHeight)}px`;
    }
    const height = Math.max(54, Math.round(rootRef.current?.offsetHeight || 54));
    if (height !== lastHeight.current) {
      lastHeight.current = height;
      current.current.onChange({ title: current.current.title, items: current.current.items, height });
    }
  }, [title, items]);
  useEffect(() => {
    if (!popup) return;
    function dismiss(event: globalThis.PointerEvent) {
      if (!popupRef.current?.contains(event.target as Node)) setPopup(null);
    }
    function escape(event: globalThis.KeyboardEvent) {
      if (event.key === "Escape") { event.preventDefault(); event.stopPropagation(); setPopup(null); focus(popup!.id); }
    }
    document.addEventListener("pointerdown", dismiss, true);
    document.addEventListener("keydown", escape, true);
    return () => { document.removeEventListener("pointerdown", dismiss, true); document.removeEventListener("keydown", escape, true); };
  }, [popup]);
  useLayoutEffect(() => { if (readOnly) cancelPendingFocus(); }, [readOnly]);
  useEffect(() => () => { dragCleanup.current?.(); cancelPendingFocus(); }, []);
  const dragCleanup = useRef<(() => void) | null>(null);
  function beginDrag(event: PointerEvent<HTMLButtonElement>, id: string) {
    if (readOnly || event.button !== 0) return;
    event.preventDefault(); event.stopPropagation();
    setPopup(null); select(id); setDragging(id);
    let target: string | null | undefined;
    const root = rootRef.current;
    function dragMove(e: globalThis.PointerEvent) {
      e.preventDefault();
      const row = document.elementFromPoint(e.clientX, e.clientY)?.closest<HTMLElement>("[data-todo-row]");
      if (row && root?.contains(row)) {
        const rect = row.getBoundingClientRect();
        const index = current.current.items.findIndex(item => item.id === row.dataset.todoRow);
        target = e.clientY < rect.top + rect.height / 2 ? row.dataset.todoRow : current.current.items[index + 1]?.id || null;
      } else if (root && e.clientY >= root.getBoundingClientRect().bottom) target = null;
      else target = undefined;
      setDropBefore(target);
    }
    function end(e: globalThis.PointerEvent) {
      e.preventDefault();
      if (target !== undefined) {
        const next = moveTodoTask(current.current.items, id, target);
        if (next !== current.current.items) publish(next);
      }
      cleanup(); focus(id);
    }
    function cancel() { cleanup(); }
    function cleanup() {
      window.removeEventListener("pointermove", dragMove); window.removeEventListener("pointerup", end); window.removeEventListener("pointercancel", cancel);
      setDragging(null); setDropBefore(undefined); dragCleanup.current = null;
    }
    dragCleanup.current?.();
    dragCleanup.current = cleanup;
    window.addEventListener("pointermove", dragMove, { passive: false }); window.addEventListener("pointerup", end); window.addEventListener("pointercancel", cancel);
  }
  function keyDown(event: KeyboardEvent<HTMLTextAreaElement>, item: TodoItem) {
    event.stopPropagation();
    if (readOnly) return;
    if (event.key === "Tab") {
      event.preventDefault();
      const next = indentTodoTask(current.current.items, item.id, event.shiftKey ? -1 : 1);
      if (next !== current.current.items) publish(next);
    } else if (event.altKey && (event.key === "ArrowUp" || event.key === "ArrowDown")) {
      event.preventDefault(); move(item.id, event.key === "ArrowUp" ? -1 : 1);
    } else if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      if (!item.text && taskIndent(item) > 0) { run("outdent"); return; }
      const start = event.currentTarget.selectionStart, end = event.currentTarget.selectionEnd;
      const next = current.current.items.map(task => task.id === item.id ? { ...task, text: task.text.slice(0, start) } : task);
      const id = makeId();
      const index = next.findIndex(task => task.id === item.id);
      next.splice(index + 1, 0, { id, text: item.text.slice(end), done: false, indent: taskIndent(item) });
      publish(next); select(id); focus(id, 0);
    } else if (event.key === "Backspace" && !item.text) {
      event.preventDefault();
      if (taskIndent(item)) run("outdent"); else if (current.current.items.length > 1) remove(item.id);
    } else if (event.key === "Escape") {
      event.preventDefault(); setPopup(null); event.currentTarget.blur();
    }
  }
  const popupTask = popup && items.find(item => item.id === popup.id);
  return <div ref={rootRef} className="todo-content todoEditor" onDoubleClick={event => event.stopPropagation()}>
    {title && <input className="plain title-input todoEditor-title" aria-label="To-do list title" value={title} readOnly={readOnly} onChange={event => publish(items, event.target.value)} onKeyDown={event => event.stopPropagation()} />}
    {items.map((item, index) => <div key={item.id} data-todo-row={item.id} className={`todoEditor-row${item.done ? " todoEditor-done" : ""}${selected === item.id ? " todoEditor-selected" : ""}${dragging === item.id ? " todoEditor-dragging" : ""}${dropBefore === item.id ? " todoEditor-dropBefore" : ""}`} style={{ paddingLeft: taskIndent(item) * 18 }}
      onContextMenu={event => { if (readOnly) return; event.preventDefault(); event.stopPropagation(); select(item.id); setPopup({ kind: "menu", id: item.id, x: Math.max(8, Math.min(event.clientX, window.innerWidth - 210)), y: Math.max(8, Math.min(event.clientY, window.innerHeight - 285)) }); }}>
      <button type="button" className="todoEditor-dragHandle" title="Drag task to reorder" aria-label={`Reorder task ${index + 1}`} onPointerDown={event => beginDrag(event, item.id)} disabled={readOnly}><GripVertical size={12} /></button>
      <div className="todoEditor-line">
        <button type="button" className="checkbox todoEditor-checkbox" role="checkbox" aria-checked={item.done} aria-label={item.done ? "Mark incomplete" : "Complete task"} disabled={readOnly} onClick={() => { select(item.id); updateTask(item.id, { done: !item.done }); }}>{item.done && <Check size={10} strokeWidth={2.4} />}</button>
        <textarea ref={field => { if (field) fields.current.set(item.id, field); else fields.current.delete(item.id); }} id={`task-${item.id}`} className="plain todoEditor-text" aria-label="Task text" placeholder="Add a task…" value={item.text} rows={1} readOnly={readOnly} onFocus={() => select(item.id)} onChange={event => updateTask(item.id, { text: event.target.value })} onKeyDown={event => keyDown(event, item)} />
        {!readOnly && <button type="button" className="todoEditor-more" title="Task options" aria-label={`Options for task ${index + 1}`} onClick={event => { select(item.id); const rect = event.currentTarget.getBoundingClientRect(); setPopup({ kind: "menu", id: item.id, x: Math.max(8, Math.min(rect.right + 4, window.innerWidth - 210)), y: Math.max(8, Math.min(rect.top, window.innerHeight - 285)) }); }}><MoreHorizontal size={13} /></button>}
      </div>
      {item.dueDate && <button type="button" className={`todoEditor-due${!item.done && item.dueDate < new Date().toLocaleDateString("en-CA") ? " todoEditor-overdue" : ""}`} title="Edit due date" aria-label={`Due ${item.dueDate}${item.reminderTime ? ` at ${item.reminderTime}` : ""}`} disabled={readOnly} onClick={() => showDate(item.id)}><CalendarDays size={10} /><span>{formatDate(item.dueDate)}{item.reminderTime ? ` · ${item.reminderTime}` : ""}</span></button>}
    </div>)}
    {dropBefore === null && <div className="todoEditor-dropEnd" />}
    {!readOnly && <button type="button" className="add-task todoEditor-add" onClick={() => add(items[items.length - 1]?.id)}><Plus size={13} />Add a task</button>}
    {popup && popupTask && createPortal(popup.kind === "menu" ? <div ref={popupRef} role="menu" aria-label="Task actions" className="todoEditor-popup todoEditor-menu" style={{ left: popup.x, top: popup.y }} onPointerDown={event => event.stopPropagation()} onKeyDown={event => event.stopPropagation()}>
      <button type="button" role="menuitem" onClick={() => showDate(popup.id)}><CalendarDays size={13} />Due date</button>
      <button type="button" role="menuitem" onClick={() => { setPopup(null); run("indent"); }} disabled={indexOf(items, popup.id) === 0}><ChevronRight size={13} />Indent<kbd>Tab</kbd></button>
      <button type="button" role="menuitem" onClick={() => { setPopup(null); run("outdent"); }} disabled={!taskIndent(popupTask)}><ChevronLeft size={13} />Unindent<kbd>⇧Tab</kbd></button>
      <div role="separator" />
      <button type="button" role="menuitem" onClick={() => { setPopup(null); move(popup.id, -1); }} disabled={indexOf(items, popup.id) === 0}><ArrowUp size={13} />Move up</button>
      <button type="button" role="menuitem" onClick={() => { setPopup(null); move(popup.id, 1); }} disabled={indexOf(items, popup.id) === items.length - 1}><ArrowDown size={13} />Move down</button>
      <button type="button" role="menuitem" onClick={() => { setPopup(null); add(popup.id); }}><Plus size={13} />Add task below</button>
      <div role="separator" />
      <button type="button" role="menuitem" className="todoEditor-delete" onClick={() => remove(popup.id)}><Trash2 size={13} />Delete task</button>
    </div> : <div ref={popupRef} role="dialog" aria-label="Task due date" className="todoEditor-popup todoEditor-date" style={{ left: popup.x, top: popup.y }} onPointerDown={event => event.stopPropagation()} onKeyDown={event => event.stopPropagation()}>
      <div className="todoEditor-popupTitle"><strong>Due date</strong><button type="button" title="Close due date" onClick={() => { setPopup(null); focus(popup.id); }}><X size={14} /></button></div>
      <label>Date<input type="date" aria-label="Task due date" value={popupTask.dueDate || ""} onChange={event => { const value = event.target.value; if (isTodoDate(value)) updateTask(popup.id, { dueDate: value }); else if (!value) updateTask(popup.id, { dueDate: undefined, reminderTime: undefined }); }} /></label>
      <label>Reminder time <span>(optional)</span><input type="time" aria-label="Task reminder time" value={popupTask.reminderTime || ""} disabled={!popupTask.dueDate} onChange={event => { const value = event.target.value; if (isTodoTime(value) || !value) updateTask(popup.id, { reminderTime: value || undefined }); }} /></label>
      <div className="todoEditor-dateActions"><button type="button" disabled={!popupTask.dueDate} onClick={() => { updateTask(popup.id, { dueDate: undefined, reminderTime: undefined }); setPopup(null); focus(popup.id); }}>Remove due date</button><button type="button" className="todoEditor-doneButton" onClick={() => { setPopup(null); focus(popup.id); }}>Done</button></div>
    </div>, document.body)}
  </div>;
});

const indexOf = (items: TodoItem[], id: string) => items.findIndex(item => item.id === id);
function formatDate(value: string) {
  if (!isTodoDate(value)) return value;
  return new Date(`${value}T12:00:00`).toLocaleDateString("en-US", { month: "short", day: "numeric", ...(value.slice(0, 4) !== String(new Date().getFullYear()) ? { year: "numeric" as const } : {}) });
}
