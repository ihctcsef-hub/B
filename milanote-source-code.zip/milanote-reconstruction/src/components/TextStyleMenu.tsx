import { useEffect,useRef } from 'react';
import { createPortal } from 'react-dom';
import { Check } from 'lucide-react';
import type { NoteEditorCommand } from './NoteEditor';
import './text-style-menu.css';

const styles:{label:string;command:NoteEditorCommand;value?:number;shortcut?:string;className:string}[]=[
  {label:'Large heading',command:'heading',value:1,shortcut:'Ctrl ⇧1',className:'large'},
  {label:'Normal heading',command:'heading',value:2,shortcut:'Ctrl ⇧2',className:'heading'},
  {label:'Normal text',command:'paragraph',className:'normal'},
  {label:'Small text',command:'smallText',shortcut:'Ctrl ⇧9',className:'small'},
  {label:'Code block',command:'codeBlock',shortcut:'Ctrl >',className:'code'},
  {label:'Callout',command:'callout',shortcut:'Ctrl ⇧6',className:'callout'},
  {label:'Quote block',command:'blockquote',shortcut:'Ctrl ”',className:'quote'},
];
export function TextStyleMenu({onCommand,onClose,active='paragraph',textColor,highlight,anchor}:{onCommand:(command:NoteEditorCommand,value?:string|number)=>void;onClose:()=>void;active?:string;textColor?:string;highlight?:string;anchor?:{left:number;top:number}}){
  const root=useRef<HTMLDivElement>(null),close=useRef(onClose);close.current=onClose;
  useEffect(()=>{
    function outside(event:PointerEvent){if((event.target as Element).closest?.('[data-text-style-trigger]'))return;if(!root.current?.contains(event.target as Node))close.current();}
    function key(event:KeyboardEvent){if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close.current();}}
    document.addEventListener('pointerdown',outside,true);document.addEventListener('keydown',key,true);
    return()=>{document.removeEventListener('pointerdown',outside,true);document.removeEventListener('keydown',key,true);};
  },[]);
  const colorRow=(isHighlight:boolean)=><section className="text-style-colors"><span>{isHighlight?'Highlight':'Color'}</span><div>{(isHighlight?['#000000','#8ae0ff','#c9f201','#ffce26','#ffa4de','#e8e9eb']:['#323b4a','#4ebafd','#4eb85a','#ff8d22','#f52929','#5f6672']).map((color,index)=><button type="button" key={color} aria-label={`${isHighlight?'Highlight':'Text'} color ${color}`} aria-pressed={isHighlight?highlight===color:textColor===color} style={isHighlight?{background:color,color:index===0?'#fff':'#323b4a'}:{color}} onClick={()=>onCommand(isHighlight?'highlight':'textColor',color)}>A</button>)}</div></section>;
  return createPortal(<div ref={root} role="menu" aria-label="Text style" className="text-style-menu" style={{left:Math.max(6,Math.min(anchor?.left??62.5,window.innerWidth-200)),top:Math.max(6,Math.min(anchor?.top??80,window.innerHeight-373))}} onPointerDown={event=>{event.preventDefault();event.stopPropagation();}}>
    <div className="text-style-rows">{styles.map(style=><button type="button" role="menuitem" className={`text-style-${style.className}`} key={style.label} onClick={()=>onCommand(style.command,style.value)}><span>{style.className==='callout'&&'⚠️ '}{style.className==='quote'?'“Quote block”':style.label}</span>{active===(style.command==='heading'?`heading${style.value}`:style.command)?<Check size={15}/>:style.shortcut&&<kbd>{style.shortcut}</kbd>}</button>)}</div>
    {colorRow(false)}{colorRow(true)}
  </div>,document.body);
}
