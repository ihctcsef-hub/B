import {useEffect,useMemo,useRef,useState,type KeyboardEvent} from 'react';
import {ChevronLeft,ChevronRight,Search,X} from 'lucide-react';
import {getTemplateCategories,searchTemplateCatalog,type CatalogTemplateOptions} from '../core/templateCatalog';
import './template-library.css';

export interface TemplateLibraryProps {
  onChoose:(templateId:string,options:CatalogTemplateOptions)=>void;
  onPreview?:(templateId:string|undefined,options:CatalogTemplateOptions)=>void;
  onClose?:()=>void;
  initialTemplateId?:string;
  initialView?:'recommended'|'categories';
}
const recommended=[{id:'empty-board',title:'Empty board'},{id:'project-plan-template',title:'Project Plan'},{id:'moodboard-template',title:'Moodboard'},{id:'creative-brief-template',title:'Creative Brief'},{id:'character-profile-template',title:'Character Profile'},{id:'weekly-plan-template',title:'Weekly Plan'}];
/** The catalog picker controls a transient preview through onPreview. The
 * caller commits only onChoose (Continue), preserving its own Undo/autosave. */
export function TemplateLibrary({onChoose,onPreview,onClose,initialTemplateId='empty-board',initialView='recommended'}:TemplateLibraryProps){
  const [view,setView]=useState<'recommended'|'categories'>(initialView),[category,setCategory]=useState<string>(),[query,setQuery]=useState(''),[selected,setSelected]=useState(initialTemplateId),[examples,setExamples]=useState(false);
  const previewCallback=useRef(onPreview);previewCallback.current=onPreview;
  const root=useRef<HTMLDivElement>(null),categories=useMemo(getTemplateCategories,[]),options=useMemo(()=>({includeExampleContent:examples}),[examples]);
  const matches=useMemo(()=>searchTemplateCatalog({query,categoryId:category}),[query,category]);
  const showResults=!!query.trim()||!!category;
  useEffect(()=>{previewCallback.current?.(selected,options);},[selected,options]);
  function select(id:string){setSelected(id);}
  function back(){if(category){setCategory(undefined);setQuery('');}else{setView('recommended');setQuery('');}}
  function keyboard(event:KeyboardEvent<HTMLDivElement>){
    if(event.key==='Escape'){event.preventDefault();event.stopPropagation();onClose?.();return;}
    if(!['ArrowDown','ArrowUp','Home','End'].includes(event.key)||event.target instanceof HTMLInputElement)return;
    const buttons=[...root.current!.querySelectorAll<HTMLButtonElement>('.template-library-item')];if(!buttons.length)return;
    const current=buttons.indexOf(document.activeElement as HTMLButtonElement),next=event.key==='Home'?0:event.key==='End'?buttons.length-1:Math.max(0,Math.min(buttons.length-1,current+(event.key==='ArrowDown'?1:-1)));
    event.preventDefault();buttons[next].focus();
  }
  return <div ref={root} className="template-library" role="region" aria-label="Choose a template" onKeyDown={keyboard}>
    <div className="template-library-header">{view==='recommended'&&!category&&!query?<strong>Choose a template</strong>:<button type="button" className="template-library-back" onClick={back}><ChevronLeft size={13}/>Back</button>}{onClose&&<button className="template-library-close" type="button" title="Close templates" onClick={onClose}><X size={14}/></button>}</div>
    {(view==='categories'||showResults)&&<label className="template-library-search"><input aria-label="Search templates" placeholder="Search templates..." value={query} onChange={event=>setQuery(event.target.value)}/><Search size={12}/></label>}
    <div className="template-library-list">
      {view==='recommended'&&!showResults?<>{recommended.map(item=><button type="button" key={item.id} data-template-id={item.id} className={`template-library-item template-library-template${selected===item.id?' selected':''}`} aria-pressed={selected===item.id} onClick={()=>select(item.id)}>{item.title}{item.id==='project-plan-template'&&<span className="template-library-top-pick">TOP PICK</span>}</button>)}<button type="button" className="template-library-item template-library-more" onClick={()=>setView('categories')}>More templates...<ChevronRight size={13}/></button></>:showResults?<>{matches.map(entry=><button type="button" key={entry.id} data-template-id={entry.id} className={`template-library-item template-library-template${selected===entry.id?' selected':''}`} aria-pressed={selected===entry.id} onClick={()=>select(entry.id)}>{entry.displayName}</button>)}{!matches.length&&<p className="template-library-empty">No templates found</p>}</>:categories.map(item=><button key={item.id} data-category-id={item.id} type="button" className="template-library-item template-library-category" onClick={()=>setCategory(item.id)}><span>{item.title}</span><small>{item.entries.length}</small><ChevronRight size={13}/></button>)}
    </div>
    <button type="button" className="template-library-continue" onClick={()=>onChoose(selected,options)}>{selected==='empty-board'?'Continue':'Use this template'}</button>
    <label className="template-library-examples"><input type="checkbox" checked={examples} disabled={selected==='empty-board'} onChange={event=>setExamples(event.target.checked)}/>Keep example content</label>
  </div>;
}
