import { useEffect, useRef } from 'react';
import type { CSSProperties } from 'react';
import { createPortal } from 'react-dom';
import { ChevronRight, Copy } from 'lucide-react';
import type { SyncedNoteLocation } from '../core/notes';
import './synced-note-locations.css';

export interface SyncedNoteAnchor { left:number; top:number; width:number; height:number }

export function SyncedNoteIndicator({count,open=false,onOpen}:{count:number;open?:boolean;onOpen:(anchor:SyncedNoteAnchor)=>void}) {
  if(count<2)return null;
  return <button type="button" className="synced-note-indicator" aria-label={`View ${count} synced copies`} aria-haspopup="dialog" aria-expanded={open}
    onPointerDown={event=>event.stopPropagation()} onDoubleClick={event=>event.stopPropagation()} onDragStart={event=>event.preventDefault()}
    onClick={event=>{event.stopPropagation();const rect=event.currentTarget.getBoundingClientRect();onOpen({left:rect.left,top:rect.top,width:rect.width,height:rect.height});}}><Copy size={12} strokeWidth={1.7}/></button>;
}

export function SyncedNoteLocations({locations,currentBoardId,anchor,onOpenBoard,onClose}:{locations:SyncedNoteLocation[];currentBoardId:string;anchor:SyncedNoteAnchor;onOpenBoard:(boardId:string)=>void;onClose:()=>void}) {
  const root=useRef<HTMLDivElement>(null),close=useRef(onClose);close.current=onClose;
  const restoreFocus=useRef(true);
  const count=locations.reduce((sum,location)=>sum+location.noteIds.length,0);
  const otherBoards=locations.filter(location=>location.boardId!==currentBoardId);
  const height=46.032+otherBoards.length*29.6;
  const below=anchor.top+anchor.height+8;
  const above=below+height>window.innerHeight-6;
  const top=above?Math.max(6,anchor.top-height-8):below;
  const left=Math.min(Math.max(6,anchor.left+anchor.width/2-80),Math.max(6,window.innerWidth-166));
  useEffect(()=>{
    const previous=document.activeElement;
    (root.current?.querySelector('button')||root.current)?.focus();
    function outside(event:PointerEvent){if(!(event.target as Element).closest?.('.synced-note-indicator')&&!root.current?.contains(event.target as Node)){restoreFocus.current=false;close.current();}}
    function key(event:KeyboardEvent){if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close.current();}}
    function changed(){restoreFocus.current=false;close.current();}
    function wheel(event:WheelEvent){if(!root.current?.contains(event.target as Node))changed();}
    document.addEventListener('pointerdown',outside,true);document.addEventListener('keydown',key,true);window.addEventListener('resize',changed);window.addEventListener('wheel',wheel,{passive:true});
    return()=>{document.removeEventListener('pointerdown',outside,true);document.removeEventListener('keydown',key,true);window.removeEventListener('resize',changed);window.removeEventListener('wheel',wheel);if(restoreFocus.current&&previous instanceof HTMLElement&&previous.isConnected)previous.focus();};
  },[]);
  useEffect(()=>{if(count<2)close.current();},[count]);
  if(count<2)return null;
  return createPortal(<div ref={root} className={`synced-note-locations${above?' synced-note-locations-above':''}`} role="dialog" aria-label="Synced note locations" tabIndex={-1} style={{left,top,'--synced-arrow':`${Math.min(142,Math.max(6,anchor.left+anchor.width/2-left-6.5))}px`} as CSSProperties} onPointerDown={event=>event.stopPropagation()} onKeyDown={event=>event.stopPropagation()}><div className="synced-note-locations-content">
    <p className="synced-note-description">There are {count} synced copies of this card{otherBoards.length?'':' on the current board'}</p>
    {otherBoards.map(location=><button key={location.boardId} type="button" className="synced-note-board" onClick={()=>{restoreFocus.current=false;onClose();onOpenBoard(location.boardId);}}><span className="synced-note-board-icon">{location.icon?.startsWith('data:image/')?<img src={location.icon} alt=""/>:location.icon&&!/^(?:https?:|\/)/i.test(location.icon)?location.icon:''}</span><span>{location.title}</span><ChevronRight size={16}/></button>)}
    </div>
  </div>,document.body);
}
