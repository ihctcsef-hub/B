import { useEffect, useMemo, useRef, useState } from 'react';
import type { CSSProperties, KeyboardEvent } from 'react';
import { createPortal } from 'react-dom';
import { Check, ChevronRight, Minus, MoreHorizontal, Plus, Tag } from 'lucide-react';
import type { Workspace } from '../core/model';
import {
  LABEL_COLORS, LABEL_NAME_LIMIT, createWorkspaceLabel, deleteWorkspaceLabel, labelSelectionState, labelUsages,
  migrateLegacyLabels, recolorWorkspaceLabel, renameWorkspaceLabel, searchWorkspaceLabels, setLabelAssignment,
} from '../core/labels';
import type { WorkspaceLabel } from '../core/labels';
import './label-manager.css';

export interface LabelManagerProps {
  workspace:Workspace;
  boardId:string;
  selectedIds:string[];
  onChange:(workspace:Workspace)=>void;
  onClose:()=>void;
  anchor?:{left:number;top:number};
  onFilter?:(labelId:string)=>void;
}

export function labelInk(color:string):string {
  const rgb=/^#([\da-f]{2})([\da-f]{2})([\da-f]{2})$/i.exec(color);
  if(!rgb)return '#323b4a';
  const channels=rgb.slice(1).map(channel=>{const value=parseInt(channel,16)/255;return value<=.04045?value/12.92:((value+.055)/1.055)**2.4;});
  const luminance=.2126*channels[0]+.7152*channels[1]+.0722*channels[2];
  return luminance>.28?'#323b4a':'#ffffff';
}

/** Non-modal Labels popover; changes are single workspace transactions for Undo. */
export function LabelManager({workspace,boardId,selectedIds,onChange,onClose,anchor={left:49,top:200},onFilter}:LabelManagerProps){
  const rootRef=useRef<HTMLDivElement>(null);
  const inputRef=useRef<HTMLInputElement>(null);
  const renameRef=useRef<HTMLInputElement>(null);
  const [query,setQuery]=useState('');
  const [editingId,setEditingId]=useState<string|null>(null);
  const [renaming,setRenaming]=useState(false);
  const [colorsOpen,setColorsOpen]=useState(false);
  const [menuTop,setMenuTop]=useState(40);
  const [draft,setDraft]=useState('');
  const [error,setError]=useState('');
  const normalized=useMemo(()=>migrateLegacyLabels(workspace),[workspace]);
  const labels=normalized.labels||[];
  const filtered=searchWorkspaceLabels(normalized,query);
  const editing=labels.find(label=>label.id===editingId);
  const matching=labels.find(label=>label.name===query.trim());
  const groupName=normalized.boards[boardId]?.title||normalized.title;
  const recentColors=[...new Set(labels.map(label=>label.color))].filter(color=>!LABEL_COLORS.some(primary=>primary===color)).slice(-10);
  const position={left:Math.max(6,Math.min(anchor.left,window.innerWidth-246)),top:Math.max(6,Math.min(anchor.top,window.innerHeight-280))};

  useEffect(()=>{
    inputRef.current?.focus({preventScroll:true});
    function outside(event:PointerEvent){if(!rootRef.current?.contains(event.target as Node))onClose();}
    document.addEventListener('pointerdown',outside,true);
    return ()=>document.removeEventListener('pointerdown',outside,true);
  },[onClose]);
  useEffect(()=>{if(renaming){renameRef.current?.focus();renameRef.current?.select();}},[renaming,editingId]);

  function publish(next:Workspace){if(next!==workspace)onChange(next);}
  function toggle(label:WorkspaceLabel){
    const assigned=labelSelectionState(normalized,boardId,selectedIds,label.id)==='all';
    publish(setLabelAssignment(normalized,boardId,selectedIds,label.id,!assigned));
  }
  function create(){
    const name=query.trim();if(!name)return;
    const result=createWorkspaceLabel(normalized,name,{boardId,cardIds:selectedIds});
    if(result.label){publish(result.workspace);setQuery('');setError('');inputRef.current?.focus();}
  }
  function rename(){
    if(!editing)return;
    const name=draft.trim();
    if(!name){setError('Enter a label name.');return;}
    if(labels.some(label=>label.id!==editing.id&&label.name===name)){setError('A label with this name already exists.');return;}
    publish(renameWorkspaceLabel(normalized,editing.id,name));setRenaming(false);setEditingId(null);setError('');inputRef.current?.focus();
  }
  function keyDown(event:KeyboardEvent<HTMLDivElement>){
    event.stopPropagation();
    if(event.key==='Escape'){
      event.preventDefault();
      if(editingId||renaming){setEditingId(null);setRenaming(false);setColorsOpen(false);setError('');inputRef.current?.focus();}
      else onClose();
    }
  }

  return createPortal(<div ref={rootRef} className="labelManager" role="dialog" aria-label="Labels" style={position}
    onPointerDown={event=>event.stopPropagation()} onDoubleClick={event=>event.stopPropagation()} onContextMenu={event=>event.stopPropagation()} onKeyDown={keyDown}>
    {editing&&!renaming&&<div className="labelManager-edit" role="menu" aria-label={`Actions for ${editing.name}`} style={{top:menuTop}}>
      <button type="button" role="menuitem" className="labelManager-editAction" onClick={()=>{setDraft(editing.name);setRenaming(true);setColorsOpen(false);setError('');}}>Rename</button>
      <button type="button" role="menuitem" aria-haspopup="menu" aria-expanded={colorsOpen} className="labelManager-editAction" onPointerEnter={()=>setColorsOpen(true)} onClick={()=>setColorsOpen(true)}>Change color<ChevronRight size={12}/></button>
      <button type="button" role="menuitem" className="labelManager-editAction labelManager-delete" onClick={()=>{publish(deleteWorkspaceLabel(normalized,editing.id));setEditingId(null);setRenaming(false);setColorsOpen(false);}}>Delete</button>
      <div className="labelManager-usageFooter">This label is used on <button type="button" aria-label={`Find items with label ${editing.name}`} disabled={!onFilter} onClick={()=>{onFilter?.(editing.id);if(onFilter)onClose();}}>{labelUsages(normalized,editing.id).length} card{labelUsages(normalized,editing.id).length===1?'':'s'}</button></div>
      {colorsOpen&&<div className="labelManager-colorMenu" role="menu" aria-label="Change label color">
        <div className="labelManager-palette" role="group" aria-label="Label color">{LABEL_COLORS.map(color=><button type="button" key={color} aria-label={`Label color ${color}`} aria-pressed={editing.color.toLowerCase()===color} style={{background:color}} onClick={()=>publish(recolorWorkspaceLabel(normalized,editing.id,color))}>{editing.color.toLowerCase()===color&&<Check size={12} color={labelInk(color)}/>}</button>)}</div>
        {!!recentColors.length&&<div className="labelManager-palette labelManager-recent" role="group" aria-label="Recent label colors">{recentColors.map(color=><button key={color} type="button" aria-label={`Recent label color ${color}`} style={{background:color}} onClick={()=>publish(recolorWorkspaceLabel(normalized,editing.id,color))}/>)}</div>}
        <label className="labelManager-customColor"><span aria-hidden="true">🌈</span>Custom color…<input type="color" aria-label="Custom label color" value={editing.color} onChange={event=>publish(recolorWorkspaceLabel(normalized,editing.id,event.target.value))}/></label>
      </div>}
    </div>}
    <div className="labelManager-search"><input ref={inputRef} aria-label="Enter label name" placeholder="Enter label name…" value={query} maxLength={LABEL_NAME_LIMIT} onChange={event=>{setQuery(event.target.value);setError('');}} onKeyDown={event=>{if(event.key==='Enter'){event.preventDefault();if(matching)toggle(matching);else create();}}}/></div>
    {filtered.length>0&&<div className="labelManager-list" role="list" aria-label="Available labels"><div className="labelManager-group">{groupName}</div>{filtered.map(label=>{
      const state=labelSelectionState(normalized,boardId,selectedIds,label.id);
      return <div className="labelManager-row" role="listitem" key={label.id}>
        <div className="labelManager-assignment">
          <button type="button" className={`labelManager-check labelManager-check-${state}`} role="checkbox" aria-checked={state==='some'?'mixed':state==='all'} aria-label={label.name} onClick={()=>toggle(label)}>{state==='all'?<Check size={10}/>:state==='some'?<Minus size={10}/>:null}</button>
          {renaming&&editingId===label.id?<span className="labelManager-inlineRename" onClick={event=>event.stopPropagation()}><input ref={renameRef} aria-label="Edit name" value={draft} maxLength={LABEL_NAME_LIMIT} onChange={event=>{setDraft(event.target.value);setError('');}} onBlur={rename} onKeyDown={event=>{if(event.key==='Enter'){event.preventDefault();rename();}else if(event.key==='Escape'){event.preventDefault();event.stopPropagation();setRenaming(false);setEditingId(null);setError('');}}}/></span>:<button type="button" className="labelManager-pill" style={{background:label.color,color:labelInk(label.color)}} onClick={()=>toggle(label)}>{label.name}</button>}
        </div>
        <button type="button" className="labelManager-more" aria-label={`Open actions for ${label.name}`} title="Edit label" onClick={event=>{const row=event.currentTarget.closest<HTMLElement>('.labelManager-row');setMenuTop(row?.offsetTop||40);setEditingId(editingId===label.id?null:label.id);setRenaming(false);setColorsOpen(false);setError('');}}><MoreHorizontal size={15}/></button>
      </div>;
    })}</div>}
    {query.trim()&&!matching&&<button type="button" className="labelManager-create" onClick={create}><Plus size={13}/><span>Create label <strong>{query.trim()}</strong></span></button>}
    {!labels.length&&!query&&<div className="labelManager-empty"><div className="labelManager-illustration" aria-hidden="true"><div className="labelManager-paper"/><span className="labelManager-exampleOne">Research</span><span className="labelManager-exampleTwo">Ideas</span><Tag size={35}/></div><p>Labels let you visually categorize<br/>your content</p></div>}
    {labels.length>0&&!filtered.length&&!query.trim()&&<p className="labelManager-noResults">No labels found</p>}
    {error&&<p className="labelManager-error" role="alert">{error}</p>}
  </div>,document.body);
}

export interface LabelBadgesProps {
  labels:WorkspaceLabel[];
  labelIds?:string[];
  onRemove?:(labelId:string)=>void;
  onRename?:(labelId:string,name:string)=>void;
  onOpen?:(labelId:string)=>void;
  readOnly?:boolean;
}

/** A focused badge consumes Delete so removing a label never deletes its card. */
export function LabelBadges({labels,labelIds=[],onRemove,onRename,onOpen,readOnly=false}:LabelBadgesProps){
  const [selected,setSelected]=useState<string|null>(null);
  const [editing,setEditing]=useState<string|null>(null);
  const [draft,setDraft]=useState('');
  const visible=labels.filter(label=>labelIds.includes(label.id));
  if(!visible.length)return null;
  function save(label:WorkspaceLabel){const value=draft.trim();if(value&&value!==label.name)onRename?.(label.id,value);setEditing(null);}
  return <div className="labelBadges" aria-label="Item labels" onPointerDown={event=>event.stopPropagation()} onDoubleClick={event=>event.stopPropagation()}>
    {visible.map(label=>editing===label.id?<input className="labelBadge-rename" key={label.id} aria-label={`Rename label ${label.name}`} value={draft} autoFocus maxLength={LABEL_NAME_LIMIT} onFocus={event=>event.currentTarget.select()} onChange={event=>setDraft(event.target.value)} onBlur={()=>save(label)} onKeyDown={event=>{event.stopPropagation();if(event.key==='Enter'){event.preventDefault();save(label);}else if(event.key==='Escape'){event.preventDefault();setEditing(null);}}}/>:<span key={label.id} className={`labelBadge${selected===label.id?' labelBadge-selected':''}`} role="button" tabIndex={0} aria-label={`Label ${label.name}`} aria-pressed={selected===label.id} style={{'--label-color':label.color,color:labelInk(label.color)} as CSSProperties}
      onFocus={()=>setSelected(label.id)} onBlur={()=>setSelected(value=>value===label.id?null:value)} onClick={event=>{event.stopPropagation();setSelected(label.id);}}
      onContextMenu={event=>{event.preventDefault();event.stopPropagation();if(!readOnly)onOpen?.(label.id);}}
      onDoubleClick={event=>{event.stopPropagation();if(!readOnly&&onRename){setDraft(label.name);setEditing(label.id);}}}
      onKeyDown={event=>{event.stopPropagation();if(!readOnly&&(event.key==='Delete'||event.key==='Backspace')){event.preventDefault();onRemove?.(label.id);setSelected(null);}else if(event.key==='Enter'&&!readOnly){event.preventDefault();onOpen?.(label.id);}}}>{label.name}</span>)}
  </div>;
}
