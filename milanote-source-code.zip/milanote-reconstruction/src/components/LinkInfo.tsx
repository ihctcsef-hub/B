import {useState} from 'react';
import './link-info.css';

export function linkFaviconSource(url:string):string|undefined{
  try{const parsed=new URL(url);if(!['http:','https:'].includes(parsed.protocol))return;
    return /(^|\.)milanote\.com$/i.test(parsed.hostname)?'/assets/milanote-favicon.png':`${parsed.origin}/favicon.ico`;
  }catch{return;}
}
export function LinkInfo({url,title,description,className='link-content'}:{url:string;title:string;description:string;className?:string}){
  let href:string|undefined;try{const parsed=new URL(url);if(['http:','https:'].includes(parsed.protocol))href=parsed.href;}catch{/* An unfinished URL is text. */}
  const source=linkFaviconSource(url),[failed,setFailed]=useState<string>();
  return <div className={`${className} link-info-view`}>
    <div className="link-source-header">{source&&failed!==source?<img className="link-favicon" src={source} alt="" draggable={false} referrerPolicy="no-referrer" onError={()=>setFailed(source)}/>:<span className="link-favicon-placeholder" aria-hidden="true">↗</span>}
      <a className="link-source-url" href={href} target="_blank" rel="noreferrer" onPointerDown={event=>event.stopPropagation()}>{url}</a>
    </div>
    <div className="link-title"><a href={href} target="_blank" rel="noreferrer" onPointerDown={event=>event.stopPropagation()}><strong>{title||'Website link'}</strong></a></div>
    {description&&<p className="link-description" dir="auto">{description}</p>}
  </div>;
}
