import {TemplateLibrary} from './TemplateLibrary';
import {getCatalogPreview,instantiateCatalogTemplate,type CatalogPreview} from '../core/templateCatalog';
import type {Point,Workspace} from '../core/model';

type ApplyTemplate=(workspace:Workspace,parentId:string,at:Point)=>{workspace:Workspace;boardId?:string};
interface Props {
  onClose:()=>void;
  onPreview:(preview:CatalogPreview|undefined)=>void;
  onChoose:(apply:ApplyTemplate)=>void;
}

/** Load the complete catalog only when its picker opens. Resolve the live
 * workspace at commit time so loading or previewing cannot overwrite edits. */
export default function TemplateCatalogSession({onClose,onPreview,onChoose}:Props){
  return <TemplateLibrary onClose={onClose}
    onPreview={(id,options)=>onPreview(id?getCatalogPreview(id,options):undefined)}
    onChoose={(id,options)=>onChoose((workspace,parentId,at)=>instantiateCatalogTemplate(workspace,id,parentId,at,options))}/>;
}
