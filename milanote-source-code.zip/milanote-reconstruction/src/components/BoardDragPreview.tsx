import {useLayoutEffect,useRef} from 'react';
import {createPortal} from 'react-dom';
import type {Card,Point} from '../core/model';
import './board-drag-preview.css';

export interface BoardDragPreviewState {element:HTMLElement;client:Point;grab:Point;zoom:number}

/** Capture the already rendered cards. This keeps editor refs, media controls,
 * and clipboard handlers out of the read-only drag image. */
export function captureBoardDragPreview(stage:HTMLElement,cards:Card[]):HTMLElement {
  const element=document.createElement('div');element.className='world board-drag-preview-world';
  const x=Math.min(...cards.map(card=>card.x)),y=Math.min(...cards.map(card=>card.y));
  const rendered=new Map([...stage.querySelectorAll<HTMLElement>('[data-card-id]')].map(node=>[node.dataset.cardId,node]));
  for(const card of cards){
    const source=rendered.get(card.id);if(!source)continue;
    const clone=source.cloneNode(true) as HTMLElement;
    clone.removeAttribute('data-card-id');clone.removeAttribute('id');clone.removeAttribute('tabindex');
    clone.querySelectorAll('[id]').forEach(node=>node.removeAttribute('id'));
    clone.querySelectorAll('[data-card-id],[data-connection-id]').forEach(node=>{node.removeAttribute('data-card-id');node.removeAttribute('data-connection-id');});
    clone.querySelectorAll('[contenteditable]').forEach(node=>node.setAttribute('contenteditable','false'));
    clone.querySelectorAll('audio,video').forEach(media=>{media.removeAttribute('autoplay');media.setAttribute('preload','none');});
    clone.style.left=`${card.x-x}px`;clone.style.top=`${card.y-y}px`;
    element.append(clone);
  }
  return element;
}

export function BoardDragPreview({element,client,grab,zoom}:BoardDragPreviewState){
  const host=useRef<HTMLDivElement>(null);
  useLayoutEffect(()=>{host.current?.replaceChildren(element);return()=>element.remove();},[element]);
  return createPortal(<div className="app reference-layout board-drag-preview" aria-hidden="true" inert style={{left:client.x-grab.x*zoom,top:client.y-grab.y*zoom}}><div ref={host} style={{transform:`scale(${zoom})`,transformOrigin:'0 0'}}/></div>,document.body);
}
