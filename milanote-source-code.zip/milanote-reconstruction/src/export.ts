import type { Board, Card, Connection, Workspace } from "./core";
import { exportNotePlainText } from "./core/text";
import {
  noteContentHtml,
  richHtmlToMarkdown,
  richHtmlToPlainText,
} from "./core/richText";
import { bakeImageEdits } from "./core/imageEditing";
import { connectionBounds, connectionGeometry } from "./core/lines";
import { mediaEmbedUrl } from "./core/media";
import { workspaceBoard } from "./core/shortcuts";
import { displayColor, swatchInk } from "./core/colors";
import {filePreviewKind,fileDetailHeight,pdfPreviewHeight,attachmentSizeLabel} from './core/filePreview';
import {linkPreviewHeight} from './core/linkPreview';
import linkInfoCss from './components/link-info.css?raw';
import {boardIconDisplaySource,selectedBoardIconId} from './core/boardIcons';
import { isTodoDate, isTodoTime, taskIndent, type TodoTask } from "./core/todo";
import {
  cellKey,
  evaluateTable,createFormulaWorkbook,reconcileFormulaWorkbook,formulaContextForTable,
  type FormulaWorkbookContext,
  normalizeTableMeta,
  type TableCellMeta,
} from "./core/spreadsheet";

const escape = (value: unknown): string =>
  String(value ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ]!,
  );
const number = (value: number, fallback = 0): number =>
  Number.isFinite(value) ? value : fallback;
const alignment = (value: string | undefined): "left" | "center" | "right" =>
  value === "center" || value === "right" ? value : "left";
const color = (value: string | undefined, fallback = "#ffffff"): string =>
  value &&
  /^(#[\da-f]{3,8}|[a-z]{1,24}|rgba?\([\d\s.,%]+\)|hsla?\([\d\s.,%]+\))$/i.test(
    value,
  )
    ? value
    : fallback;
function safeUrl(value: string, image = false): string {
  if (
    image &&
    /^data:image\/(?:png|jpeg|gif|webp|avif);base64,[a-z\d+/=\s]+$/i.test(value)
  )
    return value;
  try {
    const url = new URL(value);
    return ["https:", "http:"].includes(url.protocol) ? url.href : "";
  } catch {
    return "";
  }
}
export interface VisualExportOptions {
  formulaWorkbook?:FormulaWorkbookContext;
  workspace?: Pick<Workspace, "boards" | "labels">;
  /** Binary captures crop to content; portable HTML/SVG retain the canvas layout by default. */
  bounds?: "canvas" | "content";
}
/** Icon images are stored as raster data, so portable exports never interpolate active SVG markup. */
export function exportIconImageSource(icon?: string): string {
  return /^data:image\/(?:png|jpeg|gif|webp|avif);base64,/i.test(icon || "") ? safeUrl(icon!, true) : "";
}
function iconText(icon?: string): string { return icon && !/^(?:data:|https?:|\/)/i.test(icon) ? icon : ""; }
function iconHtml(icon?: string): string {
  const source = selectedBoardIconId(icon)?boardIconDisplaySource(icon):exportIconImageSource(icon);
  return source ? `<img class="export-board-icon" alt="" src="${escape(source)}"/>` : escape(iconText(icon));
}
function safeDownloadUrl(value: string | undefined): string {
  if(value&&/^https?:/i.test(value))return safeUrl(value);
  // Downloads may contain any file MIME type, but never executable URL schemes.
  if (
    !value ||
    !/^data:(?:[a-z\d!#$&^_.+-]+\/[a-z\d!#$&^_.+-]+)?(?:;[a-z\d._-]+=[a-z\d._%-]+)*(?:;base64)?,/i.test(
      value,
    )
  )
    return "";
  const comma = value.indexOf(","),
    header = value.slice(0, comma),
    payload = value.slice(comma + 1);
  if (/;base64$/i.test(header))
    return /^[a-z\d+/]*={0,2}$/i.test(payload.replace(/\s/g, ""))
      ? `${header},${payload.replace(/\s/g, "")}`
      : "";
  return /[\u0000-\u001f\u007f]/.test(payload) ||
    /%(?![a-f\d]{2})/i.test(payload)
    ? ""
    : value;
}
export function visibleCards(board: Board): Card[] {
  const byId = new Map(board.cards.map((card) => [card.id, card]));
  const hidden = (card: Card): boolean => {
    const seen = new Set([card.id]);
    if (card.unsorted) return true;
    let parentId = card.parentId;
    while (parentId && !seen.has(parentId)) {
      seen.add(parentId);
      const parent = byId.get(parentId);
      if (!parent) break;
      if (parent.unsorted || parent.collapsed) return true;
      parentId = parent.parentId;
    }
    return false;
  };
  return board.cards.filter((card) => !hidden(card)).sort((a, b) => a.z - b.z);
}
const cardHeight = (card: Card): number =>
  card.type === "column" && card.collapsed ? 62.2 : number(card.height, 170);
export function boardExportBounds(board: Board, options: VisualExportOptions = {}): {
  x: number;
  y: number;
  width: number;
  height: number;
} {
  const cards = visibleCards(board);
  const lines = board.connections.map(connection => connectionBounds(connection, cards, Math.max(10, number(connection.width ?? 1.6) * 3))).filter((line): line is NonNullable<typeof line> => !!line);
  const labelAreas = board.connections.filter(connection => connection.label).flatMap(connection => {
    const geometry = connectionGeometry(connection, cards);
    return geometry ? [{ x: geometry.midpoint.x - connection.label!.length * 3.5, y: geometry.midpoint.y - 24, width: connection.label!.length * 7, height: 20 }] : [];
  });
  const extras = [...lines, ...labelAreas];
  if (options.bounds === "content" && (cards.length || extras.length)) {
    const x = Math.min(...cards.map(c => number(c.x)), ...extras.map(extra => extra.x)) - 32;
    const y = Math.min(...cards.map(c => number(c.y)), ...extras.map(extra => extra.y)) - 32;
    return {
      x, y,
      width: Math.max(...cards.map(c => number(c.x) + number(c.width, 240)), ...extras.map(extra => extra.x + extra.width)) - x + 32,
      height: Math.max(...cards.map(c => number(c.y) + cardHeight(c) + tagHeight(c, options)), ...extras.map(extra => extra.y + extra.height)) - y + 32,
    };
  }
  const x = Math.min(0, ...cards.map(c => number(c.x)), ...extras.map(extra => extra.x)) - 36;
  const y = Math.min(0, ...cards.map(c => number(c.y)), ...extras.map(extra => extra.y)) - 36;
  return {
    x, y,
    width: Math.max(800, ...cards.map(c => number(c.x) + number(c.width, 240)), ...extras.map(extra => extra.x + extra.width)) - x + 36,
    height: Math.max(500, ...cards.map(c => number(c.y) + cardHeight(c) + tagHeight(c, options)), ...extras.map(extra => extra.y + extra.height)) - y + 36,
  };
}
function sketchSvg(card: Extract<Card, { type: "sketch" }>): string {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${number(card.width, 320)} ${number(card.height, 230)}" width="100%" height="100%" style="display:block;background:${color(card.background)}">${card.paths.map((path) => `<polyline points="${path.points.map((p) => `${number(p.x)},${number(p.y)}`).join(" ")}" stroke="${color(path.color, "#333333")}" stroke-width="${Math.max(0.5, Math.min(40, number(path.width, 2)))}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`).join("")}</svg>`;
}
function tableForExport(card: Extract<Card, { type: "table" }>,board:Board,options:VisualExportOptions={}) {
  const meta = normalizeTableMeta(card.cellMeta, card.rows);
  const tables=board.cards.filter(item=>item.type==='table');
  const workbook=options.formulaWorkbook?reconcileFormulaWorkbook(options.formulaWorkbook,tables):createFormulaWorkbook(tables);
  return { rows: evaluateTable(card.rows, meta,formulaContextForTable(workbook,card.id,{errorDisplay:'codes'})), meta };
}
function tableCellStyle(meta?: TableCellMeta): string {
  if (!meta) return "";
  const declarations: string[] = [];
  if (meta.color && /^#[\da-f]{3}(?:[\da-f]{3})?$/i.test(meta.color))
    declarations.push(`background:${meta.color}`);
  if (["left", "center", "right"].includes(meta.align ?? ""))
    declarations.push(`text-align:${meta.align}`);
  if (["top", "middle", "bottom"].includes(meta.verticalAlign ?? "")) declarations.push(`vertical-align:${meta.verticalAlign}`);
  if (typeof meta.bold === "boolean")
    declarations.push(`font-weight:${meta.bold ? "700" : "400"}`);
  if (typeof meta.italic === "boolean")
    declarations.push(`font-style:${meta.italic ? "italic" : "normal"}`);
  return declarations.length ? ` style="${declarations.join(";")}"` : "";
}
function taskDue(task: TodoTask): string {
  if (!isTodoDate(task.dueDate)) return "";
  return `Due: ${task.dueDate}${isTodoTime(task.reminderTime) ? ` ${task.reminderTime}` : ""}`;
}
function cardTags(card: Card): string[] {
  return [...new Set((card.tags || []).filter(tag => typeof tag === "string" && tag.trim()))];
}
export function exportCardLabels(card: Card, options: VisualExportOptions = {}): { name: string; color?: string }[] {
  const registry = options.workspace?.labels;
  return registry && card.labelIds !== undefined
    ? registry.filter(label => card.labelIds!.includes(label.id)).map(label => ({ name: label.name, color: /^#[\da-f]{6}$/i.test(label.color) ? label.color : undefined }))
    : cardTags(card).map(name => ({ name }));
}
export function exportLabelInk(value: string): string {
  const channels = /^#([\da-f]{2})([\da-f]{2})([\da-f]{2})$/i.exec(value)?.slice(1).map(channel => {
    const part = parseInt(channel, 16) / 255; return part <= .04045 ? part / 12.92 : ((part + .055) / 1.055) ** 2.4;
  });
  return channels && .2126 * channels[0] + .7152 * channels[1] + .0722 * channels[2] <= .28 ? "#ffffff" : "#323b4a";
}
let labelMeasureContext: CanvasRenderingContext2D | undefined;
function tagHeight(card: Card, options: VisualExportOptions = {}): number {
  const labels = exportCardLabels(card, options);
  if (!labels.length) return 0;
  if (!options.workspace?.labels || card.labelIds === undefined) return 18;
  if (!labelMeasureContext && typeof document !== "undefined") labelMeasureContext = document.createElement("canvas").getContext("2d") || undefined;
  if (labelMeasureContext) labelMeasureContext.font = "9px Inter,Arial,sans-serif";
  const available = Math.max(1, card.width - 12);
  let rows = 1, used = 0;
  for (const label of labels) {
    const width = Math.min(available, (labelMeasureContext?.measureText(label.name).width ?? label.name.length * 5.4) + 10);
    if (used && used + 3 + width > available) { rows++; used = width; }
    else used += (used ? 3 : 0) + width;
  }
  return 4 + rows * 14 + (rows - 1) * 3;
}
function tagsHtml(card: Card, options: VisualExportOptions = {}): string {
  if (options.workspace?.labels && card.labelIds !== undefined) {
    const labels = exportCardLabels(card, options);
    return labels.length ? `<div class="card-tags card-global-labels" aria-label="Item labels">${labels.map(label => `<span dir="auto" style="background:${label.color || "#dfe8f8"};color:${exportLabelInk(label.color || "#dfe8f8")}">${escape(label.name)}</span>`).join("")}</div>` : "";
  }
  const tags = cardTags(card);
  return tags.length ? `<div class="card-tags" aria-label="Item labels">${tags.map(tag => `<span dir="auto">${escape(tag)}</span>`).join("")}</div>` : "";
}
function cardContentHtml(card: Card, board: Board, xhtml = false, options: VisualExportOptions = {}): string {
  return `${card.stripColor?`<div class="card-top-strip" style="background:${color(card.stripColor)}"></div>`:''}<div class="card-content"${card.stripColor?' style="height:calc(100% - 4px);margin-top:4px"':''}>${cardHtml(card, board, xhtml, options)}</div>${tagsHtml(card, options)}`;
}
function captionHtml(card:Extract<Card,{type:"image"|"link"}>,xhtml=false):string{const html=noteContentHtml(card.caption||"",card.captionHtml);return xhtml?html.replace(/<br>/g,"<br/>"):html;}
function cardHtml(card: Card, board: Board, xhtml = false, options: VisualExportOptions = {}): string {
  switch (card.type) {
    case "note": {
      const html = noteContentHtml(card.text, card.html);
      return `<div class="pad text" dir="auto" style="text-align:${alignment(card.align)}">${card.isDocument ? `<h2 class="document-title">${escape(card.title || "Untitled document")}</h2>` : ""}${xhtml ? html.replace(/<br>/g, "<br/>") : html}</div>${card.syncedId ? '<small class="note-sync">Synced note</small>' : ""}`;
    }
    case "label":
      return `<div class="label" dir="auto">${escape(card.text)}</div>`;
    case "image": {
      const src = safeUrl(card.src, true);
      return `<div class="image-layout">${src ? `<img class="export-image" alt="${escape(card.caption)}" src="${escape(src)}"/>` : '<div class="empty">Image</div>'}${card.showCaption !== false ? `<div class="caption" dir="auto">${captionHtml(card,xhtml)}</div>` : ""}</div>`;
    }
    case "link": {
      const href = safeUrl(card.url);
      const preview = safeUrl(card.previewSrc || "", true);
      let media = false;
      try { media = !!card.showMedia && !!mediaEmbedUrl(card.url); } catch { /* An invalid provider URL remains ordinary link text. */ }
      const height=card.autoHeight===true&&card.previewWidth&&card.previewHeight?linkPreviewHeight(card.width,card.previewWidth,card.previewHeight):undefined;
      const favicon=safeUrl(card.faviconSrc||'',true);
      return `${media && href ? `<div class="media-placeholder"><a href="${escape(href)}" target="_blank" rel="noopener noreferrer">Open linked media ↗</a></div>` : card.showPreview !== false ? `<div class="link-preview"${height!==undefined?` style="height:${height}px;aspect-ratio:auto"`:''}>${preview ? `<img alt="Link preview" src="${escape(preview)}"${height!==undefined?' style="height:100%"':''}/>` : '<span class="link-symbol" aria-label="Web link">↗</span>'}</div>` : ""}${card.showInfo !== false ? `<div class="link-info link-content link-info-view"><div class="link-source-header">${favicon?`<img class="link-favicon" alt="" src="${escape(favicon)}"/>`:'<span class="link-favicon-placeholder" aria-hidden="true">↗</span>'}<a class="link-source-url"${href?` href="${escape(href)}"`:''} target="_blank" rel="noopener noreferrer">${escape(card.url)}</a></div><div class="link-title"><a${href?` href="${escape(href)}"`:''} target="_blank" rel="noopener noreferrer"><strong dir="auto">${escape(card.title || card.url || "Link")}</strong></a></div>${card.description ? `<p class="link-description" dir="auto">${escape(card.description)}</p>` : ""}</div>` : ""}${card.showInfo !== false && card.showCaption ? `<div class="caption" dir="auto">${captionHtml(card,xhtml)}</div>` : ""}`;
    }
    case "todo":
      return `<div class="todo-layout">${card.title ? `<strong class="todo-title" dir="auto">${escape(card.title)}</strong>` : ""}<ul class="todos">${card.items.map((item) => `<li class="${item.done ? "done" : ""}" dir="auto" style="margin-inline-start:${taskIndent(item) * 20}px"><div class="task-line"><span class="task-checkbox" aria-label="${item.done ? "Complete" : "Incomplete"}">${item.done ? "☑" : "☐"}</span><span class="task-text">${escape(item.text)}</span></div>${taskDue(item) ? `<small class="task-due">${escape(taskDue(item))}</small>` : ""}</li>`).join("")}</ul></div>`;
    case "column":
      return `<div class="column-title" dir="auto"><strong>${escape(card.title)}</strong><small>${board.cards.filter((c) => c.parentId === card.id).length} cards${card.collapsed ? " · collapsed" : ""}</small></div>`;
    case "board":
      return `<div class="pad board-tile"><span class="board-icon">${iconHtml(options.workspace?workspaceBoard(options.workspace,card.boardId)?.icon:undefined) || "▦"}</span><strong dir="auto">${escape(card.title)}</strong><small>Nested board</small></div>`;
    case "file": {
      const href=safeDownloadUrl(card.dataUrl||card.sourceUrl),preview=safeUrl(card.previewSrc||card.poster||'',true);
      const glyph='<svg class="file-glyph" viewBox="0 0 32 40" aria-hidden="true"><path d="M1 1h21l9 9v29H1z" fill="#fff" stroke="#c9cdd3" stroke-width="1.5"/><path d="M22 1v9h9" fill="#e8e9eb" stroke="#c9cdd3" stroke-width="1.5"/><path d="M8 19h16M8 24h16M8 29h11" fill="none" stroke="#a2a8b0" stroke-width="1.5"/></svg>';
      const name=`<strong class="file-name" dir="auto">${escape(card.name)}</strong>`,size=escape(attachmentSizeLabel(card.size));
      if(card.showPreview===false||!preview)return `<div class="file-icon-view"><div class="file-icon-large">${glyph}</div>${name}<small>${size}</small>${href?`<a class="file-icon-download" href="${escape(href)}" download="${escape(card.name)}" aria-label="Download ${escape(card.name)}"></a>`:''}</div>`;
      const frame=card.autoHeight===true&&card.previewWidth&&card.previewHeight?pdfPreviewHeight(card.width,card.previewWidth,card.previewHeight):Math.max(6,card.height-fileDetailHeight(0,card));
      return `<div class="file-detail-view"><img class="file-first-page" alt="${escape(card.name)} — page 1" src="${escape(preview)}" style="height:${frame}px"/>${card.showFileInfo!==false?`<div class="file-metadata"><div class="file-glyph-wrap">${glyph}</div><div class="file-details">${name}<div class="file-secondary">${href?`<a href="${escape(href)}" download="${escape(card.name)}">Download</a> - <a href="${escape(href)}" target="_blank" rel="noopener noreferrer">Open</a> - `:''}${size}</div></div></div>${card.showCaption?`<div class="file-caption">${noteContentHtml(card.caption||'',card.captionHtml)}</div>`:''}`:''}</div>`;
    }
    case "swatch": {
      const caption = noteContentHtml(card.label, card.captionHtml), height = Math.max(16, Math.min(2400, number(card.captionHeight ?? 48, 48)));
      return `<div class="swatch-layout"><div class="swatch" style="background:${color(card.value, "#b7c3a5")};color:${swatchInk(card.value)}">${card.showValue !== false ? `<span class="swatch-code">${escape(displayColor(card.value, card.colorSpace))}</span>` : ""}</div>${card.showCaption !== false ? `<div class="swatch-caption text" dir="auto" style="height:${height}px">${xhtml ? caption.replace(/<br>/g, "<br/>") : caption}</div>` : ""}</div>`;
    }
    case "sketch":
      return sketchSvg(card);
    case "table": {
      const { rows, meta } = tableForExport(card,board,options);
      const widths=card.columnWidths?.length===Math.max(1,...rows.map(row=>row.length))&&card.columnWidths.every(width=>Number.isFinite(width)&&width>=40&&width<=2400)?card.columnWidths:undefined;
      const columns=widths?`<colgroup>${widths.map(width=>`<col style="width:${width/widths.reduce((sum,value)=>sum+value,0)*100}%"/>`).join("")}</colgroup>`:"";
      return `<div class="export-table">${card.title ? `<strong class="table-title" dir="auto">${escape(card.title)}</strong>` : ""}<table${card.title ? ' style="height:calc(100% - 30px)"' : ""}>${columns}${rows.map((row, rowIndex) => `<tr>${row.map((cell, column) => `<td dir="auto"${tableCellStyle(meta[cellKey(rowIndex, column)])}>${escape(cell)}</td>`).join("")}</tr>`).join("")}</table></div>`;
    }
  }
}
function linePath(connection: Connection, cards: Card[]): { path: string; x: number; y: number } | null {
  const geometry = connectionGeometry(connection, cards);
  return geometry ? { path: geometry.path, x: geometry.midpoint.x, y: geometry.midpoint.y } : null;
}
function connectionsSvg(board: Board, cards: Card[]): string {
  return `<defs><marker id="export-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="context-stroke"/></marker></defs>${board.connections
    .map((connection) => {
      const line = linePath(connection, cards);
      if (!line) return "";
      return `<path d="${line.path}" fill="none" stroke="${color(connection.color, "#758170")}" stroke-width="${Math.max(0.8, Math.min(12, number(connection.width ?? 1.6)))}" ${connection.style === "dashed" ? 'stroke-dasharray="5 5"' : ""} ${connection.startArrow ? 'marker-start="url(#export-arrow)"' : ""} ${connection.endArrow !== false ? 'marker-end="url(#export-arrow)"' : ""}/>${connection.label ? `<text x="${line.x}" y="${line.y - 8}" fill="#4c5549" text-anchor="middle" font-size="13" font-family="Arial, sans-serif" paint-order="stroke" stroke="#f5f3ef" stroke-width="5">${escape(connection.label)}</text>` : ""}`;
    })
    .join("")}`;
}
const styles = `
*{box-sizing:border-box}
body{margin:0;background:#ebedee;color:#323b4a;font:11.2px/16px Inter,Arial,sans-serif}
h1{font:500 30px Georgia,serif;margin:0 0 24px}.sheet{padding:32px}.canvas{position:relative}
.card{position:absolute;overflow:visible;background:#fff;border:1px solid #dfe1e4;border-radius:2px;box-shadow:0 2px 5px #0000000b;color:#323b4a;font:11.2px/16px Inter,Arial,sans-serif}
.card-content{height:100%;overflow:hidden;border-radius:inherit}.card-top-strip{position:absolute;left:0;right:0;top:0;height:4px;pointer-events:none}.card.column{background:#eae7e1;box-shadow:none}.card.label{border:0;box-shadow:none;background:transparent}.card.note,.card.table,.card.swatch{border:0}
.pad{padding:18px}.card .pad.text{padding:19px 15.3px 11px 19.2px}.text{overflow-wrap:anywhere}.text p{margin:0 0 8px;color:inherit;font:inherit}.text h1,.text h2,.text h3,.text h4,.text h5,.text h6{font-family:inherit;line-height:1.3;margin:0 0 8px}.text h1{font-size:16px;line-height:24px;font-weight:600;margin:-4.8px 0 4.8px}.text h2{font-size:12.8px;line-height:20px;font-weight:600;margin:-3px 0 7px}.text h3{font-size:17px}.text h4,.text h5,.text h6{font-size:15px}.text ul,.text ol{margin:0 0 8px;padding-inline-start:20px}.text code{font:10px ui-monospace,monospace;background:#eef0f3;border-radius:2px;padding:1px 3px}.text a{color:#4d78cc;text-decoration:underline;overflow-wrap:anywhere}.text pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f1f3f5;padding:10px}.text aside[data-note-callout="true"]{background:#eef2f8;padding:12px 14px;border-radius:3px;margin:8px 0;border-left:3px solid #7696cd}.note-sync{position:absolute;right:5px;top:3px;font-size:8px;line-height:10px;color:#7a8699}.document-title{font-size:14px!important;font-weight:600;margin-bottom:8px!important}.text blockquote{margin:8px 0;padding-inline-start:10px;border-inline-start:3px solid #a4b1c5;color:#5b6575}
.label{padding:6px 2px;font-weight:600;font-size:21px}.card-tags{position:absolute;left:6px;top:100%;padding-top:3px;display:flex;gap:3px;white-space:nowrap;font:9px/14px Inter,Arial,sans-serif;max-width:100%;overflow:hidden}.card-tags span{padding:0 4px;border-radius:3px;background:#dfe8f8;color:#4f6387}.card-global-labels{padding-top:4px;flex-wrap:wrap;white-space:normal;max-width:calc(100% - 12px)}.card-global-labels span{padding:0 5px;white-space:nowrap;max-width:100%;overflow:hidden;text-overflow:ellipsis}
.image-layout{display:flex;flex-direction:column;height:100%}.image-layout img{display:block;width:100%;height:auto;min-height:0;flex:1;object-fit:cover}.caption p{margin:0}.caption a{color:#557cb8;text-decoration:underline}.caption{padding:8px 12px;font-size:11.2px;line-height:16px;color:#838b98}.image-layout .caption{height:35px;min-height:35px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;padding:9px 12px}.empty{display:grid;place-items:center;flex:1;min-height:20px;background:#e9ece5;color:#73786e}
.media-placeholder{height:46%;min-height:48px;display:flex;align-items:center;justify-content:center;background:#e6e9ee;padding:14px}.media-placeholder a{color:#4d78cc;overflow-wrap:anywhere}.link-preview{height:46%;min-height:24px;overflow:hidden;background:#e6e9ee;display:flex;align-items:center;justify-content:center}.link-preview img{display:block;width:100%;height:100%;object-fit:cover}.link-symbol{color:#8d97a4;font-size:24px}.link-auto>.link-preview,.link-auto>.media-placeholder{height:auto;aspect-ratio:16/9;min-height:0}.link-auto>.link-preview:has(img){aspect-ratio:auto;display:block}.link-auto>.link-preview img{height:auto}.link-auto .link-info a{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.link-info{padding:14px 18px}.link-info p{font-size:11px;color:#838b98;margin:8px 0 10px}.link-info a{color:#727f94;font-size:10px;display:block;overflow-wrap:anywhere}
.todo-layout{padding:15px 18px 15px 19px}.todo-title{display:block;height:30px;line-height:20px}.todos{list-style:none;margin:0;padding:0}.todos li{margin:0;min-height:24px}.task-line{display:flex;align-items:flex-start;gap:8px;padding:4px 0;line-height:16px}.task-checkbox{flex-shrink:0;width:13px;color:#465061}.task-text{white-space:pre-wrap;overflow-wrap:anywhere}.done .task-text{text-decoration:line-through;color:#a2a59d}.task-due{display:block;padding:0 0 4px 21px;line-height:16px;font-size:10px;color:#7d8797}
.column-title{padding:14px 16px;border-bottom:1px solid #dcd8cf}.column-title small{float:right}.board-tile{display:flex;flex-direction:column;align-items:center;gap:8px}.board-icon{font-size:36px;color:#8b9e7b}.export-board-icon{display:inline-block;width:28px;height:28px;object-fit:contain;vertical-align:middle}.board-tile .export-board-icon{width:44px;height:44px}.eyebrow{font-size:10px;letter-spacing:1.4px;color:#999d94;margin-bottom:10px}.pad p{color:#7c8077;font-size:12px}.pad:not(.text) a{display:block;color:#6d7f60;font-size:11px;overflow-wrap:anywhere}.pad.text p{color:inherit;font:inherit}small{font-size:11px;color:#8a8e84}.pad small{display:block}
.swatch-layout{display:flex;flex-direction:column;height:100%}.swatch-layout>.swatch{flex:1;min-height:20px;display:flex;align-items:center;justify-content:center}.swatch-code{padding:10px;font-size:11.2px;line-height:16px;text-align:center;overflow-wrap:anywhere}.swatch-caption{height:48px;min-height:16px;flex-shrink:0;padding:16px 15px;overflow:hidden;font-size:11.2px;line-height:16px}.swatch-caption p{margin:0}.swatch-caption a{color:#557cb8;text-decoration:underline}
.export-table{height:100%;padding:0}.table-title{display:block;height:30px;padding:7px 8px;line-height:16px;overflow:hidden}.export-table table{margin:0;height:100%;table-layout:fixed;width:100%;border-collapse:collapse;font:11.2px/16px Inter,Arial,sans-serif}.export-table td{height:auto;padding:3px 6px;border:1px solid #d9d9d9;background:#fff;font-weight:400;vertical-align:middle;overflow:hidden;overflow-wrap:normal;white-space:nowrap;text-overflow:clip}.export-table td:first-child{border-left:0}.export-table td:last-child{border-right:0}.export-table tr:first-child td{border-top:0}.export-table tr:last-child td{border-bottom:0}
@media print{body{background:white}.sheet{padding:0}h1{font-size:24px}.canvas{break-inside:avoid}.card{box-shadow:none}a{color:inherit}}

.file-detail-view{display:flex;flex-direction:column;width:100%;height:100%;font-family:Inter,Arial,sans-serif;color:#323b4a}.file-first-page{width:100%;object-fit:cover;display:block;flex:none}.file-metadata{display:flex;min-height:72.375px;padding:20.2px 19.2px;flex:none;box-sizing:border-box}.file-glyph-wrap{width:25.6px;height:32px;flex:none}.file-glyph{display:block;width:100%;height:100%}.file-details{min-width:0;flex:1;margin:-1px 0 0 9.6px;padding-top:3px}.file-name{display:block;font:600 12px/16px Inter,Arial,sans-serif;overflow-wrap:anywhere}.file-secondary{font:400 9.6px/12px Inter,Arial,sans-serif;color:#8d929a;white-space:nowrap}.file-secondary a{color:inherit;text-decoration:none}.file-caption{min-height:32px;padding:8px 19.2px;box-sizing:border-box;box-shadow:inset 0 1px #e8e9eb;font:11.2px/16px Inter,Arial,sans-serif}.file-caption p{margin:0}.file-icon-view{position:relative;text-align:center;padding:7.2px 8px 8px;font-family:Inter,Arial,sans-serif}.file-icon-large{width:57.6px;height:57.6px;margin:0 auto 4.8px;padding:9.6px 5.3px 1px;box-sizing:border-box}.file-icon-view .file-name{margin:0 -40px 3px;padding:3px 3px 2px}.file-icon-view small{font:9.6px/9.6px Inter,Arial,sans-serif;color:#8d929a}.file-icon-download{position:absolute;inset:0}

${linkInfoCss}
`;

/** A self-contained board snapshot with escaped text and sanitized rich note content.
 * Call prepareBoardForExport first to embed resources and flatten image edits.
 * Interactive provider embeds are represented as safe links in portable snapshots.
 */
export function exportBoardHtml(board: Board, options: VisualExportOptions = {}): string {
  const area = boardExportBounds(board, options),
    cards = visibleCards(board);
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escape(board.title)}</title><style>${styles}</style></head><body style="background:${color(board.background, "#f5f3ef")}"><main class="sheet"><h1 dir="auto">${board.icon ? `${iconHtml(board.icon)} ` : ""}${escape(board.title)}</h1><div class="canvas" style="width:${area.width}px;height:${area.height}px"><svg xmlns="http://www.w3.org/2000/svg" style="position:absolute;inset:0;overflow:visible" width="${area.width}" height="${area.height}" viewBox="${area.x} ${area.y} ${area.width} ${area.height}">${connectionsSvg(board, cards)}</svg>${cards.map((card) => `<section class="card ${card.type}${card.type==='link'&&card.autoHeight===true?' link-auto':''}" style="left:${number(card.x) - area.x}px;top:${number(card.y) - area.y}px;width:${number(card.width, 240)}px;height:${cardHeight(card)}px;background:${card.type === "label" ? "transparent" : color(card.color, card.type === "column" ? "#eae7e1" : "#ffffff")};z-index:${Math.max(0, Math.round(number(card.z)))}">${cardContentHtml(card, board, false, options)}</section>`).join("")}</div></main></body></html>`;
}

/** SVG with XHTML card content; preserves text, images, tables, and hand-drawn paths. */
export function exportBoardSvg(board: Board, options: VisualExportOptions = {}): string {
  const area = boardExportBounds(board, options),
    cards = visibleCards(board), iconSource = exportIconImageSource(board.icon);
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${area.width}" height="${area.height + 70}" viewBox="${area.x} ${area.y - 70} ${area.width} ${area.height + 70}"><title>${escape(board.title)}</title><rect x="${area.x}" y="${area.y - 70}" width="${area.width}" height="${area.height + 70}" fill="${color(board.background, "#f5f3ef")}"/>${iconSource ? `<image href="${escape(iconSource)}" x="${area.x + 32}" y="${area.y - 50}" width="28" height="28"/>` : ""}<text x="${area.x + (iconSource ? 70 : 32)}" y="${area.y - 22}" font-family="Georgia,serif" font-size="28" fill="#30332e">${iconText(board.icon) ? `${escape(iconText(board.icon))} ` : ""}${escape(board.title)}</text>${connectionsSvg(board, cards)}${cards.map((card) => `<foreignObject x="${number(card.x)}" y="${number(card.y)}" width="${number(card.width, 240)}" height="${cardHeight(card) + tagHeight(card, options)}"><div xmlns="http://www.w3.org/1999/xhtml" class="card ${card.type}${card.type==='link'&&card.autoHeight===true?' link-auto':''}" style="position:relative;width:100%;height:${cardHeight(card)}px;background:${card.type === "label" ? "transparent" : color(card.color, card.type === "column" ? "#eae7e1" : "#ffffff")}"><style>${styles}</style>${cardContentHtml(card, board, true, options)}</div></foreignObject>`).join("")}</svg>`;
}

const markdownText = (value: string): string =>
  escape(value).replace(/[\\`*{}\[\]()#+.!_|-]/g, "\\$&");
const markdownCell = (value: string): string =>
  markdownText(value).replace(/\r?\n/g, " ");
const markdownDestination = (value: string): string =>
  value.replace(/[<>\\\s]/g, (character) => encodeURIComponent(character));
const fileSummary = (card: Extract<Card, { type: "file" }>): string =>
  `${card.mime || "File"} · ${number(card.size)} bytes`;

/** Reading order keeps each column's cards beneath its heading. */
export function cardsInReadingOrder(board: Board): { card: Card; depth: number }[] {
  const cards = visibleCards(board).sort(
      (a, b) => a.y - b.y || a.x - b.x || a.z - b.z,
    ),
    ids = new Set(cards.map((card) => card.id)),
    visited = new Set<string>(),
    output: { card: Card; depth: number }[] = [];
  const visit = (card: Card, depth: number) => {
    if (visited.has(card.id)) return;
    visited.add(card.id);
    output.push({ card, depth });
    for (const child of cards.filter(
      (candidate) => candidate.parentId === card.id,
    ))
      visit(child, depth + 1);
  };
  for (const card of cards.filter(
    (candidate) => !candidate.parentId || !ids.has(candidate.parentId),
  ))
    visit(card, 0);
  // A malformed containment cycle must not lose the cards from an export.
  for (const card of cards) visit(card, 0);
  return output;
}

export interface LinearExportOptions extends VisualExportOptions {
  includeSubBoards?: boolean;
}

/** Enumerates referenced boards once, in the reading order of their visible tiles. */
export function boardsForLinearExport(board: Board, options: LinearExportOptions = {}): Board[] {
  if (!options.includeSubBoards) return [board];
  if (!options.workspace) throw new Error("Including sub-boards requires the workspace.");
  const output: Board[] = [], seen = new Set<string>();
  const visit = (current: Board) => {
    if (seen.has(current.id)) return;
    seen.add(current.id); output.push(current);
    for (const { card } of cardsInReadingOrder(current)) {
      if (card.type !== "board") continue;
      const nested = workspaceBoard(options.workspace!,card.boardId);
      // Deleted shortcut targets have no content to export; cycles are visited once.
      if (nested) visit(nested);
    }
  };
  visit(board); return output;
}

/** A portable text representation of every visible card, grouped by column. */
export function exportBoardMarkdown(board: Board, options: LinearExportOptions = {}): string {
  if (options.includeSubBoards) return boardsForLinearExport(board, options).map(current => exportBoardMarkdown(current, { workspace: options.workspace,formulaWorkbook:options.formulaWorkbook }).trimEnd()).join("\n\n---\n\n") + "\n";
  const parts = [`# ${markdownText(board.title)}`];
  for (const { card, depth } of cardsInReadingOrder(board)) {
    const heading = "#".repeat(Math.min(6, depth + 2));
    switch (card.type) {
      case "note":
        // Keep note markers, including ~~strike~~ and the ++underline++ extension.
        // Source HTML remains ordinary text and unsupported links are escaped.
        parts.push(
          [card.isDocument ? `${heading} ${markdownText(card.title || "Untitled document")}` : "", card.syncedId ? "Synced note" : "", typeof card.html === "string"
            ? richHtmlToMarkdown(card.html)
            : escape(card.text).replace(/[\\\[\]]/g, "\\$&")].filter(Boolean).join("\n\n"),
        );
        break;
      case "label":
        parts.push(`${heading} ${markdownText(card.text)}`);
        break;
      case "column":
        parts.push(
          `${heading} ${markdownText(card.title)}${card.collapsed ? " (collapsed)" : ""}`,
        );
        break;
      case "todo":
        parts.push(
          `${card.title ? `${heading} ${markdownText(card.title)}\n\n` : ""}${card.items.map((item) => `${"  ".repeat(taskIndent(item))}- [${item.done ? "x" : " "}] ${markdownText(item.text).replace(/\r?\n/g, " ")}${taskDue(item) ? ` (${markdownText(taskDue(item))})` : ""}`).join("\n")}`,
        );
        break;
      case "link": {
        const url = safeUrl(card.url);
        parts.push(
          `${url ? `[${markdownText(card.title || card.url)}](<${markdownDestination(url)}>)` : markdownText(card.title || card.url || "Link")}${card.description ? `\n\n${markdownText(card.description)}` : ""}${card.caption||card.captionHtml ? `\n\n${typeof card.captionHtml==="string"?richHtmlToMarkdown(card.captionHtml):markdownText(card.caption||"")}` : ""}`,
        );
        break;
      }
      case "image": {
        const src = safeUrl(card.src, true);
        parts.push(
          src
            ? `![${markdownText(card.caption || "Image")}](${src.replace(/[()\s]/g, (character) => encodeURIComponent(character))})${card.captionHtml?`\n\n${richHtmlToMarkdown(card.captionHtml)}`:""}`
            : `Image: ${markdownText(card.caption || card.src || "Empty image")}`,
        );
        break;
      }
      case "board":
        parts.push(
          `${heading} ${markdownText(card.title)}\n\nNested board${card.boardId ? `: ${markdownText(card.boardId)}` : ""}`,
        );
        break;
      case "file": {
      const href = safeDownloadUrl(card.dataUrl||card.sourceUrl);
        parts.push(
          `${href ? `[${markdownText(card.name)}](<${markdownDestination(href)}>)` : markdownText(card.name)}\n\n${markdownText(fileSummary(card))}`,
        );
        break;
      }
      case "swatch":
        parts.push(
          `${markdownText(card.label || "Color swatch")}: ${markdownText(card.value)}`,
        );
        break;
      case "sketch":
        parts.push(
          `Sketch: ${card.paths.length} ${card.paths.length === 1 ? "stroke" : "strokes"} (${number(card.width)} × ${number(card.height)})`,
        );
        break;
      case "table": {
        const { rows } = tableForExport(card,board,options);
        const columns = Math.max(0, ...rows.map((row) => row.length));
        const row = (values: string[]) =>
          `| ${Array.from({ length: columns }, (_, index) => markdownCell(values[index] ?? "")).join(" | ")} |`;
        parts.push(
          `${heading} ${markdownText(card.title)}${columns ? `\n\n${row(rows[0] ?? [])}\n${row(Array(columns).fill("---")).replace(/\\-/g, "-")}\n${rows.slice(1).map(row).join("\n")}` : ""}`,
        );
        break;
      }
    }
    const tags = exportCardLabels(card, options).map(label => label.name);
    if (tags.length) parts.push(`Labels: ${tags.map(markdownText).join(", ")}`);
  }
  return `${parts.filter(Boolean).join("\n\n").trim()}\n`;
}

/** Plain text retains card captions, attachment metadata and checklist state. */
export function exportBoardText(board: Board, options: LinearExportOptions = {}): string {
  if (options.includeSubBoards) return boardsForLinearExport(board, options).map(current => exportBoardText(current, { workspace: options.workspace,formulaWorkbook:options.formulaWorkbook }).trimEnd()).join("\n\n────────────────\n\n") + "\n";
  const parts = [board.title];
  for (const { card } of cardsInReadingOrder(board)) {
    switch (card.type) {
      case "note":
        parts.push(
          [card.isDocument ? card.title || "Untitled document" : "", card.syncedId ? "Synced note" : "", typeof card.html === "string"
            ? richHtmlToPlainText(card.html)
            : exportNotePlainText(card.text)].filter(Boolean).join("\n\n"),
        );
        break;
      case "label":
        parts.push(card.text);
        break;
      case "column":
        parts.push(`${card.title}${card.collapsed ? " (collapsed)" : ""}`);
        break;
      case "todo":
        parts.push(
          `${card.title ? `${card.title}\n` : ""}${card.items.map((item) => `${"  ".repeat(taskIndent(item))}[${item.done ? "x" : " "}] ${item.text}${taskDue(item) ? ` (${taskDue(item)})` : ""}`).join("\n")}`,
        );
        break;
      case "link":
        parts.push(
          [card.title || "Link", card.url, card.description, card.caption]
            .filter(Boolean)
            .join("\n"),
        );
        break;
      case "image":
        parts.push(
          [`Image: ${card.caption || "Untitled"}`, card.src]
            .filter(Boolean)
            .join("\n"),
        );
        break;
      case "board":
        parts.push(
          `Nested board: ${card.title}${card.boardId ? ` (${card.boardId})` : ""}`,
        );
        break;
      case "file":
        parts.push(`Attachment: ${card.name}\n${fileSummary(card)}`);
        break;
      case "swatch":
        parts.push(`${card.label || "Color swatch"}: ${card.value}`);
        break;
      case "sketch":
        parts.push(
          `Sketch: ${card.paths.length} ${card.paths.length === 1 ? "stroke" : "strokes"} (${number(card.width)} × ${number(card.height)})`,
        );
        break;
      case "table": {
        const { rows } = tableForExport(card,board,options);
        parts.push(
          `${card.title}\n${rows.map((row) => row.join("\t")).join("\n")}`,
        );
        break;
      }
    }
    const tags = exportCardLabels(card, options).map(label => label.name);
    if (tags.length) parts.push(`Labels: ${tags.join(", ")}`);
  }
  return `${parts.filter(Boolean).join("\n\n").trim()}\n`;
}

export function downloadFile(
  filename: string,
  data: Blob | string,
  mime = "text/plain;charset=utf-8",
): void {
  const blob = data instanceof Blob ? data : new Blob([data], { type: mime });
  const url = URL.createObjectURL(blob),
    anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename.replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_");
  anchor.style.display = "none";
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
}

export interface PrepareBoardForExportOptions {
  /** Set false for JSON backups to retain source images and editable operations. */
  flattenImageEdits?: boolean;
  /** Raster/document exports must fail rather than silently omit an inaccessible resource. */
  strictResources?: boolean;
}

/** Embeds local image resources before making a portable board or workspace backup.
 * Remote images are embedded when their server permits CORS; otherwise their URL remains.
 * Local resource failures reject so an incomplete standalone export is not silently downloaded.
 * Visual exports flatten image operations by default; JSON backups preserve them with false.
 */
export async function prepareBoardForExport(
  board: Board,
  options: PrepareBoardForExportOptions = {},
): Promise<Board> {
  const prepared = structuredClone(board);
  const base = globalThis.location?.href ?? "http://localhost/";
  const origin = new URL(base).origin;
  const cache = new Map<string, Promise<string>>();
  const embed = (source: string): Promise<string> => {
    if (!source || source.startsWith("data:")) return Promise.resolve(source);
    let url: URL;
    try {
      url = new URL(source, base);
    } catch {
      return Promise.resolve(source);
    }
    if (!["http:", "https:", "blob:"].includes(url.protocol))
      return Promise.resolve(source);
    const existing = cache.get(url.href);
    if (existing) return existing;
    const request = (async () => {
      try {
        const response = await fetch(url.href, {
          credentials: url.origin === origin ? "same-origin" : "omit",
          signal: AbortSignal.timeout(15000),
        });
        if (!response.ok)
          throw new Error(`Resource returned ${response.status}`);
        const blob = await response.blob(),
          bytes = new Uint8Array(await blob.arrayBuffer());
        let binary = "";
        for (let start = 0; start < bytes.length; start += 8192)
          binary += String.fromCharCode(...bytes.subarray(start, start + 8192));
        return `data:${blob.type || "application/octet-stream"};base64,${btoa(binary)}`;
      } catch (error) {
        if (options.strictResources || url.origin === origin || url.protocol === "blob:")
          throw new Error(`Could not embed local resource: ${url.pathname}`, {
            cause: error,
          });
        return source;
      }
    })();
    cache.set(url.href, request);
    return request;
  };
  return {
    ...prepared,
    cards: await Promise.all(
      prepared.cards.map(async (card) => {
        if (card.type === "image") {
          card.src = await embed(card.src);
          const cutout = card as typeof card & { cutoutSrc?: string; useCutout?: boolean };
          if (cutout.cutoutSrc) cutout.cutoutSrc = await embed(cutout.cutoutSrc);
          if (options.flattenImageEdits !== false && cutout.useCutout && cutout.cutoutSrc)
            card.src = cutout.cutoutSrc;
          if (options.flattenImageEdits !== false && card.imageEdits) {
            card.src = await bakeImageEdits(card.src, card.imageEdits);
            delete card.imageEdits;
          }
          return card;
        }
        if (card.type === "link" && card.previewSrc) {
          card.previewSrc = await embed(card.previewSrc);
          if(typeof globalThis.Image==='function'){
            const dimensions=await new Promise<{width:number;height:number}|undefined>(resolve=>{
              const image=new globalThis.Image();const timer=setTimeout(()=>{image.src='';resolve(undefined);},10000);
              image.onload=()=>{clearTimeout(timer);resolve(image.naturalWidth&&image.naturalHeight?{width:image.naturalWidth,height:image.naturalHeight}:undefined);};
              image.onerror=()=>{clearTimeout(timer);resolve(undefined);};image.src=card.previewSrc!;
            });
            if(dimensions){card.previewWidth=dimensions.width;card.previewHeight=dimensions.height;}
          }
          if(/(^|\.)milanote\.com$/i.test(new URL(card.url,base).hostname))card.faviconSrc=await embed('/assets/milanote-favicon.png');
          return card;
        }
        if (
          card.type === "file" &&
          card.dataUrl &&
          !card.dataUrl.startsWith("data:")
        )
          return { ...card, dataUrl: await embed(card.dataUrl), poster: card.poster ? await embed(card.poster) : undefined };
        if (card.type === "file") {
          if(card.poster)card.poster=await embed(card.poster);
          if(filePreviewKind(card)==='pdf'&&(card.dataUrl||card.sourceUrl)&&card.showPreview!==false){
            const {loadPdfThumbnail}=await import('./core/pdfPreview');
            const cachedThumbnail=card.previewSrc&&card.previewWidth&&card.previewHeight&&card.pageCount&&card.previewDigest?{imageDataUrl:card.previewSrc,width:card.previewWidth,height:card.previewHeight,pageCount:card.pageCount,sourceDigest:card.previewDigest}:undefined;
            const {thumbnail}=await loadPdfThumbnail((card.dataUrl||card.sourceUrl)!,{cachedThumbnail});
            Object.assign(card,{previewSrc:thumbnail.imageDataUrl,previewWidth:thumbnail.width,previewHeight:thumbnail.height,pageCount:thumbnail.pageCount,previewDigest:thumbnail.sourceDigest});
            if(card.autoHeight===true)card.height=fileDetailHeight(pdfPreviewHeight(card.width,thumbnail.width,thumbnail.height),card);
          }else if(card.previewSrc)card.previewSrc=await embed(card.previewSrc);
        }
        return card;
      }),
    ),
  };
}

// Keep format generators and their dependencies outside the initial editor bundle.
export async function exportBoardPng(board: Board, options: import("./core/exportFormats").RasterExportOptions = {}): Promise<Blob> {
  return (await import("./core/exportFormats")).exportBoardPng(board, options);
}
export async function exportBoardPdf(board: Board, options: import("./core/exportFormats").PdfExportOptions = {}): Promise<Blob> {
  return (await import("./core/exportFormats")).exportBoardPdf(board, options);
}
export async function exportBoardWord(board: Board, options: LinearExportOptions = {}): Promise<Blob> {
  return (await import("./core/exportFormats")).exportBoardWord(board, options);
}
export async function exportBoardAttachmentsZip(board: Board): Promise<Blob> {
  return (await import("./core/exportFormats")).exportBoardAttachmentsZip(board);
}
export async function exportDocumentFile(card: Extract<Card, { type: "note" }>, format: "pdf" | "word" | "markdown" | "text"): Promise<Blob> {
  return (await import("./core/exportFormats")).exportDocumentFile(card, format);
}

/** Opens synchronously to preserve the click gesture, then prepares a standalone print view. */
export async function printBoard(board: Board, options: VisualExportOptions = {}): Promise<void> {
  const popup = window.open("about:blank", "_blank");
  if (!popup) throw new Error("Allow pop-ups to open the print view.");
  popup.opener = null;
  try {
    const prepared = await prepareBoardForExport(board);
    if (popup.closed) return;
    popup.document.open();
    popup.document.write(exportBoardHtml(prepared, options));
    popup.addEventListener(
      "load",
      () => {
        const images = Array.from(popup.document.images);
        const ready = Promise.all(
          images.map((img) =>
            img.complete
              ? Promise.resolve()
              : new Promise<void>((resolve) => {
                  img.onload = () => resolve();
                  img.onerror = () => resolve();
                }),
          ),
        );
        Promise.race([
          ready,
          new Promise((resolve) => setTimeout(resolve, 5000)),
        ]).then(() => {
          if (!popup.closed) {
            popup.focus();
            popup.print();
          }
        });
      },
      { once: true },
    );
    popup.document.close();
  } catch (error) {
    popup.close();
    throw error;
  }
}
