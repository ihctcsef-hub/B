import { useState, useEffect, useRef, useCallback, useMemo, lazy, Suspense } from "react";
import type { CSSProperties, PointerEvent as ReactPointerEvent, KeyboardEvent as ReactKeyboardEvent } from "react";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  ChevronRight,
  ChevronDown,
  Plus,
  Minus,
  Search,
  Undo2,
  Redo2,
  MoreHorizontal,
  Type,
  Image,
  Link,
  CheckSquare,
  Columns3,
  Folder,
  Palette,
  Pencil,
  Table2,
  Tag,
  Paperclip,
  MousePointer2,
  Hand,
  MoveUpRight,
  Download,
  Upload,
  Copy,
  Trash2,
  X,
  Check,
  Maximize,
  Lock,
  Unlock,
  PanelLeftClose,
  PanelLeftOpen,
  FileText,
  CircleHelp,
  Crop,
  Quote,
  RotateCcw,
  Bold,
  Italic,
  Strikethrough,
  Underline,
  List,
  ListOrdered,
  AlignLeft,
  Code2,
  Inbox,
  Settings,
} from "lucide-react";
import {
  uid,
  createWorkspace,
  createCard,
  updateBoard,
  deleteCards,
  duplicateCards,
  copyCardsToBoard,
  loadWorkspace,
  saveWorkspace,
  exportWorkspace,
  importWorkspace,
  expandSelection,
  columnChildren,
  arrangeColumn,
  arrangeAllColumns,
  placeInColumn,
  removeFromColumn,
  resizeColumn,
} from "./core";
import type { Workspace, Board, Card, Connection } from "./core";
import { moveCardsToBoard, convertColumnToBoard } from "./core/boardActions";
import {droppedImageSize,layoutDroppedImages} from "./core/imageGrid";
import {BOARD_HOVER_OPEN_MS,boardDragAnchor,boardDragGrab,canMoveDragToBoard} from './core/boardDrag';
import {BoardDragPreview,captureBoardDragPreview} from './components/BoardDragPreview';
import type {BoardDragPreviewState} from './components/BoardDragPreview';
import { LabelManager, LabelBadges } from "./components/LabelManager";
import { migrateLegacyLabels, renameWorkspaceLabel, setLabelAssignment } from "./core/labels";
import { TrashPanel } from "./components/TrashPanel";
import { trashCards, trashConnections, restoreTrashEntry, emptyTrash, permanentlyDeleteTrashEntry, purgeExpiredTrash } from "./core/trash";
import { createBoardShortcut, boardLocalUrl, localBoardIdFromUrl, workspaceBoard } from "./core/shortcuts";
import { convertBoardToTemplate, revertTemplateToBoard, renameBoardTemplate, deleteBoardTemplate } from "./core/templates";
import { SketchEditor } from "./components/SketchEditor";
import { Presentation,PresentationCard } from "./components/Presentation";
import type {CatalogPreview} from './core/templateCatalog';
const TemplateCatalogSession=lazy(()=>import('./components/TemplateCatalogSession'));
import { drawingBounds } from "./core/drawing";
import { BackgroundRemoval } from "./components/BackgroundRemoval";
import {LinkDetailsEditor} from './components/LinkDetailsEditor';
import {LinkAutoLayout} from './components/LinkAutoLayout';
import {LinkPreview} from './components/LinkPreview';
import {NoteConnectionMarker,NoteResizeMarker} from './components/NoteControls';
import {LinkInfo} from './components/LinkInfo';
import {FileCardView} from './components/FileCardView';
import {filePreviewKind,pdfPreviewHeight,fileDetailHeight,FILE_DETAIL_FOOTER_HEIGHT,FILE_EMPTY_CAPTION_HEIGHT,FILE_ICON_WIDTH,FILE_ICON_HEIGHT} from './core/filePreview';
import type {PdfThumbnail} from './core/pdfPreview';
import {fetchLinkMetadata,linkMetadataPatch,normalizeLinkUrl} from './core/linkMetadata';
import { ImageLibrary } from "./components/ImageLibrary";
import { ExportMenu } from "./components/ExportMenu";
import { ViewMenu } from "./components/ViewMenu";
import { TextStyleMenu } from "./components/TextStyleMenu";
import { CellTypeMenu } from "./components/CellTypeMenu";
import { BoardIconPicker } from "./components/BoardIconPicker";
import {selectedBoardIconId,boardIconDisplaySource} from './core/boardIcons';
import './components/note-blocks.css';
import { CardColorMenu } from './components/CardColorMenu';
import { WorkspaceSearch } from "./components/WorkspaceSearch";
import { markBoardViewed, retainBoardActivity, stampBoardModifications } from "./core/search";
import { canUseColorStrip,updateCardAppearance } from './core/cardAppearance';
import { decodeLibraryPhoto, LIBRARY_DRAG_TYPE } from "./core/imageLibrary";
import type { LibraryPhoto } from "./core/imageLibrary";
import type { SketchEditorValue } from "./components/SketchEditor";
import { CaptionEditor } from "./components/CaptionEditor";
import { ConnectionLayer } from "./components/ConnectionLayer";
import { attachConnectionHandle, connectionAnchorAt, connectionBounds, connectionGeometry, connectionTargetAt, constrainConnectionPoint } from "./core/lines";
import { applyNoteContent, createSyncedNote, syncedNoteLocationIndex } from "./core/notes";
import { SyncedNoteIndicator, SyncedNoteLocations } from "./components/SyncedNoteLocations";
import type { SyncedNoteAnchor } from "./components/SyncedNoteLocations";
import { mediaEmbedUrl } from "./core/media";
import { saveBoardTemplate, instantiateBoardTemplate } from "./core/templates";
import { noteContentHtml } from "./core/richText";
import type { NoteEditorHandle, NoteEditorCommand } from "./components/NoteEditor";
import { bakeImageEdits } from "./core/imageEditing";
import { ImageEditor, ImagePreview } from "./components/ImageEditor";
import { TableEditor } from "./components/TableEditor";
import { ColorSwatch } from "./components/ColorSwatch";
import { BoardImageSampler } from "./components/BoardImageSampler";
import { chooseImageColor, colorImageSource, imageColorName, imagePalette, readImageColors, visibleColorImages } from "./core/imageColors";
import type { BoardColorImage, ColorImageRect } from "./core/imageColors";
import { parseColor as parseImageSampleBackground } from "./core/colors";
import { TodoEditor } from "./components/TodoEditor";
import type { TodoEditorHandle } from "./components/TodoEditor";
import type { ColorSwatchHandle } from "./components/ColorSwatch";
import type { TableEditorHandle } from "./components/TableEditor";
import {tableFormulaNames,createFormulaWorkbook,reconcileFormulaWorkbook,formulaContextForTable} from "./core/spreadsheet";
import type { TableSelection } from "./core/spreadsheet";
import {
  prepareBoardForExport,
  downloadFile,
  exportBoardHtml,
  exportBoardSvg,
  printBoard,
  exportBoardMarkdown,
  exportBoardText,
  exportBoardPng,
  exportBoardPdf,
  exportBoardWord,
  exportBoardAttachmentsZip,
  exportDocumentFile,
} from "./export";

const NoteEditor=lazy(()=>import('./components/NoteEditor').then(module=>({default:module.NoteEditor})));

type Tool = "select" | "hand" | "connect" | "draw";
type Point = { x: number; y: number };
type Modal = "help" | "export" | "templates" | "search" | "appearance" | "note-link" | "document" | "formulas" | "move" | null;
const COLORS = [
  "#ffffff",
  "#fff3bc",
  "#f8d8d3",
  "#e9e2f6",
  "#dceadf",
  "#dbe9f4",
  "#f6ddc4",
];
const TOOL_ITEMS: { type: Card["type"]; label: string; icon: typeof Type }[] = [
  { type: "note", label: "Note", icon: Type },
  { type: "link", label: "Link", icon: Link },
  { type: "todo", label: "To-do", icon: CheckSquare },
  { type: "board", label: "Board", icon: Folder },
  { type: "column", label: "Column", icon: Columns3 },
  { type: "image", label: "Image", icon: Image },
  { type: "sketch", label: "Sketch", icon: Pencil },
  { type: "swatch", label: "Color", icon: Palette },
  { type: "table", label: "Table", icon: Table2 },
  { type: "label", label: "Label", icon: Tag },
  { type: "file", label: "File", icon: Paperclip },
];
const isEditing = () => {
  const e = document.activeElement;
  return !!e?.matches('input,textarea,select,[contenteditable="true"]');
};
function keepDialogFocus(event:ReactKeyboardEvent<HTMLElement>){
  if(event.key!=='Tab')return;
  const root=event.currentTarget,items=[...root.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),a[href],[tabindex="0"]')].filter(element=>!!element.getClientRects().length);
  if(!items.length){event.preventDefault();return;}
  const first=items[0],last=items[items.length-1],active=document.activeElement;
  if(event.shiftKey&&(active===first||!root.contains(active))){event.preventDefault();last.focus();}
  else if(!event.shiftKey&&(active===last||!root.contains(active))){event.preventDefault();first.focus();}
  event.stopPropagation();
}
const cardText = (c: Card) =>
  "text" in c
    ? c.text
    : "title" in c
      ? c.title
      : "caption" in c
        ? c.caption
        : "label" in c
          ? c.label
          : "name" in c
            ? c.name
            : "";

export default function App() {
  const [doc, setDoc] = useState<Workspace>(() => createWorkspace());
  const docRef = useRef(doc);
  docRef.current = doc;
  const [ready, setReady] = useState(false);
  const [storageBlocked, setStorageBlocked] = useState(false);
  const [saved, setSaved] = useState("Loading…");
  const [boardId, setBoardId] = useState(doc.rootBoardId);
  const [selected, setSelected] = useState<string[]>([]);
  const [tool, setTool] = useState<Tool>("select");
  const [sidebar, setSidebar] = useState(false);
  const [inboxOpen, setInboxOpen] = useState(false);
  const [labelsOpen,setLabelsOpen]=useState<{left:number;top:number}|null>(null);
  const [trashOpen,setTrashOpen]=useState(false);
  const [syncedPopup,setSyncedPopup]=useState<{id:string;anchor:SyncedNoteAnchor}|null>(null);
  const [presenting,setPresenting]=useState(false);
  const [sketchSession,setSketchSession]=useState<{id?:string;at:Point;value:SketchEditorValue;mode:'sketch'|'board'}|null>(null);
  const [cutoutId,setCutoutId]=useState<string|null>(null);
  const [imageLibraryOpen,setImageLibraryOpen]=useState(false);
  const [filterLabelId,setFilterLabelId]=useState<string|null>(null);
  const [exportBusy,setExportBusy]=useState(false);
  const [exportMenuOpen,setExportMenuOpen]=useState(false);
  const [viewMenuOpen,setViewMenuOpen]=useState(false);
  const [textStyleMenuOpen,setTextStyleMenuOpen]=useState(false);
  const [cellTypeMenuOpen,setCellTypeMenuOpen]=useState(false);
  const [boardIconPickerOpen,setBoardIconPickerOpen]=useState(false);
  const [cardColorMenuOpen,setCardColorMenuOpen]=useState(false);
  const [exportSubBoards,setExportSubBoards]=useState(false);
  const [exportPdfQuality,setExportPdfQuality]=useState<'standard'|'large'>('standard');
  const [templatePickerOpen,setTemplatePickerOpen]=useState(false);
  const [templatePreview,setTemplatePreview]=useState<CatalogPreview>();
  const [templatePreviewBoard,setTemplatePreviewBoard]=useState<string>();
  const [templateRename,setTemplateRename]=useState<{id:string;title:string}|null>(null);
  const [columnDrop, setColumnDrop] = useState<{
    columnId: string;
    y: number;
  } | null>(null);
  const inboxRef = useRef<HTMLDivElement>(null);
  const [viewport, setViewport] = useState({ x: 20, y: 20, zoom: 1 });
  const vpRef = useRef(viewport);
  vpRef.current = viewport;
  const [modal, setModal] = useState<Modal>(null);
  const [query, setQuery] = useState("");
  const [context, setContext] = useState<{ x: number; y: number } | null>(null);
  const [toast, setToast] = useState("");
  const [toastRevision,setToastRevision]=useState(0);
  const [editing, setEditing] = useState<string | null>(null);
  const noteEditorRef=useRef<NoteEditorHandle>(null);
  const noteEditBase=useRef<{id:string;boardId:string;workspace:Workspace}|null>(null);
  const pendingNoteCommand=useRef<{command:NoteEditorCommand;value?:string|number}|null>(null);
  const [noteLink,setNoteLink]=useState('');
  const [documentLinkOpen,setDocumentLinkOpen]=useState(false);
  const [textInk,setTextInk]=useState('#323b4a');
  const [textHighlight,setTextHighlight]=useState('#fff3a3');
  const [imageEditorId,setImageEditorId]=useState<string|null>(null);
  const [imageMode,setImageMode]=useState<'crop'|'markup'>('crop');
  const lineEditBase=useRef<Workspace|null>(null);
  const todoRef=useRef<TodoEditorHandle>(null);
  const swatchRefs=useRef(new Map<string,ColorSwatchHandle>());
  const [imageColorSampling,setImageColorSampling]=useState<{images:BoardColorImage[];clip:ColorImageRect}|null>(null);
  const imageColorResolve=useRef<((color:string|null)=>void)|null>(null);
  const imageColorEpoch=useRef(0);
  const asyncMutationEpoch=useRef(0);
  const previewDropRequests=useRef(new Map<string,object>());
  const linkRequests=useRef(new Map<string,{controller:AbortController;workspaceId:string;boardId:string;cardId:string;url:string}>());
  const [linkPending,setLinkPending]=useState<Set<string>>(()=>new Set());
  const swatchInsertQueue=useRef(Promise.resolve());
  const imageColorBoard=useRef('');
  const tableEditorRef=useRef<TableEditorHandle>(null);
  const [tableSelection,setTableSelection]=useState<TableSelection>({row:0,column:0});
  const [from, setFrom] = useState<string | null>(null);
  const [lineId, setLineId] = useState<string | null>(null);
  const [marquee, setMarquee] = useState<{ start: Point; end: Point } | null>(
    null,
  );
  const [penColor, setPenColor] = useState("#3c4742");
  const [penWidth, setPenWidth] = useState(3);
  const [draftPath, setDraftPath] = useState<Point[]>([]);
  const history = useRef<{ past: Workspace[]; future: Workspace[] }>({
    past: [],
    future: [],
  });
  const [historyTick, setHistoryTick] = useState(0);
  const boardNavigation = useRef<{past:string[];future:string[]}>({past:[],future:[]});
  useEffect(()=>{boardNavigation.current={past:[],future:[]};},[doc.id]);
  const clipboard = useRef<{
    workspace: Workspace;
    boardId: string;
    ids: string[];
  } | null>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const uploadRef = useRef<HTMLInputElement>(null);
  const importRef = useRef<HTMLInputElement>(null);
  const importGeneration=useRef(0);
  const searchTriggerRef = useRef<HTMLButtonElement>(null);
  const uploadKind = useRef<"image" | "file">("image");
  const uploadAt=useRef<Point|undefined>(undefined);
  const pointers = useRef(new Map<number, Point>());
  const gesture = useRef<any>(null);
  const [boardDragPreview,setBoardDragPreview]=useState<BoardDragPreviewState|null>(null);
  const [boardDragHover,setBoardDragHover]=useState<string|null>(null);
  const [previewDragReady,setPreviewDragReady]=useState<string|null>(null);
  const touchCardPress=useRef<{id:string;pointer:number;x:number;y:number;started:number;moved:boolean}|null>(null);
  const lastTouchCardTap=useRef<{id:string;x:number;y:number;ended:number}|null>(null);
  const lastTouchCardOpen=useRef<{id:string;at:number}|null>(null);
  const connectorDragCleanup=useRef<(()=>void)|null>(null);
  const suppressConnectorClick=useRef(false);
  const [connectorAnchorHint,setConnectorAnchorHint]=useState<Point|null>(null);
  useEffect(()=>()=>connectorDragCleanup.current?.(),[]);
  const saveSeq = useRef(0);
  const board = workspaceBoard(doc,boardId) || workspaceBoard(doc,doc.rootBoardId)!;
  const activeId = board.id;
  const boardReadOnly=(()=>{const seen=new Set<string>();let candidate:Board|undefined=board;while(candidate&&!seen.has(candidate.id)){if(candidate.isExternalReference)return true;seen.add(candidate.id);candidate=candidate.parentBoardId?doc.boards[candidate.parentBoardId]:undefined;}return false;})();
  const formulaRegistry=useRef({workspaceId:doc.id,snapshot:createFormulaWorkbook(board.cards.filter(card=>card.type==='table'))});
  if(formulaRegistry.current.workspaceId!==doc.id){formulaRegistry.current={workspaceId:doc.id,snapshot:createFormulaWorkbook(board.cards.filter(card=>card.type==='table'))};}
  else formulaRegistry.current.snapshot=reconcileFormulaWorkbook(formulaRegistry.current.snapshot,board.cards.filter(card=>card.type==='table'));
  const formulaWorkbook=formulaRegistry.current.snapshot;
  imageColorBoard.current=activeId;
  useEffect(()=>{imageColorEpoch.current++;imageColorResolve.current?.(null);imageColorResolve.current=null;setImageColorSampling(null);},[activeId,doc.id]);
  useEffect(()=>()=>{imageColorEpoch.current++;imageColorResolve.current?.(null);imageColorResolve.current=null;},[]);
  useEffect(()=>{asyncMutationEpoch.current++;},[doc.id]);
  function cancelLinkRequests(){for(const request of linkRequests.current.values())request.controller.abort();linkRequests.current.clear();setLinkPending(new Set());}
  useEffect(()=>()=>{for(const request of linkRequests.current.values())request.controller.abort();linkRequests.current.clear();},[]);
  useEffect(()=>{
    let changed=false;
    for(const [key,request] of linkRequests.current){
      const card=workspaceBoard(doc,request.boardId)?.cards.find(card=>card.id===request.cardId);
      if(doc.id!==request.workspaceId||card?.type!=='link'||card.locked||card.url!==request.url){request.controller.abort();linkRequests.current.delete(key);changed=true;}
    }
    if(changed)setLinkPending(new Set(linkRequests.current.keys()));
  },[doc]);
  const cards = board.cards;
  const visibleCards = cards.filter(
    (c) =>
      !c.unsorted &&
      (!c.parentId ||
        (!cards.find((p) => p.id === c.parentId)?.unsorted &&
          !cards.find((p) => p.id === c.parentId)?.collapsed)),
  );
  const inboxCards = cards.filter(
    (c) =>
      c.unsorted &&
      (!c.parentId || !cards.find((p) => p.id === c.parentId)?.unsorted),
  );
  const selectedCards = cards.filter((c) => selected.includes(c.id));
  const single = selectedCards.length === 1 ? selectedCards[0] : null;
  const syncedLocations=useMemo(()=>syncedNoteLocationIndex(doc),[doc]);
  const syncedPopupCard=syncedPopup?cards.find(card=>card.id===syncedPopup.id):undefined;
  const syncedPopupLocations=syncedPopupCard?.type==='note'?(syncedLocations.get(syncedPopupCard.syncedId||'')||[]):[];
  useEffect(()=>{setSyncedPopup(null);},[activeId]);
  const selectedLine = board.connections.find((c) => c.id === lineId);
  useEffect(()=>{setTextStyleMenuOpen(false);setCellTypeMenuOpen(false);setBoardIconPickerOpen(false);setCardColorMenuOpen(false);},[single?.id,activeId]);
  const notify = (s: string) => {
    setToast(s);
    setToastRevision(revision=>revision+1);
  };
  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(""), 3500);
    return () => clearTimeout(id);
  }, [toast,toastRevision]);
  useEffect(() => {
    loadWorkspace()
      .then((w) => {
        if (w) {
          const initialId=localBoardIdFromUrl(w,location.href)||w.rootBoardId;
          const initial=markBoardViewed(migrateLegacyLabels(purgeExpiredTrash(w)),initialId);docRef.current=initial;setDoc(initial);
          setBoardId(initialId);
          setViewport(w.boards[initialId].viewport);
        }else{const initial=markBoardViewed(docRef.current,docRef.current.rootBoardId);docRef.current=initial;setDoc(initial);}
        setReady(true);
      })
      .catch(() => {
        setStorageBlocked(true);
        setReady(true);
        setSaved("Storage needs attention");
        notify(
          "Saved data could not be read. Automatic saving is paused to protect your backup.",
        );
      });
  }, []);
  useEffect(() => {
    if (!ready || storageBlocked) return;
    setSaved("Saving…");
    const seq = ++saveSeq.current;
    const id = setTimeout(() => {
      saveWorkspace(updateBoard(doc, boardId, (b) => ({ ...b, viewport })))
        .then(() => {
          if (seq === saveSeq.current) setSaved("Saved on this device");
        })
        .catch(() => setSaved("Save failed — export a backup"));
    }, 500);
    return () => clearTimeout(id);
  }, [doc, ready, viewport, boardId, storageBlocked]);
  const commit = useCallback((next: Workspace, base?: Workspace, options?: {preserveActivity?:boolean}) => {
    const old = base || docRef.current;
    if (next === old) return;
    history.current.past.push(old);
    if (history.current.past.length > 80) history.current.past.shift();
    history.current.future = [];
    const changed=options?.preserveActivity?next:stampBoardModifications(old,next);
    docRef.current=changed;
    setDoc(changed);
    setHistoryTick((n) => n + 1);
  }, []);
  const change = (fn: (b: Board) => Board) =>
    !boardReadOnly&&commit(updateBoard(docRef.current, activeId, fn));
  const undo = useCallback(() => {
    if(noteEditBase.current&&noteEditorRef.current){noteEditorRef.current.run('undo');return;}
    const old = history.current.past.pop();
    if (!old) return;
    history.current.future.push(docRef.current);
    const restored=old.id===docRef.current.id?stampBoardModifications(docRef.current,retainBoardActivity(old,docRef.current)):old;
    docRef.current=restored;setDoc(restored);
    setSelected([]);
    setHistoryTick((n) => n + 1);
  }, []);
  const redo = useCallback(() => {
    if(noteEditBase.current&&noteEditorRef.current){noteEditorRef.current.run('redo');return;}
    const next = history.current.future.pop();
    if (!next) return;
    history.current.past.push(docRef.current);
    const restored=next.id===docRef.current.id?stampBoardModifications(docRef.current,retainBoardActivity(next,docRef.current)):next;
    docRef.current=restored;setDoc(restored);
    setSelected([]);
    setHistoryTick((n) => n + 1);
  }, []);
  const patch = (id: string, values: Partial<Card>) =>
    change((b) => {
      const next = {
        ...b,
        cards: b.cards.map((c) =>
          c.id === id ? ({ ...c, ...values } as Card) : c,
        ),
      };
      const c = next.cards.find((c) => c.id === id);
      return c?.parentId ? arrangeColumn(next, c.parentId) : next;
    });
  async function refreshLinkMetadata(origin:string,baseline:Extract<Card,{type:'link'}>){
    if(baseline.locked||!normalizeLinkUrl(baseline.url))return;
    const key=JSON.stringify([origin,baseline.id]);linkRequests.current.get(key)?.controller.abort();
    const request={controller:new AbortController(),workspaceId:docRef.current.id,boardId:origin,cardId:baseline.id,url:baseline.url};
    const epoch=asyncMutationEpoch.current;
    linkRequests.current.set(key,request);setLinkPending(new Set(linkRequests.current.keys()));
    const currentCard=()=>workspaceBoard(docRef.current,origin)?.cards.find(card=>card.id===baseline.id);
    const valid=()=>!request.controller.signal.aborted&&linkRequests.current.get(key)===request&&asyncMutationEpoch.current===epoch&&docRef.current.id===request.workspaceId&&currentCard()?.type==='link'&&(currentCard() as Extract<Card,{type:'link'}>).url===baseline.url&&!currentCard()?.locked;
    try{
      const metadata=await fetchLinkMetadata(baseline.url,{signal:request.controller.signal});
      while(gesture.current||noteEditBase.current){if(!valid())return;await new Promise<void>(resolve=>requestAnimationFrame(()=>resolve()));}
      if(!valid())return;
      const card=currentCard() as Extract<Card,{type:'link'}>,values=linkMetadataPatch(card,baseline,metadata);
      if(!Object.keys(values).length)return;
      const next=updateBoard(docRef.current,origin,board=>{
        const next={...board,cards:board.cards.map(item=>item.id===card.id?{...item,...values} as Card:item)};
        return card.parentId?arrangeColumn(next,card.parentId):next;
      });
      const visibleChange=(['title','description','previewSrc'] as const).some(field=>values[field]!==undefined&&values[field]!==card[field]);
      if(visibleChange)commit(next);else{docRef.current=next;setDoc(next);}
    }catch(error){if(valid()&&imageColorBoard.current===origin&&!(error instanceof DOMException&&error.name==='AbortError'))notify('Preview unavailable. You can edit the link details.');}
    finally{if(linkRequests.current.get(key)===request){linkRequests.current.delete(key);setLinkPending(new Set(linkRequests.current.keys()));}}
  }
  function updateLinkUrl(card:Extract<Card,{type:'link'}>,source:string):boolean{
    const url=normalizeLinkUrl(source);
    if(!url){notify('Enter a valid http or https link.');return false;}
    if(card.locked)return false;
    if(url===card.url)return true;
    let priorHost='';try{priorHost=new URL(card.url).hostname;}catch{/* A new link has no prior host. */}
    const title=!card.title||card.title===card.url||card.title===priorHost?new URL(url).hostname:card.title;
    const next={...card,url,title,height:card.height===58?120:card.height,autoHeight:!card.url||card.autoHeight===true};
    patch(card.id,{url,title,height:next.height,autoHeight:next.autoHeight});
    void refreshLinkMetadata(activeId,next);
    return true;
  }
  function measureLinkHeight(id:string,height:number){
    if(gesture.current||editing===id||height<=0)return;
    const current=workspaceBoard(docRef.current,activeId)?.cards.find(card=>card.id===id);
    if(current?.type!=='link'||current.autoHeight!==true)return;
    const nextHeight=Math.max(58,Math.min(2400,height));
    if(Math.abs(nextHeight-current.height)<1)return;
    const next=updateBoard(docRef.current,activeId,board=>{
      const changed={...board,cards:board.cards.map(card=>card.id===id?{...card,height:nextHeight}:card)};
      return current.parentId?arrangeColumn(changed,current.parentId):changed;
    });
    const changed=stampBoardModifications(docRef.current,next);docRef.current=changed;setDoc(changed);
  }
  function updateTodoContent(origin:string,id:string,value:{title:string;items:Extract<Card,{type:'todo'}>['items'];height:number}){
    const current=workspaceBoard(docRef.current,origin)?.cards.find(card=>card.id===id);
    if(current?.type!=='todo'||current.locked)return;
    const contentChanged=current.title!==value.title||JSON.stringify(current.items)!==JSON.stringify(value.items);
    const height=value.height+(current.stripColor?4:0);
    if(!contentChanged&&Math.abs(height-current.height)<.01)return;
    const next=updateBoard(docRef.current,origin,board=>{
      const changed={...board,cards:board.cards.map(card=>card.id===id?{...card,title:value.title,items:value.items,height}:card)};
      return current.parentId?arrangeColumn(changed,current.parentId):changed;
    });
    if(contentChanged)commit(next);else{docRef.current=next;setDoc(next);}
  }
  function fileFrameHeight(card:Extract<Card,{type:'file'}>):number{
    if(card.autoHeight===true){
      if(card.previewWidth&&card.previewHeight)return pdfPreviewHeight(card.width,card.previewWidth,card.previewHeight);
      return filePreviewKind(card)==='audio'?54:Math.max(6,Math.round(card.width*3/4/8)*8-2);
    }
    return Math.max(6,card.height-(card.showFileInfo===false?0:FILE_DETAIL_FOOTER_HEIGHT+(card.showCaption?Math.max(FILE_EMPTY_CAPTION_HEIGHT,card.captionHeight||0):0)));
  }
  async function receivePdfPreview(origin:string,workspaceId:string,epoch:number,baseline:Extract<Card,{type:'file'}>,preview:PdfThumbnail){
    const valid=()=>docRef.current.id===workspaceId&&asyncMutationEpoch.current===epoch;
    while(gesture.current||noteEditBase.current){if(!valid())return;await new Promise<void>(resolve=>requestAnimationFrame(()=>resolve()));}
    if(!valid())return;
    const current=workspaceBoard(docRef.current,origin)?.cards.find(card=>card.id===baseline.id);
    if(current?.type!=='file'||current.dataUrl!==baseline.dataUrl||current.sourceUrl!==baseline.sourceUrl)return;
    const values={previewSrc:preview.imageDataUrl,previewWidth:preview.width,previewHeight:preview.height,pageCount:preview.pageCount,previewDigest:preview.sourceDigest};
    if(Object.entries(values).every(([key,value])=>current[key as keyof typeof current]===value))return;
    const height=current.autoHeight===true&&current.showPreview!==false?fileDetailHeight(pdfPreviewHeight(current.width,preview.width,preview.height),current):current.height;
    const next=updateBoard(docRef.current,origin,board=>{
      const changed={...board,cards:board.cards.map(card=>card.id===current.id?{...card,...values,height}:card)};
      return current.parentId?arrangeColumn(changed,current.parentId):changed;
    });
    docRef.current=next;setDoc(next);
  }
  function toggleFilePreview(card:Extract<Card,{type:'file'}>){
    if(card.showPreview!==false){
      patch(card.id,{showPreview:false,detailWidth:card.width,detailHeight:card.height,detailAutoHeight:card.autoHeight===true,width:FILE_ICON_WIDTH,height:FILE_ICON_HEIGHT,autoHeight:false});
    }else{
      const width=card.detailWidth||270,autoHeight=card.detailAutoHeight!==false;
      const restored={...card,width,autoHeight,showPreview:true};
      patch(card.id,{showPreview:true,width,autoHeight,height:autoHeight?fileDetailHeight(fileFrameHeight(restored),restored):card.detailHeight||300});
    }
  }
  function updateFileDetail(card:Extract<Card,{type:'file'}>,values:Partial<Extract<Card,{type:'file'}>>){
    const next={...card,...values};
    const height=card.showPreview!==false&&(filePreviewKind(card)!=='icon'||!!card.previewSrc)?fileDetailHeight(fileFrameHeight(card),next):card.height;
    patch(card.id,{...values,height});
  }
  function openAttachment(card:Extract<Card,{type:'file'}>){
    if(!card.dataUrl){if(card.sourceUrl)window.open(safeUrl(card.sourceUrl),'_blank','noopener,noreferrer');return;}
    // Browsers reject top-level data: navigation. Preserve original bytes in a
    // temporary Blob URL rather than opening the generated first-page raster.
    void fetch(card.dataUrl).then(response=>response.blob()).then(blob=>{
      const url=URL.createObjectURL(blob);window.open(url,'_blank','noopener,noreferrer');setTimeout(()=>URL.revokeObjectURL(url),60000);
    }).catch(()=>notify('The attachment could not be opened.'));
  }
  function finishNoteEdit(){const session=noteEditBase.current;if(!session)return;noteEditBase.current=null;pendingNoteCommand.current=null;const next=docRef.current;const before=session.workspace.boards[session.boardId]?.cards.find(c=>c.id===session.id),after=next.boards[session.boardId]?.cards.find(c=>c.id===session.id);if(before&&after&&JSON.stringify(before)!==JSON.stringify(after))commit(next,session.workspace);setEditing(null);}
  function beginNoteEdit(card:Card){if(boardReadOnly)return;if(card.type!=='note'){setEditing(card.id);return;}if(noteEditBase.current?.id!==card.id){finishNoteEdit();noteEditBase.current={id:card.id,boardId:activeId,workspace:docRef.current};}setEditing(card.id);if(card.isDocument)setModal('document');}
  function runNoteCommand(command:NoteEditorCommand,value?:string|number){if(single?.type!=='note')return;if(editing===single.id&&noteEditorRef.current){noteEditorRef.current.run(command,value);return;}beginNoteEdit(single);pendingNoteCommand.current={command,value};}
  function handleNoteReady(){const pending=pendingNoteCommand.current;if(pending&&noteEditorRef.current){pendingNoteCommand.current=null;noteEditorRef.current.run('selectAll');noteEditorRef.current.run(pending.command,pending.value);}}
  function updateNoteContent(card:Extract<Card,{type:'note'}>,value:{text:string;html:string;height:number}){const session=noteEditBase.current;if(!session||session.id!==card.id)return;const height=Math.max(value.text.trim()?54:56,Math.min(2400,value.height+(card.parentId?4:0)))+(card.stripColor?4:0);const next=stampBoardModifications(docRef.current,applyNoteContent(docRef.current,session.boardId,card.id,value,height));docRef.current=next;setDoc(next);}
  function closeModal(){if(documentLinkOpen){setDocumentLinkOpen(false);noteEditorRef.current?.focus();return;}if(modal==='document')finishNoteEdit();setModal(null);}
  function requestTextLink(){setNoteLink('');if(modal==='document')setDocumentLinkOpen(true);else setModal('note-link');}
  function closeTextLink(){setDocumentLinkOpen(false);if(modal==='note-link')setModal(null);requestAnimationFrame(()=>noteEditorRef.current?.focus());}
  function textLinkForm(){return <><h2>Add a text link</h2><form onSubmit={event=>{event.preventDefault();runNoteCommand('link',noteLink);closeTextLink();}}><label className="note-link-label">URL<input autoFocus aria-label="Text link URL" value={noteLink} placeholder="https://example.com" onChange={event=>setNoteLink(event.target.value)}/></label><div className="note-link-actions"><button type="button" onClick={()=>{runNoteCommand('unsetLink');closeTextLink();}}>Remove link</button><button type="submit">Apply link</button></div></form></>;}
  function insertDocument(){finishNoteEdit();const p=center(),card={...createCard('note',p.x,p.y),type:'note' as const,text:'',isDocument:true,title:'Untitled document',height:150};change(b=>appendCardsAt(b,[card],p));setSelected([card.id]);beginNoteEdit(card);}
  const point = (clientX: number, clientY: number): Point => {
    const r = stageRef.current!.getBoundingClientRect();
    const v = vpRef.current;
    return {
      x: (clientX - r.left - v.x) / v.zoom,
      y: (clientY - r.top - v.y) / v.zoom,
    };
  };
  const center = (): Point => {
    const r = stageRef.current?.getBoundingClientRect();
    return r
      ? point(r.left + r.width / 2 - 100, r.top + r.height / 2 - 80)
      : { x: 140, y: 120 };
  };
  const navigate = (id: string, remember = true) => {
    finishNoteEdit();
    if (!workspaceBoard(docRef.current,id)) {notify('The original board has been deleted');return;}
    if(remember&&id!==activeId){boardNavigation.current.past.push(activeId);boardNavigation.current.future=[];}
    const visited=markBoardViewed(updateBoard(docRef.current, activeId, (b) => ({...b,viewport:vpRef.current})),id);
    docRef.current=visited;setDoc(visited);
    setBoardId(id);
    window.history.replaceState(null,'',boardLocalUrl(id));
    setSelected([]);
    setLineId(null);
    setEditing(null);
    setViewport(
      docRef.current.boards[id].viewport || { x: 30, y: 28, zoom: 0.85 },
    );
  };
  function navigateHistory(direction:'past'|'future'){
    const trail=boardNavigation.current,stack=trail[direction];
    let id:string|undefined;
    while(stack.length){const candidate=stack.pop()!;if(candidate!==activeId&&workspaceBoard(docRef.current,candidate)){id=candidate;break;}}
    if(!id)return;
    trail[direction==='past'?'future':'past'].push(activeId);
    navigate(id,false);
  }
  function beginDrawing(card?:Extract<Card,{type:'sketch'}>){if(boardReadOnly)return;finishNoteEdit();setTool('select');const rect=stageRef.current?.getBoundingClientRect();const at=rect?point(rect.left,rect.top):{x:0,y:0};setSketchSession(card?{id:card.id,at:{x:card.x,y:card.y},value:{paths:card.paths,width:card.width,height:card.height,background:card.background||'#ffffff'},mode:'sketch'}:{at,value:{paths:[],width:(rect?.width||1000)/viewport.zoom,height:(rect?.height||700)/viewport.zoom,background:'transparent'},mode:'board'});}
  function saveDrawing(value:SketchEditorValue){const session=sketchSession;if(!session)return;if(session.id)patch(session.id,value as Partial<Card>);else{const bounds=drawingBounds(value.paths);if(bounds){const margin=8;const card={...createCard('sketch',session.at.x+bounds.x-margin,session.at.y+bounds.y-margin),type:'sketch' as const,background:'transparent',width:Math.max(16,bounds.width+margin*2),height:Math.max(16,bounds.height+margin*2),paths:value.paths.map(path=>({...path,points:path.points.map(point=>({x:point.x-bounds.x+margin,y:point.y-bounds.y+margin}))}))};change(board=>({...board,cards:[...board.cards,card]}));setSelected([card.id]);}}setSketchSession(null);}
  useEffect(()=>{
    function openLinkedBoard(){const id=localBoardIdFromUrl(docRef.current,location.href);if(id&&id!==activeId)navigate(id);}
    window.addEventListener('hashchange',openLinkedBoard);
    return()=>window.removeEventListener('hashchange',openLinkedBoard);
  });
  function openWorkspaceSearch(){finishNoteEdit();setQuery('');setFilterLabelId(null);setModal(current=>current==='search'?null:'search');}
  const insertFreeLine=(at?:Point)=>{finishNoteEdit();const p=at||center(),line:Connection={id:uid(),from:'',to:'',start:{x:p.x,y:p.y+90},end:{x:p.x+180,y:p.y},color:'#323b4a',width:1.6,style:'solid',endArrow:true};change(b=>({...b,connections:[...b.connections,line]}));setSelected([]);setLineId(line.id);setTool('select');};
  function finishImageColorSampling(color:string|null){const resolve=imageColorResolve.current;imageColorResolve.current=null;setImageColorSampling(null);resolve?.(color);}
  function sampleBoardImageColor():Promise<string|null>{
    const stage=stageRef.current;if(!stage)return Promise.resolve(null);const bounds=stage.getBoundingClientRect();
    const images=visibleColorImages(board).sort((a,b)=>b.z-a.z).flatMap(card=>{
      const preview=stage.querySelector<HTMLElement>(`[data-card-id="${CSS.escape(card.id)}"] .image-preview`);if(!preview)return [];
      const rect=preview.getBoundingClientRect();if(!rect.width||!rect.height||rect.right<=bounds.left||rect.left>=bounds.right||rect.bottom<=bounds.top||rect.top>=bounds.bottom)return [];
      let background=board.background||'#ebedee',node:Element|null=preview;
      while(node&&stage.contains(node)){const color=parseImageSampleBackground(getComputedStyle(node).backgroundColor);if(color){background=color;break;}node=node.parentElement;}
      return [{id:card.id,source:colorImageSource(card),edits:card.imageEdits,background,rect:{x:rect.x,y:rect.y,width:rect.width,height:rect.height}}];
    });
    if(!images.length)return Promise.resolve(null);
    finishImageColorSampling(null);
    return new Promise(resolve=>{imageColorResolve.current=resolve;setImageColorSampling({images,clip:{x:bounds.x,y:bounds.y,width:bounds.width,height:bounds.height}});});
  }
  const insert = (type: Card["type"], at?: Point) => {
    if(boardReadOnly)return;
    const p = at || center();
    if(type==='swatch'&&visibleColorImages(board).length){
      const origin=activeId,workspaceId=docRef.current.id,epoch=imageColorEpoch.current,images=visibleColorImages(board).slice(0,24);
      const add=async()=>{
        if(epoch!==imageColorEpoch.current||docRef.current.id!==workspaceId||!docRef.current.boards[origin])return;
        const results=await Promise.allSettled(images.map(async image=>imagePalette(await readImageColors(colorImageSource(image),image.imageEdits))));
        if(epoch!==imageColorEpoch.current||docRef.current.id!==workspaceId||!docRef.current.boards[origin])return;
        // Drag previews rebuild from their captured workspace. Wait until that
        // transaction has committed so an asynchronous extraction cannot be
        // overwritten by the next pointer move or accidentally join its Undo.
        while(gesture.current){
          if(epoch!==imageColorEpoch.current||docRef.current.id!==workspaceId||!docRef.current.boards[origin])return;
          await new Promise<void>(resolve=>requestAnimationFrame(()=>resolve()));
        }
        if(epoch!==imageColorEpoch.current||docRef.current.id!==workspaceId||!docRef.current.boards[origin])return;
        const current=docRef.current.boards[origin],palette=results.flatMap(result=>result.status==='fulfilled'?result.value:[]),used=current.cards.filter((card):card is Extract<Card,{type:'swatch'}>=>card.type==='swatch').map(card=>card.value);
        const value=chooseImageColor(palette,used),card=createCard('swatch',Math.round(p.x),Math.round(p.y));
        if(card.type!=='swatch')return;if(value){card.value=value;card.label=imageColorName(value);}
        commit(updateBoard(docRef.current,origin,board=>appendCardsAt(board,[card],p)));
        if(imageColorBoard.current===origin)setSelected([card.id]);
      };
      swatchInsertQueue.current=swatchInsertQueue.current.then(add,add);return;
    }
    if (type === "board") {
      const childId = uid();
      const card = {
        ...createCard("board", p.x, p.y),
        title: "Untitled board",
        boardId: childId,
      } as Card;
      const next = {
        ...docRef.current,
        boards: {
          ...docRef.current.boards,
          [childId]: {
            id: childId,
            title: "Untitled board",
            parentBoardId: activeId,
            cards: [],
            connections: [],
            viewport: { x: 30, y: 28, zoom: 1 },
          } as Board,
        },
      };
      commit(updateBoard(next, activeId, (b) => appendCardsAt(b, [card], p)));
      setSelected([card.id]);
      return;
    }
    if (type === "image" || type === "file") {
      uploadKind.current = type;
      uploadAt.current=at;
      if (uploadRef.current)
        uploadRef.current.accept = type === "image" ? "image/*" : "";
      uploadRef.current?.click();
      return;
    }
    const c = createCard(type, Math.round(p.x), Math.round(p.y));
    if(c.type==='table')formulaRegistry.current.snapshot=reconcileFormulaWorkbook(formulaRegistry.current.snapshot,[c],{createdTableIds:[c.id]});
    change((b) => appendCardsAt(b, [c], p));
    setSelected([c.id]);
    if(type==='note')beginNoteEdit(c);else if(type==='label')setEditing(c.id);
    if (c.type === "sketch") beginDrawing(c);
  };
  const remove = () => {
    if(boardReadOnly)return;
    finishNoteEdit();
    if(lineId){commit(trashConnections(docRef.current,activeId,[lineId]));setLineId(null);return;}
    const ids=selected.filter(id=>!cards.find(card=>card.id===id)?.locked);
    if(!ids.length){if(selected.length)notify('Unlock the item before deleting');return;}
    commit(trashCards(docRef.current,activeId,ids));setSelected([]);setEditing(null);
  };
  const copy = () => {
    clipboard.current = {
      workspace: structuredClone(docRef.current),
      boardId: activeId,
      ids: [...selected],
    };
    notify(
      `${selectedCards.length} item${selectedCards.length === 1 ? "" : "s"} copied`,
    );
  };
  const paste = (at?:Point) => {
    const clip = clipboard.current;
    if (!clip) return;
    const result = copyCardsToBoard(
      clip.workspace,
      clip.boardId,
      clip.ids,
      docRef.current,
      activeId,
      at?{x:at.x-Math.min(...clip.workspace.boards[clip.boardId].cards.filter(card=>clip.ids.includes(card.id)).map(card=>card.x)),y:at.y-Math.min(...clip.workspace.boards[clip.boardId].cards.filter(card=>clip.ids.includes(card.id)).map(card=>card.y))}:undefined,
    );
    commit(result.workspace);
    setSelected(result.ids);
  };
  const duplicate = () => {
    const next = duplicateCards(docRef.current, activeId, selected);
    commit(next.workspace);
    setSelected(next.ids);
  };
  const fit = () => {
    const lineBounds=board.connections.map(line=>connectionBounds(line,visibleCards,12)).filter((value):value is NonNullable<typeof value>=>!!value);
    if (!visibleCards.length&&!lineBounds.length) {
      setViewport({ x: 30, y: 28, zoom: 1 });
      return;
    }
    const r = stageRef.current!.getBoundingClientRect();
    const minX = Math.min(...visibleCards.map((c) => c.x),...lineBounds.map(bounds=>bounds.x)),
      minY = Math.min(...visibleCards.map((c) => c.y),...lineBounds.map(bounds=>bounds.y));
    const maxX = Math.max(...visibleCards.map((c) => c.x + c.width),...lineBounds.map(bounds=>bounds.x+bounds.width)),
      maxY = Math.max(
        ...visibleCards.map(
          (c) => c.y + (c.type === "column" && c.collapsed ? 62.2 : c.height),
        ),...lineBounds.map(bounds=>bounds.y+bounds.height),
      );
    const z = Math.min(
      1.25,
      Math.max(
        0.15,
        Math.min(
          (r.width - 200) / (maxX - minX),
          (r.height - 250) / (maxY - minY),
        ),
      ),
    );
    setViewport({
      x: 100 + (r.width - 120 - (maxX - minX) * z) / 2 - minX * z,
      y: 170 + (r.height - 240 - (maxY - minY) * z) / 2 - minY * z,
      zoom: z,
    });
  };
  const zoom = (factor: number) => {
    const r = stageRef.current!.getBoundingClientRect();
    setViewport((v) => {
      const z = Math.min(2.5, Math.max(0.15, v.zoom * factor));
      return {
        x: r.width / 2 - ((r.width / 2 - v.x) * z) / v.zoom,
        y: r.height / 2 - ((r.height / 2 - v.y) * z) / v.zoom,
        zoom: z,
      };
    });
  };
  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const wheel = (e: WheelEvent) => {
      e.preventDefault();
      if (e.ctrlKey || e.metaKey) {
        const r = el.getBoundingClientRect();
        const x = e.clientX - r.left,
          y = e.clientY - r.top;
        setViewport((v) => {
          const z = Math.min(
            2.5,
            Math.max(0.15, v.zoom * Math.exp(-e.deltaY * 0.007)),
          );
          return {
            x: x - ((x - v.x) * z) / v.zoom,
            y: y - ((y - v.y) * z) / v.zoom,
            zoom: z,
          };
        });
      } else
        setViewport((v) => ({ ...v, x: v.x - e.deltaX, y: v.y - e.deltaY }));
    };
    el.addEventListener("wheel", wheel, { passive: false });
    return () => el.removeEventListener("wheel", wheel);
  }, []);
  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if(e.defaultPrevented&&e.key!=='Escape')return;
      if(presenting||sketchSession||labelsOpen||trashOpen||syncedPopup||cutoutId||imageLibraryOpen||exportMenuOpen||viewMenuOpen)return;
      if (e.key === "Escape") {
        if(documentLinkOpen){e.preventDefault();setDocumentLinkOpen(false);noteEditorRef.current?.focus();return;}
        if(imageEditorId){setImageEditorId(null);return;}
        const cancelledGesture=gesture.current;
        clearBoardDrag(cancelledGesture,true);
        if(cancelledGesture?.base){docRef.current=cancelledGesture.base;setDoc(cancelledGesture.base);}
        connectorDragCleanup.current?.();gesture.current=null;pointers.current.clear();
        setMarquee(null);setColumnDrop(null);setDraftPath([]);
        finishNoteEdit();
        if (
          document.activeElement instanceof HTMLTextAreaElement ||
          document.activeElement instanceof HTMLInputElement
        )
          (document.activeElement as HTMLElement).blur();
        setModal(null);
        setContext(null);
        setEditing(null);
        setTool("select");
        setFrom(null);
        setSelected(cancelledGesture?.kind==='move'?cancelledGesture.originalIds:[]);
        return;
      }
      if(modal||imageEditorId)return;
      const mod = e.ctrlKey || e.metaKey;
      if(mod&&e.key==='Enter'&&single&&['note','column','board'].includes(single.type)){e.preventDefault();finishNoteEdit();insert(single.type,{x:single.x,y:single.y+single.height+24});return;}
      if (isEditing()) return;
      if(mod&&(e.key==='+'||e.key==='=')){e.preventDefault();zoom(1.2);}
      else if(mod&&e.key==='-'){e.preventDefault();zoom(1/1.2);}
      else if(mod&&e.key==='0'){e.preventDefault();zoom(1/vpRef.current.zoom);}
      else if(mod&&e.key==='['){e.preventDefault();navigateHistory('past');}
      else if(mod&&e.key===']'){e.preventDefault();navigateHistory('future');}
      else if(mod&&e.key.toLowerCase()==='u'){e.preventDefault();if(board.parentBoardId)navigate(board.parentBoardId);}
      else if (mod && e.key.toLowerCase() === "z") {
        e.preventDefault();
        e.shiftKey ? redo() : undo();
      } else if (mod && e.key.toLowerCase() === "y") {
        e.preventDefault();
        redo();
      } else if (mod && e.key.toLowerCase() === "a") {
        e.preventDefault();
        setSelected(visibleCards.map((c) => c.id));
      } else if (mod && e.key.toLowerCase() === "c") {
        e.preventDefault();
        copy();
      } else if (mod && e.key.toLowerCase() === "v") {
        /* The paste event also accepts system text and images. */
      } else if (mod && e.key.toLowerCase() === "d") {
        e.preventDefault();
        duplicate();
      } else if(mod&&e.key.toLowerCase()==='x'){e.preventDefault();copy();remove();}
      else if(mod&&e.shiftKey&&['ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();change(b=>({...b,cards:b.cards.map(card=>selected.includes(card.id)?{...card,z:e.key==='ArrowUp'?Math.max(...b.cards.map(item=>item.z))+1:Math.min(...b.cards.map(item=>item.z))-1}:card)}));}
      else if (mod && ["k","f"].includes(e.key.toLowerCase())) {
        e.preventDefault();
        openWorkspaceSearch();
      } else if (e.key === "Delete" || e.key === "Backspace") {
        e.preventDefault();
        remove();
      } else if (e.code === "Space") {
        e.preventDefault();
        setTool("hand");
      } else if(single?.type==='image'&&!mod&&!e.altKey&&e.key.length===1){e.preventDefault();patch(single.id,{showCaption:true,caption:single.caption+e.key});setEditing(single.id);}
      else if (e.key === "v") setTool("select");
      else if (e.key === "p" || e.shiftKey&&e.key.toLowerCase()==='d') beginDrawing();
      else if (e.key === "l") setTool("connect");
      else if (e.key === "n") insert("note");
      else if (e.key === "0" || e.key.toLowerCase()==='z') fit();
      else if(e.key==='/'){e.preventDefault();setModal('help');}
      else if (
        ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key) &&
        selected.length
      ) {
        e.preventDefault();
        const s = e.shiftKey ? 10 : 1;
        change((b) => ({
          ...b,
          cards: b.cards.map((c) =>
            expandSelection(
              b,
              selected.filter(
                (id) => !b.cards.find((c) => c.id === id)?.locked,
              ),
            ).includes(c.id)
              ? {
                  ...c,
                  x:
                    c.x +
                    (e.key === "ArrowRight"
                      ? s
                      : e.key === "ArrowLeft"
                        ? -s
                        : 0),
                  y:
                    c.y +
                    (e.key === "ArrowDown" ? s : e.key === "ArrowUp" ? -s : 0),
                }
              : c,
          ),
        }));
      }
    };
    const up = (e: KeyboardEvent) => {
      if (e.code === "Space") setTool("select");
    };
    window.addEventListener("keydown", key);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", key);
      window.removeEventListener("keyup", up);
    };
  });
  const captureTouch = (e: ReactPointerEvent) => {
    if (e.pointerType !== "touch") return;
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.current.size === 2) {
      touchCardPress.current=null;lastTouchCardTap.current=null;
      const [a, b] = [...pointers.current.values()];
      if(gesture.current?.kind==='create-connection'){const g=gesture.current;connectorDragCleanup.current?.();docRef.current=g.base;setLineId(g.lineId);setSelected(g.selected);setFrom(g.from);setTool(g.tool);}
      clearBoardDrag(gesture.current);
      if (gesture.current?.base) setDoc(gesture.current.base);
      gesture.current = {
        kind: "pinch",
        distance: Math.hypot(a.x - b.x, a.y - b.y),
        mid: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 },
        vp: { ...vpRef.current },
      };
      stageRef.current?.setPointerCapture(e.pointerId);
      setColumnDrop(null);
      e.preventDefault();
      e.stopPropagation();
    }
  };
  function createSyncedCopy(noteId:string){finishNoteEdit();const result=createSyncedNote(docRef.current,activeId,noteId);commit(result.workspace);if(result.id)setSelected([result.id]);}
  function syncedIndicator(card:Card){
    if(card.type!=='note'||!card.syncedId)return null;
    const count=(syncedLocations.get(card.syncedId)||[]).reduce((sum,location)=>sum+location.noteIds.length,0);
    return <SyncedNoteIndicator count={count} open={syncedPopup?.id===card.id} onOpen={anchor=>{finishNoteEdit();setSyncedPopup(previous=>previous?.id===card.id?null:{id:card.id,anchor});}}/>;
  }
  function openSyncedBoard(id:string){const location=syncedPopupLocations.find(location=>location.boardId===id);setSyncedPopup(null);navigate(id);if(location?.unsorted)setInboxOpen(true);}
  function openCard(card:Card){
    if(boardReadOnly&&card.type!=='board')return;
    if(card.type==='board'){navigate(card.boardId);return;}
    if(card.locked&&card.type!=='note')return;
    if(card.type==='sketch'){beginDrawing(card);setSelected([card.id]);}
    else if(card.type==='note')beginNoteEdit(card);
    else if(card.type==='image'){setEditing(null);setImageMode('crop');setImageEditorId(card.id);}
    else if(card.type==='swatch')swatchRefs.current.get(card.id)?.openPicker();
    else if(card.type==='link'||card.type==='label')setEditing(card.id);
  }
  function finishTouchCardTap(event:ReactPointerEvent){
    const press=touchCardPress.current;touchCardPress.current=null;
    if(event.pointerType!=='touch'||!press||press.pointer!==event.pointerId)return;
    const now=Date.now();
    if(press.moved||now-press.started>450||Math.hypot(event.clientX-press.x,event.clientY-press.y)>4){lastTouchCardTap.current=null;return;}
    const previous=lastTouchCardTap.current;
    if(previous?.id===press.id&&now-previous.ended<=350&&Math.hypot(event.clientX-previous.x,event.clientY-previous.y)<=18){
      lastTouchCardTap.current=null;
      const card=docRef.current.boards[activeId]?.cards.find(card=>card.id===press.id);
      if(card){lastTouchCardOpen.current={id:card.id,at:now};openCard(card);}
    }else lastTouchCardTap.current={id:press.id,x:event.clientX,y:event.clientY,ended:now};
  }
  const startStage = (e: ReactPointerEvent) => {
    if(e.pointerType==='touch'&&!(e.target as Element).closest('.card')){touchCardPress.current=null;lastTouchCardTap.current=null;}
    if (
      (e.target as HTMLElement).closest(
        'button,input,textarea,a,[contenteditable="true"]',
      )
    )
      return;
    setContext(null);
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.current.size === 2) {
      const [a, b] = [...pointers.current.values()];
      clearBoardDrag(gesture.current);
      if (gesture.current?.base) setDoc(gesture.current.base);
      gesture.current = {
        kind: "pinch",
        distance: Math.hypot(a.x - b.x, a.y - b.y),
        mid: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 },
        vp: { ...vpRef.current },
      };
      stageRef.current?.setPointerCapture(e.pointerId);
      return;
    }
    if (
      (e.target as HTMLElement).closest(".card") &&
      tool !== "hand" &&
      tool !== "draw"
    )
      return;
    stageRef.current?.setPointerCapture(e.pointerId);
    const p = point(e.clientX, e.clientY);
    if (tool === "draw") {
      const el = (e.target as HTMLElement).closest(
        "[data-card-id]",
      ) as HTMLElement | null;
      const c = cards.find((c) => c.id === el?.dataset.cardId);
      if (c?.type === "sketch" && !c.locked) {
        setSelected([c.id]);
        gesture.current = {
          kind: "draw-in",
          card: c,
          base: docRef.current,
          points: [{ x: p.x - c.x, y: p.y - c.y }],
        };
      } else {
        gesture.current = { kind: "draw", points: [p] };
        setDraftPath([p]);
      }
    } else if (tool === "hand" || e.button === 1 || e.pointerType === "touch") {
      gesture.current = {
        kind: "pan",
        x: e.clientX,
        y: e.clientY,
        vp: { ...vpRef.current },
      };
    } else {
      gesture.current = { kind: "marquee", start: p, add: e.shiftKey };
      setMarquee({ start: p, end: p });
      if (!e.shiftKey) setSelected([]);
      setLineId(null);
      setEditing(null);
    }
  };
  function clearBoardDrag(g:any,restoreView=false){
    if(g?.kind!=='move')return;
    clearTimeout(g.previewHoverTimer);g.previewHover=undefined;setPreviewDragReady(null);
    clearTimeout(g.boardHoverTimer);g.boardHover=undefined;setBoardDragHover(null);setBoardDragPreview(null);
    if(restoreView&&g.sourceBoardId&&g.hasOpenedBoard){
      // Seen boards remain in recent history, while the drag's content and
      // navigation trail return to their pre-drag state.
      if(g.seenBoardActivity)g.base=retainBoardActivity(g.base,{...g.base,boardActivity:g.seenBoardActivity});
      if(g.navigationTrail)boardNavigation.current={past:[...g.navigationTrail.past],future:[...g.navigationTrail.future]};
      setBoardId(g.sourceBoardId);setViewport(g.sourceViewport);setSelected(g.originalIds);window.history.replaceState(null,'',g.sourceUrl);
    }
  }
  function rememberBoardDragVisit(g:any){
    if(!g.hasOpenedBoard||g.viewBoardId===g.sourceBoardId)return;
    const trail=g.navigationTrail||boardNavigation.current;
    boardNavigation.current={past:[...trail.past,g.sourceBoardId],future:[]};
  }
  function draggedCards(g:any){return docRef.current.boards[g.sourceBoardId]?.cards.filter(card=>g.ids.includes(card.id))||[];}
  function updateBoardDragPreview(g:any){
    if(!g.hasOpenedBoard||!g.previewElement)return;
    setBoardDragPreview({element:g.previewElement,client:g.lastClient,grab:g.grab,zoom:vpRef.current.zoom});
  }
  function boardTileUnderPointer(board:Board,client:Point,movingIds:string[]){
    const stage=stageRef.current,rect=stage?.getBoundingClientRect();
    if(!stage||!rect||client.x<rect.left||client.x>rect.right||client.y<rect.top||client.y>rect.bottom)return;
    const ignored=new Set(movingIds),seen=new Set<string>();
    for(const element of document.elementsFromPoint(client.x,client.y)){
      if(element.closest('.board-drag-preview'))continue;
      const article=element.closest<HTMLElement>('[data-card-id]');
      if(!article||!stage.contains(article)||!article.dataset.cardId||seen.has(article.dataset.cardId))continue;
      const id=article.dataset.cardId;seen.add(id);if(ignored.has(id))continue;
      const card=board.cards.find(card=>card.id===id);
      // A visible note or other card covers the tile beneath it. Only the
      // frontmost non-carried card is a possible board target.
      return card?.type==='board'&&!card.unsorted?card:undefined;
    }
  }
  function previewTargetUnderPointer(g:any){
    if(g.ids.length!==1||g.duplicateOnDrag||g.hasOpenedBoard)return;
    const board=workspaceBoard(docRef.current,g.sourceBoardId),image=board?.cards.find(card=>card.id===g.ids[0]);
    if(image?.type!=='image'||image.locked)return;
    for(const element of document.elementsFromPoint(g.lastClient.x,g.lastClient.y)){
      const article=element.closest<HTMLElement>('[data-card-id]');if(!article||g.ids.includes(article.dataset.cardId))continue;
      const target=board?.cards.find(card=>card.id===article.dataset.cardId);
      if(target?.type!=='link'||target.locked||!target.previewSrc||target.showPreview===false||target.showMedia)return;
      const preview=article.querySelector('.link-preview')?.getBoundingClientRect();
      if(preview&&g.lastClient.x>=preview.left&&g.lastClient.x<=preview.right&&g.lastClient.y>=preview.top&&g.lastClient.y<=preview.bottom)return target;
      return;
    }
  }
  function armPreviewDrag(g:any){
    const target=g.moved?previewTargetUnderPointer(g):undefined;
    if(target&&g.previewHover?.id===target.id)return;
    clearTimeout(g.previewHoverTimer);g.previewHover=undefined;setPreviewDragReady(null);
    if(!target)return;
    const held={id:target.id,ready:false};g.previewHover=held;
    g.previewHoverTimer=setTimeout(()=>{if(gesture.current===g&&g.previewHover===held&&previewTargetUnderPointer(g)?.id===held.id){held.ready=true;setPreviewDragReady(held.id);}},1000);
  }
  async function replaceHeldPreview(origin:string,image:Extract<Card,{type:'image'}>,target:Extract<Card,{type:'link'}>){
    const workspaceId=docRef.current.id,epoch=asyncMutationEpoch.current,key=JSON.stringify([origin,target.id]),request={};previewDropRequests.current.set(key,request);
    const valid=()=>{const board=workspaceBoard(docRef.current,origin),source=board?.cards.find(card=>card.id===image.id),link=board?.cards.find(card=>card.id===target.id);return previewDropRequests.current.get(key)===request&&epoch===asyncMutationEpoch.current&&docRef.current.id===workspaceId&&source?.type==='image'&&!source.locked&&source.src===image.src&&source.cutoutSrc===image.cutoutSrc&&source.useCutout===image.useCutout&&JSON.stringify(source.imageEdits)===JSON.stringify(image.imageEdits)&&link?.type==='link'&&!link.locked&&link.url===target.url&&link.previewSrc===target.previewSrc;};
    try{
      const src=await bakeImageEdits(image.useCutout&&image.cutoutSrc?image.cutoutSrc:image.src,image.imageEdits);
      while(gesture.current||noteEditBase.current){if(!valid())return;await new Promise<void>(resolve=>requestAnimationFrame(()=>resolve()));}
      if(!valid())return;
      let next=deleteCards(docRef.current,origin,[image.id]);
      next=updateBoard(next,origin,board=>arrangeAllColumns({...board,cards:board.cards.map(card=>card.id===target.id?{...card,previewSrc:src,showPreview:true}:card)}));
      commit(next);if(imageColorBoard.current===origin)setSelected([target.id]);
    }catch{if(valid()&&imageColorBoard.current===origin)notify('The image could not be opened.');}
    finally{if(previewDropRequests.current.get(key)===request)previewDropRequests.current.delete(key);}
  }
  function armBoardDragHover(g:any){
    armPreviewDrag(g);
    const client=g.lastClient as Point,currentId=g.viewBoardId as string,current=docRef.current.boards[currentId];
    if(!g.moved||!current){clearTimeout(g.boardHoverTimer);g.boardHover=undefined;setBoardDragHover(null);return;}
    let candidate:{id:string;key:string}|undefined;
    for(const crumb of document.querySelectorAll<HTMLElement>('.breadcrumbs [data-drag-board-id]')){
      const rect=crumb.getBoundingClientRect(),id=crumb.dataset.dragBoardId;
      if(id&&id!==currentId&&rect.width&&client.x>=rect.left&&client.x<=rect.right&&client.y>=rect.top&&client.y<=rect.bottom){candidate={id,key:`breadcrumb:${id}`};break;}
    }
    if(!candidate){
      const tile=boardTileUnderPointer(current,client,g.ids);
      if(tile?.type==='board'&&tile.boardId!==currentId)candidate={id:tile.boardId,key:`tile:${tile.id}`};
    }
    if(candidate&&g.boardHover?.key===candidate.key)return;
    if(!candidate||!canMoveDragToBoard(docRef.current,g.sourceBoardId,candidate.id,g.ids)){
      // Returning to the source board is a view operation, not a transfer.
      if(candidate?.id!==g.sourceBoardId){clearTimeout(g.boardHoverTimer);g.boardHover=undefined;setBoardDragHover(null);return;}
    }
    if(!candidate)return;
    clearTimeout(g.boardHoverTimer);g.boardHover=candidate;setBoardDragHover(candidate.key);
    const held=candidate;
    g.boardHoverTimer=setTimeout(()=>{
      if(gesture.current!==g||g.boardHover!==held||!docRef.current.boards[held.id])return;
      if(held.id!==g.sourceBoardId&&!canMoveDragToBoard(docRef.current,g.sourceBoardId,held.id,g.ids))return;
      if(!g.previewElement&&stageRef.current)g.previewElement=captureBoardDragPreview(stageRef.current,draggedCards(g));
      const nextViewport=docRef.current.boards[held.id].viewport;
      g.hasOpenedBoard=true;g.viewBoardId=held.id;g.boardHover=undefined;setBoardDragHover(null);setColumnDrop(null);
      navigate(held.id,false);g.seenBoardActivity=docRef.current.boardActivity;setSelected(g.ids);
      if(g.previewElement)setBoardDragPreview({element:g.previewElement,client:g.lastClient,grab:g.grab,zoom:nextViewport.zoom});
    },BOARD_HOVER_OPEN_MS);
  }
  function completeBoardDrag(g:any,event:ReactPointerEvent){
    const stage=stageRef.current?.getBoundingClientRect(),source=docRef.current.boards[g.sourceBoardId],target=docRef.current.boards[g.viewBoardId];
    clearBoardDrag(g);
    if(!stage||!source||!target||event.clientX<stage.left||event.clientX>stage.right||event.clientY<stage.top||event.clientY>stage.bottom){docRef.current=g.base;setDoc(g.base);clearBoardDrag(g,true);setSelected(g.originalIds);return;}
    const at=boardDragAnchor({x:event.clientX,y:event.clientY},stage,vpRef.current,g.grab),payload=draggedCards(g);
    if(!payload.length){docRef.current=g.base;setDoc(g.base);clearBoardDrag(g,true);setSelected(g.originalIds);return;}
    const tile=boardTileUnderPointer(target,{x:event.clientX,y:event.clientY},g.ids);
    if(tile?.type==='board'&&canMoveDragToBoard(docRef.current,g.sourceBoardId,tile.boardId,g.ids)){
      commit(moveCardsToBoard(docRef.current,g.sourceBoardId,tile.boardId,g.ids,{x:40,y:40}),g.base);rememberBoardDragVisit(g);setSelected([]);setColumnDrop(null);return;
    }
    let next:Workspace;
    if(g.sourceBoardId!==g.viewBoardId)next=moveCardsToBoard(docRef.current,g.sourceBoardId,g.viewBoardId,g.ids,at);
    else{
      const dx=at.x-Math.min(...payload.map(card=>card.x)),dy=at.y-Math.min(...payload.map(card=>card.y));
      next=updateBoard(docRef.current,g.sourceBoardId,board=>({...board,cards:board.cards.map(card=>g.ids.includes(card.id)?{...card,x:Math.round(card.x+dx),y:Math.round(card.y+dy)}:card)}));
    }
    if(next===docRef.current){docRef.current=g.base;setDoc(g.base);clearBoardDrag(g,true);setSelected(g.originalIds);return;}
    const current=next.boards[g.viewBoardId],roots=current.cards.filter(card=>g.ids.includes(card.id)&&(!card.parentId||!g.ids.includes(card.parentId))),column=columnTarget(current,roots,g.ids);
    if(column){const siblings=columnChildren(current,column.id).filter(card=>!g.ids.includes(card.id)),first=roots.find(card=>card.type!=='column'),index=first?siblings.filter(card=>card.y+card.height/2<first.y+first.height/2).length:siblings.length;next=updateBoard(next,g.viewBoardId,board=>placeInColumn(board,roots.map(card=>card.id),column.id,index));}
    else next=updateBoard(next,g.viewBoardId,board=>removeFromColumn(board,roots.filter(card=>card.parentId).map(card=>card.id)));
    commit(next,g.base);rememberBoardDragVisit(g);setSelected(g.ids);setColumnDrop(null);
  }
  const startCard = (e: ReactPointerEvent, c: Card) => {
    if(boardReadOnly&&tool!=='hand'){e.stopPropagation();setSelected([c.id]);return;}
    // A secondary click must keep its real card target for the context menu.
    // Capturing it as a move retargets Chromium's contextmenu to the stage.
    if(e.button===2){e.stopPropagation();return;}
    if (
      (e.target as HTMLElement).closest(
        'button,input,textarea,a,[contenteditable="true"]',
      ) ||
      editing === c.id
    )
      return;
    if (tool === "hand") return;
    if (tool === "connect") {
      e.stopPropagation();
      if (from && from !== c.id) {
        const connection: Connection = {
          id: uid(),
          from,
          to: c.id,
          color: "#69796b",
          style: "solid",
        };
        change((b) => ({ ...b, connections: [...b.connections, connection] }));
        setFrom(null);
        setTool("select");
      } else setFrom(c.id);
      return;
    }
    if (tool === "draw") return;
    // A read-mode card owns the pointer drag. In WebKit an existing native
    // text selection can otherwise start HTML dragging and steal the stream.
    finishNoteEdit();
    if(document.activeElement instanceof HTMLElement&&document.activeElement!==document.body)document.activeElement.blur();
    document.getSelection()?.removeAllRanges();
    e.preventDefault();
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.current.size === 2) {
      const [a, b] = [...pointers.current.values()];
      clearBoardDrag(gesture.current);
      if (gesture.current?.base) setDoc(gesture.current.base);
      gesture.current = {
        kind: "pinch",
        distance: Math.hypot(a.x - b.x, a.y - b.y),
        mid: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 },
        vp: { ...vpRef.current },
      };
      stageRef.current?.setPointerCapture(e.pointerId);
      e.stopPropagation();
      return;
    }
    e.stopPropagation();
    setContext(null);
    setLineId(null);
    let ids = selected.includes(c.id)
      ? selected
      : e.shiftKey
        ? [...selected, c.id]
        : [c.id];
    if (e.shiftKey && selected.includes(c.id))
      ids = selected.filter((id) => id !== c.id);
    setSelected(ids);
    if (c.locked) return;
    ids = expandSelection(
      board,
      ids.filter((id) => !cards.find((c) => c.id === id)?.locked),
    );
    gesture.current = {
      kind: "move",
      pointerId:e.pointerId,
      sourceBoardId:activeId,viewBoardId:activeId,sourceViewport:{...vpRef.current},sourceUrl:location.href,lastClient:{x:e.clientX,y:e.clientY},
      navigationTrail:{past:[...boardNavigation.current.past],future:[...boardNavigation.current.future]},
      grab:boardDragGrab(cards.filter(card=>ids.includes(card.id)),point(e.clientX,e.clientY)),
      x: e.clientX,
      y: e.clientY,
      ids,
      base: docRef.current,
      duplicateOnDrag:e.altKey,
      originalIds:[...selected],
      positions: new Map(
        cards
          .filter((i) => ids.includes(i.id))
          .map((i) => [i.id, { x: i.x, y: i.y }]),
      ),
    };
    stageRef.current?.setPointerCapture(e.pointerId);
  };
  const startConnector = (e: ReactPointerEvent<HTMLButtonElement>,card:Card) => {
    if(e.button!==0)return;
    e.preventDefault();e.stopPropagation();finishNoteEdit();
    connectorDragCleanup.current?.();
    suppressConnectorClick.current=false;
    const capture=e.currentTarget,pointerId=e.pointerId;
    const g={kind:'create-connection',pointerId,base:docRef.current,boardId:activeId,card,x:e.clientX,y:e.clientY,moved:false,line:{id:uid(),from:card.id,to:'',end:point(e.clientX,e.clientY),color:'#323b4a',style:'solid',width:1.6} as Connection,cards:visibleCards,selected:[...selected],lineId,from,tool,hover:undefined as {card:Card;point:Point;ready:boolean;shifted:boolean}|undefined,timer:undefined as ReturnType<typeof setTimeout>|undefined};
    gesture.current=g;
    try{capture.setPointerCapture(pointerId);}catch{/* Stage handlers still receive the pointer. */}
    const cleanup=()=>{clearTimeout(g.timer);setConnectorAnchorHint(null);window.removeEventListener('keydown',key,true);try{if(capture.hasPointerCapture(pointerId))capture.releasePointerCapture(pointerId);}catch{/* The board may have changed. */}connectorDragCleanup.current=null;};
    const key=(event:KeyboardEvent)=>{
      event.stopPropagation();
      if(event.key!=='Escape')return;
      event.preventDefault();cleanup();suppressConnectorClick.current=true;
      docRef.current=g.base;setDoc(g.base);setSelected(g.selected);setLineId(g.lineId);setFrom(g.from);setTool(g.tool);gesture.current=null;
      window.addEventListener('pointerup',()=>{setTimeout(()=>{suppressConnectorClick.current=false;},0);},{capture:true,once:true});
    };
    connectorDragCleanup.current=cleanup;
    window.addEventListener('keydown',key,true);
  };
  const previewConnector = (g:any,e:ReactPointerEvent) => {
    if(e.pointerId!==g.pointerId)return;
    if(!g.moved&&Math.hypot(e.clientX-g.x,e.clientY-g.y)<3)return;
    g.moved=true;suppressConnectorClick.current=true;
    let at=point(e.clientX,e.clientY);
    const initial=connectionGeometry(g.line,g.cards);
    const source=g.card;
    if(e.shiftKey)at=constrainConnectionPoint({x:source.x+source.width,y:source.y+(source.type==='column'&&source.collapsed?62.2:source.height)/2},at);
    const target=connectionTargetAt(at,g.cards,source.id);
    if(!target||g.hover?.card.id!==target.id||Math.hypot(at.x-g.hover.point.x,at.y-g.hover.point.y)>3||g.hover.shifted!==e.shiftKey){
      clearTimeout(g.timer);setConnectorAnchorHint(null);
      g.hover=target?{card:target,point:{...at},ready:e.shiftKey,shifted:e.shiftKey}:undefined;
      if(g.hover&&!g.hover.ready){
        const held=g.hover;
        g.timer=setTimeout(()=>{
          if(gesture.current!==g||g.hover!==held)return;
          held.ready=true;setConnectorAnchorHint(held.point);
          g.line=attachConnectionHandle({...g.line,to:'',toAnchor:undefined,end:held.point},'end',held.card,connectionAnchorAt(held.card,held.point));
          const next=updateBoard(g.base,g.boardId,b=>({...b,connections:[...b.connections,g.line]}));docRef.current=next;setDoc(next);
        },450);
      }
    }
    let next:Connection={...g.line,to:'',toAnchor:undefined,end:at};
    if(g.hover){next=attachConnectionHandle(next,'end',g.hover.card,g.hover.ready?connectionAnchorAt(g.hover.card,g.hover.point):undefined);if(g.hover.ready)setConnectorAnchorHint(g.hover.point);}
    // Keep Shift constrained even when the pointer crosses the source card's center.
    if(e.shiftKey&&initial)next={...next,fromAnchor:connectionAnchorAt(source,{x:source.x+source.width,y:source.y+(source.type==='column'&&source.collapsed?62.2:source.height)/2})};
    else next={...next,fromAnchor:undefined};
    g.line=next;
    const preview=updateBoard(g.base,g.boardId,b=>({...b,connections:[...b.connections,next]}));docRef.current=preview;setDoc(preview);setSelected([]);setLineId(next.id);setFrom(null);setTool('select');
  };
  const movePointer = (e: ReactPointerEvent) => {
    const touchPress=touchCardPress.current;
    if(touchPress?.pointer===e.pointerId&&Math.hypot(e.clientX-touchPress.x,e.clientY-touchPress.y)>4)touchPress.moved=true;
    if (pointers.current.has(e.pointerId))
      pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const g = gesture.current;
    if (!g) return;
    if (g.kind === "pinch" && pointers.current.size === 2) {
      const [a, b] = [...pointers.current.values()];
      const r = stageRef.current!.getBoundingClientRect();
      const z = Math.min(
        2.5,
        Math.max(
          0.15,
          (g.vp.zoom * Math.hypot(a.x - b.x, a.y - b.y)) / g.distance,
        ),
      );
      const mx = (a.x + b.x) / 2 - r.left,
        my = (a.y + b.y) / 2 - r.top;
      setViewport({
        zoom: z,
        x: mx - ((g.mid.x - r.left - g.vp.x) * z) / g.vp.zoom,
        y: my - ((g.mid.y - r.top - g.vp.y) * z) / g.vp.zoom,
      });
    } else if (g.kind === "pan")
      setViewport({
        ...g.vp,
        x: g.vp.x + e.clientX - g.x,
        y: g.vp.y + e.clientY - g.y,
      });
    else if(g.kind==='create-connection')previewConnector(g,e);
    else if (g.kind === "move") {
      if(e.pointerId!==g.pointerId)return;
      g.lastClient={x:e.clientX,y:e.clientY};
      if(g.hasOpenedBoard){updateBoardDragPreview(g);armBoardDragHover(g);return;}
      const dx = (e.clientX - g.x) / vpRef.current.zoom,
        dy = (e.clientY - g.y) / vpRef.current.zoom;
      g.moved = Math.abs(dx) + Math.abs(dy) > 2 || !!g.working;
      if(g.duplicateOnDrag&&g.moved&&!g.working){
        const result=duplicateCards(g.base,activeId,g.ids,{x:0,y:0});
        g.working=result.workspace;g.ids=result.ids;
        g.positions=new Map(result.workspace.boards[activeId].cards.filter(card=>g.ids.includes(card.id)).map(card=>[card.id,{x:card.x,y:card.y}]));
        setSelected(result.ids);
      }
      const preview = updateBoard(g.working||g.base, activeId, (b) => ({
        ...b,
        cards: b.cards.map((c) => {
          const p = g.positions.get(c.id);
          return p ? { ...c, x: p.x + dx, y: p.y + dy } : c;
        }),
      })).boards[activeId];
      const roots = preview.cards.filter(
        (c) =>
          g.positions.has(c.id) &&
          (!c.parentId || !g.positions.has(c.parentId)),
      );
      const target = columnTarget(preview, roots, g.ids);
      const first = roots.find((c) => c.type !== "column");
      const siblings = target
        ? columnChildren(preview, target.id).filter(
            (c) => !g.ids.includes(c.id),
          )
        : [];
      const before = first
        ? siblings.find((c) => c.y + c.height / 2 > first.y + first.height / 2)
        : undefined;
      setColumnDrop(
        target
          ? {
              columnId: target.id,
              y: before
                ? before.y - 8
                : siblings.length
                  ? siblings[siblings.length - 1].y +
                    siblings[siblings.length - 1].height +
                    8
                  : target.y + 54,
            }
          : null,
      );
      setDoc(
        updateBoard(g.working||g.base, activeId, (b) => ({
          ...b,
          cards: b.cards.map((c) => {
            const p = g.positions.get(c.id);
            return p
              ? { ...c, x: Math.round(p.x + dx), y: Math.round(p.y + dy) }
              : c;
          }),
        })),
      );
      armBoardDragHover(g);
    } else if (g.kind === "resize") {
      const dx = (e.clientX - g.x) / vpRef.current.zoom,
        dy = (e.clientY - g.y) / vpRef.current.zoom;
      setDoc(
        updateBoard(g.base, activeId, (b) =>
          b.cards.find((c) => c.id === g.id)?.type === "column"
            ? resizeColumn(
                b,
                g.id,
                Math.max(180, g.width + dx),
                Math.max(100, g.height + dy),
              )
            : {
                ...b,
                cards: b.cards.map((c) =>
                  c.id === g.id
                    ? {
                        ...c,
                        width: Math.max(140, g.width + dx),
                        height: Math.max(65, g.height + dy),
                        ...(['link','file'].includes(c.type)?{autoHeight:false}:{}),
                      }
                    : c,
                ),
              },
        ),
      );
      g.moved = true;
    } else if (g.kind === "marquee")
      setMarquee({ start: g.start, end: point(e.clientX, e.clientY) });
    else if (g.kind === "draw-in") {
      const p = point(e.clientX, e.clientY),
        c = g.card;
      g.points.push({
        x: Math.max(0, Math.min(c.width, p.x - c.x)),
        y: Math.max(0, Math.min(c.height, p.y - c.y)),
      });
      setDoc(
        updateBoard(g.base, activeId, (b) => ({
          ...b,
          cards: b.cards.map((item) =>
            item.id === c.id
              ? ({
                  ...item,
                  paths: [
                    ...c.paths,
                    { points: [...g.points], color: penColor, width: penWidth },
                  ],
                } as Card)
              : item,
          ),
        })),
      );
    } else if (g.kind === "draw") {
      g.points.push(point(e.clientX, e.clientY));
      setDraftPath([...g.points]);
    }
  };
  const endPointer = (e: ReactPointerEvent) => {
    pointers.current.delete(e.pointerId);
    const g = gesture.current;
    if (!g) return;
    if(g.kind==='move'){
      if(e.pointerId!==g.pointerId)return;
      g.lastClient={x:e.clientX,y:e.clientY};
      const previewTarget=g.previewHover?.ready?previewTargetUnderPointer(g):undefined;
      clearTimeout(g.previewHoverTimer);setPreviewDragReady(null);
      if(previewTarget&&previewTarget.id===g.previewHover.id){
        const image=g.base.boards[g.sourceBoardId]?.cards.find((card:Card)=>card.id===g.ids[0]);
        if(image?.type==='image'){clearBoardDrag(g);docRef.current=g.base;setDoc(g.base);gesture.current=null;setColumnDrop(null);void replaceHeldPreview(g.sourceBoardId,image,previewTarget);return;}
      }
      clearTimeout(g.boardHoverTimer);setBoardDragHover(null);
      if(g.hasOpenedBoard){completeBoardDrag(g,e);gesture.current=null;return;}
    }
    if(g.kind==='create-connection'){
      if(e.pointerId!==g.pointerId)return;
      if(g.moved){previewConnector(g,e);commit(updateBoard(g.base,g.boardId,b=>({...b,connections:[...b.connections,g.line]})),g.base);setSelected([]);setLineId(g.line.id);setFrom(null);setTool('select');}
      connectorDragCleanup.current?.();
      if(g.moved)setTimeout(()=>{suppressConnectorClick.current=false;},0);
    } else if (g.kind === "move" && g.moved) {
      // Pointerup may arrive before React renders the last pointermove.
      // Commit the release coordinates rather than an older preview frame.
      const dx=(e.clientX-g.x)/vpRef.current.zoom,dy=(e.clientY-g.y)/vpRef.current.zoom;
      docRef.current=updateBoard(docRef.current,activeId,b=>({...b,cards:b.cards.map(card=>{
        const start=g.positions.get(card.id);return start?{...card,x:Math.round(start.x+dx),y:Math.round(start.y+dy)}:card;
      })}));
      const r = inboxRef.current?.getBoundingClientRect();
      if (
        r &&
        e.clientX >= r.left &&
        e.clientX <= r.right &&
        e.clientY >= r.top &&
        e.clientY <= r.bottom
      ) {
        const moved = new Set<string>(g.ids);
        commit(
          updateBoard(docRef.current, activeId, (b) =>
            arrangeAllColumns({
              ...b,
              cards: b.cards.map((c) =>
                moved.has(c.id)
                  ? {
                      ...c,
                      unsorted: true,
                      parentId:
                        c.parentId && moved.has(c.parentId)
                          ? c.parentId
                          : undefined,
                    }
                  : c,
              ),
            }),
          ),
          g.base,
        );
        setSelected([]);
      } else {
        const current = docRef.current.boards[activeId];
        const roots = current.cards.filter(
          (c) =>
            g.positions.has(c.id) &&
            (!c.parentId || !g.positions.has(c.parentId)),
        );
        const boardTarget=boardTileUnderPointer(current,{x:e.clientX,y:e.clientY},g.ids);
        if(boardTarget?.type==='board'){
          const moved=moveCardsToBoard(docRef.current,activeId,boardTarget.boardId,g.ids,{x:40,y:40});
          if(moved!==docRef.current){commit(moved,g.base);setSelected([]);setColumnDrop(null);gesture.current=null;notify('Items moved to '+boardTarget.title);return;}
        }
        const target = columnTarget(current, roots, g.ids);
        let next = current;
        if (target) {
          const siblings = columnChildren(current, target.id).filter(
            (c) => !g.ids.includes(c.id),
          );
          const first = roots.find((c) => c.type !== "column");
          const index = first
            ? siblings.filter(
                (c) => c.y + c.height / 2 < first.y + first.height / 2,
              ).length
            : siblings.length;
          next = placeInColumn(
            current,
            roots.map((c) => c.id),
            target.id,
            index,
          );
        } else
          next = removeFromColumn(
            current,
            roots.filter((c) => c.parentId).map((c) => c.id),
          );
        commit(
          updateBoard(docRef.current, activeId, () => next),
          g.base,
        );
      }
      setColumnDrop(null);
    } else if (g.kind === "resize" && g.moved) {
      commit(
        updateBoard(docRef.current, activeId, (b) => {
          const width=Math.max(140,g.width+(e.clientX-g.x)/vpRef.current.zoom),height=Math.max(65,g.height+(e.clientY-g.y)/vpRef.current.zoom);
          const c = b.cards.find((c) => c.id === g.id);
          const resized=c?.type==='column'?resizeColumn(b,g.id,Math.max(180,width),Math.max(100,height)):{...b,cards:b.cards.map(card=>card.id===g.id?{...card,width,height,...(['link','file'].includes(card.type)?{autoHeight:false}:{})}:card)};
          return c?.parentId ? arrangeColumn(resized, c.parentId) : resized;
        }),
        g.base,
      );
    } else if (g.kind === "marquee" && marquee) {
      const x = Math.min(g.start.x, marquee.end.x),
        y = Math.min(g.start.y, marquee.end.y),
        w = Math.abs(g.start.x - marquee.end.x),
        h = Math.abs(g.start.y - marquee.end.y);
      if (w + h > 8) {
        const ids = visibleCards
          .filter(
            (c) =>
              c.x < x + w &&
              c.x + c.width > x &&
              c.y < y + h &&
              c.y + c.height > y,
          )
          .map((c) => c.id);
        setSelected(g.add ? [...new Set([...selected, ...ids])] : ids);
      }
      setMarquee(null);
    } else if (g.kind === "draw-in" && g.points.length > 1)
      commit(docRef.current, g.base);
    else if (g.kind === "draw" && g.points.length > 2) {
      const xs = g.points.map((p: Point) => p.x),
        ys = g.points.map((p: Point) => p.y);
      const x = Math.min(...xs) - 8,
        y = Math.min(...ys) - 8;
      const c = {
        ...createCard("sketch", x, y),
        width: Math.max(40, Math.max(...xs) - x + 8),
        height: Math.max(40, Math.max(...ys) - y + 8),
        background: "transparent",
        paths: [
          {
            points: g.points.map((p: Point) => ({ x: p.x - x, y: p.y - y })),
            color: penColor,
            width: penWidth,
          },
        ],
      } as Card;
      change((b) => ({ ...b, cards: [...b.cards, c] }));
      setDraftPath([]);
    }
    if (g.kind === "draw") setDraftPath([]);
    if (g.kind === "pinch" && pointers.current.size === 1) {
      const p = [...pointers.current.values()][0];
      gesture.current = {
        kind: "pan",
        x: p.x,
        y: p.y,
        vp: { ...vpRef.current },
      };
    } else gesture.current = null;
  };
  async function replaceDroppedPreview(file:File,baseline:Card){
    if(baseline.locked||!(baseline.type==='link'||baseline.type==='file'&&baseline.mime.startsWith('video/')))return;
    const origin=activeId,workspaceId=docRef.current.id,epoch=asyncMutationEpoch.current,key=JSON.stringify([origin,baseline.id]),request={};
    previewDropRequests.current.set(key,request);
    const current=()=>workspaceBoard(docRef.current,origin)?.cards.find(card=>card.id===baseline.id);
    const valid=()=>{
      const card=current();
      return previewDropRequests.current.get(key)===request&&epoch===asyncMutationEpoch.current&&docRef.current.id===workspaceId&&card&&!card.locked&&
        (baseline.type==='link'&&card.type==='link'&&card.url===baseline.url&&card.previewSrc===baseline.previewSrc||
         baseline.type==='file'&&card.type==='file'&&card.dataUrl===baseline.dataUrl&&card.mime===baseline.mime&&card.poster===baseline.poster);
    };
    try{
      const src=await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(new Error('Image read failed'));reader.onabort=()=>reject(new Error('Image read cancelled'));reader.readAsDataURL(file);});
      while(gesture.current||noteEditBase.current){if(!valid())return;await new Promise<void>(resolve=>requestAnimationFrame(()=>resolve()));}
      if(!valid())return;
      commit(updateBoard(docRef.current,origin,board=>({...board,cards:board.cards.map(card=>card.id!==baseline.id?card:card.type==='link'?{...card,previewSrc:src,showPreview:true}:card.type==='file'?{...card,poster:src}:card)})));
    }catch{if(valid()&&imageColorBoard.current===origin)notify('The image could not be opened.');}
    finally{if(previewDropRequests.current.get(key)===request)previewDropRequests.current.delete(key);}
  }
  const loadFiles = async (files: FileList | null, at?: Point) => {
    if(boardReadOnly)return;
    if (!files?.length) return;
    const origin=activeId,workspaceId=docRef.current.id,epoch=asyncMutationEpoch.current;
    const valid=()=>epoch===asyncMutationEpoch.current&&docRef.current.id===workspaceId&&!!docRef.current.boards[origin];
    const p = at || center();
    const layoutWidth=(stageRef.current?.getBoundingClientRect().width||window.innerWidth)/vpRef.current.zoom;
    const result: Card[] = [];
    for (const [i, file] of [...files].entries()) {
      if (file.size > 15 * 1024 * 1024) {
        notify("Use files smaller than 15 MB.");
        continue;
      }
      const dataUrl = await new Promise<string>((res, rej) => {
        const r = new FileReader();
        r.onload = () => res(r.result as string);
        r.onerror = rej;
        r.readAsDataURL(file);
      });
      const type = file.type.startsWith("image/") ? "image" : "file";
      const c = createCard(type, p.x + (i % 3) * 294, p.y + Math.floor(i / 3) * 280);
      if (c.type === "image") {
        c.src = dataUrl;
        c.originalName=file.name;
        c.caption = at ? '' : file.name;
        if(at)c.showCaption=false;
        const dimensions=await new Promise<{width:number;height:number}>(resolve=>{const image=new window.Image();image.onload=()=>resolve(at?droppedImageSize(image.naturalWidth,image.naturalHeight):{width:270,height:270*image.naturalHeight/image.naturalWidth+35});image.onerror=()=>resolve({width:270,height:at?220:240});image.src=dataUrl;});
        Object.assign(c,dimensions);
      } else if (c.type === "file") {
        c.name = file.name;
        c.mime = file.type;
        c.size = file.size;
        c.dataUrl = dataUrl;
        const kind=filePreviewKind(c);
        if(kind==='icon'){c.width=FILE_ICON_WIDTH;c.height=FILE_ICON_HEIGHT;}
        else{c.autoHeight=true;c.height=fileDetailHeight(kind==='audio'?54:198,c);}
      }
      result.push(c);
    }
    if (result.length) {
      while(gesture.current){if(!valid())return;await new Promise<void>(resolve=>requestAnimationFrame(()=>resolve()));}
      if(!valid())return;
      commit(updateBoard(docRef.current,origin,board=>at?appendCardsAt(board,layoutDroppedImages(board,result,p,layoutWidth),p):({...board,cards:[...board.cards,...result.map(card=>({...card,unsorted:true}))]})));
      if(imageColorBoard.current===origin){if(at)setSelected(result.map(card=>card.id));else{setSelected([]);setInboxOpen(true);}}
    }
  };
  function addLibraryPhoto(photo:LibraryPhoto,at?:Point){
    const p=at||center();
    const card:Extract<Card,{type:'image'}>={...createCard('image',p.x,p.y),type:'image',src:photo.src,originalName:`pexels-${photo.id}.jpg`,caption:photo.alt||'',width:270,height:270*photo.height/photo.width+(photo.alt?35:0),showCaption:!!photo.alt,unsorted:!at};
    change(board=>at?appendCardsAt(board,[card],p):{...board,cards:[...board.cards,card]});
    if(at)setSelected([card.id]);else{setSelected([]);setInboxOpen(true);}
  }
  useEffect(() => {
    const handler = (e: ClipboardEvent) => {
      if (isEditing()) return;
      if(presenting||sketchSession||modal||imageEditorId||labelsOpen||trashOpen||syncedPopup||cutoutId||imageLibraryOpen)return;
      const data = e.clipboardData;
      if (!data) return;
      const source=data.getData('text/plain').trim(),linkedBoard=source?localBoardIdFromUrl(docRef.current,source):null;
      if (data.files.length) {
        e.preventDefault();
        void loadFiles(data.files,center());
      } else if(linkedBoard){
        e.preventDefault();const result=createBoardShortcut(docRef.current,linkedBoard,activeId,center());commit(result.workspace);if(result.id)setSelected([result.id]);
      } else if (clipboard.current) {
        e.preventDefault();
        paste();
      } else {
        const text = data.getData("text/plain");
        if (text) {
          e.preventDefault();
          const p = center();
          let c:Card;
          if(normalizeLinkUrl(text.trim())){const url=normalizeLinkUrl(text.trim())!;c={...createCard('link',p.x,p.y),type:'link',url,title:new URL(url).hostname,description:'',height:120,autoHeight:true};}
          else c={ ...createCard("note", p.x, p.y), text } as Card;
          change((b) => ({ ...b, cards: [...b.cards, c] }));
          setSelected([c.id]);
          if(c.type==='link')void refreshLinkMetadata(activeId,c);
        }
      }
    };
    window.addEventListener("paste", handler);
    return () => window.removeEventListener("paste", handler);
  });
  const sendToInbox = (ids: string[]) => {
    const moved = new Set(
      expandSelection(
        board,
        ids.filter((id) => !cards.find((c) => c.id === id)?.locked),
      ),
    );
    change((b) =>
      arrangeAllColumns({
        ...b,
        cards: b.cards.map((c) =>
          moved.has(c.id)
            ? {
                ...c,
                unsorted: true,
                parentId:
                  c.parentId && moved.has(c.parentId) ? c.parentId : undefined,
              }
            : c,
        ),
      }),
    );
    setSelected([]);
    setInboxOpen(true);
  };
  const placeInbox = (id: string, at = center()) => {
    const c = cards.find((c) => c.id === id);
    if (!c) return;
    const moved = new Set(expandSelection(board, [id]));
    const dx = at.x - c.x,
      dy = at.y - c.y;
    change((b) => ({
      ...b,
      cards: b.cards.map((item) =>
        moved.has(item.id)
          ? { ...item, unsorted: false, x: item.x + dx, y: item.y + dy }
          : item,
      ),
    }));
    setSelected([id]);
  };
  const exportCurrent = async (
    kind: "json" | "html" | "svg" | "print" | "md" | "txt" | "png" | "pdf" | "docx" | "zip",
    quality: 'standard'|'large'=exportPdfQuality,
  ) => {
    if(exportBusy)return;
    finishNoteEdit();setExportBusy(true);
    try {
      await new Promise<void>(resolve=>requestAnimationFrame(()=>resolve()));
      const currentBoard=docRef.current.boards[activeId];
      if (kind === "print") {
        await printBoard(currentBoard,{workspace:docRef.current,formulaWorkbook:formulaRegistry.current.snapshot});
        return;
      }
      if (kind === "json") {
        const snapshot = updateBoard(docRef.current, activeId, (b) => ({
          ...b,
          viewport: vpRef.current,
        }));
        const entries = await Promise.all(
          Object.entries(snapshot.boards).map(
            async ([id, b]) => [id, await prepareBoardForExport(b,{flattenImageEdits:false,strictResources:true})] as const,
          ),
        );
        const trash=await Promise.all((snapshot.trash||[]).map(async entry=>{
          const roots=await prepareBoardForExport({...currentBoard,cards:entry.cards,connections:entry.connections},{flattenImageEdits:false,strictResources:true});
          const nested=await Promise.all(Object.entries(entry.boards).map(async([id,child])=>[id,await prepareBoardForExport(child,{flattenImageEdits:false,strictResources:true})] as const));
          return {...entry,cards:roots.cards,connections:roots.connections,boards:Object.fromEntries(nested)};
        }));
        downloadFile(
          "canvas-workspace.json",
          exportWorkspace({ ...snapshot, boards: Object.fromEntries(entries),...(snapshot.trash?{trash}:{}) }),
          "application/json",
        );
        notify("Workspace backup exported");
        return;
      }
      if (kind === "md" || kind === "txt") {
        downloadFile(
          `${slug(board.title)}.${kind}`,
          kind === "md" ? exportBoardMarkdown(currentBoard,{includeSubBoards:exportSubBoards,workspace:docRef.current,formulaWorkbook:formulaRegistry.current.snapshot}) : exportBoardText(currentBoard,{includeSubBoards:exportSubBoards,workspace:docRef.current,formulaWorkbook:formulaRegistry.current.snapshot}),
          kind === "md"
            ? "text/markdown;charset=utf-8"
            : "text/plain;charset=utf-8",
        );
        return;
      }
      if(['png','pdf','docx','zip'].includes(kind)){
        const sourceElement=stageRef.current?.querySelector<HTMLElement>('.world')||undefined;
        const data=kind==='png'?await exportBoardPng(currentBoard,{sourceElement,workspace:docRef.current,formulaWorkbook:formulaRegistry.current.snapshot}):kind==='pdf'?await exportBoardPdf(currentBoard,{sourceElement,workspace:docRef.current,formulaWorkbook:formulaRegistry.current.snapshot,format:quality}):kind==='docx'?await exportBoardWord(currentBoard,{includeSubBoards:exportSubBoards,workspace:docRef.current,formulaWorkbook:formulaRegistry.current.snapshot}):await exportBoardAttachmentsZip(currentBoard);
        downloadFile(`${slug(currentBoard.title)}.${kind}`,data);notify('Export downloaded');return;
      }
      const prepared = await prepareBoardForExport(currentBoard);
      downloadFile(
        `${slug(board.title)}.${kind}`,
        kind === "html" ? exportBoardHtml(prepared,{workspace:docRef.current,formulaWorkbook:formulaRegistry.current.snapshot}) : exportBoardSvg(prepared,{workspace:docRef.current,formulaWorkbook:formulaRegistry.current.snapshot}),
        kind === "html" ? "text/html" : "image/svg+xml",
      );
    } catch (error) {
      notify(
        error instanceof Error ? error.message : "Could not export this board.",
      );
    } finally {setExportBusy(false);}
  };
  async function downloadDocument(format:'pdf'|'word'|'markdown'|'text'){
    if(single?.type!=='note'||exportBusy)return;
    finishNoteEdit();setExportBusy(true);
    try{const current=docRef.current.boards[activeId].cards.find(card=>card.id===single.id);if(current?.type!=='note')return;beginNoteEdit(current);const blob=await exportDocumentFile(current,format);downloadFile(`${slug(current.title||'document')}.${({word:'docx',markdown:'md',text:'txt',pdf:'pdf'})[format]}`,blob);}
    catch(error){notify(error instanceof Error?error.message:'Could not export the document');}
    finally{setExportBusy(false);}
  }
  const lineage: Board[] = [];
  let ancestor: Board | undefined = board;
  const seen = new Set<string>();
  while (ancestor && !seen.has(ancestor.id)) {
    lineage.unshift(ancestor);
    seen.add(ancestor.id);
    ancestor = ancestor.parentBoardId
      ? workspaceBoard(doc, ancestor.parentBoardId)
      : undefined;
  }
  const formatNote=(marker:string)=>{const command:Record<string,NoteEditorCommand>={'**':'bold','*':'italic','~~':'strike','++':'underline','`':'code'};if(command[marker])runNoteCommand(command[marker]);};
  const formatBlock=(prefix:string)=>{if(prefix==='number')runNoteCommand('orderedList');else if(prefix==='- ')runNoteCommand('bulletList');else if(prefix.startsWith('#'))runNoteCommand('heading',prefix.trim().length);else if(prefix==='smallText')runNoteCommand('smallText');else if(prefix==='codeBlock')runNoteCommand('codeBlock');else if(prefix==='blockquote')runNoteCommand('blockquote');else if(prefix==='callout')runNoteCommand('callout');else runNoteCommand('paragraph');};
  function updateSwatch(id:string,values:Partial<Extract<Card,{type:'swatch'}>>){
    const current=docRef.current.boards[activeId]?.cards.find(card=>card.id===id);
    if(current?.type!=='swatch')return;
    const previousCaption=current.captionHeight||48,nextCaption=values.captionHeight??previousCaption;
    const before=current.showCaption!==false,after=values.showCaption??before;
    const delta=(after?nextCaption:0)-(before?previousCaption:0);
    patch(id,{...values,...(delta?{height:Math.max(20,current.height+delta)}:{})});
  }
  const renderCard = (c: Card) => {
    const edit = editing === c.id;
    const update = (values: Partial<Card>) => patch(c.id, values);
    if(c.type==='note'&&c.isDocument)return <div className="document-card"><FileText size={32}/><strong>{c.title||'Untitled document'}</strong><p>{c.text.slice(0,150)||'Double-click to write'}</p>{c.syncedId&&<small>Synced note</small>}</div>;
    if(c.type==='note')return edit?<Suspense fallback={<div className="note-editor-loading" role="status">Loading editor…</div>}><NoteEditor key={c.id} ref={noteEditorRef} text={c.text} html={c.html} autoFocus onReady={handleNoteReady} onRequestLink={requestTextLink} onChange={value=>updateNoteContent(c,value)} onBlur={event=>{const target=event.relatedTarget as HTMLElement|null;if(target?.closest('.selection-toolbar,.modal'))return;finishNoteEdit();}}/></Suspense>:<div className="note-text" style={{textAlign:c.align||'start'}} dir="auto" dangerouslySetInnerHTML={{__html:c.text||c.html?noteContentHtml(c.text,c.html):'<p class="note-placeholder">Start typing...</p>'}}/>;
    if (c.type === "label")
      return edit ? (
        <input
          aria-label="Label text"
          autoFocus
          defaultValue={c.text}
          onBlur={(e) => {
            update({ text: e.target.value } as Partial<Card>);
            setEditing(null);
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter") e.currentTarget.blur();
          }}
        />
      ) : (
        <div className="label-text" dir="auto">
          {c.text || "Untitled label"}
        </div>
      );
    if (c.type === "image")
      return (
        <>
          <ImagePreview src={c.useCutout&&c.cutoutSrc?c.cutoutSrc:c.src} edits={c.imageEdits} alt={c.caption||'Board image'} className="image-preview" style={{height:c.showCaption===false?"100%":`calc(100% - ${c.captionHeight||35}px)`}}/>
          {c.showCaption!==false && <div className="image-caption"><CaptionEditor text={c.caption} html={c.captionHtml} ariaLabel="Image caption" active={edit} autoFocus={edit} readOnly={c.locked||boardReadOnly} onChange={({text,html,height})=>{const captionHeight=Math.max(30,Math.min(600,height));update({caption:text,captionHtml:html,captionHeight,height:c.height-(c.captionHeight||35)+captionHeight} as Partial<Card>);}} onFinish={()=>setEditing(null)}/></div>}
        </>
      );
    if (c.type === "link" && !c.url && !c.title && !edit)
      return (
        <div className="empty-link">
          <Link size={15} />
          <input
            aria-label="Link URL"
            placeholder="Enter a link URL"
            onBlur={(e) => {
              const url = e.target.value;
              if (!url) return;
              updateLinkUrl(c,url);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter") e.currentTarget.blur();
            }}
          />
        </div>
      );
    if (c.type === "link")
      return edit ? (
        <LinkDetailsEditor card={c} busy={linkPending.has(JSON.stringify([activeId,c.id]))} onChange={values=>update(values)} onUrlChange={url=>updateLinkUrl(c,url)} onRefresh={()=>void refreshLinkMetadata(activeId,c)} onDone={()=>setEditing(null)}/>
      ) : (
        <LinkAutoLayout automatic={c.autoHeight===true} blocked={!!gesture.current} onHeight={height=>measureLinkHeight(c.id,height)}>
          {c.showMedia && mediaEmbedUrl(c.url) ? <iframe className="media-embed" title={c.title||"Embedded media"} src={mediaEmbedUrl(c.url)!} allow="fullscreen; encrypted-media; picture-in-picture" sandbox="allow-scripts allow-same-origin allow-presentation allow-popups" referrerPolicy="strict-origin-when-cross-origin" loading="lazy"/> : c.showPreview!==false && <LinkPreview src={c.previewSrc?safeImageSrc(c.previewSrc):undefined} automatic={c.autoHeight===true} placeholder={<><div className="link-symbol"><Link size={26}/></div><ArrowUpRight size={18}/></>} overlay={previewDragReady===c.id?<span className="preview-drop-overlay">Replace image</span>:undefined}/>}
          {c.showInfo!==false&&<LinkInfo url={c.url} title={c.title} description={c.description}/>}
          {c.showInfo!==false && c.showCaption && <div className="link-caption"><CaptionEditor text={c.caption||''} html={c.captionHtml} ariaLabel="Link caption" readOnly={c.locked||boardReadOnly} onChange={({text,html})=>update({caption:text,captionHtml:html} as Partial<Card>)}/></div>}
        </LinkAutoLayout>
      );
    if(c.type==='todo')return <TodoEditor ref={single?.id===c.id?todoRef:undefined} title={c.title} items={c.items} readOnly={c.locked||boardReadOnly} onSelectionChange={()=>{finishNoteEdit();setSelected([c.id]);setLineId(null);}} onChange={value=>{if(!boardReadOnly)updateTodoContent(activeId,c.id,value);}}/>;
    if (c.type === "column")
      return (
        <>
          <div className="column-header">
            <span className="column-grip">⠿</span>
            <input
              aria-label="Column title"
              className="plain title-input"
              value={c.title}
              onChange={(e) =>
                update({ title: e.target.value } as Partial<Card>)
              }
            />
            <span className="count">
              {
                cards.filter((item) => item.parentId === c.id && !item.unsorted)
                  .length
              }
            </span>
            <button
              title={c.collapsed ? "Expand column" : "Collapse column"}
              onClick={() => update({ collapsed: !c.collapsed })}
            >
              {c.collapsed ? <Plus size={14} /> : <Minus size={14} />}
            </button>
          </div>
          {!c.collapsed && (
            <div className="column-drop-hint">
              Drop items here to group them
            </div>
          )}
        </>
      );
    if (c.type === "board") {
      const child = workspaceBoard(doc,c.boardId);
      return (
        <div className="board-card-content">
          <div className="board-symbol">
            {child?.icon?/^data:image\//.test(child.icon)?<img className={`board-custom-icon-image${selectedBoardIconId(child.icon)?' board-catalog-icon':''}`} data-board-icon-id={selectedBoardIconId(child.icon)} src={boardIconDisplaySource(child.icon)} alt="Board icon"/>:<span className="board-custom-icon">{child.icon}</span>:<Folder size={30} />}
            <div className="mini-cards">
              <i />
              <i />
              <i />
            </div>
          </div>
          <input
            aria-label="Board name"
            className="plain title-input"
            value={child?.title || c.title}
            onChange={(e) => {
              const value = e.target.value;
              const next = updateBoard(docRef.current, activeId, (b) => ({
                ...b,
                cards: b.cards.map((item) =>
                  item.id === c.id ? ({ ...item, title: value } as Card) : item,
                ),
              }));
              commit(
                child
                  ? {
                      ...next,
                      boards: {
                        ...next.boards,
                        [c.boardId]: { ...child, title: value },
                      },
                    }
                  : next,
              );
            }}
          />
          <span>{c.isShortcut&&!child?'Original board deleted':`${child?.cards.length||0} items`}</span>{c.isShortcut&&<span className="shortcut-indicator" title="Board shortcut">↗</span>}{child?.isTemplate&&<small>Template</small>}
          <button className="open-board" onClick={() => navigate(c.boardId)}>
            Open board <ArrowRight size={13} />
          </button>
        </div>
      );
    }
    if(c.type==='swatch')return <ColorSwatch ref={handle=>{if(handle)swatchRefs.current.set(c.id,handle);else swatchRefs.current.delete(c.id);}} value={c.value} label={c.label} captionHtml={c.captionHtml} captionHeight={c.captionHeight} showCaption={c.showCaption} showValue={c.showValue} colorSpace={c.colorSpace} readOnly={c.locked||boardReadOnly} onSampleImage={visibleColorImages(board).length?sampleBoardImageColor:undefined} onChange={values=>updateSwatch(c.id,values)}/>;
    if (c.type === "file") {
      const origin=activeId,workspaceId=doc.id,epoch=asyncMutationEpoch.current;
      return <FileCardView key={`${workspaceId}:${epoch}:${c.id}`} file={c} previewHeight={fileFrameHeight(c)} editingName={edit} readOnly={c.locked||boardReadOnly}
        onRename={name=>update({name})} onRequestRename={()=>setEditing(c.id)} onFinishRename={()=>setEditing(null)}
        onCaptionChange={({text,html,height})=>updateFileDetail(c,{caption:text,captionHtml:html,captionHeight:Math.max(FILE_EMPTY_CAPTION_HEIGHT,Math.min(2400,height+16))})}
        onReady={preview=>void receivePdfPreview(origin,workspaceId,epoch,c,preview)} onOpen={()=>openAttachment(c)}/>;
    }
    if (c.type === "table")
      return <div className="table-content table-content-grid">
        {c.title && <input className="plain title-input" aria-label="Table title" value={c.title} onChange={e=>update({title:e.target.value} as Partial<Card>)}/>}
        <TableEditor evaluationContext={formulaContextForTable(formulaWorkbook,c.id,{errorDisplay:'blank'})} ref={single?.id===c.id?tableEditorRef:undefined} rows={c.rows} meta={c.cellMeta} readOnly={c.locked||boardReadOnly} columnWidths={c.columnWidths?.map(width=>width*c.width/c.columnWidths!.reduce((sum,value)=>sum+value,0))} onColumnWidthsChange={columnWidths=>update({columnWidths,width:columnWidths.reduce((sum,width)=>sum+width,0)} as Partial<Card>)}
          onSelectionChange={selection=>{finishNoteEdit();setSelected([c.id]);setLineId(null);setTableSelection(selection);}}
          onChange={(rows,cellMeta,columnWidths)=>{const columns=Math.max(1,...rows.map(row=>row.length));const previous=Math.max(1,...c.rows.map(row=>row.length));update({rows,cellMeta,columnWidths:columnWidths||c.columnWidths,height:rows.length*24-2+(c.title?32:0),width:columnWidths?columnWidths.reduce((sum,width)=>sum+width,0):columns!==previous?c.width/previous*columns:c.width} as Partial<Card>);}}/>
      </div>;
    if (c.type === "sketch")
      return (
        <svg
          className="sketch-content"
          viewBox={`0 0 ${c.width} ${c.height}`}
          preserveAspectRatio="none"
          style={{ background: c.background || "#fff" }}
        >
          {c.paths.map((path, i) => (
            <polyline
              key={i}
              fill="none"
              stroke={path.color}
              strokeWidth={path.width}
              strokeLinecap="round"
              strokeLinejoin="round"
              points={path.points.map((p) => `${p.x},${p.y}`).join(" ")}
            />
          ))}
          {!c.paths.length && (
            <text x="20" y="40" fill="#9b9b96" fontSize="14">
              Use the pen to draw on your board
            </text>
          )}
        </svg>
      );
  };
  return (
    <div
      className={`app reference-layout ${sidebar ? "sidebar-open" : ""}`}
      data-history={historyTick}
    >
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark">
            <i />
            <i />
            <i />
          </span>
          <span>
            canvas<span className="brand-dot">.</span>
          </span>
        </div>
        <button
          className="board-navigation-toggle"
          title="Show boards"
          onClick={() => setSidebar(!sidebar)}
        >
          <PanelLeftOpen size={17} />
        </button>
        <div className="header-divider" />
        <nav className="breadcrumbs" aria-label="Board breadcrumb">
          {lineage.map((b, i) => (
            <span key={b.id}>
              {i > 0 && <ChevronRight size={14} />}
              <button
                onClick={() => navigate(b.id)}
                data-drag-board-id={b.id}
                className={`${i === lineage.length - 1 ? "current" : ""}${boardDragHover===`breadcrumb:${b.id}`?' board-drag-hover':''}`}
              >
                {i === 0 && <Folder size={15} />} {b.title}
              </button>
            </span>
          ))}
        </nav>
        <div className="header-actions">
          <button
            title="Undo (⌘Z)"
            onPointerDown={e=>{if(noteEditBase.current)e.preventDefault();}}
            disabled={!history.current.past.length}
            onClick={undo}
          >
            <Undo2 size={18} />
          </button>
          <button
            title="Redo (⇧⌘Z)"
            onPointerDown={e=>{if(noteEditBase.current)e.preventDefault();}}
            disabled={!history.current.future.length}
            onClick={redo}
          >
            <Redo2 size={18} />
          </button>
          <span />

          <span className="save-status">
            <span
              className={
                saved.startsWith("Saved") ? "status-dot" : "status-dot pending"
              }
            />
            {saved}
          </span>
          <button ref={searchTriggerRef} title="Search boards (⌘K)" data-search-trigger aria-pressed={modal==='search'} onClick={openWorkspaceSearch}>
            <Search size={18} />
          </button>
          <button title="View" data-view-trigger onClick={()=>setViewMenuOpen(!viewMenuOpen)}>View <ChevronDown size={10}/></button>
          <button className="export-button" data-export-trigger onClick={() => {finishNoteEdit();setExportMenuOpen(!exportMenuOpen);}}>
            <Download size={15} />
            <span>Export</span>
          </button>
          <button
            title="More options"
            onClick={() => {finishNoteEdit();setSelected([]);setContext({ x: window.innerWidth - 220, y: 60 });}}
          >
            <MoreHorizontal size={20} />
          </button>
        </div>
      </header>
      <div className="workspace-layout">
        <aside className={"sidebar " + (!sidebar ? "collapsed" : "")}>
          <div className="sidebar-heading">
            <span>YOUR WORKSPACE</span>
            <button title="Collapse sidebar" onClick={() => setSidebar(false)}>
              <PanelLeftClose size={16} />
            </button>
          </div>
          <button
            className="workspace-home"
            onClick={() => navigate(doc.rootBoardId)}
          >
            <div className="workspace-avatar">S</div>
            <div>
              <strong>Studio workspace</strong>
              <span>Personal · Local storage</span>
            </div>
            <ChevronDown size={14} />
          </button>
          <div className="sidebar-section-title">
            BOARDS{" "}
            <button title="New board" onClick={() => insert("board")}>
              <Plus size={14} />
            </button>
          </div>
          <div className="board-tree">
            {Object.values(doc.boards).map((b) => (
              <button
                key={b.id}
                className={activeId === b.id ? "active" : ""}
                style={{ paddingLeft: b.parentBoardId ? 25 : 12 }}
                onClick={() => navigate(b.id)}
              >
                <Folder size={15} />
                <span>{b.title}</span>
                <span className="tree-count">{b.cards.length}</span>
              </button>
            ))}
          </div>
          <div className="sidebar-footer">
            <div className="local-badge">
              <span>✦</span>
              <div>
                <strong>A little space for big ideas.</strong>
                <p>Your boards stay on this device.</p>
              </div>
            </div>
            <button onClick={() => setModal("help")}>
              <CircleHelp size={16} /> Help & shortcuts <span>?</span>
            </button>
            <button onClick={()=>{setSidebar(false);setModal("templates");}}><Columns3 size={16}/> Saved templates & starters</button>
            <button onClick={() => importRef.current?.click()}>
              <Upload size={16} /> Import a workspace
            </button>
          </div>
        </aside>
        <main
          className="editor"
          style={{ background: board.background || "#ebedee" }}
        >
          <div className="board-heading">
            {!sidebar && (
              <button
                className="sidebar-expand"
                title="Show sidebar"
                onClick={() => setSidebar(true)}
              >
                <PanelLeftOpen size={18} />
              </button>
            )}
            <div>
              <div className="eyebrow">A SPACE TO THINK VISUALLY</div>
              <input
                className="board-title"
                aria-label="Current board title"
                readOnly={boardReadOnly}
                value={board.title}
                onChange={(e) => {
                  const title = e.target.value;
                  const next = updateBoard(docRef.current, activeId, (b) => ({
                    ...b,
                    title,
                  }));
                  commit({
                    ...next,
                    boards: Object.fromEntries(
                      Object.entries(next.boards).map(([id, b]) => [
                        id,
                        {
                          ...b,
                          cards: b.cards.map((c) =>
                            c.type === "board" && c.boardId === activeId
                              ? { ...c, title }
                              : c,
                          ),
                        },
                      ]),
                    ),
                  });
                }}
              />
              <div className="board-subtitle">
                Collect your inspiration. Connect your ideas.
              </div>
            </div>
            <div className="heading-tools">
              <button
                className={"inbox-toggle " + (inboxOpen ? "active" : "")}
                title="Unsorted items"
                onClick={() => setInboxOpen(!inboxOpen)}
              >
                <Inbox size={16} />
                <span>Unsorted</span>
                {inboxCards.length > 0 && <b>{inboxCards.length}</b>}
              </button>
              <button
                title="Board appearance"
                onClick={() => setModal("appearance")}
              >
                <Settings size={16} />
              </button>
              <button
                className="template-button"
                onClick={() => {finishNoteEdit();setTemplatePickerOpen(true);}}
              >
                <Columns3 size={15} /> Templates
              </button>
            </div>
          </div>
          <button className="trash-toggle" title="Trash" aria-pressed={trashOpen} onClick={()=>setTrashOpen(!trashOpen)}><Trash2 size={23}/><span>Trash</span></button>
          <div className="tool-rail" aria-label="Create tools" inert={boardReadOnly}>
            <div className="rail-section">
              {['note','link','todo','free-line','board','column','table','image','file','draw','sketch','swatch','label','document','connect'].map(type=>{
                if(type==='free-line')return <button key={type} title="Add Line" data-tool="free-line" draggable onDragStart={e=>e.dataTransfer.setData('application/canvas-type','free-line')} onClick={()=>insertFreeLine()}><MoveUpRight size={21}/><span>Line</span></button>;
                if(type==='draw')return <button key={type} className={tool==='draw'?'active':''} data-tool="draw" title="Draw (P)" onClick={()=>beginDrawing()}><Pencil size={20}/><span>Draw</span></button>;
                if(type==='document')return <button key={type} title="Add Document" data-tool="document" onClick={insertDocument}><FileText size={20} strokeWidth={1.5}/><span>Document</span></button>;
                if(type==='connect')return <button key={type} className={tool==='connect'?'active':''} data-tool="line" title="Connect cards (L)" onClick={()=>{setTool(tool==='connect'?'select':'connect');setFrom(null);}}><MoveUpRight size={21}/><span>Connect</span></button>;
                const item=TOOL_ITEMS.find(item=>item.type===type);if(!item)return null;const Icon=item.icon;
                return <button key={type} data-tool={type} title={`Add ${item.label}`} draggable onDragStart={e=>e.dataTransfer.setData('application/canvas-type',type)} onClick={()=>type==='image'?setImageLibraryOpen(!imageLibraryOpen):insert(item.type)}><Icon size={20} strokeWidth={1.5}/><span>{type==='image'?'Add image':type==='file'?'Upload':item.label}</span></button>;
              })}
            </div>
          </div>
          <div
            ref={stageRef}
            className={`stage tool-${tool}`}
            onPointerDownCapture={captureTouch}
            onPointerDown={startStage}
            onPointerMove={movePointer}
            onPointerUp={event=>{endPointer(event);finishTouchCardTap(event);}}
            onPointerCancel={(e) => {
              clearBoardDrag(gesture.current,true);
              touchCardPress.current=null;lastTouchCardTap.current=null;
              pointers.current.delete(e.pointerId);
              if(gesture.current?.kind==='create-connection'){const g=gesture.current;setLineId(g.lineId);setSelected(g.selected);setFrom(g.from);setTool(g.tool);suppressConnectorClick.current=true;setTimeout(()=>{suppressConnectorClick.current=false;},0);}
              connectorDragCleanup.current?.();
              if (gesture.current?.base) {docRef.current=gesture.current.base;setDoc(gesture.current.base);if(gesture.current.kind==='move')setSelected(gesture.current.originalIds);}
              gesture.current = null;
              setMarquee(null);
              setColumnDrop(null);
              setDraftPath([]);
            }}
            onContextMenu={(e) => {
              e.preventDefault();
              if(boardReadOnly)return;
              if (!(e.target as HTMLElement).closest(".card")) setSelected([]);
              setContext({
                x: Math.min(e.clientX, window.innerWidth - 215),
                y: Math.min(e.clientY, window.innerHeight - 300),
              });
            }}
            onDoubleClick={(e) => {
              if (tool !== "select") return;
              const hit = document
                .elementFromPoint(e.clientX, e.clientY)
                ?.closest<HTMLElement>("[data-card-id]");
              const card = cards.find((c) => c.id === hit?.dataset.cardId);
              if (card) {
                setSelected([card.id]);
                if (card.type === "board") navigate(card.boardId);
                else if (card.type === "sketch") beginDrawing(card);
                else if(card.type==='note')beginNoteEdit(card);else if(card.type==='image'){setEditing(null);setImageMode('crop');setImageEditorId(card.id);}else if(card.type==='swatch')swatchRefs.current.get(card.id)?.openPicker();else if (["link", "label"].includes(card.type))setEditing(card.id);
              } else insert("note", point(e.clientX, e.clientY));
            }}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              const type = e.dataTransfer.getData(
                "application/canvas-type",
              ) as Card["type"];
              const at = point(e.clientX, e.clientY);
              const inboxId = e.dataTransfer.getData(
                "application/canvas-inbox-id",
              );
              const trashId=e.dataTransfer.getData('application/canvas-trash-id');
              const photo=decodeLibraryPhoto(e.dataTransfer.getData(LIBRARY_DRAG_TYPE));
              if(trashId){commit(restoreTrashEntry(docRef.current,trashId,{targetBoardId:activeId,at}));}
              else if(photo)addLibraryPhoto(photo,at);
              else if (inboxId) placeInbox(inboxId, at);
              else if ((type as string)==='free-line')insertFreeLine(at);
              else if (type) insert(type, at);
              else if (e.dataTransfer.files.length){
                const hit=document.elementFromPoint(e.clientX,e.clientY)?.closest<HTMLElement>('[data-card-id]');
                const target=cards.find(card=>card.id===hit?.dataset.cardId),file=e.dataTransfer.files[0];
                if(e.dataTransfer.files.length===1&&file.type.startsWith('image/')&&file.size<=15*1024*1024&&(target?.type==='link'||(target?.type==='file'&&target.mime.startsWith('video/')))){
                  void replaceDroppedPreview(file,target);
                }else loadFiles(e.dataTransfer.files,at);
              }
            }}
            style={{
              backgroundColor: board.background || "#ebedee",
              backgroundImage: board.grid === false ? "none" : undefined,
              ["--board-bg" as string]: board.background || "#ebedee",
              backgroundPosition: `${viewport.x-2*viewport.zoom}px ${viewport.y-2*viewport.zoom}px`,
              backgroundSize: `${8 * viewport.zoom}px ${8 * viewport.zoom}px`,
            }}
          >
            <div
              className="world"
              style={{
                transform: `translate(${viewport.x}px,${viewport.y}px) scale(${viewport.zoom})`,
              }}
            >
              <ConnectionLayer connections={board.connections} cards={visibleCards} selectedId={lineId} anchorHint={connectorAnchorHint} onSelect={id=>{finishNoteEdit();setSelected([]);setLineId(id);}}
                onPreview={connections=>{const base=lineEditBase.current||docRef.current;lineEditBase.current=base;const next=updateBoard(docRef.current,activeId,b=>({...b,connections}));docRef.current=next;setDoc(next);if(JSON.stringify(connections)===JSON.stringify(base.boards[activeId].connections))lineEditBase.current=null;}}
                onCommit={(_before,connections)=>{const base=lineEditBase.current||docRef.current;lineEditBase.current=null;commit(updateBoard(docRef.current,activeId,b=>({...b,connections})),base);}}/>
              {[...visibleCards]
                .sort((a, b) =>
                  a.type === "column"
                    ? -1
                    : b.type === "column"
                      ? 1
                      : a.z - b.z,
                )
                .filter(
                  (c) =>
                    !c.parentId ||
                    !cards.find((p) => p.id === c.parentId)?.collapsed,
                )
                .map((c) => (
                  <article
                    key={c.id}
                    data-card-id={c.id}
                    className={`card card-${c.type} ${c.type==='file'&&(c.showPreview===false||filePreviewKind(c)==='icon'&&!c.previewSrc)?'file-compact':''} ${previewDragReady===c.id?"preview-drop-ready":""} ${c.stripColor?'has-top-strip':''} ${c.color==='transparent'?'transparent-card':''} ${selected.includes(c.id) ? "selected" : ""} ${c.locked ? "locked" : ""} ${c.parentId?'contained':''} ${from === c.id ? "connect-source" : ""}`}
                    style={
                      {
                        left: c.x,
                        top: c.y,
                        width: c.width,
                        height:
                          c.type === "column" && c.collapsed ? 62.2 : c.height,
                        zIndex: c.type === "column" ? 0 : c.z + 1,
                        background: c.color || undefined,
                        '--note-card-background':c.color||'#fff',
                        '--note-callout-tint':!c.color||['#fff','#ffffff'].includes(c.color.toLowerCase())?'#323b4a':'#000',
                        visibility:boardDragPreview&&gesture.current?.sourceBoardId===activeId&&gesture.current?.ids?.includes(c.id)?'hidden':undefined,
                        outline:boardDragHover===`tile:${c.id}`?'2px solid #5882f8':undefined,
                        outlineOffset:boardDragHover===`tile:${c.id}`?'3px':undefined,
                      } as CSSProperties
                    }
                    tabIndex={c.type === "board" ? 0 : undefined}
                    onKeyDown={(e) => {
                      if (
                        c.type === "board" &&
                        e.key === "Enter" &&
                        e.target === e.currentTarget
                      ) {
                        e.preventDefault();
                        navigate(c.boardId);
                      }
                    }}
                    onPointerDown={(e) => {
                      const interactive=(e.target as Element).closest('button,input,textarea,a,[contenteditable="true"],[role="button"]');
                      if(e.pointerType==='touch'&&tool==='select'&&!interactive&&pointers.current.size===1){
                        touchCardPress.current={id:c.id,pointer:e.pointerId,x:e.clientX,y:e.clientY,started:Date.now(),moved:false};
                      }else if(e.pointerType==='touch'){touchCardPress.current=null;lastTouchCardTap.current=null;}
                      startCard(e,c);
                    }}
                    onDoubleClick={(e) => {
                      e.stopPropagation();
                      if(boardReadOnly&&c.type!=='board')return;
                      if(lastTouchCardOpen.current?.id===c.id&&Date.now()-lastTouchCardOpen.current.at<500)return;
                      openCard(c);
                    }}
                    onContextMenu={() => {
                      if (!selected.includes(c.id)) setSelected([c.id]);
                    }}
                  >
                    {c.stripColor&&<div className="card-top-strip" style={{background:c.stripColor}} aria-label="Card top strip"/>}
                    {renderCard(c)}
                    {syncedIndicator(c)}
                    {c.type==='table'&&!c.locked&&<div className="table-move-handle" role="button" tabIndex={0} aria-label="Move table" title="Move table" onPointerDown={event=>startCard(event,c)}>⠿</div>}
                    {!!c.labelIds?.length&&<LabelBadges labels={doc.labels||[]} labelIds={c.labelIds} readOnly={c.locked||boardReadOnly} onRemove={id=>commit(setLabelAssignment(docRef.current,activeId,[c.id],id,false))} onRename={(id,name)=>commit(renameWorkspaceLabel(docRef.current,id,name))} onOpen={()=>{setSelected([c.id]);setLabelsOpen({left:49,top:200});}}/>}
                    {c.locked && <Lock className="lock-indicator" size={12} />}
                    <button
                      className="connector-handle"
                      title="Connect this item"
                      onPointerDown={(e) => startConnector(e,c)}
                      onClick={() => {
                        if(suppressConnectorClick.current)return;
                        if (from && from !== c.id) {
                          change((b) => ({
                            ...b,
                            connections: [
                              ...b.connections,
                              {
                                id: uid(),
                                from,
                                to: c.id,
                                color: "#69796b",
                                style: "solid",
                              },
                            ],
                          }));
                          setFrom(null);
                          setTool("select");
                        } else {
                          setFrom(c.id);
                          setTool("connect");
                        }
                      }}
                    >
                      {c.type==='note'?<NoteConnectionMarker/>:<span/>}
                    </button>
                    {selected.includes(c.id) && !c.locked && c.type!=='table' && (
                      <div
                        className="resize-handle"
                        role="button"
                        aria-label="Resize item"
                        onDoubleClick={e=>{e.stopPropagation();if(c.type==='image'){const image=new window.Image();image.onload=()=>patch(c.id,{width:270,height:270*image.naturalHeight/image.naturalWidth+(c.showCaption===false?0:35)});image.src=c.src;}}}
                        onPointerDown={(e) => {
                          e.stopPropagation();
                          gesture.current = {
                            kind: "resize",
                            id: c.id,
                            x: e.clientX,
                            y: e.clientY,
                            width: c.width,
                            height: c.height,
                            base: docRef.current,
                          };
                          stageRef.current?.setPointerCapture(e.pointerId);
                        }}
                      >{c.type==='note'&&<NoteResizeMarker/>}</div>
                    )}
                  </article>
                ))}
              {columnDrop &&
                (() => {
                  const c = cards.find((c) => c.id === columnDrop.columnId);
                  return c ? (
                    <div
                      className="column-insertion"
                      style={{
                        left: c.x + 12,
                        top: columnDrop.y,
                        width: c.width - 24,
                      }}
                    />
                  ) : null;
                })()}
              {draftPath.length > 0 && (
                <svg className="draw-overlay" width="10000" height="10000">
                  <polyline
                    fill="none"
                    stroke={penColor}
                    strokeWidth={penWidth}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    points={draftPath.map((p) => `${p.x},${p.y}`).join(" ")}
                  />
                </svg>
              )}
              {marquee && (
                <div
                  className="marquee"
                  style={{
                    left: Math.min(marquee.start.x, marquee.end.x),
                    top: Math.min(marquee.start.y, marquee.end.y),
                    width: Math.abs(marquee.start.x - marquee.end.x),
                    height: Math.abs(marquee.start.y - marquee.end.y),
                  }}
                />
              )}
            </div>
            {!visibleCards.length && (
              <div className="empty-board">
                <div className="empty-illustration">
                  <div />
                  <div />
                  <div />
                </div>
                <h2>Every idea starts somewhere.</h2>
                <p>Drag a tool onto your board, or start with a template.</p>
                <button onClick={() => insert("note")}>
                  <Plus size={16} /> Add your first note
                </button>
                <button
                  className="text-button"
                  onClick={() => {finishNoteEdit();setTemplatePickerOpen(true);}}
                >
                  Explore templates <ArrowRight size={14} />
                </button>
              </div>
            )}
          </div>
          {inboxOpen && (
            <aside
              className="inbox-panel"
              ref={inboxRef}
              aria-label="Unsorted items panel"
              onDragOver={(e) => e.preventDefault()}
            >
              <div className="inbox-title">
                <Inbox size={17} />
                <strong>Unsorted</strong>
                <span>{inboxCards.length}</span>
                <button
                  title="Close Unsorted"
                  onClick={() => setInboxOpen(false)}
                >
                  <X size={16} />
                </button>
              </div>
              <p>
                Keep ideas here until they find their place. Drag an item onto
                your board.
              </p>
              <div className="inbox-list">
                {inboxCards.map((c) => (
                  <div
                    className="inbox-item"
                    key={c.id}
                    draggable
                    onDragStart={(e) =>
                      e.dataTransfer.setData(
                        "application/canvas-inbox-id",
                        c.id,
                      )
                    }
                  >
                    {c.type === "image" ? (
                      <img src={c.src} alt={c.caption} />
                    ) : (
                      <div className="inbox-item-type">
                        {TOOL_ITEMS.find((t) => t.type === c.type)?.label}
                      </div>
                    )}
                    <strong dir="auto">{cardText(c) || "Untitled item"}</strong>
                    {syncedIndicator(c)}
                    <button
                      title="Place on board"
                      onClick={() => placeInbox(c.id)}
                    >
                      <ArrowLeft size={13} /> Place on board
                    </button>
                  </div>
                ))}
                {!inboxCards.length && (
                  <div className="inbox-empty">
                    <Inbox size={28} />
                    <span>A home for your next idea.</span>
                    <small>
                      Drag selected cards here, or use “Move to Unsorted”.
                    </small>
                  </div>
                )}
              </div>
              <button
                className="inbox-new"
                onClick={() => {
                  const c = {
                    ...createCard("note"),
                    text: "A thought for later…",
                    unsorted: true,
                  } as Card;
                  change((b) => ({ ...b, cards: [...b.cards, c] }));
                }}
              >
                <Plus size={14} /> Add a quick note
              </button>
            </aside>
          )}
          {!boardReadOnly&&(selected.length > 0 || selectedLine) && (
            <div
              className={
                "selection-toolbar " +
                (selectedLine ? "line-tools" : "card-tools")
              }
              onPointerDown={(e) => e.stopPropagation()}
            >
              <button
                title="Back to tools"
                data-label="Back"
                onClick={() => {
                  finishNoteEdit();
                  setSelected([]);
                  setLineId(null);
                  setEditing(null);
                }}
              >
                <ArrowLeft size={18} />
              </button>
              <span className="selection-count">
                {selectedLine ? "Line" : `${selected.length} selected`}
              </span>
              <i />
              {selectedLine ? (
                <>
                  <input
                    aria-label="Line label"
                    placeholder="Add a label"
                    value={selectedLine.label || ""}
                    onChange={(e) =>
                      change((b) => ({
                        ...b,
                        connections: b.connections.map((l) =>
                          l.id === lineId ? { ...l, label: e.target.value } : l,
                        ),
                      }))
                    }
                  />
                  <input
                    type="color"
                    aria-label="Line color"
                    value={selectedLine.color}
                    onChange={(e) =>
                      change((b) => ({
                        ...b,
                        connections: b.connections.map((l) =>
                          l.id === lineId ? { ...l, color: e.target.value } : l,
                        ),
                      }))
                    }
                  />
                  <select
                    aria-label="Line style"
                    value={selectedLine.style}
                    onChange={(e) =>
                      change((b) => ({
                        ...b,
                        connections: b.connections.map((l) =>
                          l.id === lineId
                            ? {
                                ...l,
                                style: e.target.value as "solid" | "dashed",
                              }
                            : l,
                        ),
                      }))
                    }
                  >
                    <option value="solid">Solid</option>
                    <option value="dashed">Dashed</option>
                  </select>
                  <input
                    title="Line thickness"
                    aria-label="Line thickness"
                    type="range"
                    min="0.8"
                    max="3.2"
                    step="0.8"
                    value={selectedLine.width || 1.6}
                    onChange={(e) =>
                      change((b) => ({
                        ...b,
                        connections: b.connections.map((l) =>
                          l.id === lineId
                            ? { ...l, width: +e.target.value }
                            : l,
                        ),
                      }))
                    }
                  />
                  <button title="Start arrow" aria-pressed={!!selectedLine.startArrow} onClick={()=>change(b=>({...b,connections:b.connections.map(line=>line.id===lineId?{...line,startArrow:!line.startArrow}:line)}))}><ArrowLeft size={16}/></button>
                  <button title="End arrow" aria-pressed={selectedLine.endArrow!==false} onClick={()=>change(b=>({...b,connections:b.connections.map(line=>line.id===lineId?{...line,endArrow:line.endArrow===false}:line)}))}><ArrowRight size={16}/></button>
                  <input
                    title="Line curve"
                    aria-label="Line curve"
                    type="range"
                    min="0"
                    max="350"
                    value={selectedLine.bend ?? 100}
                    onChange={(e) =>
                      change((b) => ({
                        ...b,
                        connections: b.connections.map((l) =>
                          l.id === lineId ? { ...l, bend: +e.target.value, control:undefined } : l,
                        ),
                      }))
                    }
                  />
                </>
              ) : (
                <>
                  {single?.type === "note" && (
                    <>
                      <button
                        title="Bold"
                        onPointerDown={(e) => e.preventDefault()}
                        onClick={() => formatNote("**")}
                      >
                        <Bold size={15} />
                      </button>
                      <button
                        title="Italic"
                        onPointerDown={(e) => e.preventDefault()}
                        onClick={() => formatNote("*")}
                      >
                        <Italic size={15} />
                      </button>
                      <button
                        title="Strikethrough"
                        onPointerDown={(e) => e.preventDefault()}
                        onClick={() => formatNote("~~")}
                      >
                        <Strikethrough size={16} />
                      </button>
                      <button
                        title="Underline"
                        onPointerDown={(e) => e.preventDefault()}
                        onClick={() => formatNote("++")}
                      >
                        <Underline size={16} />
                      </button>
                      <button
                        title="Bullet list"
                        onPointerDown={(e) => e.preventDefault()}
                        onClick={() => formatBlock("- ")}
                      >
                        <List size={16} />
                      </button>
                      <button
                        title="Numbered list"
                        onPointerDown={(e) => e.preventDefault()}
                        onClick={() => formatBlock("number")}
                      >
                        <ListOrdered size={16} />
                      </button>
                      <button title="Text alignment" onPointerDown={e=>e.preventDefault()} onClick={()=>{const align=single.align==='center'?'right':single.align==='right'?'left':'center';patch(single.id,{align});runNoteCommand(align==='center'?'alignCenter':align==='right'?'alignRight':'alignLeft');}}><AlignLeft size={16}/></button>
                      <button
                        title="Inline code"
                        onPointerDown={(e) => e.preventDefault()}
                        onClick={() => formatNote("`")}
                      >
                        <Code2 size={16} />
                      </button>
                      <button title="Text style" data-label="Text style" data-text-style-trigger aria-expanded={textStyleMenuOpen} onPointerDown={event=>event.preventDefault()} onClick={()=>setTextStyleMenuOpen(!textStyleMenuOpen)}><Type size={18}/></button>
                      <i />
                    </>
                  )}
                  {single?.type==='note'&&<><button title={single.isDocument?'Convert to note':'Convert to document'} data-label="Document" onClick={()=>{finishNoteEdit();patch(single.id,{isDocument:!single.isDocument,title:single.title||'Untitled document',height:single.isDocument?Math.max(54,single.text.split('\n').length*24+30):150});if(!single.isDocument)beginNoteEdit({...single,isDocument:true});}}><FileText size={17}/></button><button title="Create synced copy" data-label="Sync copy" onClick={()=>createSyncedCopy(single.id)}><Copy size={17}/></button>{single.syncedId&&<button title="Unlink synced note" onClick={()=>patch(single.id,{syncedId:undefined})}><Unlock size={16}/></button>}<button title="Clear highlight" onPointerDown={e=>e.preventDefault()} onClick={()=>runNoteCommand('unsetHighlight')}><X size={12}/></button></>}
                  {single?.type==='note'&&<div className="note-color-tools"><label title="Text color">A<input type="color" aria-label="Text color" value={textInk} onChange={e=>{setTextInk(e.target.value);runNoteCommand('textColor',e.target.value);}}/></label><label title="Highlight color">▰<input type="color" aria-label="Highlight color" value={textHighlight} onChange={e=>{setTextHighlight(e.target.value);runNoteCommand('highlight',e.target.value);}}/></label><button title="Clear text color" onPointerDown={e=>e.preventDefault()} onClick={()=>runNoteCommand('unsetTextColor')}><X size={12}/></button></div>}
                  {single?.type==='note'&&<><button title="Text link" onPointerDown={e=>e.preventDefault()} onClick={requestTextLink}><Link size={16}/></button><button title="Quote block" onPointerDown={e=>e.preventDefault()} onClick={()=>runNoteCommand('blockquote')}><Quote size={16}/></button></>}
                  {single?.type==='image'&&<><button title="Crop and rotate image" data-label="Crop" onClick={()=>{setImageMode('crop');setImageEditorId(single.id);}}><Crop size={18}/></button><button title="Draw on image" data-label="Draw" onClick={()=>{setImageMode('markup');setImageEditorId(single.id);}}><Pencil size={18}/></button><button title="Download original image" data-label="Original" onClick={()=>{fetch(single.src).then(r=>{if(!r.ok)throw new Error('Image download failed');return r.blob();}).then(blob=>downloadFile(single.caption||'original-image',blob)).catch(error=>notify(error.message));}}><Download size={17}/></button></>}
                  {single?.type==='image'&&<><button title="Image caption" data-label="Caption" aria-pressed={single.showCaption!==false} onClick={()=>{patch(single.id,{showCaption:single.showCaption===false});setEditing(single.id);}}><Type size={17}/></button><button title="Edit image caption" onClick={()=>{patch(single.id,{showCaption:true});setEditing(single.id);}}><Pencil size={16}/></button></>}
                  {single?.type==='link'&&mediaEmbedUrl(single.url)&&<button title="Show media" data-label="Media" aria-pressed={!!single.showMedia} onClick={()=>patch(single.id,{showMedia:!single.showMedia,height:single.showMedia?180:330})}><Image size={17}/></button>}
                  {single?.type==='board'&&workspaceBoard(doc,single.boardId)&&<button title="Board icon" data-label="Icon" data-board-icon-trigger aria-expanded={boardIconPickerOpen} onClick={()=>setBoardIconPickerOpen(!boardIconPickerOpen)}><Folder size={18}/></button>}
                  {single?.type==='link'&&<><button title="Link preview" data-label="Preview" aria-pressed={single.showPreview!==false} onClick={()=>patch(single.id,{showPreview:single.showPreview===false})}><Image size={17}/></button><button title="Link info" data-label="Info" aria-pressed={single.showInfo!==false} onClick={()=>patch(single.id,{showInfo:single.showInfo===false})}><Link size={17}/></button><button title="Rename link" data-label="Rename" onClick={()=>setEditing(single.id)}><Pencil size={17}/></button><button title="Link caption" data-label="Caption" aria-pressed={!!single.showCaption} onClick={()=>patch(single.id,{showCaption:!single.showCaption})}><Type size={17}/></button></>}
                  <button title="Move to board" data-label="Move" onClick={()=>{finishNoteEdit();setModal('move');}}><Folder size={17}/></button>
                  {single?.type==='column'&&<button title="Convert column to board" data-label="To board" onClick={()=>{finishNoteEdit();const result=convertColumnToBoard(docRef.current,activeId,single.id);if(result.boardId){commit(result.workspace);setEditing(null);notify('Column converted to a board');}}}><Folder size={17}/></button>}
                  {single?.type==='image'&&<button title="Remove image background" data-label="Background" onClick={()=>setCutoutId(single.id)}><Image size={18}/></button>}
                  {single?.type==='board'&&<><button title="Create a Shortcut to This Board" data-label="Shortcut" disabled={!workspaceBoard(doc,single.boardId)} onClick={()=>{const result=createBoardShortcut(docRef.current,single.boardId,activeId,{x:single.x+single.width+30,y:single.y});commit(result.workspace);if(result.id)setSelected([result.id]);}}><Copy size={17}/></button><button title="Copy a Link to This Board" data-label="Copy link" onClick={()=>navigator.clipboard.writeText(boardLocalUrl(single.boardId)).then(()=>notify('Board link copied')).catch(()=>notify('Clipboard is unavailable in this browser'))}><Link size={17}/></button><button disabled={!workspaceBoard(doc,single.boardId)} title={workspaceBoard(doc,single.boardId)?.isTemplate?'Revert to regular board':'Convert to Template'} data-label="Template" onClick={()=>commit(workspaceBoard(doc,single.boardId)?.isTemplate?revertTemplateToBoard(docRef.current,single.boardId):convertBoardToTemplate(docRef.current,single.boardId))}><Columns3 size={17}/></button></>}
                  {single?.type==='file'&&<>
                    {single.showFileInfo!==false&&<button title="Rename file" data-label="Rename" onClick={()=>setEditing(single.id)}><Pencil size={17}/></button>}
                    {/^(audio|video)\//.test(single.mime)&&<><button title="Loop media" data-label="Loop" aria-pressed={!!single.loop} onClick={()=>patch(single.id,{loop:!single.loop})}><RotateCcw size={17}/></button><button title="Autoplay media" data-label="Autoplay" aria-pressed={!!single.autoplay} onClick={()=>patch(single.id,{autoplay:!single.autoplay})}><ArrowRight size={17}/></button></>}
                    {(filePreviewKind(single)!=='icon'||!!single.previewSrc)&&<><button title={filePreviewKind(single)==='pdf'?'PDF preview':'File preview'} data-label="Preview" aria-pressed={single.showPreview!==false} onClick={()=>toggleFilePreview(single)}><FileText size={17}/></button>
                      <button title="File info" data-label="Info" disabled={single.showPreview===false} aria-pressed={single.showFileInfo!==false} onClick={()=>updateFileDetail(single,{showFileInfo:single.showFileInfo===false})}><Paperclip size={17}/></button>
                      <button title="File caption" data-label="Caption" disabled={single.showPreview===false||single.showFileInfo===false} aria-pressed={!!single.showCaption} onClick={()=>updateFileDetail(single,{showCaption:!single.showCaption})}><Type size={17}/></button></>}
                  </>}
                  {single?.type==='todo'&&<><button title="To-do title" data-label="Title" aria-pressed={!!single.title} onClick={()=>todoRef.current?.run('toggleTitle')}><Type size={18}/></button><button title="Due date" data-label="Due date" onClick={()=>todoRef.current?.run('dueDate')}><CheckSquare size={18}/></button><button title="Indent task" onClick={()=>todoRef.current?.run('indent')}><ArrowRight size={16}/></button><button title="Outdent task" onClick={()=>todoRef.current?.run('outdent')}><ArrowLeft size={16}/></button><button title="Add task" data-label="Add task" onClick={()=>todoRef.current?.run('addTask')}><Plus size={17}/></button></>}
                  {single?.type==='swatch'&&<><button title="Edit color" data-label="Color" onClick={()=>swatchRefs.current.get(single.id)?.openPicker()}><Palette size={18}/></button><select title="Color display" aria-label="Color display" value={single.showValue===false?'off':single.colorSpace||'hex'} onChange={e=>patch(single.id,e.target.value==='off'?{showValue:false}:{showValue:true,colorSpace:e.target.value as 'hex'|'rgb'|'hsl'})}><option value="hex">HEX</option><option value="rgb">RGB</option><option value="hsl">HSL</option><option value="off">Off</option></select><button title="Swatch caption" data-label="Caption" aria-pressed={single.showCaption!==false} onClick={()=>updateSwatch(single.id,{showCaption:single.showCaption===false})}><Type size={17}/></button></>}
                  {single?.type === 'table' && <>
                    <select aria-label="Table text style" title="Table text style" value="" onChange={e=>{tableEditorRef.current?.run(e.target.value==='italic'?'setItalic':'setBold',e.target.value==='normal'?false:undefined);if(e.target.value==='normal')tableEditorRef.current?.run('setItalic',false);}}><option value="">Text style</option><option value="normal">Normal</option><option value="bold">Bold</option><option value="italic">Italic</option></select>
                    <button title="Cell type" data-label="Cell type" data-table-cell-type aria-expanded={cellTypeMenuOpen} onClick={()=>setCellTypeMenuOpen(!cellTypeMenuOpen)}><Type size={18}/></button>
                    <input type="color" aria-label="Cell color" title="Cell color" value={single.cellMeta?.[`${tableSelection.row}:${tableSelection.column}`]?.color||'#ffffff'} onChange={e=>tableEditorRef.current?.run('setColor',e.target.value)}/>
                    <button title="Browse formulas" data-label="Functions" onClick={()=>{setQuery('');setModal('formulas');}}><Search size={17}/></button>
                    <button title="Formula" data-label="Formula" onPointerDown={e=>e.preventDefault()} onClick={()=>tableEditorRef.current?.run('formula')}><Code2 size={18}/></button>
                    <select aria-label="Cell alignment" title="Cell alignment" value={single.cellMeta?.[`${tableSelection.row}:${tableSelection.column}`]?.align||'left'} onChange={e=>tableEditorRef.current?.run('setAlign',e.target.value)}><option value="left">Left</option><option value="center">Center</option><option value="right">Right</option></select>
                    <select aria-label="Cell vertical alignment" title="Cell vertical alignment" value={single.cellMeta?.[`${tableSelection.row}:${tableSelection.column}`]?.verticalAlign||'top'} onChange={e=>tableEditorRef.current?.run('setVerticalAlign',e.target.value)}><option value="top">Top</option><option value="middle">Middle</option><option value="bottom">Bottom</option></select>
                    <button title="Add column" data-label="Column" onClick={()=>tableEditorRef.current?.run('addColumn')}><Columns3 size={18}/></button>
                    <button title="Add row" data-label="Row" onClick={()=>tableEditorRef.current?.run('addRow')}><Plus size={18}/></button>
                    <button title="Delete column" onClick={()=>tableEditorRef.current?.run('deleteColumn')} disabled={single.rows[0]?.length<=1}><Minus size={16}/></button>
                    <button title="Delete row" onClick={()=>tableEditorRef.current?.run('deleteRow')} disabled={single.rows.length<=1}><Minus size={16}/></button>
                  </>}
                  <button title="Labels" data-label="Labels" onClick={event=>{finishNoteEdit();const r=event.currentTarget.getBoundingClientRect();setLabelsOpen({left:49,top:r.top});}}><Tag size={18}/></button>
                  {single?.type === "sketch" && (
                    <>
                      <button
                        title="Draw in sketch"
                        onClick={() => beginDrawing(single)}
                      >
                        <Pencil size={16} />
                      </button>
                      <button
                        title="Clear sketch"
                        onClick={() =>
                          patch(single.id, { paths: [] } as Partial<Card>)
                        }
                      >
                        <RotateCcw size={16} />
                      </button>
                      <i />
                    </>
                  )}
                  {selected.length > 1 && (
                    <>
                      <button
                        title="Align left"
                        onClick={() =>
                          change((b) => ({
                            ...b,
                            cards: b.cards.map((c) =>
                              selected.includes(c.id) && !c.locked
                                ? {
                                    ...c,
                                    x: Math.min(
                                      ...selectedCards.map((c) => c.x),
                                    ),
                                  }
                                : c,
                            ),
                          }))
                        }
                      >
                        <ArrowLeft size={16} />
                      </button>
                      <button
                        title="Group into a column"
                        onClick={() => {
                          const x =
                              Math.min(...selectedCards.map((c) => c.x)) - 16,
                            y = Math.min(...selectedCards.map((c) => c.y)) - 60;
                          const column = {
                            ...createCard("column", x, y),
                            title: "New group",
                            width:
                              Math.max(...selectedCards.map((c) => c.width)) +
                              32,
                            height:
                              Math.max(
                                ...selectedCards.map((c) => c.y + c.height),
                              ) -
                              y +
                              25,
                          } as Card;
                          change((b) =>
                            placeInColumn(
                              { ...b, cards: [...b.cards, column] },
                              selected,
                              column.id,
                            ),
                          );
                          setSelected([column.id]);
                        }}
                      >
                        <Columns3 size={16} />
                      </button>
                      <i />
                    </>
                  )}
                  <button title="Color" data-label="Color" data-card-color-trigger aria-expanded={cardColorMenuOpen} onClick={()=>{finishNoteEdit();setCardColorMenuOpen(!cardColorMenuOpen);}}><Palette size={18}/></button>
                  <i />
                  <button
                    title="Move to Unsorted"
                    onClick={() => sendToInbox(selected)}
                  >
                    <Inbox size={16} />
                  </button>
                  <button title="Duplicate (⌘D)" onClick={duplicate}>
                    <Copy size={16} />
                  </button>
                  <button
                    title={single?.locked ? "Unlock" : "Lock"}
                    onClick={() =>
                      change((b) => ({
                        ...b,
                        cards: b.cards.map((c) =>
                          selected.includes(c.id)
                            ? { ...c, locked: !c.locked }
                            : c,
                        ),
                      }))
                    }
                  >
                    {single?.locked ? <Unlock size={16} /> : <Lock size={16} />}
                  </button>
                  <button
                    title="Bring to front"
                    onClick={() =>
                      change((b) => ({
                        ...b,
                        cards: b.cards.map((c) =>
                          selected.includes(c.id)
                            ? {
                                ...c,
                                z: Math.max(...b.cards.map((c) => c.z)) + 1,
                              }
                            : c,
                        ),
                      }))
                    }
                  >
                    <ArrowUpRight size={16} />
                  </button>
                </>
              )}
              <i />
              <button
                title="Delete selected"
                className="danger"
                onClick={remove}
              >
                <Trash2 size={16} />
              </button>
              <button
                title="Clear selection"
                onClick={() => {
                  setSelected([]);
                  setLineId(null);
                }}
              >
                <X size={15} />
              </button>
            </div>
          )}
          {tool === "draw" && (
            <div className="pen-toolbar">
              <Pencil size={16} />
              <span>Draw freely</span>
              <input
                type="color"
                aria-label="Pen color"
                value={penColor}
                onChange={(e) => setPenColor(e.target.value)}
              />
              <input
                aria-label="Pen width"
                type="range"
                min="1"
                max="12"
                value={penWidth}
                onChange={(e) => setPenWidth(+e.target.value)}
              />
              <button onClick={() => setTool("select")}>
                Done <Check size={14} />
              </button>
            </div>
          )}
          {tool === "connect" && (
            <div className="mode-hint">
              {from
                ? "Choose the destination card"
                : "Choose a card to start a connection"}
              <button
                onClick={() => {
                  setTool("select");
                  setFrom(null);
                }}
              >
                <X size={14} />
              </button>
            </div>
          )}
        </main>
      </div>
      {toast && (
        <div className="toast">
          <Check size={16} />
          {toast}
        </div>
      )}
      {context && (
        <>
          <div className="context-backdrop" onClick={() => setContext(null)} />
          <div
            className="context-menu"
            style={{ left: context.x, top: context.y }}
          >
            {!selected.length&&(<div className="canvas-bottom">
            <div className="view-tools">
              <button
                className={tool === "select" ? "active" : ""}
                title="Select (V)"
                onClick={() => setTool("select")}
              >
                <MousePointer2 size={17} />
              </button>
              <button
                className={tool === "hand" ? "active" : ""}
                title="Pan (hold Space)"
                onClick={() => setTool("hand")}
              >
                <Hand size={17} />
              </button>
              <i />
              <button title="Zoom out" onClick={() => zoom(1 / 1.2)}>
                <Minus size={15} />
              </button>
              <button
                className="zoom-label"
                title="Reset zoom"
                onClick={() => setViewport((v) => ({ ...v, zoom: 1 }))}
              >
                {Math.round(viewport.zoom * 100)}%
              </button>
              <button title="Zoom in" onClick={() => zoom(1.2)}>
                <Plus size={15} />
              </button>
              <i />
              <button title="Fit board (0)" onClick={fit}>
                <Maximize size={16} />
              </button>
            </div>
            <div className="board-meta">
              <span>{cards.length} items</span>
              <span>·</span>
              <span>{board.connections.length} connections</span>
            </div>
            <button
              className="help-button"
              title="Keyboard shortcuts"
              onClick={() => {setContext(null);setModal("help");}}
            >
              <CircleHelp size={18} />
            </button>
          </div>)}
            {selected.length > 0 ? (
              <>
                <button
                  onClick={() => {
                    copy();
                    setContext(null);
                  }}
                >
                  <Copy size={15} />
                  Copy<span>⌘C</span>
                </button>
                <button
                  onClick={() => {
                    duplicate();
                    setContext(null);
                  }}
                >
                  <Plus size={15} />
                  Duplicate<span>⌘D</span>
                </button>
                {single?.type==='note'&&<button onClick={()=>{createSyncedCopy(single.id);setContext(null);}}><Copy size={15}/>Create Synced Copy</button>}
                <button
                  onClick={() => {
                    setEditing(selected[0]);
                    setContext(null);
                  }}
                >
                  <Pencil size={15} />
                  Edit
                </button>
                <hr />
                <button
                  onClick={() => {
                    sendToInbox(selected);
                    setContext(null);
                  }}
                >
                  <Inbox size={15} />
                  Move to Unsorted
                </button>
                <button
                  className="danger"
                  onClick={() => {
                    remove();
                    setContext(null);
                  }}
                >
                  <Trash2 size={15} />
                  Delete<span>⌫</span>
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => {
                    insert("note");
                    setContext(null);
                  }}
                >
                  <Type size={15} />
                  Add note
                </button>
                <button
                  onClick={() => {
                    paste(context?point(context.x,context.y):undefined);
                    setContext(null);
                  }}
                >
                  <Copy size={15} />
                  Paste<span>⌘V</span>
                </button>
                <button
                  onClick={() => {
                    fit();
                    setContext(null);
                  }}
                >
                  <Maximize size={15} />
                  Fit to screen
                </button>
                <hr />
                <button
                  onClick={() => {
                    setModal("export");
                    setContext(null);
                  }}
                >
                  <Download size={15} />
                  Export board
                </button>
                <button
                  onClick={() => {
                    importRef.current?.click();
                    setContext(null);
                  }}
                >
                  <Upload size={15} />
                  Import workspace
                </button>
                <button
                  onClick={() => {
                    setModal("help");
                    setContext(null);
                  }}
                >
                  <CircleHelp size={15} />
                  Help & shortcuts
                </button>
              </>
            )}
          </div>
        </>
      )}
      {cardColorMenuOpen&&selected.length>0&&<CardColorMenu background={single?.color} strip={single?.stripColor} customColors={doc.customColors} allowStrip={selectedCards.every(canUseColorStrip)} onClose={()=>setCardColorMenuOpen(false)} onChange={value=>commit(updateCardAppearance(docRef.current,activeId,selected,value))}/>}
      {boardIconPickerOpen&&single?.type==='board'&&workspaceBoard(doc,single.boardId)&&<BoardIconPicker boardTitle={workspaceBoard(doc,single.boardId)?.title} anchor={{left:60.5,top:80}} value={workspaceBoard(doc,single.boardId)?.icon} onClose={()=>setBoardIconPickerOpen(false)} onChange={icon=>commit(updateBoard(docRef.current,single.boardId,board=>({...board,icon})))}/>}
      {boardDragPreview&&<BoardDragPreview {...boardDragPreview}/>}
      {viewMenuOpen&&<ViewMenu zoom={viewport.zoom} onZoom={value=>zoom(value/viewport.zoom)} onFit={fit} onClose={()=>setViewMenuOpen(false)} onPresent={()=>{finishNoteEdit();setViewMenuOpen(false);setPresenting(true);}}/>}
      {textStyleMenuOpen&&single?.type==='note'&&<TextStyleMenu active={noteEditorRef.current?.isActive('heading',1)?'heading1':noteEditorRef.current?.isActive('heading',2)?'heading2':noteEditorRef.current?.isActive('smallText')?'smallText':noteEditorRef.current?.isActive('codeBlock')?'codeBlock':noteEditorRef.current?.isActive('callout')?'callout':noteEditorRef.current?.isActive('blockquote')?'blockquote':'paragraph'} textColor={textInk} highlight={textHighlight} onClose={()=>setTextStyleMenuOpen(false)} onCommand={(command,value)=>{if(command==='textColor'&&typeof value==='string')setTextInk(value);if(command==='highlight'&&typeof value==='string')setTextHighlight(value);runNoteCommand(command,value);}}/>}
      {cellTypeMenuOpen&&single?.type==='table'&&<CellTypeMenu meta={single.cellMeta?.[`${tableSelection.row}:${tableSelection.column}`]} value={single.rows[tableSelection.row]?.[tableSelection.column]||''} onRun={(action,value)=>tableEditorRef.current?.run(action,value)} onClose={()=>setCellTypeMenuOpen(false)}/>}
      {exportMenuOpen&&<ExportMenu includeSubBoards={exportSubBoards} onIncludeSubBoardsChange={setExportSubBoards} busy={exportBusy} onClose={()=>setExportMenuOpen(false)} onExport={kind=>void exportCurrent(kind==='pdf-high'?'pdf':kind,kind==='pdf-high'?'large':'standard')}/>}
      {imageLibraryOpen&&<ImageLibrary anchor={{left:69,top:110}} onClose={()=>setImageLibraryOpen(false)} onSelect={photo=>addLibraryPhoto(photo)} onUpload={()=>{setImageLibraryOpen(false);uploadKind.current='image';uploadAt.current=undefined;if(uploadRef.current)uploadRef.current.accept='image/*';uploadRef.current?.click();}}/>}
      {labelsOpen&&<LabelManager workspace={doc} boardId={activeId} selectedIds={selected} anchor={labelsOpen} onClose={()=>setLabelsOpen(null)} onChange={commit} onFilter={id=>{setLabelsOpen(null);setFilterLabelId(id);setQuery(doc.labels?.find(label=>label.id===id)?.name||'');setModal('search');}}/>}
      {syncedPopup&&<SyncedNoteLocations key={syncedPopup.id} locations={syncedPopupLocations} currentBoardId={activeId} anchor={syncedPopup.anchor} onOpenBoard={openSyncedBoard} onClose={()=>setSyncedPopup(null)}/>}
      {modal==='search'&&<WorkspaceSearch workspace={doc} query={query} labelId={filterLabelId} anchorRight={searchTriggerRef.current?.getBoundingClientRect().right} onQuery={value=>{setFilterLabelId(null);setQuery(value);}} onClose={()=>setModal(null)} onChoose={(id,card)=>{navigate(id);if(card){setSelected([card.id]);if(card.unsorted)setInboxOpen(true);else{if(card.parentId&&docRef.current.boards[id].cards.find(item=>item.id===card.parentId)?.collapsed)commit(updateBoard(docRef.current,id,target=>({...target,cards:target.cards.map(item=>item.id===card.parentId?{...item,collapsed:false}:item)})));setViewport({x:130-card.x*.9,y:100-card.y*.9,zoom:.9});}}}}/>}
      <TrashPanel entries={doc.trash||[]} open={trashOpen} onClose={()=>setTrashOpen(false)} onRestore={id=>commit(restoreTrashEntry(docRef.current,id))} onEmpty={()=>commit(emptyTrash(docRef.current))} onDelete={id=>commit(permanentlyDeleteTrashEntry(docRef.current,id))}/>
      {sketchSession&&<SketchEditor {...sketchSession.value} mode={sketchSession.mode} onSave={saveDrawing} onCancel={()=>setSketchSession(null)}/>}
      {presenting&&<Presentation formulaWorkbook={formulaWorkbook} board={{...board,viewport}} boards={doc.boards} labels={doc.labels||[]} onClose={()=>setPresenting(false)} onCardDoubleClick={card=>{if(card.type==='board')navigate(card.boardId);}} onCardMove={(id,at)=>patch(id,at)} onCardChange={patch}/>}
      {cutoutId&&(()=>{const card=cards.find(card=>card.id===cutoutId);return card?.type==='image'?<BackgroundRemoval src={card.src} cutoutSrc={card.cutoutSrc} useCutout={card.useCutout} edits={card.imageEdits} onSave={values=>{patch(card.id,values);setCutoutId(null);}} onCancel={()=>setCutoutId(null)}/>:null;})()}
      {imageColorSampling&&<BoardImageSampler {...imageColorSampling} onFinish={finishImageColorSampling}/>}
      {imageEditorId&&(()=>{const card=cards.find(c=>c.id===imageEditorId);return card?.type==='image'?<ImageEditor src={card.useCutout&&card.cutoutSrc?card.cutoutSrc:card.src} edits={card.imageEdits} initialMode={imageMode} onCancel={()=>setImageEditorId(null)} onSave={(imageEdits,size)=>{patch(card.id,{imageEdits,height:Math.max(90,Math.min(1600,card.width*size.height/size.width+35))});setImageEditorId(null);}}/>:null;})()}
      {modal && modal!=='search' && (
        <div
          className="modal-backdrop"
          onPointerDown={(e) => {
            if (e.target === e.currentTarget) closeModal();
          }}
        >
          <section className={"modal modal-" + modal} role={modal==='note-link'?'dialog':undefined} aria-modal={modal==='note-link'?true:undefined} aria-label={modal==='note-link'?'Add a text link':undefined} onKeyDown={modal==='note-link'?keepDialogFocus:undefined}>
            <button
              className="modal-close"
              title="Close dialog"
              onClick={closeModal}
            >
              <X size={20} />
            </button>
            {modal==='move'&&<><h2>Move to board</h2><div className="board-destinations">{Object.values(doc.boards).filter(target=>target.id!==activeId&&!target.isTemplate).map(target=><button key={target.id} onClick={()=>{const next=moveCardsToBoard(docRef.current,activeId,target.id,selected,{x:40,y:40});if(next===docRef.current){notify('These items cannot move into that board');return;}commit(next);setSelected([]);setModal(null);notify('Items moved to '+target.title);}}><Folder size={18}/><span>{target.title}</span><ArrowRight size={16}/></button>)}</div></>}
            {modal==='formulas'&&single?.type==='table'&&<><h2>Table functions</h2><div className="search-field"><Search size={18}/><input aria-label="Find formula" autoFocus placeholder="Find a function…" value={query} onChange={e=>setQuery(e.target.value)}/></div><div className="formula-list">{tableFormulaNames.filter(name=>name.toLowerCase().includes(query.toLowerCase())).map(name=><button key={name} onClick={()=>{setModal(null);tableEditorRef.current?.run('formula',`=${name}()`);}}>{name}</button>)}</div></>}
            {modal==='document'&&single?.type==='note'&&<><input className="document-title" aria-label="Document title" value={single.title||''} placeholder="Untitled document" onChange={e=>patch(single.id,{title:e.target.value})}/><div className="document-toolbar">{(['bold','italic','underline','bulletList','orderedList','blockquote','callout'] as NoteEditorCommand[]).map(command=><button key={command} title={`Document ${command}`} onPointerDown={e=>e.preventDefault()} onClick={()=>runNoteCommand(command)}>{command}</button>)}{(['pdf','word','markdown','text'] as const).map(format=><button key={format} title={`Download document ${{pdf:'PDF',word:'Word',markdown:'Markdown',text:'Text'}[format]}`} disabled={exportBusy} onPointerDown={e=>e.preventDefault()} onClick={()=>void downloadDocument(format)}>Download {{pdf:'PDF',word:'Word',markdown:'Markdown',text:'Text'}[format]}</button>)}</div><Suspense fallback={<p>Loading editor…</p>}><NoteEditor key={single.id} ref={noteEditorRef} text={single.text} html={single.html} autoFocus onReady={handleNoteReady} ariaLabel="Document text" onRequestLink={requestTextLink} onChange={value=>updateNoteContent(single,value)}/></Suspense></>}
            {modal==='note-link'&&textLinkForm()}
            {modal==='document'&&documentLinkOpen&&<div className="modal-backdrop document-link-backdrop" onPointerDown={event=>{event.stopPropagation();if(event.target===event.currentTarget)closeTextLink();}}><section className="modal modal-note-link" role="dialog" aria-modal="true" aria-label="Add a text link" onKeyDown={keepDialogFocus} onPointerDown={event=>event.stopPropagation()}><button className="modal-close" title="Close text link" onClick={closeTextLink}><X size={20}/></button>{textLinkForm()}</section></div>}
            {modal === "appearance" && (
              <>
                <div className="modal-icon">
                  <Palette size={24} />
                </div>
                <h2>Make this space yours.</h2>
                <p className="modal-description">
                  A quiet background for your ideas.
                </p>
                <div className="board-color-options">
                  {[
                    "#f5f3ef",
                    "#ffffff",
                    "#eef2e7",
                    "#eaf0f4",
                    "#f5eae5",
                    "#252d28",
                  ].map((value) => (
                    <button
                      key={value}
                      title={`Board background ${value}`}
                      style={{ background: value }}
                      onClick={() =>
                        change((b) => ({ ...b, background: value }))
                      }
                    >
                      {board.background === value && <Check size={18} />}
                    </button>
                  ))}
                  <input
                    type="color"
                    aria-label="Custom board background"
                    value={board.background || "#ebedee"}
                    onChange={(e) =>
                      change((b) => ({ ...b, background: e.target.value }))
                    }
                  />
                </div>
                <label className="grid-choice">
                  <input
                    type="checkbox"
                    checked={board.grid !== false}
                    onChange={(e) =>
                      change((b) => ({ ...b, grid: e.target.checked }))
                    }
                  />
                  Show dot grid
                </label>
              </>
            )}
            {modal === "help" && (
              <>
                <div className="modal-icon">
                  <CircleHelp size={24} />
                </div>
                <h2>A little help for your next big idea.</h2>
                <p className="modal-description">
                  Make room for inspiration. Everything saves locally on this
                  device.
                </p>
                <div className="shortcuts">
                  {[
                    ["Create a note", "N"],
                    ["Select / hand tool", "V / Space"],
                    ["Draw / connect cards", "P / L"],
                    ["Undo / redo", "⌘Z / ⇧⌘Z"],
                    ["Copy / paste / duplicate", "⌘C / ⌘V / ⌘D"],
                    ["Select all / delete", "⌘A / Delete"],
                    ["Nudge / nudge 10px", "Arrow / Shift + Arrow"],
                    ["Fit all items", "0"],
                    ["Search workspace", "⌘K"],
                  ].map(([a, b]) => (
                    <div key={a}>
                      <span>{a}</span>
                      <kbd>{b}</kbd>
                    </div>
                  ))}
                </div>
                <div className="help-note">
                  <strong>On iPad</strong>
                  <p>
                    Pinch to zoom, drag the canvas to pan, and drag cards to
                    move them. Double-tap a note to edit. Use the arrow tool to
                    select and the handles to resize.
                  </p>
                  <strong>Keep a backup</strong>
                  <p>
                    Export a workspace JSON to preserve all boards and attached
                    files. Clearing browser data removes local boards.
                  </p>
                </div>
              </>
            )}
            {modal === "export" && (
              <>
                <div className="modal-icon">
                  <Download size={24} />
                </div>
                <h2>Take your ideas with you.</h2>
                <p className="modal-description">
                  Export this board, or save a complete editable workspace
                  backup.
                </p>
                <div className="export-settings">
                  <label><input type="checkbox" checked={exportSubBoards} onChange={event=>setExportSubBoards(event.target.checked)}/>Include sub-boards in Word, Markdown and plain text</label>
                  <label>PDF quality<select aria-label="PDF quality" value={exportPdfQuality} onChange={event=>setExportPdfQuality(event.target.value as 'standard'|'large')}><option value="standard">Standard (small file size)</option><option value="large">High quality (large file size)</option></select></label>
                </div>
                {exportBusy&&<p role="status">Preparing export…</p>}
                <div className="export-options" aria-busy={exportBusy}>
                  {(['pdf','png','docx','zip'] as const).map(format=><button key={format} disabled={exportBusy} onClick={()=>void exportCurrent(format)}><div><Download size={22}/></div><span><strong>{{pdf:'PDF document',png:'PNG image',docx:'Word document',zip:'Download all attachments'}[format]}</strong><small>{{pdf:'Visual board layout',png:'High resolution board image',docx:'Editable notes, tasks and tables',zip:'Original images and files in a ZIP'}[format]}</small></span><Download size={17}/></button>)}
                  <button onClick={() => void exportCurrent("json")}>
                    <div>
                      <Folder size={22} />
                    </div>
                    <span>
                      <strong>Workspace backup</strong>
                      <small>All boards & attachments · editable JSON</small>
                    </span>
                    <Download size={17} />
                  </button>
                  <button onClick={() => void exportCurrent("html")}>
                    <div>
                      <FileText size={22} />
                    </div>
                    <span>
                      <strong>Board as HTML</strong>
                      <small>Standalone visual board</small>
                    </span>
                    <Download size={17} />
                  </button>
                  <button onClick={() => void exportCurrent("svg")}>
                    <div>
                      <Image size={22} />
                    </div>
                    <span>
                      <strong>Board as SVG</strong>
                      <small>Visual layout · browser compatible</small>
                    </span>
                    <Download size={17} />
                  </button>
                  <button onClick={() => void exportCurrent("md")}>
                    <div>
                      <FileText size={22} />
                    </div>
                    <span>
                      <strong>Board as Markdown</strong>
                      <small>Notes, tasks, links & tables</small>
                    </span>
                    <Download size={17} />
                  </button>
                  <button onClick={() => void exportCurrent("txt")}>
                    <div>
                      <Type size={22} />
                    </div>
                    <span>
                      <strong>Board as plain text</strong>
                      <small>Readable content without formatting</small>
                    </span>
                    <Download size={17} />
                  </button>
                  <button onClick={() => void exportCurrent("print")}>
                    <div>
                      <Download size={22} />
                    </div>
                    <span>
                      <strong>Print / Save as PDF</strong>
                      <small>Choose “Save as PDF” in your print dialog</small>
                    </span>
                    <ArrowUpRight size={17} />
                  </button>
                </div>
                <button
                  className="import-inline"
                  onClick={() => importRef.current?.click()}
                >
                  <Upload size={15} /> Import a workspace backup
                </button>
              </>
            )}
            {modal === "templates" && (
              <>
                <div className="modal-icon">
                  <Columns3 size={24} />
                </div>
                <h2>A head start for your ideas.</h2>
                <p className="modal-description">
                  Add a fresh board to your workspace. Your existing boards stay
                  here.
                </p>
                <button className="save-template" onClick={()=>{finishNoteEdit();commit(saveBoardTemplate(docRef.current,activeId));notify('Board saved as a template');}}><Plus size={15}/> Save current board as a template</button>
                <div className="templates">
                  {Object.values(doc.boards).filter(board=>board.isTemplate).map(template=><div className="saved-template" key={template.id}><button aria-label={`Use template ${template.title}`} onClick={()=>{const p=center();const result=instantiateBoardTemplate(docRef.current,template.id,activeId,p.x,p.y);if(result.boardId){commit(result.workspace);navigate(result.boardId);setModal(null);}}}><div className="template-preview">📋</div><strong>{template.title}</strong><span>Saved template · {template.cards.length} items</span></button>{templateRename?.id===template.id?<form className="template-rename" onSubmit={event=>{event.preventDefault();commit(renameBoardTemplate(docRef.current,template.id,templateRename.title));setTemplateRename(null);}}><input autoFocus aria-label="Template name" value={templateRename.title} onChange={event=>setTemplateRename({id:template.id,title:event.target.value})} onKeyDown={event=>{if(event.key==='Escape'){event.stopPropagation();setTemplateRename(null);}}}/><button type="submit">Save</button></form>:<div className="template-actions"><button aria-label={`Rename template ${template.title}`} onClick={()=>setTemplateRename({id:template.id,title:template.title})}>Rename</button><button aria-label={`Revert template ${template.title} to board`} onClick={()=>commit(revertTemplateToBoard(docRef.current,template.id))}>Revert to board</button><button aria-label={`Delete template ${template.title}`} onClick={()=>{commit(deleteBoardTemplate(docRef.current,template.id));notify('Template moved to Trash');}}>Delete</button></div>}</div>)}
                  {[
                    {
                      name: "Blank canvas",
                      desc: "A little space for anything.",
                      kind: "blank",
                    },
                    {
                      name: "Creative project",
                      desc: "Inspiration, ideas & a plan.",
                      kind: "project",
                    },
                    {
                      name: "Moodboard",
                      desc: "Bring a visual direction together.",
                      kind: "mood",
                    },
                    {
                      name: "Weekly planner",
                      desc: "Turn your ideas into next steps.",
                      kind: "planner",
                    },
                  ].map((t, i) => (
                    <button
                      key={t.kind}
                      onClick={() => {
                        const id = uid();
                        const newCards: Card[] =
                          t.kind === "blank"
                            ? []
                            : t.kind === "planner"
                              ? [
                                  "Monday",
                                  "Tuesday",
                                  "Wednesday",
                                  "Thursday",
                                  "Friday",
                                ].map(
                                  (title, i) =>
                                    ({
                                      ...createCard("todo", 80 + i * 290, 100),
                                      title,
                                      items: [
                                        {
                                          id: uid(),
                                          text: "One thing to focus on",
                                          done: false,
                                        },
                                      ],
                                      width: 250,
                                      height: 220,
                                    }) as Card,
                                )
                              : [
                                  {
                                    ...createCard("label", 80, 55),
                                    text: t.name.toUpperCase(),
                                    width: 400,
                                    height: 50,
                                  } as Card,
                                  ...["Inspiration", "Ideas", "Next steps"].map(
                                    (title, i) =>
                                      ({
                                        ...createCard(
                                          "column",
                                          80 + i * 320,
                                          150,
                                        ),
                                        title,
                                        width: 280,
                                        height: 480,
                                      }) as Card,
                                  ),
                                  {
                                    ...createCard("note", 100, 220),
                                    text: "What do you want to create?\n\nStart with a thought, a reference, or a question.",
                                    color: "#fff3bc",
                                    width: 240,
                                    height: 180,
                                  } as Card,
                                ];
                        const parent = docRef.current.boards[activeId];
                        const c = {
                          ...createCard("board", center().x, center().y),
                          title: t.name,
                          boardId: id,
                        } as Card;
                        commit({
                          ...docRef.current,
                          boards: {
                            ...docRef.current.boards,
                            [activeId]: {
                              ...parent,
                              cards: [...parent.cards, c],
                            },
                            [id]: {
                              id,
                              title: t.name,
                              parentBoardId: activeId,
                              cards: newCards,
                              connections: [],
                              viewport: { x: 40, y: 30, zoom: 0.85 },
                            },
                          },
                        });
                        navigate(id);
                        setModal(null);
                      }}
                    >
                      <div className={`template-preview preview-${i}`}>
                        <i />
                        <i />
                        <i />
                        <i />
                      </div>
                      <strong>{t.name}</strong>
                      <span>{t.desc}</span>
                    </button>
                  ))}
                </div>
              </>
            )}
          </section>
        </div>
      )}
      {templatePickerOpen&&<>
        {templatePreview&&(()=>{const previewBoard=templatePreview.boards[templatePreviewBoard||templatePreview.rootBoardId]||templatePreview.boards[templatePreview.rootBoardId];const visible=previewBoard.cards.filter(card=>!card.unsorted&&(!card.parentId||!previewBoard.cards.find(owner=>owner.id===card.parentId)?.collapsed));const extent={width:Math.max(800,...visible.map(card=>card.x+card.width+40)),height:Math.max(500,...visible.map(card=>card.y+card.height+40))};const zoom=Math.min(1,(window.innerWidth-360)/extent.width,(window.innerHeight-160)/extent.height);return <div className="catalog-preview-stage" aria-label="Template preview" style={{background:previewBoard.background||'#ebedee'}}>
          <div className="catalog-preview-title">{previewBoard.title}{previewBoard.id!==templatePreview.rootBoardId&&<button onClick={()=>setTemplatePreviewBoard(templatePreview.rootBoardId)}>Back to template</button>}</div>
          <div className="catalog-preview-world" style={{transform:`translate(32px,48px) scale(${Math.max(.1,zoom)})`}}>{visible.map(card=><article key={card.id} data-template-preview-card={card.id} className={`card card-${card.type}`} style={{left:card.x,top:card.y,width:card.width,height:card.height,background:card.color,zIndex:card.type==='column'?0:card.z+1}} onDoubleClick={()=>{if(card.type==='board'&&templatePreview.boards[card.boardId])setTemplatePreviewBoard(card.boardId);}}><PresentationCard card={card} board={previewBoard} boards={templatePreview.boards}/></article>)}</div>
        </div>;})()}
        <Suspense fallback={<div className="template-library" role="status">Loading templates…</div>}><TemplateCatalogSession onClose={()=>{setTemplatePickerOpen(false);setTemplatePreview(undefined);}} onPreview={preview=>{setTemplatePreview(preview);setTemplatePreviewBoard(undefined);}} onChoose={apply=>{const result=apply(docRef.current,activeId,center());if(result.boardId){commit(result.workspace);navigate(result.boardId);}setTemplatePickerOpen(false);setTemplatePreview(undefined);}}/></Suspense>
      </>}
      <input
        ref={uploadRef}
        type="file"
        hidden
        multiple
        accept={uploadKind.current === "image" ? "image/*" : undefined}
        onChange={(e) => {
          loadFiles(e.target.files,uploadAt.current);
          uploadAt.current=undefined;
          e.target.value = "";
        }}
      />
      <input
        ref={importRef}
        type="file"
        hidden
        accept="application/json,.json"
        onChange={async (e) => {
          const input=e.target;
          const file = input.files?.[0];
          if (!file) return;
          const generation=++importGeneration.current;
          setToast("");
          try {
            finishNoteEdit();
            imageColorEpoch.current++;asyncMutationEpoch.current++;cancelLinkRequests();finishImageColorSampling(null);
            const next = migrateLegacyLabels(purgeExpiredTrash(await importWorkspace(await file.text())));
            if(generation!==importGeneration.current)return;
            formulaRegistry.current={workspaceId:next.id,snapshot:createFormulaWorkbook(next.boards[next.rootBoardId].cards.filter(card=>card.type==='table'))};
            clearBoardDrag(gesture.current);connectorDragCleanup.current?.();gesture.current=null;pointers.current.clear();lineEditBase.current=null;
            setLineId(null);setFrom(null);setTool('select');setEditing(null);setContext(null);setMarquee(null);setColumnDrop(null);setDraftPath([]);
            setTemplatePickerOpen(false);setTemplatePreview(undefined);setSyncedPopup(null);setDocumentLinkOpen(false);setSketchSession(null);setCutoutId(null);setImageEditorId(null);setPresenting(false);setImageLibraryOpen(false);setExportMenuOpen(false);setViewMenuOpen(false);setCardColorMenuOpen(false);setLabelsOpen(null);setTrashOpen(false);
            commit(markBoardViewed(next,next.rootBoardId),undefined,{preserveActivity:true});
            setStorageBlocked(false);
            boardNavigation.current={past:[],future:[]};
            setBoardId(next.rootBoardId);
            window.history.replaceState(null,'',boardLocalUrl(next.rootBoardId));
            setSelected([]);
            setModal(null);
            setViewport(next.boards[next.rootBoardId].viewport);
            notify(
              "Workspace imported. Undo to return to your previous workspace.",
            );
          } catch (err) {
            if(generation===importGeneration.current)notify(
              err instanceof Error ? err.message : "Invalid workspace file",
            );
          } finally {
            if(generation===importGeneration.current)input.value="";
          }
        }}
      />
    </div>
  );
}
function safeImageSrc(value:string){return /^(?:data:image\/[a-z0-9.+-]+;base64,|\/(?!\/))/i.test(value)?value:safeUrl(value);}
function safeUrl(value: string) {
  try {
    const u = new URL(value);
    return ["https:", "http:"].includes(u.protocol) ? u.href : "#";
  } catch {
    return "#";
  }
}
function slug(value: string) {
  return (
    value.replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-|-$/g, "") || "board"
  );
}

function columnTarget(board: Board, roots: Card[], moving: string[]) {
  const first = roots.find((c) => c.type !== "column");
  if (!first) return undefined;
  return board.cards
    .filter(
      (c) =>
        c.type === "column" &&
        !c.collapsed &&
        !c.locked &&
        !c.unsorted &&
        !moving.includes(c.id) &&
        first.x + first.width / 2 > c.x &&
        first.x + first.width / 2 < c.x + c.width &&
        first.y + first.height / 2 > c.y + 38 &&
        first.y < c.y + c.height,
    )
    .sort((a, b) => b.z - a.z)[0];
}

function appendCardsAt(board: Board, items: Card[], at: Point): Board {
  const next = { ...board, cards: [...board.cards, ...items] };
  const container = board.cards
    .filter(
      (c) =>
        c.type === "column" &&
        !c.collapsed &&
        !c.locked &&
        !c.unsorted &&
        at.x > c.x &&
        at.x < c.x + c.width &&
        at.y > c.y + 38 &&
        at.y < c.y + c.height,
    )
    .sort((a, b) => b.z - a.z)[0];
  if (!container) return next;
  const index = columnChildren(board, container.id).filter(
    (c) => c.y + c.height / 2 < at.y,
  ).length;
  return placeInColumn(
    next,
    items.filter((c) => c.type !== "column").map((c) => c.id),
    container.id,
    index,
  );
}
