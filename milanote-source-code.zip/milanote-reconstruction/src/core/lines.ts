import type { Card, Connection, Point } from "./model";

export type EditableConnection = Connection & { start?: Point; end?: Point; control?: Point; fromAnchor?: Point; toAnchor?: Point };
export interface ConnectionGeometry {
  path: string;
  start: Point;
  end: Point;
  midpoint: Point;
  startTangent: Point;
  endTangent: Point;
  kind: "straight" | "quadratic" | "cubic";
  control?: Point;
  controls?: [Point, Point];
}
const finitePoint = (point: Point | undefined): point is Point => !!point && Number.isFinite(point.x) && Number.isFinite(point.y);
const middle = (a: Point, b: Point): Point => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
const vector = (a: Point, b: Point): Point => ({ x: b.x - a.x, y: b.y - a.y });
const tangent = (a: Point, b: Point, fallback: Point): Point => { const value = vector(a, b); return Math.hypot(value.x, value.y) > 1e-10 ? value : fallback; };
const cardHeight = (card: Card) => card.type === "column" && card.collapsed ? 62.2 : card.height;
const cardCenter = (card: Card): Point => ({ x: card.x + card.width / 2, y: card.y + cardHeight(card) / 2 });
const cardAnchor = (card: Card, other: Point): Point => ({ x: card.x + (other.x < cardCenter(card).x ? 0 : card.width), y: card.y + cardHeight(card) / 2 });
const normalizedAnchor = (point: Point | undefined): point is Point => finitePoint(point) && point.x >= 0 && point.x <= 1 && point.y >= 0 && point.y <= 1;
const anchoredPoint = (card: Card, anchor: Point): Point => ({ x: card.x + card.width * anchor.x, y: card.y + cardHeight(card) * anchor.y });

/** Shift locks to the nearest horizontal or vertical axis through the opposite end. */
export function constrainConnectionPoint(origin: Point, point: Point): Point {
  return Math.abs(point.x - origin.x) >= Math.abs(point.y - origin.y)
    ? { x: point.x, y: origin.y } : { x: origin.x, y: point.y };
}

/** Select the topmost visible card under a dragged endpoint; a column sits behind its members. */
export function connectionTargetAt(point: Point, cards: Card[], excludedId?: string): Card | undefined {
  return cards.filter(card => card.id !== excludedId && point.x >= card.x && point.x <= card.x + card.width && point.y >= card.y && point.y <= card.y + cardHeight(card))
    .sort((a, b) => Number(a.type !== "column") - Number(b.type !== "column") || a.z - b.z).at(-1);
}

export function connectionAnchorAt(card: Card, point: Point): Point {
  return { x: Math.max(0, Math.min(1, (point.x - card.x) / card.width)), y: Math.max(0, Math.min(1, (point.y - card.y) / cardHeight(card))) };
}

/** A normal drop attaches to a side; holding still supplies a stable proportional point. */
export function attachConnectionHandle(connection: EditableConnection, handle: "start" | "end", card: Card, anchor?: Point): EditableConnection {
  if (handle === "start") return { ...connection, from: card.id, start: undefined, fromAnchor: normalizedAnchor(anchor) ? { ...anchor } : undefined };
  return { ...connection, to: card.id, end: undefined, toAnchor: normalizedAnchor(anchor) ? { ...anchor } : undefined };
}

export function straightenConnection(connection: EditableConnection): EditableConnection {
  return { ...connection, control: undefined, bend: 0 };
}

/** Attached legacy connectors retain their original horizontal-side cubic routing. */
export function connectionGeometry(connection: EditableConnection, cards: Card[]): ConnectionGeometry | null {
  const from = connection.from ? cards.find(card => card.id === connection.from) : undefined;
  const to = connection.to ? cards.find(card => card.id === connection.to) : undefined;
  if ((connection.from && !from) || (connection.to && !to)) return null;
  if ((!from && !finitePoint(connection.start)) || (!to && !finitePoint(connection.end))) return null;
  let start: Point, end: Point;
  if (from && to) {
    const reverse = to.x < from.x;
    start = { x: from.x + (reverse ? 0 : from.width), y: from.y + cardHeight(from) / 2 };
    end = { x: to.x + (reverse ? to.width : 0), y: to.y + cardHeight(to) / 2 };
  } else {
    start = from ? cardAnchor(from, to ? cardCenter(to) : connection.end!) : { ...connection.start! };
    end = to ? cardAnchor(to, start) : { ...connection.end! };
  }
  if (from && normalizedAnchor(connection.fromAnchor)) start = anchoredPoint(from, connection.fromAnchor);
  if (to && normalizedAnchor(connection.toAnchor)) end = anchoredPoint(to, connection.toAnchor);
  if (!finitePoint(start) || !finitePoint(end)) return null;
  const legacyAttached = from && to && !normalizedAnchor(connection.fromAnchor) && !normalizedAnchor(connection.toAnchor);
  let control = finitePoint(connection.control) ? { ...connection.control } : undefined;
  if (!control && !legacyAttached && connection.bend) {
    const dx = end.x - start.x, dy = end.y - start.y, length = Math.hypot(dx, dy) || 1;
    const midpoint = middle(start, end);
    control = { x: midpoint.x - dy / length * connection.bend * 2, y: midpoint.y + dx / length * connection.bend * 2 };
  }
  if (control) {
    const midpoint = { x: (start.x + 2 * control.x + end.x) / 4, y: (start.y + 2 * control.y + end.y) / 4 };
    return { kind: "quadratic", start, end, control, midpoint, path: `M ${start.x} ${start.y} Q ${control.x} ${control.y}, ${end.x} ${end.y}`, startTangent: tangent(start, control, vector(start, end)), endTangent: tangent(control, end, vector(start, end)) };
  }
  if (legacyAttached) {
    const reverse = to.x < from.x;
    const bend = connection.bend ?? Math.max(45, Math.abs(end.x - start.x) * 0.45);
    const first = { x: start.x + (reverse ? -bend : bend), y: start.y };
    const second = { x: end.x + (reverse ? bend : -bend), y: end.y };
    return { kind: "cubic", start, end, controls: [first, second], midpoint: middle(start, end), path: `M ${start.x} ${start.y} C ${first.x} ${first.y}, ${second.x} ${second.y}, ${end.x} ${end.y}`, startTangent: tangent(start, first, vector(start, end)), endTangent: tangent(second, end, vector(start, end)) };
  }
  return { kind: "straight", start, end, midpoint: middle(start, end), path: `M ${start.x} ${start.y} L ${end.x} ${end.y}`, startTangent: vector(start, end), endTangent: vector(start, end) };
}

export function quadraticControlForMidpoint(start: Point, end: Point, midpoint: Point): Point {
  return { x: midpoint.x * 2 - (start.x + end.x) / 2, y: midpoint.y * 2 - (start.y + end.y) / 2 };
}

/** Detach only the endpoint explicitly dragged; keep the other card attachment. */
export function moveConnectionHandle(connection: EditableConnection, cards: Card[], handle: "start" | "end" | "control", point: Point): EditableConnection {
  if (!finitePoint(point)) return connection;
  const geometry = connectionGeometry(connection, cards);
  if (!geometry) return connection;
  if (handle === "control") return { ...connection, control: quadraticControlForMidpoint(geometry.start, geometry.end, point) };
  if (handle === "start") return { ...connection, from: "", fromAnchor: undefined, start: { ...point } };
  return { ...connection, to: "", toAnchor: undefined, end: { ...point } };
}

export function pointOnConnection(geometry: ConnectionGeometry, t: number): Point {
  const s = geometry.start, e = geometry.end, u = 1 - t;
  if (geometry.kind === "quadratic" && geometry.control) {
    const c = geometry.control;
    return { x: u * u * s.x + 2 * u * t * c.x + t * t * e.x, y: u * u * s.y + 2 * u * t * c.y + t * t * e.y };
  }
  if (geometry.kind === "cubic" && geometry.controls) {
    const [a, b] = geometry.controls;
    return { x: u ** 3 * s.x + 3 * u * u * t * a.x + 3 * u * t * t * b.x + t ** 3 * e.x, y: u ** 3 * s.y + 3 * u * u * t * a.y + 3 * u * t * t * b.y + t ** 3 * e.y };
  }
  return { x: s.x + (e.x - s.x) * t, y: s.y + (e.y - s.y) * t };
}

/** Bounds include real curve extrema rather than only endpoints. Padding is for stroke/caps. */
export function connectionBounds(connection: EditableConnection, cards: Card[], padding = 0): { x: number; y: number; width: number; height: number } | null {
  const geometry = connectionGeometry(connection, cards);
  if (!geometry) return null;
  const roots: number[] = [0, 1];
  for (const axis of ["x", "y"] as const) {
    const start = geometry.start[axis], end = geometry.end[axis];
    if (geometry.kind === "quadratic" && geometry.control) {
      const control = geometry.control[axis], denominator = start - 2 * control + end;
      if (Math.abs(denominator) > 1e-10) roots.push((start - control) / denominator);
    } else if (geometry.kind === "cubic" && geometry.controls) {
      const [first, second] = geometry.controls.map(point => point[axis]);
      const a = -start + 3 * first - 3 * second + end, b = 2 * (start - 2 * first + second), c = first - start;
      if (Math.abs(a) < 1e-10) { if (Math.abs(b) > 1e-10) roots.push(-c / b); }
      else {
        const discriminant = b * b - 4 * a * c;
        if (discriminant >= 0) { roots.push((-b + Math.sqrt(discriminant)) / (2 * a)); roots.push((-b - Math.sqrt(discriminant)) / (2 * a)); }
      }
    }
  }
  const points = roots.filter(t => t >= 0 && t <= 1).map(t => pointOnConnection(geometry, t));
  const x = Math.min(...points.map(point => point.x)), y = Math.min(...points.map(point => point.y));
  return { x: x - padding, y: y - padding, width: Math.max(...points.map(point => point.x)) - x + padding * 2, height: Math.max(...points.map(point => point.y)) - y + padding * 2 };
}
