import type { Point, SketchPath } from "./model";

export type ImageRotation = 0 | 90 | 180 | 270;
export interface ImageCrop {
  x: number;
  y: number;
  width: number;
  height: number;
}
/** Crop coordinates describe the image after rotation and visible-axis flips.
 * Paths stay in original source coordinates, with stroke widths relative to its
 * shortest side. Omitted flip flags are false for older saved documents. */
export interface ImageEdits {
  rotation: ImageRotation;
  flipX?: boolean;
  flipY?: boolean;
  crop: ImageCrop;
  paths: SketchPath[];
}
export interface ImageSize {
  width: number;
  height: number;
}

const MIN_CROP = 0.005;
const finite = (n: unknown): n is number => typeof n === "number" && Number.isFinite(n);
const record = (value: unknown): value is Record<string, unknown> =>
  !!value && typeof value === "object" && !Array.isArray(value);
const clamp = (n: number, min = 0, max = 1) => Math.max(min, Math.min(max, n));
const unit = (value: unknown): value is number => finite(value) && value >= 0 && value <= 1;
const color = (value: unknown): value is string =>
  typeof value === "string" && /^#[\da-f]{3}(?:[\da-f]{3})?$/i.test(value);

export function defaultImageEdits(): ImageEdits {
  return { rotation: 0, crop: { x: 0, y: 0, width: 1, height: 1 }, paths: [] };
}

export function isValidImageEdits(value: unknown): value is ImageEdits {
  if (!record(value) || ![0, 90, 180, 270].includes(value.rotation as number)) return false;
  if ((value.flipX !== undefined && typeof value.flipX !== "boolean") ||
    (value.flipY !== undefined && typeof value.flipY !== "boolean")) return false;
  const crop = value.crop;
  if (!record(crop) || !unit(crop.x) || !unit(crop.y) || !unit(crop.width) ||
    !unit(crop.height) || crop.width <= 0 || crop.height <= 0 ||
    crop.x + crop.width > 1 + 1e-9 || crop.y + crop.height > 1 + 1e-9) return false;
  return Array.isArray(value.paths) && value.paths.every((path) =>
    record(path) && color(path.color) && finite(path.width) && path.width > 0 &&
    path.width <= 1 && Array.isArray(path.points) && path.points.length > 0 &&
    path.points.every((point) => record(point) && unit(point.x) && unit(point.y)));
}

/** Makes rendering resilient to old or partially written local documents. */
export function normalizeImageEdits(value: unknown): ImageEdits {
  if (isValidImageEdits(value)) return {
    rotation: value.rotation,
    ...(value.flipX !== undefined ? { flipX: value.flipX } : {}),
    ...(value.flipY !== undefined ? { flipY: value.flipY } : {}),
    crop: { ...value.crop },
    paths: value.paths.map((path) => ({ ...path, points: path.points.map((point) => ({ ...point })) })),
  };
  const edits = defaultImageEdits();
  if (!record(value)) return edits;
  if ([0, 90, 180, 270].includes(value.rotation as number))
    edits.rotation = value.rotation as ImageRotation;
  if (typeof value.flipX === "boolean") edits.flipX = value.flipX;
  if (typeof value.flipY === "boolean") edits.flipY = value.flipY;
  if (record(value.crop)) {
    const crop = value.crop;
    const x = finite(crop.x) ? clamp(crop.x, 0, 1 - MIN_CROP) : 0;
    const y = finite(crop.y) ? clamp(crop.y, 0, 1 - MIN_CROP) : 0;
    edits.crop = {
      x,
      y,
      width: finite(crop.width) ? clamp(crop.width, MIN_CROP, 1 - x) : 1 - x,
      height: finite(crop.height) ? clamp(crop.height, MIN_CROP, 1 - y) : 1 - y,
    };
  }
  if (Array.isArray(value.paths)) {
    edits.paths = value.paths.flatMap((path) => {
      if (!record(path) || !color(path.color) || !finite(path.width) ||
        path.width <= 0 || !Array.isArray(path.points)) return [];
      const points = path.points.flatMap((point) => record(point) && finite(point.x) && finite(point.y)
        ? [{ x: clamp(point.x), y: clamp(point.y) }] : []);
      return points.length ? [{ color: path.color, width: Math.min(1, path.width), points }] : [];
    });
  }
  return edits;
}

export function hasImageEdits(value?: ImageEdits): boolean {
  if (!value) return false;
  const edits = normalizeImageEdits(value);
  return edits.rotation !== 0 || !!edits.flipX || !!edits.flipY || edits.paths.length > 0 ||
    Math.abs(edits.crop.x) > 1e-9 || Math.abs(edits.crop.y) > 1e-9 ||
    Math.abs(edits.crop.width - 1) > 1e-9 || Math.abs(edits.crop.height - 1) > 1e-9;
}

export function rotateNormalizedPoint(point: Point, rotation: ImageRotation): Point {
  switch (rotation) {
    case 90: return { x: 1 - point.y, y: point.x };
    case 180: return { x: 1 - point.x, y: 1 - point.y };
    case 270: return { x: point.y, y: 1 - point.x };
    default: return { ...point };
  }
}

export function unrotateNormalizedPoint(point: Point, rotation: ImageRotation): Point {
  return rotateNormalizedPoint(point, ((360 - rotation) % 360) as ImageRotation);
}

/** Maps an original source point into the complete visible image. */
export function transformImagePoint(point: Point, edits: ImageEdits): Point {
  const rotated = rotateNormalizedPoint(point, edits.rotation);
  return { x: edits.flipX ? 1 - rotated.x : rotated.x, y: edits.flipY ? 1 - rotated.y : rotated.y };
}

/** Maps pointer coordinates on the visible image back to the original source. */
export function inverseImagePoint(point: Point, edits: ImageEdits): Point {
  return unrotateNormalizedPoint({ x: edits.flipX ? 1 - point.x : point.x, y: edits.flipY ? 1 - point.y : point.y }, edits.rotation);
}

function segmentDistance(point: Point, start: Point, end: Point): number {
  const dx = end.x - start.x, dy = end.y - start.y;
  const t = dx || dy ? clamp(((point.x - start.x) * dx + (point.y - start.y) * dy) / (dx * dx + dy * dy)) : 0;
  return Math.hypot(point.x - start.x - t * dx, point.y - start.y - t * dy);
}

/** Hit-tests the topmost annotation in CSS pixels, independently of source
 * resolution, quarter-turn rotation, visible-axis flips or editor zoom. The
 * editor displays the complete image; crop coordinates do not change this map. */
export function hitTestImagePath(value: ImageEdits, point: Point, source: ImageSize, viewport: ImageSize, tolerance = 7): number | null {
  if (viewport.width <= 0 || viewport.height <= 0 || source.width <= 0 || source.height <= 0) return null;
  const target = { x: point.x * viewport.width, y: point.y * viewport.height };
  const rotated = rotatedImageSize(source.width, source.height, value.rotation);
  const scale = Math.min(viewport.width / rotated.width, viewport.height / rotated.height);
  for (let index = value.paths.length - 1; index >= 0; index--) {
    const path = value.paths[index];
    const radius = Math.max(0, tolerance) + path.width * Math.min(source.width, source.height) * scale / 2;
    const points = path.points.map(original => {
      const visible = transformImagePoint(original, value);
      return { x: visible.x * viewport.width, y: visible.y * viewport.height };
    });
    if (points.some((end, i) => segmentDistance(target, points[Math.max(0, i - 1)], end) <= radius)) return index;
  }
  return null;
}

/** Moves a selected group in original normalized source coordinates. Clamping
 * the shared delta keeps every point in bounds without distorting the strokes. */
export function translateImagePaths(value: ImageEdits, selected: readonly number[], delta: Point): ImageEdits {
  const edits = normalizeImageEdits(value), indices = new Set(selected);
  const points = edits.paths.flatMap((path, index) => indices.has(index) ? path.points : []);
  if (!points.length || !Number.isFinite(delta.x) || !Number.isFinite(delta.y)) return edits;
  const bounds = points.reduce((result, point) => ({ left: Math.min(result.left, point.x), right: Math.max(result.right, point.x),
    top: Math.min(result.top, point.y), bottom: Math.max(result.bottom, point.y) }), { left: 1, right: 0, top: 1, bottom: 0 });
  const dx = clamp(delta.x, -bounds.left, 1 - bounds.right);
  const dy = clamp(delta.y, -bounds.top, 1 - bounds.bottom);
  return { ...edits, paths: edits.paths.map((path, index) => indices.has(index)
    ? { ...path, points: path.points.map(point => ({ x: clamp(point.x + dx), y: clamp(point.y + dy) })) } : path) };
}

/** Bounding box of selected centerlines on the complete visible image. */
export function imagePathsBounds(value: ImageEdits, selected: readonly number[]): ImageCrop | null {
  const indices = new Set(selected);
  const points = value.paths.flatMap((path, index) => indices.has(index)
    ? path.points.map(point => transformImagePoint(point, value)) : []);
  if (!points.length) return null;
  const bounds = points.reduce((result, point) => ({ left: Math.min(result.left, point.x), right: Math.max(result.right, point.x),
    top: Math.min(result.top, point.y), bottom: Math.max(result.bottom, point.y) }), { left: 1, right: 0, top: 1, bottom: 0 });
  return { x: bounds.left, y: bounds.top, width: bounds.right - bounds.left, height: bounds.bottom - bounds.top };
}

export function flipImageEdits(value: ImageEdits, axis: "horizontal" | "vertical"): ImageEdits {
  const edits = normalizeImageEdits(value), crop = edits.crop;
  return axis === "horizontal"
    ? { ...edits, flipX: !edits.flipX, crop: { ...crop, x: clamp(1 - crop.x - crop.width) } }
    : { ...edits, flipY: !edits.flipY, crop: { ...crop, y: clamp(1 - crop.y - crop.height) } };
}

export function rotateImageEdits(value: ImageEdits, direction: 1 | -1): ImageEdits {
  const edits = normalizeImageEdits(value), crop = edits.crop;
  return {
    ...edits,
    rotation: ((edits.rotation + direction * 90 + 360) % 360) as ImageRotation,
    // The flags refer to visible axes. Swapping them rotates the entire current
    // picture, including any earlier reflection, rather than changing its axis.
    ...(edits.flipX !== undefined || edits.flipY !== undefined
      ? { flipX: !!edits.flipY, flipY: !!edits.flipX } : {}),
    crop: direction === 1
      ? { x: clamp(1 - crop.y - crop.height), y: crop.x, width: crop.height, height: crop.width }
      : { x: crop.y, y: clamp(1 - crop.x - crop.width), width: crop.height, height: crop.width },
  };
}

export function rotatedImageSize(width: number, height: number, rotation: ImageRotation): ImageSize {
  return rotation === 90 || rotation === 270 ? { width: height, height: width } : { width, height };
}

export function imageCropBounds(width: number, height: number, value?: ImageEdits): ImageCrop {
  const edits = normalizeImageEdits(value);
  const size = rotatedImageSize(width, height, edits.rotation);
  return { x: edits.crop.x * size.width, y: edits.crop.y * size.height,
    width: edits.crop.width * size.width, height: edits.crop.height * size.height };
}

export function imagePathToSvg(points: Point[]): string {
  if (!points.length) return "";
  const result = points.map((point, index) => `${index ? "L" : "M"} ${point.x} ${point.y}`).join(" ");
  return points.length === 1 ? `${result} L ${points[0].x} ${points[0].y}` : result;
}

export function imageRotationTransform(width: number, height: number, rotation: ImageRotation): string {
  switch (rotation) {
    case 90: return `translate(${height} 0) rotate(90)`;
    case 180: return `translate(${width} ${height}) rotate(180)`;
    case 270: return `translate(0 ${width}) rotate(270)`;
    default: return "";
  }
}

export function imageEditsTransform(width: number, height: number, edits: ImageEdits): string {
  const size = rotatedImageSize(width, height, edits.rotation);
  const reflection = edits.flipX || edits.flipY
    ? `translate(${edits.flipX ? size.width : 0} ${edits.flipY ? size.height : 0}) scale(${edits.flipX ? -1 : 1} ${edits.flipY ? -1 : 1}) ` : "";
  return `${reflection}${imageRotationTransform(width, height, edits.rotation)}`.trim();
}

function loadImage(src: string, forExport = false): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    if (forExport && /^https?:\/\//i.test(src)) image.crossOrigin = "anonymous";
    image.onload = () => image.naturalWidth && image.naturalHeight
      ? resolve(image) : reject(new Error("This image has no usable dimensions."));
    image.onerror = () => reject(new Error("The image could not be loaded. Try uploading it again."));
    image.src = src;
  });
}

export async function loadImageDimensions(src: string): Promise<ImageSize> {
  const image = await loadImage(src);
  return { width: image.naturalWidth, height: image.naturalHeight };
}

/** Produces a portable PNG of exactly the same crop, rotation and annotations
 * shown by ImagePreview. The source and editable history remain untouched. */
export async function bakeImageEdits(src: string, value?: ImageEdits): Promise<string> {
  if (!hasImageEdits(value)) return src;
  const image = await loadImage(src, true), edits = normalizeImageEdits(value);
  const width = image.naturalWidth, height = image.naturalHeight;
  const crop = imageCropBounds(width, height, edits);
  const scale = Math.min(1, 8192 / Math.max(crop.width, crop.height), Math.sqrt(32000000 / (crop.width * crop.height)));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(crop.width * scale));
  canvas.height = Math.max(1, Math.round(crop.height * scale));
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Your browser could not prepare the edited image.");
  ctx.scale(canvas.width / crop.width, canvas.height / crop.height);
  ctx.translate(-crop.x, -crop.y);
  const rotated = rotatedImageSize(width, height, edits.rotation);
  ctx.translate(edits.flipX ? rotated.width : 0, edits.flipY ? rotated.height : 0);
  ctx.scale(edits.flipX ? -1 : 1, edits.flipY ? -1 : 1);
  if (edits.rotation === 90) ctx.translate(height, 0);
  else if (edits.rotation === 180) ctx.translate(width, height);
  else if (edits.rotation === 270) ctx.translate(0, width);
  ctx.rotate(edits.rotation * Math.PI / 180);
  ctx.drawImage(image, 0, 0);
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  for (const path of edits.paths) {
    ctx.beginPath();
    ctx.strokeStyle = path.color;
    ctx.fillStyle = path.color;
    ctx.lineWidth = path.width * Math.min(width, height);
    path.points.forEach((point, index) => {
      const x = point.x * width, y = point.y * height;
      if (index === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    if (path.points.length === 1) {
      const point = path.points[0];
      ctx.arc(point.x * width, point.y * height, ctx.lineWidth / 2, 0, Math.PI * 2);
      ctx.fill();
    } else ctx.stroke();
  }
  try { return canvas.toDataURL("image/png"); }
  catch { throw new Error("This image server blocks image export. Upload a copy of the image to export your edits."); }
}
