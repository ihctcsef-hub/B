/** Link-image geometry measured independently in the reference UI. The first
 * image is framed by an eight-pixel envelope with a two-pixel inset, so its
 * visible height is not always the image's mathematically exact aspect ratio.
 * Width is a logical CSS width (before canvas zoom), not a screen rectangle. */
export function linkPreviewHeight(width:number,naturalWidth:number,naturalHeight:number):number {
  if(![width,naturalWidth,naturalHeight].every(value=>Number.isFinite(value)&&value>0))throw new Error('Link preview dimensions must be finite and positive.');
  const height=width*naturalHeight/naturalWidth;
  if(!Number.isFinite(height))throw new Error('The link preview ratio is too large.');
  return Math.max(6,Math.round(height/8)*8-2);
}
