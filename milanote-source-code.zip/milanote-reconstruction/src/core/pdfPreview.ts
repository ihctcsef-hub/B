/// <reference types="vite/client" />
import workerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';

export interface PdfThumbnail {
  /** Original first-page viewport, including the PDF's page rotation. */
  width:number;
  height:number;
  pageCount:number;
  imageDataUrl:string;
  /** SHA-256 of the original PDF bytes, never of an identifier or file name. */
  sourceDigest:string;
}

export const MAX_PDF_PREVIEW_BYTES=15*1024*1024;
const aborted=()=>new DOMException('The preview was cancelled.','AbortError');
const checkAbort=(signal?:AbortSignal)=>{if(signal?.aborted)throw aborted();};
/** Local attachments only. Embedded links/actions are never opened by previewing. */
export function decodePdfAttachment(source:string):Uint8Array {
  const match=/^data:(?:application\/pdf|application\/octet-stream);base64,([a-z\d+/=\s]+)$/i.exec(source);
  if(!match)throw new Error('The PDF attachment could not be read.');
  const encoded=match[1].replace(/\s/g,'');
  if(!encoded.length||encoded.length>Math.ceil(MAX_PDF_PREVIEW_BYTES/3)*4)throw new Error('The PDF attachment exceeds the preview size limit.');
  let binary:string;try{binary=atob(encoded);}catch{throw new Error('The PDF attachment could not be read.');}
  if(binary.length>MAX_PDF_PREVIEW_BYTES)throw new Error('The PDF attachment exceeds the preview size limit.');
  return Uint8Array.from(binary,char=>char.charCodeAt(0));
}
/** Public template attachments can retain their original HTTP(S) URL. Browser
 * CORS rules still apply. Neither cookies nor application credentials are sent. */
export async function readPdfAttachment(source:string,signal?:AbortSignal):Promise<Uint8Array>{
  checkAbort(signal);
  if(source.startsWith('data:'))return decodePdfAttachment(source);
  let url:URL;try{url=new URL(source);}catch{throw new Error('The PDF attachment could not be read.');}
  if(!['http:','https:'].includes(url.protocol)||url.username||url.password)throw new Error('The PDF attachment could not be read.');
  const response=await fetch(url.href,{signal,credentials:'omit',referrerPolicy:'no-referrer'});
  if(!response.ok)throw new Error('The PDF attachment could not be read.');
  const declared=Number(response.headers.get('content-length'));
  if(declared>MAX_PDF_PREVIEW_BYTES){await response.body?.cancel();throw new Error('The PDF attachment exceeds the preview size limit.');}
  const reader=response.body?.getReader();
  if(!reader){const bytes=new Uint8Array(await response.arrayBuffer());if(bytes.byteLength>MAX_PDF_PREVIEW_BYTES)throw new Error('The PDF attachment exceeds the preview size limit.');checkAbort(signal);return bytes;}
  const chunks:Uint8Array[]=[];let length=0;
  try{
    for(;;){checkAbort(signal);const {done,value}=await reader.read();if(done)break;length+=value.byteLength;if(length>MAX_PDF_PREVIEW_BYTES){await reader.cancel();throw new Error('The PDF attachment exceeds the preview size limit.');}chunks.push(value);}
    checkAbort(signal);const result=new Uint8Array(length);let at=0;for(const chunk of chunks){result.set(chunk,at);at+=chunk.length;}return result;
  }finally{reader.releaseLock();}
}
/** WebCrypto requires a secure context. The bundled implementation provides the
 * same digest when this standalone app is opened from an HTTP LAN address. */
export async function pdfBytesDigest(data:Uint8Array):Promise<string>{
  if(globalThis.crypto?.subtle){
    const digest=await globalThis.crypto.subtle.digest('SHA-256',new Uint8Array(data).buffer);
    return Array.from(new Uint8Array(digest),value=>value.toString(16).padStart(2,'0')).join('');
  }
  const {default:hashes}=await import('hash.js');return hashes.sha256().update(data).digest('hex');
}
export async function pdfAttachmentDigest(source:string,options:{signal?:AbortSignal}={}):Promise<string>{
  const data=await readPdfAttachment(source,options.signal);const digest=await pdfBytesDigest(data);checkAbort(options.signal);return digest;
}
let renderer:Promise<typeof import('pdfjs-dist')>|undefined;
async function pdfRenderer(){
  if(!renderer){renderer=import('pdfjs-dist').then(pdfjs=>{pdfjs.GlobalWorkerOptions.workerSrc=workerUrl;return pdfjs;});renderer.catch(()=>{renderer=undefined;});}
  return renderer;
}
function validCachedThumbnail(cache:PdfThumbnail|undefined,digest:string):cache is PdfThumbnail{
  return !!cache&&cache.sourceDigest===digest&&/^data:image\/png;base64,[a-z\d+/=]+$/i.test(cache.imageDataUrl)&&[cache.width,cache.height,cache.pageCount].every(value=>Number.isFinite(value)&&value>0)&&Number.isInteger(cache.pageCount);
}
/** A cache is accepted only after its original bytes have been fingerprinted.
 * File name, card ID, and stale object identity are never cache keys. */
export async function loadPdfThumbnail(source:string,options:{signal?:AbortSignal;cachedThumbnail?:PdfThumbnail}={}):Promise<{thumbnail:PdfThumbnail;fromCache:boolean}>{
  const controller=new AbortController(),signal=controller.signal;
  const abort=()=>controller.abort();options.signal?.addEventListener('abort',abort,{once:true});if(options.signal?.aborted)controller.abort();
  let timedOut=false;const timer=setTimeout(()=>{timedOut=true;controller.abort();},20000);
  let destroy:(()=>Promise<void>)|undefined;
  try{
    const data=await readPdfAttachment(source,signal);checkAbort(signal);
    // PDF.js transfers/detaches data. Hashing must finish before getDocument.
    const sourceDigest=await pdfBytesDigest(data);checkAbort(signal);
    if(validCachedThumbnail(options.cachedThumbnail,sourceDigest))return {thumbnail:options.cachedThumbnail,fromCache:true};
    const pdfjs=await pdfRenderer();checkAbort(signal);const root=import.meta.env.BASE_URL||'/';
    const task=pdfjs.getDocument({data,standardFontDataUrl:`${root}pdfjs/standard_fonts/`,cMapUrl:`${root}pdfjs/cmaps/`,cMapPacked:true,wasmUrl:`${root}pdfjs/wasm/`,isEvalSupported:false,useSystemFonts:false,disableFontFace:true,isOffscreenCanvasSupported:false,isImageDecoderSupported:false});
    destroy=()=>task.destroy();let painting:ReturnType<import('pdfjs-dist').PDFPageProxy['render']>|undefined;
    const cancel=()=>{painting?.cancel();void task.destroy().catch(()=>{});};signal.addEventListener('abort',cancel,{once:true});
    try{
      const pdf=await task.promise;checkAbort(signal);
      const page=await pdf.getPage(1),original=page.getViewport({scale:1});
      if(!Number.isFinite(original.width)||!Number.isFinite(original.height)||original.width<=0||original.height<=0)throw new Error('The first PDF page could not be measured.');
      const scale=Math.min(2,720/original.width,1000/original.height,Math.sqrt(1_000_000/(original.width*original.height))),viewport=page.getViewport({scale});
      const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.ceil(viewport.width));canvas.height=Math.max(1,Math.ceil(viewport.height));
      try{
        const context=canvas.getContext('2d');if(!context)throw new Error('The PDF preview renderer is unavailable.');checkAbort(signal);
        const renderTask=page.render({canvas,canvasContext:context,viewport,background:'rgb(255,255,255)'});painting=renderTask;await renderTask.promise;checkAbort(signal);
        return {thumbnail:{width:original.width,height:original.height,pageCount:pdf.numPages,imageDataUrl:canvas.toDataURL('image/png'),sourceDigest},fromCache:false};
      }finally{canvas.width=canvas.height=0;page.cleanup();}
    }finally{signal.removeEventListener('abort',cancel);}
  }catch(error){
    if(timedOut&&!options.signal?.aborted)throw new Error('The PDF preview took too long.');
    if(signal.aborted)throw aborted();throw error instanceof Error?error:new Error('The PDF preview could not be generated.');
  }finally{clearTimeout(timer);options.signal?.removeEventListener('abort',abort);await destroy?.().catch(()=>{});}
}
/** Render just the first page. All support assets are bundled locally; the
 * original document is never uploaded to an external conversion service. */
export async function renderPdfThumbnail(source:string,options:{signal?:AbortSignal}={}):Promise<PdfThumbnail>{
  return (await loadPdfThumbnail(source,options)).thumbnail;
}
