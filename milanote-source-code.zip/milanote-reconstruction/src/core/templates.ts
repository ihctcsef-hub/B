import { copyCardsToBoard, uid } from './model';
import type { Workspace, Board } from './model';
import { isBoardShortcut } from './shortcuts';
import { trashCards } from './trash';

/** Snapshot content and descendant boards; later edits cannot change the template. */
export function saveBoardTemplate(workspace: Workspace, boardId: string): Workspace {
  const source = workspace.boards[boardId];
  if (!source) return workspace;
  const id = uid();
  const empty: Board = { ...structuredClone(source), id, title: `${source.title} template`, parentBoardId: undefined, isTemplate: true, cards: [], connections: [] };
  const target = { ...workspace, boards: { ...workspace.boards, [id]: empty } };
  const result=copyCardsToBoard(workspace, boardId, source.cards.map(card => card.id), target, id, { x: 0, y: 0 }).workspace;
  result.boards[id]={...result.boards[id],connections:[...result.boards[id].connections,...source.connections.filter(line=>!line.from&&!line.to).map(line=>({...structuredClone(line),id:uid()}))]};
  for(const [boardId, board] of Object.entries(result.boards)) if(boardId===id || !workspace.boards[boardId]) result.boards[boardId]={...board,cards:board.cards.map(card=>card.type==='note'?{...card,syncedId:undefined}:card)};
  return result;
}

export function instantiateBoardTemplate(workspace: Workspace, templateId: string, parentId: string, x: number, y: number): { workspace: Workspace; boardId?: string } {
  const template = workspace.boards[templateId];
  if (!template?.isTemplate || !workspace.boards[parentId]) return { workspace };
  const id = uid(), cardId = uid();
  const title = template.parentBoardId === undefined ? template.title.replace(/ template$/, '') : template.title;
  const board: Board = { ...structuredClone(template), id, title, isTemplate: undefined, parentBoardId: parentId, cards: [], connections: [] };
  const target = { ...workspace, boards: { ...workspace.boards, [id]: board, [parentId]: { ...workspace.boards[parentId], cards: [...workspace.boards[parentId].cards, { id: cardId, type: 'board' as const, boardId: id, title, x, y, width: 160, height: 160, z: Date.now() }] } } };
  const result=copyCardsToBoard(workspace, templateId, template.cards.map(card => card.id), target, id, { x: 0, y: 0 }).workspace;
  result.boards[id]={...result.boards[id],connections:[...result.boards[id].connections,...template.connections.filter(line=>!line.from&&!line.to).map(line=>({...structuredClone(line),id:uid()}))]};
  return {workspace:result,boardId:id};
}

/** Converting a board marks the original editable content; it does not create a detached snapshot. */
export function convertBoardToTemplate(workspace: Workspace, boardId: string): Workspace {
  const board = workspace.boards[boardId];
  if (!board || boardId === workspace.rootBoardId || board.isTemplate) return workspace;
  return { ...workspace, updatedAt: new Date().toISOString(), boards: { ...workspace.boards, [boardId]: { ...board, isTemplate: true } } };
}

/** Remove the template badge/library entry while keeping its content and owning tile. */
export function revertTemplateToBoard(workspace: Workspace, boardId: string): Workspace {
  const board = workspace.boards[boardId];
  if (!board?.isTemplate) return workspace;
  const owner = Object.values(workspace.boards).find(candidate => candidate.cards.some(card => card.type === 'board' && !isBoardShortcut(card) && card.boardId === boardId));
  if (owner) return { ...workspace, updatedAt: new Date().toISOString(), boards: { ...workspace.boards, [boardId]: { ...board, isTemplate: undefined } } };
  // Earlier versions stored private snapshots without a tile. Reverting gives that content a Home tile.
  const root = workspace.boards[workspace.rootBoardId];
  const tile = { id: uid(), type: 'board' as const, boardId, title: board.title, x: 40, y: 40, width: 160, height: 160, z: Date.now() };
  return { ...workspace, updatedAt: new Date().toISOString(), boards: { ...workspace.boards,
    [boardId]: { ...board, isTemplate: undefined, parentBoardId: root.id },
    [root.id]: { ...root, cards: [...root.cards, tile] } } };
}

export function renameBoardTemplate(workspace: Workspace, boardId: string, title: string): Workspace {
  const board = workspace.boards[boardId];
  if (!board?.isTemplate || typeof title !== 'string') return workspace;
  const name = title.trim() || 'Untitled template';
  if (board.title === name) return workspace;
  const boards = Object.fromEntries(Object.entries(workspace.boards).map(([id, board]) => [id, {
    ...board, ...(id === boardId ? { title: name } : {}),
    cards: board.cards.map(card => card.type === 'board' && card.boardId === boardId ? { ...card, title: name } : card),
  }]));
  return { ...workspace, boards, updatedAt: new Date().toISOString() };
}

/** Deleting the entire template follows the same recoverable deletion path as any board. */
export function deleteBoardTemplate(workspace: Workspace, boardId: string): Workspace {
  if (!workspace.boards[boardId]?.isTemplate || boardId === workspace.rootBoardId) return workspace;
  const owner = Object.values(workspace.boards).find(board => board.cards.some(card => card.type === 'board' && !isBoardShortcut(card) && card.boardId === boardId));
  if (owner) {
    const ids = owner.cards.filter(card => card.type === 'board' && !isBoardShortcut(card) && card.boardId === boardId).map(card => card.id);
    return trashCards(workspace, owner.id, ids);
  }
  const attached = revertTemplateToBoard(workspace, boardId), root = attached.boards[attached.rootBoardId];
  const tile = root.cards.find(card => card.type === 'board' && !isBoardShortcut(card) && card.boardId === boardId);
  return tile ? trashCards(attached, root.id, [tile.id]) : workspace;
}
