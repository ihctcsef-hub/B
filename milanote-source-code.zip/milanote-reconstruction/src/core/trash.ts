import { uid } from './model';
import type { Board, Card, Connection, Point, Workspace } from './model';
import { arrangeAllColumns, expandSelection } from './columns';
import { isBoardShortcut, ownedBoardDescendants } from './shortcuts';
import { connectionBounds } from './lines';
import { restoredSyncedNote } from './notes';

export interface TrashEntry {
  id: string;
  deletedAt: string;
  sourceBoardId: string;
  sourceBoardTitle: string;
  rootIds: string[];
  cards: Card[];
  connections: Connection[];
  boards: Record<string, Board>;
}
export type TrashWorkspace = Workspace & { trash?: TrashEntry[] };
export interface RestoreTrashOptions { targetBoardId?: string; at?: Point }
const stamp = (date: Date | string | number) => new Date(date).toISOString();
const record = (value: unknown): value is Record<string, unknown> => !!value && typeof value === 'object' && !Array.isArray(value);

/** Calendar-month retention matches the documented three months (not a fixed 90 days). */
export function trashEntryExpiresAt(entry: Pick<TrashEntry, 'deletedAt'>): string {
  const date = new Date(entry.deletedAt);
  if (!Number.isFinite(date.getTime())) return new Date(0).toISOString();
  const year = date.getUTCFullYear(), month = date.getUTCMonth() + 3;
  const lastDay = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
  return new Date(Date.UTC(year, month, Math.min(date.getUTCDate(), lastDay), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds(), date.getUTCMilliseconds())).toISOString();
}
export function purgeExpiredTrash(workspace: TrashWorkspace, now: Date | string | number = Date.now()): TrashWorkspace {
  if (!workspace.trash?.length) return workspace;
  const time = new Date(now).getTime();
  const trash = workspace.trash.filter(entry => new Date(trashEntryExpiresAt(entry)).getTime() > time);
  return trash.length === workspace.trash.length ? workspace : { ...workspace, trash };
}

export function trashCards(workspace: TrashWorkspace, boardId: string, ids: string[], now: Date | string | number = Date.now()): TrashWorkspace {
  const board = workspace.boards[boardId];
  if (!board) return workspace;
  const selected = new Set(expandSelection(board, ids));
  const cards = board.cards.filter(card => selected.has(card.id));
  if (!cards.length) return workspace;
  const removedBoards = ownedBoardDescendants(workspace, cards.flatMap(card => card.type === 'board' && !isBoardShortcut(card) ? [card.boardId] : []));
  // Invalid imported ownership must never let deleting a tile delete the current or Home board.
  if (removedBoards.has(boardId) || removedBoards.has(workspace.rootBoardId)) return workspace;
  const deletedAt = stamp(now);
  const entry: TrashEntry = { id: uid(), deletedAt, sourceBoardId: boardId, sourceBoardTitle: board.title,
    rootIds: cards.filter(card => !card.parentId || !selected.has(card.parentId)).map(card => card.id),
    cards: structuredClone(cards),
    connections: structuredClone(board.connections.filter(line => selected.has(line.from) || selected.has(line.to))),
    boards: Object.fromEntries([...removedBoards].map(id => [id, structuredClone(workspace.boards[id])])),
  };
  const nextBoard = arrangeAllColumns({ ...board, cards: board.cards.filter(card => !selected.has(card.id)),
    connections: board.connections.filter(line => !selected.has(line.from) && !selected.has(line.to)) });
  const boards = Object.fromEntries(Object.entries(workspace.boards).filter(([id]) => !removedBoards.has(id)));
  boards[boardId] = nextBoard;
  const existing = purgeExpiredTrash(workspace, now).trash || [];
  return { ...workspace, boards, trash: [entry, ...existing], updatedAt: deletedAt };
}

export function trashConnections(workspace: TrashWorkspace, boardId: string, ids: string[], now: Date | string | number = Date.now()): TrashWorkspace {
  const board = workspace.boards[boardId], selected = new Set(ids);
  if (!board) return workspace;
  const connections = board.connections.filter(line => selected.has(line.id));
  if (!connections.length) return workspace;
  const deletedAt = stamp(now);
  const entry: TrashEntry = { id: uid(), deletedAt, sourceBoardId: boardId, sourceBoardTitle: board.title,
    rootIds: [], cards: [], connections: structuredClone(connections), boards: {} };
  return { ...workspace, updatedAt: deletedAt,
    boards: { ...workspace.boards, [boardId]: { ...board, connections: board.connections.filter(line => !selected.has(line.id)) } },
    trash: [entry, ...(purgeExpiredTrash(workspace, now).trash || [])] };
}

function cleanLabels(workspace: Workspace, card: Card): Card {
  const registry = (workspace as Workspace & { labels?: Array<{ id: string; name: string }> }).labels;
  const labelIds = (card as Card & { labelIds?: string[] }).labelIds;
  if (!registry || !labelIds) return card;
  const ids = labelIds.filter(id => registry.some(label => label.id === id));
  return { ...card, labelIds: ids, tags: ids.map(id => registry.find(label => label.id === id)!.name) } as Card;
}
const freeEndpoint = (line: Connection, end: 'from' | 'to') => end === 'from' ? !!line.start : !!line.end;
function uniqueId(used: Set<string>): string { let id = uid(); while (used.has(id)) id = uid(); used.add(id); return id; }

/** Restore into the original board, or Home if that board no longer exists. */
export function restoreTrashEntry(workspace: TrashWorkspace, entryId: string, options: RestoreTrashOptions = {}, now: Date | string | number = Date.now()): TrashWorkspace {
  const entry = workspace.trash?.find(entry => entry.id === entryId);
  if (!entry || new Date(trashEntryExpiresAt(entry)).getTime() <= new Date(now).getTime()) return workspace;
  const targetId = options.targetBoardId || (workspace.boards[entry.sourceBoardId] ? entry.sourceBoardId : workspace.rootBoardId);
  const target = workspace.boards[targetId];
  if (!target || (options.at && (!Number.isFinite(options.at.x) || !Number.isFinite(options.at.y)))) return workspace;
  const usedBoardIds = new Set(Object.keys(workspace.boards));
  const boardMap = new Map(Object.keys(entry.boards).map(id => [id, usedBoardIds.has(id) ? uniqueId(usedBoardIds) : (usedBoardIds.add(id), id)]));
  const usedCardIds = new Set(target.cards.map(card => card.id));
  const cardMap = new Map(entry.cards.map(card => [card.id, usedCardIds.has(card.id) ? uniqueId(usedCardIds) : (usedCardIds.add(card.id), card.id)]));
  const topIds = new Set(entry.cards.map(card => card.id));
  const lineBounds = entry.cards.length ? [] : entry.connections.map(line => connectionBounds(line, target.cards)).filter((value): value is NonNullable<typeof value> => !!value);
  const offset = options.at && (entry.cards.length || lineBounds.length) ? {
    x: options.at.x - Math.min(...entry.cards.map(card => card.x), ...lineBounds.map(bounds => bounds.x)),
    y: options.at.y - Math.min(...entry.cards.map(card => card.y), ...lineBounds.map(bounds => bounds.y)),
  } : { x: 0, y: 0 };
  const restored = entry.cards.map(source => {
    let card = restoredSyncedNote(workspace, cleanLabels(workspace, structuredClone(source)));
    card.id = cardMap.get(source.id)!; card.x += offset.x; card.y += offset.y;
    if (options.at) card.unsorted = false;
    if (source.parentId && topIds.has(source.parentId)) card.parentId = cardMap.get(source.parentId);
    else if (source.parentId && (targetId !== entry.sourceBoardId || target.cards.find(card => card.id === source.parentId)?.type !== 'column')) {
      card.parentId = undefined; card.width = card.preColumnWidth || card.width; card.preColumnWidth = undefined;
    }
    if (card.type === 'board' && boardMap.has(card.boardId)) card.boardId = boardMap.get(card.boardId)!;
    return card;
  });
  const boards = { ...workspace.boards };
  for (const [id, source] of Object.entries(entry.boards)) {
    const board = structuredClone(source);
    board.id = boardMap.get(id)!;
    board.parentBoardId = source.parentBoardId && boardMap.has(source.parentBoardId) ? boardMap.get(source.parentBoardId) : targetId;
    board.cards = board.cards.map(source => {
      const card = restoredSyncedNote(workspace, cleanLabels(workspace, source));
      if (card.type === 'board' && boardMap.has(card.boardId)) return { ...card, boardId: boardMap.get(card.boardId)! };
      return card;
    });
    boards[board.id] = board;
  }
  const targetCards = [...target.cards, ...restored], targetCardIds = new Set(targetCards.map(card => card.id));
  const usedLineIds = new Set(target.connections.map(line => line.id));
  const connections = entry.connections.flatMap(source => {
    const line = structuredClone(source);
    if (topIds.has(line.from)) line.from = cardMap.get(line.from)!;
    if (topIds.has(line.to)) line.to = cardMap.get(line.to)!;
    if ((!line.from && !freeEndpoint(line, 'from')) || (!line.to && !freeEndpoint(line, 'to')) ||
      (line.from && !targetCardIds.has(line.from)) || (line.to && !targetCardIds.has(line.to)) || (line.from && line.from === line.to)) return [];
    if (usedLineIds.has(line.id)) line.id = uniqueId(usedLineIds); else usedLineIds.add(line.id);
    if (options.at) for (const key of ['start', 'end', 'control'] as const) if (line[key]) line[key] = { x: line[key]!.x + offset.x, y: line[key]!.y + offset.y };
    return [line];
  });
  if (!restored.length && !connections.length) return workspace;
  boards[targetId] = arrangeAllColumns({ ...target, cards: targetCards, connections: [...target.connections, ...connections] });
  return { ...workspace, boards, trash: workspace.trash!.filter(entry => entry.id !== entryId), updatedAt: stamp(now) };
}

export function permanentlyDeleteTrashEntry(workspace: TrashWorkspace, entryId: string): TrashWorkspace {
  const trash = workspace.trash?.filter(entry => entry.id !== entryId);
  return !trash || trash.length === workspace.trash?.length ? workspace : { ...workspace, trash, updatedAt: stamp(Date.now()) };
}
export function emptyTrash(workspace: TrashWorkspace): TrashWorkspace {
  return workspace.trash?.length ? { ...workspace, trash: [], updatedAt: stamp(Date.now()) } : workspace;
}

/** Basic payload guards; call the normal workspace validator on trashEntryValidationWorkspace for full card/graph checks. */
export function isValidTrashEntry(value: unknown): value is TrashEntry {
  if (!record(value) || !['id', 'deletedAt', 'sourceBoardId', 'sourceBoardTitle'].every(key => typeof value[key] === 'string') ||
    !value.id || !value.sourceBoardId || !Number.isFinite(Date.parse(value.deletedAt as string)) ||
    !Array.isArray(value.cards) || !Array.isArray(value.connections) || !Array.isArray(value.rootIds) || !record(value.boards) ||
    (!value.cards.length && !value.connections.length)) return false;
  if (!value.cards.every(card => record(card) && typeof card.id === 'string') || !value.connections.every(line => record(line) && typeof line.id === 'string')) return false;
  const ids = new Set(value.cards.map(card => (card as { id: string }).id));
  return ids.size === value.cards.length && value.rootIds.every(id => typeof id === 'string' && ids.has(id)) && new Set(value.rootIds).size === value.rootIds.length &&
    Object.entries(value.boards).every(([id, board]) => record(board) && board.id === id);
}

/** A validation-only graph adds placeholders for live endpoints not included in the deleted selection. */
export function trashEntryValidationWorkspace(entry: TrashEntry): Workspace {
  const cards: Card[] = structuredClone(entry.cards).map(card => ({ ...card, parentId: undefined }));
  const ids = new Set(cards.map(card => card.id));
  for (const line of entry.connections) for (const id of [line.from, line.to]) if (id && !ids.has(id)) {
    cards.push({ id, type: 'note', text: '', x: 0, y: 0, width: 1, height: 1, z: 0 }); ids.add(id);
  }
  const source: Board = { id: entry.sourceBoardId, title: entry.sourceBoardTitle, cards, connections: structuredClone(entry.connections), viewport: { x: 0, y: 0, zoom: 1 } };
  return { version: 1, id: `trash-${entry.id}`, title: 'Trash validation', rootBoardId: source.id, updatedAt: entry.deletedAt, boards: { [source.id]: source, ...structuredClone(entry.boards) } };
}
