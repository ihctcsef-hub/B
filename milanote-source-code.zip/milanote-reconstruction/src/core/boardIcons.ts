import catalogJson from '../data/boardIconCatalog.json';
import freePathsJson from '../data/boardIconFreePaths.json';
import referenceAssetsJson from '../data/boardIconReferenceAssets.json';

export interface BoardIconChoice {id:string;name:string;terms:string[];aliases:string[];referenceKnown:boolean;artSource:string;templateOnly?:boolean}
type IconCatalog={referenceKnownCount:number;freeArtworkCount:number;referenceInventoryComplete:boolean;referenceQueries:Record<string,string[]>;entries:BoardIconChoice[]};
type FreeGlyph={viewBox:number[];path:string|string[]};
type VisualGlyph={viewBox:number[];paths:{d:string;opacity?:number;fill?:string;fillRule?:'evenodd';transform?:string}[]};
const catalog=catalogJson as IconCatalog,paths=freePathsJson as Record<string,FreeGlyph>,referenceAssets=referenceAssetsJson.entries as Record<string,VisualGlyph>;
const rasterFallbackIds=new Set<string>(referenceAssetsJson.rasterFallbackIds);
const byId=new Map(catalog.entries.map(icon=>[icon.id,icon]));
const fold=(text:string)=>text.normalize('NFKD').replace(/\p{M}/gu,'').toLocaleLowerCase().trim();
export const BOARD_ICON_CHARACTERS=[...'1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ!#$%&=~'];
export const BOARD_ICON_DIGITS=[...'1234567890'];

/** This is a bounded observed reference inventory, plus an explicitly separate
 * open collection. A usable local search is not a complete server index. */
export function boardIconCatalogCoverage(){return {referenceKnownCount:catalog.referenceKnownCount,freeArtworkCount:catalog.freeArtworkCount,availableCount:catalog.entries.length,referenceInventoryComplete:catalog.referenceInventoryComplete};}
export function getBoardIcon(id:string):BoardIconChoice|undefined {const choice=byId.get(id);return choice?structuredClone(choice):undefined;}
export function getReferenceBoardIcons():BoardIconChoice[]{return catalog.entries.filter(icon=>icon.referenceKnown).map(icon=>structuredClone(icon));}
export function searchBoardIcons(query:string,limit=32):BoardIconChoice[]{
 const term=fold(query);if(!term)return [];
 const observed=catalog.referenceQueries[term];
 if(observed)return observed.slice(0,limit).flatMap(id=>{const icon=byId.get(id);return icon?[structuredClone(icon)]:[];});
 const words=term.split(/[\s-]+/).filter(Boolean);
 return catalog.entries.filter(icon=>!icon.templateOnly).map((icon,index)=>{
   const name=fold(icon.name),id=fold(icon.id).replaceAll('-',' '),aliases=icon.aliases.map(fold),text=fold([icon.name,icon.id,...icon.aliases,...icon.terms].join(' ')).replaceAll('-',' ');
   const score=fold(icon.id)===term||name===term||id===term?0:aliases.includes(term)?1:name.startsWith(term)||id.startsWith(term)?2:words.every(word=>text.includes(word))?3:Infinity;
   return {icon,index,score};
 }).filter(item=>Number.isFinite(item.score)).sort((a,b)=>a.score-b.score||Number(b.icon.referenceKnown)-Number(a.icon.referenceKnown)||a.index-b.index).slice(0,limit).map(item=>structuredClone(item.icon));
}
export function boardIconCategory(category:'recommended'|'new'|'board',boardTitle='New Board'):BoardIconChoice[]{
 if(category==='recommended')return searchBoardIcons(boardTitle,8);
 return searchBoardIcons(category,32);
}

/** Visual assets are normalized into numeric viewports and path data at the
 * producing boundary. No captured markup, HTML, script or CSS is interpreted. */
export function boardIconSvg(id:string,{color='#5f6672',size=160}:{color?:string;size?:number}={}):string|undefined {
 const choice=byId.get(id);if(!choice)return;
 if(!/^#[a-f\d]{6}$/i.test(color)||!Number.isFinite(size)||size<=0||size>4096)throw new Error('Invalid board icon rendering options.');
 const observed=referenceAssets[id],free=paths[id];if(!observed&&!free)return;
 const box=observed?.viewBox||free.viewBox;
 const body=observed?observed.paths.map(path=>`<path d="${path.d}"${path.opacity===undefined?'':` opacity="${path.opacity}"`}${path.fill===undefined?'':` fill="${path.fill}"`}${path.fillRule===undefined?'':` fill-rule="${path.fillRule}"`}${path.transform===undefined?'':` transform="${path.transform}"`}/>`).join(''):(Array.isArray(free.path)?free.path:[free.path]).map(path=>`<path d="${path}"/>`).join('');
 return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="${box.join(' ')}" fill="${color}" data-board-icon="${id}">${body}</svg>`;
}
export function boardIconSvgUrl(id:string,options?:{color?:string;size?:number}):string|undefined {const svg=boardIconSvg(id,options);return svg?`data:image/svg+xml;base64,${btoa(svg)}`:undefined;}
export function boardIconPngUrl(id:string):string|undefined {return rasterFallbackIds.has(id)?`${import.meta.env.BASE_URL}board-icons/reference-48/${id}.png`:undefined;}

/** Keep the durable PNG backup while painting known catalog icons as vectors.
 * Resampling a160px backup to the measured fractional CSS glyph size changes
 * antialiasing. Arbitrary uploaded images are never reinterpreted as SVG. */
export function boardIconDisplaySource(value:string|undefined,{color='#323b4a'}:{color?:string}={}):string|undefined {
 const id=selectedBoardIconId(value);return id?boardIconSvgUrl(id,{color})||value:value;
}

const pngSignature=[137,80,78,71,13,10,26,10],identityKey='visual-workspace-icon';
const crcTable=Uint32Array.from({length:256},(_,value)=>{let crc=value;for(let bit=0;bit<8;bit++)crc=(crc&1)?0xedb88320^(crc>>>1):crc>>>1;return crc>>>0;});
function crc32(bytes:Uint8Array){let crc=0xffffffff;for(const byte of bytes)crc=crcTable[(crc^byte)&255]^(crc>>>8);return (crc^0xffffffff)>>>0;}
function readUint(bytes:Uint8Array,offset:number){return new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength).getUint32(offset);}
function pngBytes(source:string):Uint8Array|undefined {
 if(!source.startsWith('data:image/png;base64,')||source.length>2_000_000)return;
 try{const bytes=Uint8Array.from(atob(source.slice(22)),char=>char.charCodeAt(0));return pngSignature.every((byte,index)=>bytes[index]===byte)?bytes:undefined;}catch{return;}
}
function pngChunks(bytes:Uint8Array):{offset:number;length:number;type:string;valid:boolean}[]{
 const chunks=[];let offset=8;
 while(offset+12<=bytes.length){const length=readUint(bytes,offset);if(length>bytes.length-offset-12)return [];const type=String.fromCharCode(...bytes.subarray(offset+4,offset+8));chunks.push({offset,length,type,valid:crc32(bytes.subarray(offset+4,offset+8+length))===readUint(bytes,offset+8+length)});offset+=12+length;if(type==='IEND')return offset===bytes.length?chunks:[];}
 return [];
}
function encodePng(bytes:Uint8Array){let binary='';for(let offset=0;offset<bytes.length;offset+=8192)binary+=String.fromCharCode(...bytes.subarray(offset,offset+8192));return `data:image/png;base64,${btoa(binary)}`;}
/** Identity travels with the raster bytes, so selection survives IndexedDB,
 * JSON export/import, reload and undo without a process-local lookup map. */
export function withBoardIconIdentity(source:string,id:string):string {
 if(!byId.has(id))throw new Error('Unknown board icon.');
 const bytes=pngBytes(source);if(!bytes)throw new Error('The board icon is not a PNG.');const chunks=pngChunks(bytes);if(!chunks.length||chunks.some(chunk=>!chunk.valid))throw new Error('The board icon PNG could not be read.');
 const payload=new TextEncoder().encode(`${identityKey}\0v1:${id}`),chunk=new Uint8Array(payload.length+12),view=new DataView(chunk.buffer);view.setUint32(0,payload.length);chunk.set([116,69,88,116],4);chunk.set(payload,8);view.setUint32(payload.length+8,crc32(chunk.subarray(4,payload.length+8)));
 const retained=chunks.filter(item=>item.type!=='tEXt'||!new TextDecoder().decode(bytes.subarray(item.offset+8,item.offset+8+item.length)).startsWith(`${identityKey}\0`));
 const length=8+chunk.length+retained.reduce((sum,item)=>sum+item.length+12,0),result=new Uint8Array(length);result.set(bytes.subarray(0,8));let offset=8;
 for(const item of retained){if(item.type==='IEND'){result.set(chunk,offset);offset+=chunk.length;}result.set(bytes.subarray(item.offset,item.offset+12+item.length),offset);offset+=12+item.length;}return encodePng(result);
}
export function selectedBoardIconId(source?:string):string|undefined {
 if(!source)return;
 // Keep identity readable for older SVG choices, before PNG conversion existed.
 if(source.startsWith('data:image/svg+xml;base64,'))try{const id=/data-board-icon="([a-z0-9-]+)"/.exec(atob(source.slice(source.indexOf(',')+1)))?.[1];return id&&byId.has(id)?id:undefined;}catch{return;}
 const bytes=pngBytes(source);if(!bytes)return;
 const chunks=pngChunks(bytes);if(chunks.some(chunk=>!chunk.valid))return;
 for(const chunk of chunks)if(chunk.type==='tEXt'){const text=new TextDecoder().decode(bytes.subarray(chunk.offset+8,chunk.offset+8+chunk.length));if(text.startsWith(`${identityKey}\0v1:`)){const id=text.slice(identityKey.length+4);if(byId.has(id))return id;}}
}
