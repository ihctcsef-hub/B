/** Independent calculation adapter. HyperFormula retains its GPLv3 license; see docs/THIRD-PARTY.md. */
import{HyperFormula,CellError,ErrorType,FunctionPlugin,FunctionArgumentType}from'hyperformula';
import type{TableEvaluationContext}from'./formulaWorkbook';
class BoundedRept extends FunctionPlugin{
 static implementedFunctions={REPT:{method:'boundedRept',parameters:[{argumentType:FunctionArgumentType.STRING},{argumentType:FunctionArgumentType.NUMBER}]}};
 boundedRept(ast:{args:Parameters<FunctionPlugin['runFunction']>[0]},state:Parameters<FunctionPlugin['evaluateAst']>[1]){return this.runFunction(ast.args,state,this.metadata('REPT'),(text:string,count:number)=>count<0||text.length*Math.trunc(count)>1000000?new CellError(ErrorType.VALUE):text.repeat(count));}
}
HyperFormula.registerFunctionPlugin(BoundedRept);
export const supported=new Set(HyperFormula.getRegisteredFunctionNames('enGB'));
export class FullRuntime{
 private engine:HyperFormula;private sheet:number;
 constructor(rows:string[][],meta:Record<string,{type?:string}>,context?:TableEvaluationContext){
 const w=context?.workbook,index=context?.tableId?w?.tableIndices[context.tableId]:undefined,count=w?.sheetCount||1,names=Array.from({length:count},(_,i)=>`__reserved_${i+1}`);
 for(const[id,slot]of Object.entries(w?.tableIndices||{}))names[slot-1]=id;
 this.sheet=index?index-1:0;const sheets:Record<string,(string|null)[][]>=Object.create(null);
 for(const name of names)sheets[name]=[];
 sheets[names[this.sheet]]=rows.map((row,r)=>row.map((v,c)=>!v?null:meta[`${r}:${c}`]?.type==='text'?"'"+v:v.trimStart().startsWith('=')?v.trimStart():v));
 this.engine=HyperFormula.buildFromSheets(sheets,{licenseKey:'gpl-v3',language:'enGB',dateFormats:['YYYY-MM-DD','MM/DD/YYYY','DD/MM/YYYY'],useArrayArithmetic:false});
 this.engine.addNamedExpression('TRUE','=TRUE()');this.engine.addNamedExpression('FALSE','=FALSE()');
 }
 read(row:number,col:number){const value=this.engine.getCellValue({sheet:this.sheet,row,col});if(value&&typeof value==='object'&&'type'in value)return{value:value.value,error:{code:value.value,message:(value.message||(value.type==='DIV_BY_ZERO'?"Numbers can't be divided by zero":value.value)).replace(/\.$/,'')}};return{value:value??''};}
 dispose(){this.engine.destroy();}
}
