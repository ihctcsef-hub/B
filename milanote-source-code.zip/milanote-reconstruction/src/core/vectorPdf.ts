/** Conservative DOM text extraction for hybrid PDF export. Unsupported text is
 * left in the raster capture, rather than removed or replaced with hidden OCR. */
export interface PdfVectorText {
  text: string;
  x: number;
  baseline: number;
  width: number;
  fontSize: number;
  letterSpacing?: number;
  weight: number;
  italic: boolean;
  color: [number, number, number];
  href?: string;
}
export interface PdfVectorOverlay { texts: PdfVectorText[]; rasterFallbackNodes: number; overlappingCards: number }
type Rect = { left: number; top: number; right: number; bottom: number; width: number; height: number };
const overlaps = (a: Rect,b: Rect) => Math.min(a.right,b.right)>Math.max(a.left,b.left) && Math.min(a.bottom,b.bottom)>Math.max(a.top,b.top);
const contains = (outer: Rect,inner: Rect) => inner.left>=outer.left-.75 && inner.top>=outer.top-.75 && inner.right<=outer.right+.75 && inner.bottom<=outer.bottom+.75;
function colorOf(value:string):[number,number,number]|null {
  const values=/^rgba?\(\s*([\d.]+)[, ]+([\d.]+)[, ]+([\d.]+)(?:\s*[,/]\s*([\d.]+))?\s*\)$/.exec(value);
  if(!values || (values[4]!==undefined && Number(values[4])!==1)) return null;
  return [Number(values[1])/255,Number(values[2])/255,Number(values[3])/255];
}
function safeHref(node:Element):string|undefined {
  const value=node.closest('a')?.getAttribute('href');if(!value)return;
  try{const url=new URL(value);if(['http:','https:','mailto:'].includes(url.protocol))return url.href;}catch{/* Unsupported links remain visible without an annotation. */}
}
function baselineOffset(doc:Document,style:CSSStyleDeclaration,text:string):number {
  const probe=doc.createElement('span');
  Object.assign(probe.style,{all:'initial',position:'fixed',left:'-90000px',top:'0',display:'inline-block',whiteSpace:'pre',font:style.font,fontFamily:style.fontFamily,fontSize:style.fontSize,fontWeight:style.fontWeight,fontStyle:style.fontStyle,lineHeight:style.lineHeight,letterSpacing:style.letterSpacing,direction:style.direction});
  const content=doc.createTextNode(text),marker=doc.createElement('i');
  Object.assign(marker.style,{display:'inline-block',width:'0',height:'0',padding:'0',margin:'0',border:'0',verticalAlign:'baseline'});
  probe.append(content,marker);doc.body.append(probe);
  try { const range=doc.createRange();range.selectNodeContents(content);return marker.getBoundingClientRect().top-range.getBoundingClientRect().top; }
  finally{probe.remove();}
}
export function collectPdfVectorText(element:HTMLElement,canRender:(text:string,weight:number,italic:boolean,width:number,fontSize:number,letterSpacing:number)=>boolean):PdfVectorOverlay {
  const doc=element.ownerDocument,view=doc.defaultView!;
  const root=element.getBoundingClientRect(),cards=[...element.querySelectorAll<HTMLElement>('.card')];
  const boxes=new Map(cards.map(card=>[card,card.getBoundingClientRect()])),blocked=new Set<HTMLElement>();
  for(let i=0;i<cards.length;i++)for(let j=i+1;j<cards.length;j++)if(overlaps(boxes.get(cards[i])!,boxes.get(cards[j])!)){blocked.add(cards[i]);blocked.add(cards[j]);}
  const walker=doc.createTreeWalker(element,NodeFilter.SHOW_TEXT),nodes:Text[]=[];let found:Node|null;
  while((found=walker.nextNode()))nodes.push(found as Text);
  const texts:PdfVectorText[]=[],baselines=new Map<string,number>();let rasterFallbackNodes=0,characters=0;
  const segments=new Intl.Segmenter(undefined,{granularity:'grapheme'}),range=doc.createRange();
  for(const node of nodes){
    const parent=node.parentElement,text=node.data;if(!parent||!text.length||parent.closest('style,script,svg,textarea,select,option'))continue;
    const card=parent.closest<HTMLElement>('.card');if(card&&blocked.has(card)){rasterFallbackNodes++;continue;}
    const style=view.getComputedStyle(parent),fontSize=parseFloat(style.fontSize),weight=Number(style.fontWeight)||400,italic=style.fontStyle!=='normal',color=colorOf(style.color);
    if(style.display==='none'||style.visibility!=='visible')continue;
    // PDF runs currently paint a solid color fill only. Keep browser-specific
    // fill overrides and outlined glyphs raster instead of changing their ink.
    const textFill=style.getPropertyValue('-webkit-text-fill-color'),fillColor=textFill&&textFill!=='currentcolor'?colorOf(textFill):color;
    const alteredFill=!fillColor||fillColor.some((channel,index)=>channel!==color?.[index]);
    const letterSpacing=style.letterSpacing==='normal'?0:parseFloat(style.letterSpacing);
    const outlined=(parseFloat(style.getPropertyValue('-webkit-text-stroke-width'))||0)>0;
    if(!color||alteredFill||outlined||!Number.isFinite(fontSize)||fontSize<=0||!/Inter|Arial|Helvetica|sans-serif/i.test(style.fontFamily)||/monospace|serif(?!-)/i.test(style.fontFamily.replace(/sans-serif/gi,''))||style.textTransform!=='none'||style.textShadow!=='none'||style.writingMode!=='horizontal-tb'||!Number.isFinite(letterSpacing)||(style.wordSpacing!=='normal'&&parseFloat(style.wordSpacing)!==0)||(characters+=text.length)>24000){rasterFallbackNodes++;continue;}
    let unsupported=false;const clips:Rect[]=[root];
    for(let ancestor:Element|null=parent;ancestor&&ancestor!==element;ancestor=ancestor.parentElement){
      const css=view.getComputedStyle(ancestor);
      if(Number(css.opacity)!==1||css.filter!=='none'||css.clipPath!=='none'||css.mixBlendMode!=='normal'){unsupported=true;break;}
      // The cloned world has only a translation. Other transforms need a
      // general text matrix; keeping them raster preserves their appearance.
      if(css.transform!=='none'&&!ancestor.classList.contains('world')){unsupported=true;break;}
      if(['hidden','clip','auto','scroll'].includes(css.overflowX)||['hidden','clip','auto','scroll'].includes(css.overflowY))clips.push(ancestor.getBoundingClientRect());
    }
    if(unsupported){rasterFallbackNodes++;continue;}
    const groups:{text:string;left:number;top:number;right:number;bottom:number}[]=[];
    for(const part of segments.segment(text)){
      range.setStart(node,part.index);range.setEnd(node,part.index+part.segment.length);
      const rects=[...range.getClientRects()].filter(rect=>rect.width>.01&&rect.height>.01);
      if(!rects.length)continue;
      if(rects.length!==1||clips.some(clip=>!contains(clip,rects[0]))){unsupported=true;break;}
      const rect=rects[0],value=/^\s+$/.test(part.segment)&&!['pre','pre-wrap','break-spaces'].includes(style.whiteSpace)?' ':part.segment;
      const last=groups.at(-1);
      if(last&&Math.abs(last.top-rect.top)<.75&&Math.abs(last.bottom-rect.bottom)<.75){last.text+=value;last.left=Math.min(last.left,rect.left);last.right=Math.max(last.right,rect.right);}
      else groups.push({text:value,left:rect.left,top:rect.top,right:rect.right,bottom:rect.bottom});
    }
    if(unsupported||!groups.length||groups.some(group=>!canRender(group.text,weight,italic,group.right-group.left,fontSize,letterSpacing))){rasterFallbackNodes++;continue;}
    const href=safeHref(parent);
    for(const group of groups){
      const key=[style.fontFamily,fontSize,weight,style.fontStyle,style.lineHeight,/[\u0600-\u08ff]/.test(group.text)].join('|');
      let offset=baselines.get(key);if(offset===undefined){offset=baselineOffset(doc,style,group.text);baselines.set(key,offset);}
      texts.push({text:group.text,x:group.left-root.left,baseline:group.top-root.top+offset,width:group.right-group.left,fontSize,letterSpacing,weight,italic,color,...(href?{href}:{})});
    }
    const transparent=doc.createElement('span');transparent.style.display='contents';transparent.style.setProperty('color','transparent','important');transparent.style.setProperty('-webkit-text-fill-color','transparent','important');
    node.replaceWith(transparent);transparent.append(node);
  }
  return {texts,rasterFallbackNodes,overlappingCards:blocked.size};
}
