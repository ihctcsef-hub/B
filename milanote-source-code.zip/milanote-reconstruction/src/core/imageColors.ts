import type { Board, Card } from './model';
import type { ImageEdits } from './imageEditing';
import { imageCropBounds, normalizeImageEdits, rotatedImageSize } from './imageEditing';
import { hexToRgb, rgbToHex } from './colors';
import { nearestNamedColor } from './namedColors';

export interface WeightedImageColor { value:string; weight:number }
export interface ImagePixels { width:number; height:number; data:Uint8ClampedArray }
export type ImageColorCard=Extract<Card,{type:'image'}>;
export interface ColorImageRect { x:number; y:number; width:number; height:number }
export interface BoardColorImage { id:string; source:string; edits?:ImageEdits; rect:ColorImageRect; background:string }
const distance=(a:string,b:string)=>{const first=hexToRgb(a),second=hexToRgb(b);return first&&second?Math.hypot(first.r-second.r,first.g-second.g,first.b-second.b):Infinity;};

/** A deterministic independent quantizer. These are image colors, not a copy of
 * Milanote's unpublished palette ordering or naming algorithm. */
export function imagePalette(pixels:Pick<ImagePixels,'data'>,limit=12):WeightedImageColor[]{
  const buckets=new Map<number,{r:number;g:number;b:number;weight:number}>();
  for(let index=0;index+3<pixels.data.length;index+=4){
    const alpha=pixels.data[index+3]/255;if(alpha<.125)continue;
    const r=pixels.data[index],g=pixels.data[index+1],b=pixels.data[index+2],key=(r>>3)*1024+(g>>3)*32+(b>>3);
    const bucket=buckets.get(key)||{r:0,g:0,b:0,weight:0};bucket.r+=r*alpha;bucket.g+=g*alpha;bucket.b+=b*alpha;bucket.weight+=alpha;buckets.set(key,bucket);
  }
  const candidates=[...buckets.entries()].sort((a,b)=>b[1].weight-a[1].weight||a[0]-b[0]).map(([,item])=>({value:rgbToHex({r:item.r/item.weight,g:item.g/item.weight,b:item.b/item.weight}),weight:item.weight}));
  const result:WeightedImageColor[]=[];
  for(const candidate of candidates){const near=result.find(item=>distance(item.value,candidate.value)<32);if(near)near.weight+=candidate.weight;else if(result.length<Math.max(1,Math.min(24,limit)))result.push({...candidate});}
  return result.sort((a,b)=>b.weight-a.weight);
}
export function chooseImageColor(palette:WeightedImageColor[],used:string[]):string|undefined{
  const colors=[...palette].sort((a,b)=>b.weight-a.weight);
  if(!colors.length)return undefined;
  const unused=colors.find(color=>used.every(value=>distance(value,color.value)>=36));
  if(unused)return unused.value;
  return colors.reduce((best,color)=>Math.min(...used.map(value=>distance(value,color.value)))>Math.min(...used.map(value=>distance(value,best.value)))?color:best).value;
}
export function imageColorName(value:string):string{return nearestNamedColor(value)?.name||'Unknown color';}
export function visibleColorImages(board:Board):ImageColorCard[]{
  return board.cards.filter((card):card is ImageColorCard=>{
    if(card.type!=='image'||card.unsorted)return false;const seen=new Set<string>();let parent=card.parentId;
    while(parent){if(seen.has(parent))return false;seen.add(parent);const owner=board.cards.find(item=>item.id===parent);if(!owner||owner.unsorted||owner.type==='column'&&owner.collapsed)return false;parent=owner.parentId;}
    return true;
  });
}
export function colorImageSource(card:ImageColorCard):string{return card.useCutout&&card.cutoutSrc?card.cutoutSrc:card.src;}

/** Object-fit cover / SVG slice both crop around the center of the displayed
 * edited image. This maps a displayed pixel without including captions/strips. */
export function imagePointAt(rect:ColorImageRect,width:number,height:number,x:number,y:number):{x:number;y:number}|null{
  if(!width||!height||!rect.width||!rect.height||x<rect.x||y<rect.y||x>=rect.x+rect.width||y>=rect.y+rect.height)return null;
  const scale=Math.max(rect.width/width,rect.height/height);
  return {x:Math.min(width-1,Math.max(0,Math.floor((x-rect.x+(width*scale-rect.width)/2)/scale))),y:Math.min(height-1,Math.max(0,Math.floor((y-rect.y+(height*scale-rect.height)/2)/scale)))};
}
export function imagePixelColor(pixels:ImagePixels,point:{x:number;y:number},background='#ffffff'):string{
  const at=(point.y*pixels.width+point.x)*4,alpha=pixels.data[at+3]/255,bg=hexToRgb(background)||{r:255,g:255,b:255};
  return rgbToHex({r:pixels.data[at]*alpha+bg.r*(1-alpha),g:pixels.data[at+1]*alpha+bg.g*(1-alpha),b:pixels.data[at+2]*alpha+bg.b*(1-alpha)});
}

const cache=new Map<string,Map<string,Promise<ImagePixels>>>();
function loadColorImage(source:string):Promise<HTMLImageElement>{
  return new Promise((resolve,reject)=>{
    const image=new Image();const timer=setTimeout(()=>{image.onload=image.onerror=null;image.src='';reject(new Error('This image took too long to load.'));},12000);
    image.crossOrigin='anonymous';image.onload=()=>{clearTimeout(timer);image.onload=image.onerror=null;image.naturalWidth&&image.naturalHeight?resolve(image):reject(new Error('This image has no usable pixels.'));};
    image.onerror=()=>{clearTimeout(timer);image.onload=image.onerror=null;reject(new Error('The image could not be read. Upload a local copy to pick its colors.'));};image.src=source;
  });
}
export async function readImageColors(source:string,value?:ImageEdits,maxSize=128):Promise<ImagePixels>{
  const edits=normalizeImageEdits(value),size=Math.max(16,Math.min(2048,Math.floor(maxSize))),key=JSON.stringify([edits,size]);
  let group=cache.get(source);if(!group){group=new Map();cache.set(source,group);if(cache.size>8)cache.delete(cache.keys().next().value!);}
  const previous=size<=256?group.get(key):undefined;if(previous)return previous;
  const operation=(async()=>{
    const image=await loadColorImage(source),width=image.naturalWidth,height=image.naturalHeight,crop=imageCropBounds(width,height,edits),ratio=Math.min(1,size/Math.max(crop.width,crop.height));
    const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(crop.width*ratio));canvas.height=Math.max(1,Math.round(crop.height*ratio));
    const ctx=canvas.getContext('2d',{willReadFrequently:true});if(!ctx)throw new Error('Image color sampling is unavailable.');
    ctx.scale(canvas.width/crop.width,canvas.height/crop.height);ctx.translate(-crop.x,-crop.y);const rotated=rotatedImageSize(width,height,edits.rotation);
    ctx.translate(edits.flipX?rotated.width:0,edits.flipY?rotated.height:0);ctx.scale(edits.flipX?-1:1,edits.flipY?-1:1);
    if(edits.rotation===90)ctx.translate(height,0);else if(edits.rotation===180)ctx.translate(width,height);else if(edits.rotation===270)ctx.translate(0,width);
    ctx.rotate(edits.rotation*Math.PI/180);ctx.drawImage(image,0,0);ctx.lineCap='round';ctx.lineJoin='round';
    for(const path of edits.paths){ctx.beginPath();ctx.strokeStyle=ctx.fillStyle=path.color;ctx.lineWidth=path.width*Math.min(width,height);path.points.forEach((point,index)=>index?ctx.lineTo(point.x*width,point.y*height):ctx.moveTo(point.x*width,point.y*height));if(path.points.length===1){const point=path.points[0];ctx.arc(point.x*width,point.y*height,ctx.lineWidth/2,0,Math.PI*2);ctx.fill();}else ctx.stroke();}
    try{return {width:canvas.width,height:canvas.height,data:ctx.getImageData(0,0,canvas.width,canvas.height).data};}catch{throw new Error('This image server blocks color sampling. Upload a local copy to pick its colors.');}
  })();
  // Keep only small palette reads. Full-resolution eyedropper pixels are
  // transient so several edited photos cannot retain hundreds of MB on iPad.
  if(size<=256){group.set(key,operation);if(group.size>6)group.delete(group.keys().next().value!);operation.catch(()=>group?.delete(key));}
  return operation;
}
