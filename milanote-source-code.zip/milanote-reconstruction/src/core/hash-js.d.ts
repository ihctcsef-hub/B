declare module 'hash.js' {
  interface Hash {
    update(data:Uint8Array):Hash;
    digest(encoding:'hex'):string;
  }
  const hashes:{sha256:()=>Hash};
  export default hashes;
}
