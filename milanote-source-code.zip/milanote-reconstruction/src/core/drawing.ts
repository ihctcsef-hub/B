import type { Point, SketchPath } from './model';

export interface DrawingRect { x:number; y:number; width:number; height:number }
export interface DrawingSize { width:number; height:number }
export interface DrawingHistory { past:SketchPath[][]; present:SketchPath[]; future:SketchPath[][] }
const finite=(value:number)=>Number.isFinite(value);
const clamp=(value:number,min:number,max:number)=>Math.max(min,Math.min(max,value));

export function drawingBounds(paths:SketchPath[],indices?:number[]):DrawingRect|null {
  const selected=indices?new Set(indices):null;
  let left=Infinity,top=Infinity,right=-Infinity,bottom=-Infinity;
  paths.forEach((path,index)=>{
    if(selected&&!selected.has(index))return;
    const inset=Math.max(0,path.width)/2;
    for(const point of path.points){
      if(!finite(point.x)||!finite(point.y))continue;
      left=Math.min(left,point.x-inset);top=Math.min(top,point.y-inset);
      right=Math.max(right,point.x+inset);bottom=Math.max(bottom,point.y+inset);
    }
  });
  return left===Infinity?null:{x:left,y:top,width:right-left,height:bottom-top};
}
function segmentDistance(point:Point,from:Point,to:Point):number {
  const dx=to.x-from.x,dy=to.y-from.y;
  const t=dx||dy?clamp(((point.x-from.x)*dx+(point.y-from.y)*dy)/(dx*dx+dy*dy),0,1):0;
  return Math.hypot(point.x-from.x-t*dx,point.y-from.y-t*dy);
}

/** Coordinates and tolerance are in the drawing's own pixel coordinate system. */
export function hitDrawingPath(paths:SketchPath[],point:Point,tolerance=5):number|null {
  for(let index=paths.length-1;index>=0;index--){
    const path=paths[index],radius=Math.max(0,tolerance)+Math.max(0,path.width)/2;
    if(path.points.length===1&&Math.hypot(point.x-path.points[0].x,point.y-path.points[0].y)<=radius)return index;
    for(let i=1;i<path.points.length;i++)if(segmentDistance(point,path.points[i-1],path.points[i])<=radius)return index;
  }
  return null;
}

export function drawingPathsInRect(paths:SketchPath[],rect:DrawingRect):number[] {
  const left=Math.min(rect.x,rect.x+rect.width),right=Math.max(rect.x,rect.x+rect.width);
  const top=Math.min(rect.y,rect.y+rect.height),bottom=Math.max(rect.y,rect.y+rect.height);
  return paths.flatMap((path,index)=>{
    const bounds=drawingBounds([path]);
    return bounds&&bounds.x<=right&&bounds.x+bounds.width>=left&&bounds.y<=bottom&&bounds.y+bounds.height>=top?[index]:[];
  });
}

export function translateDrawingPaths(paths:SketchPath[],indices:number[],delta:Point,size?:DrawingSize):SketchPath[] {
  if(!finite(delta.x)||!finite(delta.y))return paths;
  const selected=new Set(indices),bounds=drawingBounds(paths,indices);
  if(!bounds||!selected.size)return paths;
  let dx=delta.x,dy=delta.y;
  if(size){
    // A drawing wider than the canvas can still move back into view; never
    // invert the interval or independently distort individual strokes.
    const minX=-bounds.x,maxX=size.width-bounds.x-bounds.width;
    const minY=-bounds.y,maxY=size.height-bounds.y-bounds.height;
    if(minX<=maxX)dx=clamp(dx,minX,maxX);
    if(minY<=maxY)dy=clamp(dy,minY,maxY);
  }
  if(!dx&&!dy)return paths;
  return paths.map((path,index)=>selected.has(index)?{...path,points:path.points.map(point=>({x:point.x+dx,y:point.y+dy}))}:path);
}

export function drawingPathData(points:Point[]):string {
  if(!points.length)return '';
  if(points.length===1)return `M ${points[0].x} ${points[0].y} l 0.01 0`;
  return `M ${points.map(point=>`${point.x} ${point.y}`).join(' L ')}`;
}
export function drawingHistory(paths:SketchPath[]):DrawingHistory {return {past:[],present:structuredClone(paths),future:[]};}
export function commitDrawing(history:DrawingHistory,paths:SketchPath[]):DrawingHistory {
  return JSON.stringify(paths)===JSON.stringify(history.present)?history:{past:[...history.past.slice(-99),history.present],present:structuredClone(paths),future:[]};
}
export function undoDrawing(history:DrawingHistory):DrawingHistory {
  return history.past.length?{past:history.past.slice(0,-1),present:history.past.at(-1)!,future:[history.present,...history.future]}:history;
}
export function redoDrawing(history:DrawingHistory):DrawingHistory {
  return history.future.length?{past:[...history.past,history.present],present:history.future[0],future:history.future.slice(1)}:history;
}
