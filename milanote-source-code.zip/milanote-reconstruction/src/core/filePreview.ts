/** Classification is deliberately narrower than the list of allowed uploads.
 * An arbitrary Office/archive attachment remains a file icon; an extension is
 * not evidence that the browser can produce a faithful thumbnail for it. */
export function filePreviewKind(file:{name:string;mime:string}):'pdf'|'audio'|'video'|'icon'{
  if(file.mime==='application/pdf'||(!file.mime||file.mime==='application/octet-stream')&&/\.pdf$/i.test(file.name))return 'pdf';
  if(file.mime.startsWith('audio/'))return 'audio';
  if(file.mime.startsWith('video/'))return 'video';
  return 'icon';
}

export const FILE_DETAIL_FOOTER_HEIGHT=72.375;
export const FILE_EMPTY_CAPTION_HEIGHT=32;
export const FILE_ICON_WIDTH=78;
export const FILE_ICON_HEIGHT=111.171875;

/** Measured first-page framing follows the same eight-pixel envelope as image
 * drops: 360x480 paper at270px wide produces358px, rather than360px. */
export function pdfPreviewHeight(width:number,pageWidth:number,pageHeight:number):number{
  if(![width,pageWidth,pageHeight].every(value=>Number.isFinite(value)&&value>0))throw new Error('PDF preview dimensions must be finite and positive.');
  return Math.max(6,Math.round(width*pageHeight/pageWidth/8)*8-2);
}

export function fileDetailHeight(previewHeight:number,options:{showFileInfo?:boolean;showCaption?:boolean;captionHeight?:number}={}):number{
  const info=options.showFileInfo!==false;
  const caption=info&&options.showCaption?Math.max(FILE_EMPTY_CAPTION_HEIGHT,options.captionHeight||0):0;
  return previewHeight+(info?FILE_DETAIL_FOOTER_HEIGHT:0)+caption;
}

export function attachmentSizeLabel(bytes:number):string{
  const safe=Number.isFinite(bytes)?Math.max(0,bytes):0;
  if(safe<1024*1024)return `${Math.max(1,Math.round(safe/1024))} KB`;
  return `${Number((safe/(1024*1024)).toFixed(1))} MB`;
}
