export type ColorSpace = "hex" | "rgb" | "hsl";
export interface RgbColor { r: number; g: number; b: number }
export interface HslColor { h: number; s: number; l: number }
const byte = (value: number) => Math.max(0, Math.min(255, Math.round(value)));
const percent = (value: number) => Math.max(0, Math.min(100, value));

export function rgbToHex({ r, g, b }: RgbColor): string {
  return `#${[r, g, b].map(value => byte(value).toString(16).padStart(2, "0")).join("")}`;
}
export function hexToRgb(value: string): RgbColor | null {
  const match = /^#?([a-f\d]{3}|[a-f\d]{6})$/i.exec(value.trim());
  if (!match) return null;
  const hex = match[1].length === 3 ? [...match[1]].map(char => char + char).join("") : match[1];
  return { r: parseInt(hex.slice(0, 2), 16), g: parseInt(hex.slice(2, 4), 16), b: parseInt(hex.slice(4, 6), 16) };
}
export function rgbToHsl({ r, g, b }: RgbColor): HslColor {
  r = byte(r) / 255; g = byte(g) / 255; b = byte(b) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b), delta = max - min;
  const lightness = (max + min) / 2;
  if (!delta) return { h: 0, s: 0, l: lightness * 100 };
  let hue = max === r ? ((g - b) / delta) % 6 : max === g ? (b - r) / delta + 2 : (r - g) / delta + 4;
  hue = ((hue * 60) + 360) % 360;
  return { h: hue, s: (delta / (1 - Math.abs(2 * lightness - 1))) * 100, l: lightness * 100 };
}
export function hslToRgb({ h, s, l }: HslColor): RgbColor {
  h = ((h % 360) + 360) % 360; s = percent(s) / 100; l = percent(l) / 100;
  const chroma = (1 - Math.abs(2 * l - 1)) * s, secondary = chroma * (1 - Math.abs((h / 60) % 2 - 1)), offset = l - chroma / 2;
  const parts = h < 60 ? [chroma, secondary, 0] : h < 120 ? [secondary, chroma, 0] : h < 180 ? [0, chroma, secondary] : h < 240 ? [0, secondary, chroma] : h < 300 ? [secondary, 0, chroma] : [chroma, 0, secondary];
  return { r: byte((parts[0] + offset) * 255), g: byte((parts[1] + offset) * 255), b: byte((parts[2] + offset) * 255) };
}
/** Accept only an opaque HEX/RGB/HSL value. No CSS expressions, variables, URLs or alpha. */
export function parseColor(value: string): string | null {
  const hex = hexToRgb(value);
  if (hex) return rgbToHex(hex);
  const rgb = /^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$/i.exec(value.trim());
  if (rgb) {
    const [r, g, b] = rgb.slice(1).map(Number);
    return [r, g, b].every(channel => channel <= 255) ? rgbToHex({ r, g, b }) : null;
  }
  const hsl = /^hsl\(\s*([-+]?\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)%\s*,\s*(\d+(?:\.\d+)?)%\s*\)$/i.exec(value.trim());
  if (!hsl) return null;
  const [h, s, l] = hsl.slice(1).map(Number);
  return [h, s, l].every(Number.isFinite) && s <= 100 && l <= 100 ? rgbToHex(hslToRgb({ h, s, l })) : null;
}
export function displayColor(value: string, colorSpace: ColorSpace = "hex"): string {
  const rgb = hexToRgb(value);
  if (!rgb) return value;
  if (colorSpace === "rgb") return `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`;
  if (colorSpace === "hsl") {
    const hsl = rgbToHsl(rgb);
    return `hsl(${Math.round(hsl.h)}, ${Math.round(hsl.s)}%, ${Math.round(hsl.l)}%)`;
  }
  return rgbToHex(rgb).toUpperCase();
}
/** WCAG relative luminance contrast, used only to keep the value legible. */
export function swatchInk(value: string): "#ffffff" | "#323b4a" {
  const rgb = hexToRgb(value);
  if (!rgb) return "#323b4a";
  const linear = [rgb.r, rgb.g, rgb.b].map(channel => { const s = channel / 255; return s <= .04045 ? s / 12.92 : ((s + .055) / 1.055) ** 2.4; });
  const luminance = .2126 * linear[0] + .7152 * linear[1] + .0722 * linear[2];
  return (luminance + .05) / .05 >= 4.5 ? "#323b4a" : "#ffffff";
}
