/** Task metadata stays in the document; no account or notification service is required. */
export interface TodoTask {
  id: string;
  text: string;
  done: boolean;
  indent?: number;
  dueDate?: string;
  reminderTime?: string;
}

export const TODO_MAX_INDENT = 8;
export const taskIndent = (task: TodoTask) => Math.max(0, Math.min(TODO_MAX_INDENT, Math.floor(task.indent || 0)));

export function isTodoDate(value: unknown): value is string {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T12:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
export function isTodoTime(value: unknown): value is string {
  return typeof value === "string" && /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value);
}
export function isValidTodoMetadata(task: unknown): boolean {
  if (!task || typeof task !== "object") return false;
  const value = task as Record<string, unknown>;
  return (value.indent === undefined || (typeof value.indent === "number" && Number.isInteger(value.indent) && value.indent >= 0 && value.indent <= TODO_MAX_INDENT))
    && (value.dueDate === undefined || isTodoDate(value.dueDate))
    && (value.reminderTime === undefined || (isTodoTime(value.reminderTime) && isTodoDate(value.dueDate)));
}

function subtreeEnd(items: TodoTask[], index: number) {
  let end = index + 1;
  while (end < items.length && taskIndent(items[end]) > taskIndent(items[index])) end++;
  return end;
}

/** Keep children with their parent while indenting or moving a task. */
export function indentTodoTask<T extends TodoTask>(items: T[], id: string, direction: 1 | -1): T[] {
  const index = items.findIndex(task => task.id === id);
  if (index < 0) return items;
  const previous = index ? taskIndent(items[index - 1]) : -1;
  const current = taskIndent(items[index]);
  const end = subtreeEnd(items, index);
  const target = Math.max(0, Math.min(TODO_MAX_INDENT, current + direction, previous + 1));
  const deepest = Math.max(...items.slice(index, end).map(taskIndent));
  const delta = Math.min(target - current, TODO_MAX_INDENT - deepest);
  if (!delta) return items;
  return items.map((task, i) => i >= index && i < end ? { ...task, indent: taskIndent(task) + delta } : task);
}

/** Move the selected task and its nested children before another task. */
export function moveTodoTask<T extends TodoTask>(items: T[], id: string, beforeId: string | null): T[] {
  const index = items.findIndex(task => task.id === id);
  const target = beforeId === null ? items.length : items.findIndex(task => task.id === beforeId);
  if (index < 0 || target < 0) return items;
  const end = subtreeEnd(items, index);
  if (target >= index && target <= end) return items;
  const moved = items.slice(index, end);
  const rest = [...items.slice(0, index), ...items.slice(end)];
  const insertion = target > index ? target - moved.length : target;
  const previous = insertion ? taskIndent(rest[insertion - 1]) : -1;
  const desired = Math.min(taskIndent(moved[0]), previous + 1);
  const delta = desired - taskIndent(moved[0]);
  const next = [...rest.slice(0, insertion), ...moved.map(task => ({ ...task, indent: taskIndent(task) + delta })), ...rest.slice(insertion)];
  // Moving a parent away may leave its former next sibling under a missing level.
  let last = -1;
  return next.map(task => {
    const depth = Math.min(taskIndent(task), last + 1);
    last = depth;
    return depth === taskIndent(task) ? task : { ...task, indent: depth };
  });
}

export function removeTodoTask<T extends TodoTask>(items: T[], id: string): T[] {
  const index = items.findIndex(task => task.id === id);
  if (index < 0) return items;
  if (items.length === 1) return [{ ...items[0], text: "", done: false, indent: 0, dueDate: undefined, reminderTime: undefined }];
  const end = subtreeEnd(items, index);
  return items.filter(task => task.id !== id).map((task, i) => i >= index && i < end - 1 ? { ...task, indent: Math.max(0, taskIndent(task) - 1) } : task);
}
