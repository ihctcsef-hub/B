import { uid, updateBoard } from './model';
import type { Workspace, Card } from './model';
import { arrangeAllColumns } from './columns';

export function applyNoteContent(workspace: Workspace, boardId: string, noteId: string, content: { text: string; html: string }, height: number): Workspace {
  const source = workspace.boards[boardId]?.cards.find(card => card.id === noteId);
  if (source?.type !== 'note') return workspace;
  const boards = { ...workspace.boards };
  for (const [id, board] of Object.entries(boards)) {
    let changed = false;
    const cards = board.cards.map(card => {
      if (card.type !== 'note' || !(card.id === noteId || (source.syncedId && card.syncedId === source.syncedId))) return card;
      changed = true;
      return { ...card, ...content, height: card.id === noteId && !card.isDocument ? height : card.height };
    });
    if (changed) boards[id] = arrangeAllColumns({ ...board, cards });
  }
  return { ...workspace, boards, updatedAt: new Date().toISOString() };
}

export function createSyncedNote(workspace: Workspace, boardId: string, noteId: string): { workspace: Workspace; id?: string } {
  const note = workspace.boards[boardId]?.cards.find(card => card.id === noteId);
  if (note?.type !== 'note') return { workspace };
  const group = note.syncedId || uid(), id = uid();
  const copy: Card = { ...structuredClone(note), id, syncedId: group, parentId: undefined, x: note.x + 16, y: note.y + 16, z: Date.now() };
  return { workspace: updateBoard(workspace, boardId, board => ({ ...board, cards: [...board.cards.map(card => card.id === noteId ? { ...card, syncedId: group } : card), copy] })), id };
}

export interface SyncedNoteLocation {
  boardId: string;
  title: string;
  icon?: string;
  noteIds: string[];
  unsorted: boolean;
}

/** Deleted cards do not contribute to the visible copy count. A board appears
 * once even when it contains several copies, including copies in Unsorted. */
export function syncedNoteLocations(workspace: Workspace, syncedId: string | undefined): SyncedNoteLocation[] {
  return syncedId ? syncedNoteLocationIndex(workspace).get(syncedId) || [] : [];
}

export function syncedNoteLocationIndex(workspace: Workspace): Map<string,SyncedNoteLocation[]> {
  const index=new Map<string,SyncedNoteLocation[]>();
  for(const board of Object.values(workspace.boards)){
    const groups=new Map<string,SyncedNoteLocation>();
    for(const card of board.cards){
      if(card.type!=='note'||!card.syncedId)continue;
      let location=groups.get(card.syncedId);
      if(!location){location={boardId:board.id,title:board.title,icon:board.icon,noteIds:[],unsorted:false};groups.set(card.syncedId,location);}
      location.noteIds.push(card.id);location.unsorted||=card.unsorted===true;
    }
    for(const[group,location]of groups)index.set(group,[...(index.get(group)||[]),location]);
  }
  return index;
}

/** A restored reference rejoins its live group without changing its own layout,
 * labels, document title, or the recoverable snapshot kept in Trash. */
export function restoredSyncedNote(workspace: Workspace, card: Card): Card {
  if (card.type !== 'note' || !card.syncedId) return card;
  const live = Object.values(workspace.boards).flatMap(board => board.cards)
    .find(candidate => candidate.type === 'note' && candidate.syncedId === card.syncedId);
  return live?.type === 'note' ? { ...card, text: live.text, html: live.html } : card;
}
