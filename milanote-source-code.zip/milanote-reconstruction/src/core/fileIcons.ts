import assets from '../data/fileIconAssets.json';

export type ObservedFileIcon=keyof typeof assets.icons;
/** These four public visual assets were observed on the owned reference
 * fixtures. Unobserved extensions keep the independent generic fallback. */
export function observedFileIcon(file:{name:string;mime:string}):ObservedFileIcon|undefined{
  const extension=file.name.split('.').pop()?.toLowerCase();
  if(file.mime==='application/pdf'||extension==='pdf')return 'file-acrobat';
  if(['application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document'].includes(file.mime)||['doc','docx'].includes(extension||''))return 'file-word';
  if(file.mime==='text/plain'||extension==='txt')return 'file-plaintext';
  if(['application/zip','application/x-zip-compressed'].includes(file.mime)||extension==='zip')return 'file-zip';
}
export function observedFileIconAsset(file:{name:string;mime:string}){
  const id=observedFileIcon(file);return id?{id,...assets.icons[id]}:undefined;
}
