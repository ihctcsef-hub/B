/** A transient worksheet registry, shared by every consumer in one workspace
 * session. It is intentionally not serialized with card content: a fresh load
 * rebuilds compact worksheet indices from the tables loaded by that page. */
export interface FormulaTableIdentity { readonly id:string }
export interface FormulaWorkbookContext {
  readonly tableIndices:Readonly<Record<string,number>>;
  readonly sheetCount:number;
  readonly creationSlotReserved:boolean;
}
export interface TableEvaluationContext {
  readonly tableId?:string;
  readonly workbook?:FormulaWorkbookContext;
  /** Raw evaluator results always retain error codes. This controls display. */
  readonly errorDisplay?:'blank'|'codes';
}
const identity=(table:string|FormulaTableIdentity)=>typeof table==='string'?table:table.id;
const own=(indices:Readonly<Record<string,number>>,id:string)=>Object.prototype.hasOwnProperty.call(indices,id);
function snapshot(indices:Record<string,number>,sheetCount:number,creationSlotReserved=false):FormulaWorkbookContext {
  return Object.freeze({tableIndices:Object.freeze(indices),sheetCount,creationSlotReserved});
}
export function createFormulaWorkbook(loadedTables:readonly (string|FormulaTableIdentity)[]):FormulaWorkbookContext {
  const indices:Record<string,number>={},seen=new Set<string>();let count=0;
  for(const table of loadedTables){const id=identity(table);if(!id||seen.has(id))continue;seen.add(id);Object.defineProperty(indices,id,{value:++count,enumerable:true,configurable:true,writable:true});}
  return snapshot(indices,count);
}
/** Add loaded tables without mutating earlier snapshots. Newly created tables
 * reserve one extra transient slot on the first native creation in this page,
 * as measured on hard-reloaded empty and existing-table boards;
 * previously loaded/undo-restored tables keep their original identity/index.
 * Deletion never compacts this registry. Only createFormulaWorkbook (reload or
 * a replacement import) starts a new registry. */
export function reconcileFormulaWorkbook(previous:FormulaWorkbookContext,activeTables:readonly (string|FormulaTableIdentity)[],options:{createdTableIds?:readonly string[]}={}):FormulaWorkbookContext {
  const created=new Set(options.createdTableIds),indices={...previous.tableIndices};let count=previous.sheetCount,changed=false,reserved=previous.creationSlotReserved;
  for(const table of activeTables){const id=identity(table);if(!id||own(indices,id))continue;count+=created.has(id)&&!reserved?2:1;if(created.has(id))reserved=true;Object.defineProperty(indices,id,{value:count,enumerable:true,configurable:true,writable:true});changed=true;}
  return changed?snapshot(indices,count,reserved):previous;
}
export function formulaContextForTable(workbook:FormulaWorkbookContext,tableId:string,options:{errorDisplay?:'blank'|'codes'}={}):TableEvaluationContext {
  return Object.freeze({workbook,tableId,...options});
}
export function formulaSheetIndex(context?:TableEvaluationContext):number|undefined {
  // A standalone evaluation is one independent table. A shared context must
  // explicitly contain the requested table; silently returning 1 would hide a
  // stale context after an import or board switch.
  if(!context?.workbook)return 1;
  return context.tableId&&own(context.workbook.tableIndices,context.tableId)?context.workbook.tableIndices[context.tableId]:undefined;
}
