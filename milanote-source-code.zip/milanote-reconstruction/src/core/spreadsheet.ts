import {FullRuntime,supported} from './formulaRuntime';
import {FunctionRuntime} from './formulaFunctionRuntime';
import * as FormulaFunctions from "@formulajs/formulajs";
import { formulaDateText } from './formulaDateText';
import {installFormulaCompatibility} from './formulaCompatibility';
import { formulaSheetIndex } from './formulaWorkbook';
import type { TableEvaluationContext } from './formulaWorkbook';
export {createFormulaWorkbook,reconcileFormulaWorkbook,formulaContextForTable} from './formulaWorkbook';
export type {FormulaWorkbookContext,FormulaTableIdentity,TableEvaluationContext} from './formulaWorkbook';

export type TableCellType = "auto" | "number" | "currency" | "percentage" | "text" | "date" | "checkbox";
export const TABLE_DATE_FORMATS = ["none", "wordsLong", "wordsShort", "numericLong", "numericShort", "numericDashed", "weekday"] as const;
export const TABLE_TIME_FORMATS = ["none", "twelveHourSeconds", "twelveHour", "twentyFourHourSeconds", "twentyFourHour"] as const;
export interface TableCellMeta {
  type?: TableCellType;
  color?: string;
  align?: "left" | "center" | "right";
  verticalAlign?: "top" | "middle" | "bottom";
  bold?: boolean;
  italic?: boolean;
  decimals?: number;
  thousandsSeparator?: boolean;
  currency?: string;
  currencyDisplay?: "symbol" | "code" | "name";
  accounting?: boolean;
  dateFormat?: typeof TABLE_DATE_FORMATS[number];
  timeFormat?: typeof TABLE_TIME_FORMATS[number];
}
export type TableCellMetaMap = Record<string, TableCellMeta>;
export interface TableSelection { row: number; column: number; endRow?: number; endColumn?: number }
export interface TableData { rows: string[][]; meta: TableCellMetaMap }
type CellValue = string | number | boolean;
type FormulaValue = CellValue | CellValue[][];
const CELL_TYPES: TableCellType[] = ["auto", "number", "currency", "percentage", "text", "date", "checkbox"];
const ERROR = /^#(?:ERROR!|REF!|DIV\/0!|VALUE!|CYCLE!|NUM!|NAME\?|N\/A|NULL!)$/;
const record = (value: unknown): value is Record<string, unknown> => !!value && typeof value === "object" && !Array.isArray(value);

export const cellKey = (row: number, column: number) => `${row}:${column}`;
function columnName(column: number): string {
  let label = "";
  for (let n = column + 1; n > 0; n = Math.floor((n - 1) / 26)) label = String.fromCharCode(65 + (n - 1) % 26) + label;
  return label;
}
export const cellAddress = (row: number, column: number) => `${columnName(column)}${row + 1}`;
function reference(value: string): { row: number; column: number } | null {
  const match = /^\$?([A-Z]+)\$?([1-9]\d*)$/i.exec(value);
  if (!match) return null;
  let column = 0;
  for (const character of match[1].toUpperCase()) column = column * 26 + character.charCodeAt(0) - 64;
  const row = Number(match[2]) - 1;
  return Number.isSafeInteger(row) && Number.isSafeInteger(column) ? { row, column: column - 1 } : null;
}

export function normalizeTableMeta(value: unknown, rows?: string[][]): TableCellMetaMap {
  if (!record(value)) return {};
  const result: TableCellMetaMap = {};
  for (const [key, source] of Object.entries(value)) {
    if (!/^\d+:\d+$/.test(key) || !record(source)) continue;
    const [row, column] = key.split(":").map(Number);
    if (!Number.isSafeInteger(row) || !Number.isSafeInteger(column) || (rows && (row >= rows.length || column >= (rows[row]?.length || 0)))) continue;
    const cell: TableCellMeta = {};
    if (CELL_TYPES.includes(source.type as TableCellType)) cell.type = source.type as TableCellType;
    if (typeof source.color === "string" && /^#[\da-f]{3}(?:[\da-f]{3})?$/i.test(source.color)) cell.color = source.color;
    if (["left", "center", "right"].includes(source.align as string)) cell.align = source.align as TableCellMeta["align"];
    if (["top", "middle", "bottom"].includes(source.verticalAlign as string)) cell.verticalAlign = source.verticalAlign as TableCellMeta["verticalAlign"];
    if (typeof source.bold === "boolean") cell.bold = source.bold;
    if (typeof source.italic === "boolean") cell.italic = source.italic;
    if (Number.isInteger(source.decimals) && Number(source.decimals) >= 0 && Number(source.decimals) <= 10) cell.decimals = Number(source.decimals);
    if (typeof source.thousandsSeparator === "boolean") cell.thousandsSeparator = source.thousandsSeparator;
    if (typeof source.currency === "string" && /^[A-Z]{3}$/.test(source.currency)) cell.currency = source.currency;
    if (["symbol", "code", "name"].includes(source.currencyDisplay as string)) cell.currencyDisplay = source.currencyDisplay as TableCellMeta["currencyDisplay"];
    if (typeof source.accounting === "boolean") cell.accounting = source.accounting;
    if (TABLE_DATE_FORMATS.includes(source.dateFormat as TableCellMeta["dateFormat"] & string)) cell.dateFormat = source.dateFormat as TableCellMeta["dateFormat"];
    if (TABLE_TIME_FORMATS.includes(source.timeFormat as TableCellMeta["timeFormat"] & string)) cell.timeFormat = source.timeFormat as TableCellMeta["timeFormat"];
    if (Object.keys(cell).length) result[key] = cell;
  }
  return result;
}
export function isValidTableMeta(value: unknown, rows?: string[][]): value is TableCellMetaMap {
  if (!record(value)) return false;
  return Object.entries(value).every(([key, cell]) => /^\d+:\d+$/.test(key) &&
    key.split(":").every((part) => Number.isSafeInteger(Number(part))) &&
    (!rows || (Number(key.split(":")[0]) < rows.length && Number(key.split(":")[1]) < (rows[Number(key.split(":")[0])]?.length || 0))) && record(cell) &&
    Object.keys(cell).every((field) => ["type", "color", "align", "verticalAlign", "bold", "italic", "decimals", "thousandsSeparator", "currency", "currencyDisplay", "accounting", "dateFormat", "timeFormat"].includes(field)) &&
    (cell.type === undefined || CELL_TYPES.includes(cell.type as TableCellType)) &&
    (cell.color === undefined || (typeof cell.color === "string" && /^#[\da-f]{3}(?:[\da-f]{3})?$/i.test(cell.color))) &&
    (cell.align === undefined || ["left", "center", "right"].includes(cell.align as string)) &&
    (cell.verticalAlign === undefined || ["top", "middle", "bottom"].includes(cell.verticalAlign as string)) &&
    (cell.bold === undefined || typeof cell.bold === "boolean") &&
    (cell.italic === undefined || typeof cell.italic === "boolean") &&
    (cell.decimals === undefined || (Number.isInteger(cell.decimals) && Number(cell.decimals) >= 0 && Number(cell.decimals) <= 10)) &&
    (cell.thousandsSeparator === undefined || typeof cell.thousandsSeparator === "boolean") &&
    (cell.currency === undefined || (typeof cell.currency === "string" && /^[A-Z]{3}$/.test(cell.currency))) &&
    (cell.currencyDisplay === undefined || ["symbol", "code", "name"].includes(cell.currencyDisplay as string)) &&
    (cell.accounting === undefined || typeof cell.accounting === "boolean") &&
    (cell.dateFormat === undefined || TABLE_DATE_FORMATS.includes(cell.dateFormat as TableCellMeta["dateFormat"] & string)) &&
    (cell.timeFormat === undefined || TABLE_TIME_FORMATS.includes(cell.timeFormat as TableCellMeta["timeFormat"] & string)));
}

const formulaErrorMessage=(code:string)=>code==='#DIV/0!'?"Numbers can't be divided by zero":code;
class FormulaError extends Error {
  constructor(code:string,readonly detail=formulaErrorMessage(code)){super(code);}
}
const fail = (error = "#ERROR!",detail=formulaErrorMessage(error)): never => { throw new FormulaError(error,detail); };
const MAX_FORMULA_LENGTH = 8192;
const MAX_FORMULA_TOKENS = 4096;
const MAX_FORMULA_DEPTH = 128;
const MAX_RANGE_CELLS = 100000;
const MAX_OUTPUT_LENGTH = 1000000;
function scalar(value: FormulaValue): CellValue {
  if (Array.isArray(value)) return fail("#VALUE!");
  return value;
}
function numeric(value: FormulaValue): number {
  const cell = scalar(value);
  if (typeof cell === "number") return Number.isFinite(cell) ? cell : fail("#NUM!");
  if (typeof cell === "boolean") return cell ? 1 : 0;
  if (!cell.trim()) return 0;
  const number = Number(cell.replace(/,/g, ""));
  return Number.isFinite(number) ? number : fail("#VALUE!","Value cannot be coerced to number");
}
function boolean(value: FormulaValue): boolean {
  const cell = scalar(value);
  if (typeof cell === "boolean") return cell;
  if (typeof cell === "number") return cell !== 0;
  if (!cell.trim() || /^false$/i.test(cell)) return false;
  if (/^true$/i.test(cell)) return true;
  return fail("#VALUE!","Wrong type of argument");
}
const textValue = (value: FormulaValue) => {
  const cell = scalar(value);
  return typeof cell === "boolean" ? cell ? "TRUE" : "FALSE" : String(cell);
};
function literal(raw: string): CellValue {
  const value = raw.trim();
  if (!value) return "";
  if (/^(?:true|false)$/i.test(value)) return value.toLowerCase() === "true";
  if (/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(value)) return Number(value);
  if (/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)%$/.test(value)) return Number(value.slice(0, -1)) / 100;
  return raw;
}

interface Token { type: "number" | "ref" | "word" | "string" | "symbol" | "error"; text: string }
function tokenize(source: string): Token[] {
  if (source.length > MAX_FORMULA_LENGTH) return fail("#ERROR!");
  const tokens: Token[] = [];
  let index = 0;
  while (index < source.length) {
    if (tokens.length >= MAX_FORMULA_TOKENS) return fail("#ERROR!");
    const rest = source.slice(index);
    const space = /^\s+/.exec(rest);
    if (space) { index += space[0].length; continue; }
    const number = /^(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?/i.exec(rest);
    if (number) { tokens.push({ type: "number", text: number[0] }); index += number[0].length; continue; }
    const ref = /^\$?[A-Z]+\$?[1-9]\d*\b/i.exec(rest);
    // LOG10(...) and ATAN2(...) are functions, although they resemble A1 addresses.
    if (ref && !/^\s*\(/.test(rest.slice(ref[0].length)) && !/[\w.]/.test(rest[ref[0].length] || "")) {
      tokens.push({ type: "ref", text: ref[0] }); index += ref[0].length; continue;
    }
    const word = /^[a-z_][a-z0-9_.]*/i.exec(rest);
    if (word) { tokens.push({ type: "word", text: word[0].toUpperCase() }); index += word[0].length; continue; }
    const error = /^#(?:REF!|DIV\/0!|ERROR!|VALUE!|CYCLE!|NUM!|NAME\?|N\/A|NULL!)/i.exec(rest);
    if (error) { tokens.push({ type: "error", text: error[0].toUpperCase() }); index += error[0].length; continue; }
    if (rest[0] === '"') {
      let text = "", closed = false;
      index++;
      while (index < source.length) {
        if (source[index] === '"') {
          if (source[index + 1] === '"') { text += '"'; index += 2; continue; }
          index++; closed = true; break;
        }
        text += source[index++];
      }
      if (!closed) fail();
      tokens.push({ type: "string", text }); continue;
    }
    const comparison = /^(?:<=|>=|<>)/.exec(rest);
    if (comparison) { tokens.push({ type: "symbol", text: comparison[0] }); index += comparison[0].length; continue; }
    if ("+-*/^%():,;&=<>".includes(rest[0])) { tokens.push({ type: "symbol", text: rest[0] }); index++; continue; }
    fail();
  }
  return tokens;
}

type FormulaNode =
  | { kind: "literal"; value: CellValue }
  | { kind: "error"; value: string }
  | { kind: "ref"; row: number; column: number }
  | { kind: "range"; start: { row: number; column: number }; end: { row: number; column: number } }
  | { kind: "unary"; operator: string; value: FormulaNode }
  | { kind: "binary"; operator: string; left: FormulaNode; right: FormulaNode }
  | { kind: "call"; name: string; args: FormulaNode[] };

type SpreadsheetFunction = (...args: unknown[]) => unknown;
const functions = new Map<string, SpreadsheetFunction>();
function collectFunctions(namespace: unknown, prefix = "", depth = 0) {
  if ((!namespace || (typeof namespace !== "object" && typeof namespace !== "function")) || depth > 4) return;
  for (const [name, value] of Object.entries(namespace)) {
    if (!/^[A-Z0-9][A-Z0-9_]*$/.test(name)) continue;
    const fullName = prefix + name;
    if (typeof value === "function") functions.set(fullName, value as SpreadsheetFunction);
    collectFunctions(value, fullName + ".", depth + 1);
  }
}
collectFunctions(FormulaFunctions);
installFormulaCompatibility(functions);
// FormulaJS exposes these legacy names as namespaces; their unqualified Excel forms use the sample variant.
for (const [alias, target] of Object.entries({ STDEV: "STDEV.S", VAR: "VAR.S", CONFIDENCE:"CONFIDENCE.NORM", POISSON:"POISSON.DIST", TDIST2T:"T.DIST.2T", TINV2T:"T.INV.2T", WEIBULL:"WEIBULL.DIST" })) {
  const implementation = functions.get(target);
  if (implementation) functions.set(alias, implementation);
}
functions.set('ISBINARY',value=>/^[01]+$/.test(String(value).trim()));
functions.set('COUNTUNIQUE',(...values)=>new Set(values.flat(Infinity).filter(value=>value!=='')).size);
// Milanote's published SPLIT returns one space-separated token by zero-based index, not an array spill.
functions.set('SPLIT',(value,index)=>typeof index==='number'&&Number.isInteger(index)&&index>=0?String(value).split(' ')[index]??'':'');
const numericText=functions.get('TEXT');
if(numericText)functions.set('TEXT',(value,format)=>formulaDateText(value,format)??numericText(value,format));
// Array-spill functions require a separate spill model. Do not run expensive constructors for unsupported results.
const ARRAY_FUNCTIONS = new Set(["MUNIT", "MMULT", "TRANSPOSE", "FREQUENCY", "GROWTH", "LINEST", "LOGEST", "TREND", "MODE.MULT", "MODEMULT", "SORT", "UNIQUE"]);
export const tableFormulaNames: readonly string[] = Object.freeze([...new Set([...functions.keys(),'ISFORMULA','FORMULATEXT','ISREF','SHEET','SHEETS'])]
  .filter(name => !ARRAY_FUNCTIONS.has(name)).sort());

function formulaResult(value: unknown): CellValue {
  if (value instanceof Error) return fail(ERROR.test(value.message) ? value.message : /not implemented/i.test(value.message) ? "#NAME?" : "#ERROR!");
  if (value instanceof Date) {
    if (!Number.isFinite(value.getTime())) return fail("#VALUE!");
    // Preserve calendar components across browser time zones; the document stores Excel-style serial dates.
    return (Date.UTC(value.getFullYear(), value.getMonth(), value.getDate(), value.getHours(), value.getMinutes(), value.getSeconds(), value.getMilliseconds()) - Date.UTC(1899, 11, 30)) / 86400000;
  }
  if (typeof value === "number") return Number.isFinite(value) ? value : fail("#NUM!");
  if (typeof value === "boolean") return value;
  if (typeof value === "string") return value.length <= MAX_OUTPUT_LENGTH ? value : fail("#VALUE!");
  return fail("#VALUE!");
}
function compare(left: FormulaValue, right: FormulaValue, operator: string): boolean {
  let a = scalar(left), b = scalar(right);
  // Spreadsheet comparison is case-insensitive. Blank cells compare as zero with numbers.
  if (a === "" && typeof b === "number") a = 0;
  if (b === "" && typeof a === "number") b = 0;
  if (typeof a === "string") a = a.toLocaleLowerCase("en-US");
  if (typeof b === "string") b = b.toLocaleLowerCase("en-US");
  const rank = (value: CellValue) => typeof value === "number" ? 0 : typeof value === "string" ? 1 : 2;
  const result = typeof a !== typeof b ? Math.sign(rank(a) - rank(b)) : a < b ? -1 : a > b ? 1 : 0;
  return operator === "=" ? result === 0 : operator === "<>" ? result !== 0 : operator === "<" ? result < 0 : operator === ">" ? result > 0 : operator === "<=" ? result <= 0 : result >= 0;
}

/** Parses a restricted spreadsheet expression. Formula text is never passed to eval or Function. */
function parseFormula(source: string, read: (row: number, column: number) => CellValue, rowCount: number, columnCount: number, currentRow: number, currentColumn: number, sourceAt:(row:number,column:number)=>{raw:string;isFormula:boolean}|null,context:TableEvaluationContext|undefined,runtime:FunctionRuntime): CellValue {
  const tokens = tokenize(source);
  let cursor = 0, parserDepth = 0;
  const take = (value: string) => tokens[cursor]?.text === value ? (cursor++, true) : false;
  const binary = (operator: string, left: FormulaNode, right: FormulaNode): FormulaNode => ({ kind: "binary", operator, left, right });
  function expression(): FormulaNode {
    if (++parserDepth > MAX_FORMULA_DEPTH) return fail("#ERROR!");
    let value = concat();
    while (["=", "<>", "<", ">", "<=", ">="].includes(tokens[cursor]?.text)) value = binary(tokens[cursor++].text, value, concat());
    parserDepth--;
    return value;
  }
  function concat(): FormulaNode {
    let value = sum();
    while (take("&")) value = binary("&", value, sum());
    return value;
  }
  function sum(): FormulaNode {
    let value = term();
    while (["+", "-"].includes(tokens[cursor]?.text)) value = binary(tokens[cursor++].text, value, term());
    return value;
  }
  function term(): FormulaNode {
    let value=power(0);
    while(['*','/'].includes(tokens[cursor]?.text))value=binary(tokens[cursor++].text,value,power(0));
    return value;
  }
  function unary(depth=0):FormulaNode {
    if(depth>MAX_FORMULA_DEPTH)return fail('#ERROR!');
    if(['+','-'].includes(tokens[cursor]?.text))return{kind:'unary',operator:tokens[cursor++].text,value:unary(depth+1)};
    let value=atom();while(take('%'))value={kind:'unary',operator:'%',value};return value;
  }
  function power(depth:number):FormulaNode {
    let value=unary(depth);while(take('^'))value=binary('^',value,unary(depth+1));return value;
  }
  function atom(): FormulaNode {
    const token = tokens[cursor++];
    if (!token) return fail();
    if (token.type === "number") return { kind: "literal", value: Number(token.text) };
    if (token.type === "string") return { kind: "literal", value: token.text };
    if (token.type === "error") return { kind: "error", value: token.text };
    if (token.text === "(") { const value = expression(); if (!take(")")) fail(); return value; }
    if (token.type === "ref") {
      const start = reference(token.text);
      if (!start) return fail("#REF!");
      if (take(":")) {
        const endToken = tokens[cursor++], end = endToken?.type === "ref" ? reference(endToken.text) : null;
        if (!end) return fail("#REF!");
        return { kind: "range", start, end };
      }
      return { kind: "ref", ...start };
    }
    if (token.type === "word") {
      if (["TRUE", "FALSE"].includes(token.text) && tokens[cursor]?.text !== "(") return { kind: "literal", value: token.text === "TRUE" };
      if (!take("(")) return fail("#NAME?");
      const args: FormulaNode[] = [];
      if (!take(")")) {
        do {
          args.push([",", ";", ")"].includes(tokens[cursor]?.text) ? { kind: "literal", value: "" } : expression());
        } while (take(",") || take(";"));
        if (!take(")")) fail();
      }
      return { kind: "call", name: token.text, args };
    }
    return fail();
  }
  const root = expression();
  if (cursor !== tokens.length) return fail();
  if (root.kind === "range") return fail("#VALUE!");
  let steps = 0;
  function evaluate(node: FormulaNode, depth = 0): FormulaValue {
    if (++steps > MAX_FORMULA_TOKENS * 4 || depth > MAX_FORMULA_DEPTH) return fail("#ERROR!");
    const next = (child: FormulaNode) => evaluate(child, depth + 1);
    if (node.kind === "literal") return typeof node.value === "number" ? formulaResult(node.value) : node.value;
    if (node.kind === "error") return fail(node.value);
    if (node.kind === "ref") return scalar(read(node.row, node.column));
    if (node.kind === "range") {
      const minRow = Math.min(node.start.row, node.end.row), maxRow = Math.max(node.start.row, node.end.row);
      const minColumn = Math.min(node.start.column, node.end.column), maxColumn = Math.max(node.start.column, node.end.column);
      if ((maxRow - minRow + 1) * (maxColumn - minColumn + 1) > MAX_RANGE_CELLS) return fail("#REF!");
      const matrix: CellValue[][] = [];
      for (let row = minRow; row <= maxRow; row++) {
        const values: CellValue[] = [];
        for (let column = minColumn; column <= maxColumn; column++) values.push(scalar(read(row, column)));
        matrix.push(values);
      }
      return matrix;
    }
    if (node.kind === "unary") {
      const value = numeric(next(node.value));
      return node.operator === "-" ? -value : node.operator === "%" ? value / 100 : value;
    }
    if (node.kind === "binary") {
      const left = next(node.left), right = next(node.right);
      if (["=", "<>", "<", ">", "<=", ">="].includes(node.operator)) return compare(left, right, node.operator);
      if (node.operator === "&") return formulaResult(textValue(left) + textValue(right));
      const a = numeric(left), b = numeric(right);
      if (node.operator === "/" && b === 0) return fail("#DIV/0!");
      return formulaResult(node.operator === "+" ? a + b : node.operator === "-" ? a - b : node.operator === "*" ? a * b : node.operator === "/" ? a / b : a ** b);
    }
    const argument = (index: number, fallback: CellValue = "") => node.args[index] ? next(node.args[index]) : fallback;
    const exactArity:Record<string,[number,number]>={IF:[2,3],IFERROR:[2,2],IFNA:[2,2],ISERROR:[1,1],ISERR:[1,1],ISNA:[1,1],ISREF:[1,1],ISFORMULA:[1,1],FORMULATEXT:[1,1],ISBLANK:[1,1],ISLOGICAL:[1,1],ISNONTEXT:[1,1],ISNUMBER:[1,1],ISTEXT:[1,1],ROW:[0,1],COLUMN:[0,1]};
    const arity=exactArity[node.name];if(arity&&(node.args.length<arity[0]||node.args.length>arity[1])||node.name==='SWITCH'&&node.args.length<3)return fail('#N/A','Wrong number of arguments');
    if(['ISBLANK','ISLOGICAL','ISNONTEXT','ISNUMBER','ISTEXT'].includes(node.name)){try{argument(0);}catch(error){if(error instanceof FormulaError)return node.name==='ISNONTEXT';throw error;}}
    if(node.name==='SHEET'||node.name==='SHEETS'){
      if(node.args.length>1)return fail('#N/A','Wrong number of arguments');
      const value=node.args[0];
      if(value?.kind==='error')return fail(value.value);
      if(value&&value.kind!=='ref'&&value.kind!=='range'){next(value);return node.name==='SHEET'?fail('#N/A','Sheet does not exist'):fail('#VALUE!','Cell reference expected');}
      const index=formulaSheetIndex(context);
      if(index===undefined)return fail('#REF!');
      return node.name==='SHEET'?index:value?1:context?.workbook?.sheetCount??1;
    }
    if(node.name==='ISFORMULA'||node.name==='FORMULATEXT'){
      const value=node.args[0],ref=value?.kind==='range'?value.start:value?.kind==='ref'?value:null;
      if(!ref){if(value)next(value);return fail('#VALUE!','Cell reference expected');}
      const source=sourceAt(ref.row,ref.column);
      if(node.name==='ISFORMULA')return source?.isFormula===true;
      return source?.isFormula?source.raw:fail('#N/A','Expected formula');
    }
    // The reference's ISREF tests the #REF! error value; it is not Excel's reference-argument predicate.
    if(node.name==='ISREF'){
      const value=node.args[0];
      if(value?.kind==='ref'&&!sourceAt(value.row,value.column))return false;
      try{argument(0);return false;}catch(error){if(error instanceof FormulaError)return error.message==='#REF!';throw error;}
    }
    if (node.name === "IF") return boolean(argument(0)) ? argument(1, 0) : argument(2, false);
    if (node.name === "IFERROR" || node.name === "IFNA") {
      try { return argument(0); }
      catch (error) { if (error instanceof FormulaError && (node.name === "IFERROR" || error.message === "#N/A")) return argument(1); throw error; }
    }
    if (["ISERROR", "ISERR", "ISNA", "ERROR.TYPE"].includes(node.name)) {
      let caught: FormulaError | null = null;
      try { argument(0); }
      catch (error) { if (!(error instanceof FormulaError)) throw error; caught = error; }
      if (node.name === "ERROR.TYPE") return caught
        ? ["#NULL!", "#DIV/0!", "#VALUE!", "#REF!", "#NAME?", "#NUM!", "#N/A", "#CYCLE!"].indexOf(caught.message) + 1 || fail("#N/A")
        : fail("#N/A");
      return !!caught && (node.name === "ISERROR" || (node.name === "ISERR" ? caught.message !== "#N/A" : caught.message === "#N/A"));
    }
    if (node.name === "IFS") {
      for (let index = 0; index < node.args.length; index += 2) if (boolean(argument(index))) return argument(index + 1);
      return fail("#N/A");
    }
    if (node.name === "SWITCH") {
      const value = argument(0);
      for (let index = 1; index + 1 < node.args.length; index += 2) if (compare(value, argument(index), "=")) return argument(index + 1);
      return node.args.length % 2 === 0 ? argument(node.args.length - 1) : fail("#N/A");
    }
    if (node.name === "ROW" || node.name === "COLUMN") {
      const value = node.args[0], axis = node.name === "ROW" ? "row" : "column";
      if (!value) return (axis === "row" ? currentRow : currentColumn) + 1;
      if (value.kind === "ref") return value[axis] + 1;
      if (value.kind === "range") return value.start[axis] + 1;
      if(value)next(value);return fail("#VALUE!","Cell reference expected");
    }
    if (ARRAY_FUNCTIONS.has(node.name)) return fail("#VALUE!");
    const implementation = functions.get(node.name);
    if (!implementation) return fail("#NAME?");
    if(node.name==='COUNTUNIQUE'){
      const readUnique=(row:number,column:number)=>{try{return read(row,column);}catch(error){if(error instanceof FormulaError)return new Error(error.message);throw error;}};
      const uniqueValues=node.args.map(arg=>{if(arg.kind==='range'){const result:(CellValue|Error)[][]=[];for(let r=Math.min(arg.start.row,arg.end.row);r<=Math.max(arg.start.row,arg.end.row);r++){const row:(CellValue|Error)[]=[];for(let c=Math.min(arg.start.column,arg.end.column);c<=Math.max(arg.start.column,arg.end.column);c++)row.push(readUnique(r,c));result.push(row);}return result;}try{return next(arg);}catch(error){if(error instanceof FormulaError)return new Error(error.message);throw error;}});
      const result=runtime.run(node.name,uniqueValues,node.args.map(arg=>{if(arg.kind==='ref')return (sourceAt(arg.row,arg.column)?.raw??'').trim()==='';if(arg.kind==='range'){const result:boolean[][]=[];for(let r=Math.min(arg.start.row,arg.end.row);r<=Math.max(arg.start.row,arg.end.row);r++){const row:boolean[]=[];for(let c=Math.min(arg.start.column,arg.end.column);c<=Math.max(arg.start.column,arg.end.column);c++)row.push((sourceAt(r,c)?.raw??'').trim()==='');result.push(row);}return result;}return false;}));if(result.error)return fail(result.error.code,result.error.message);return formulaResult(result.value);
    }
    const values = node.args.map(next);
    const limit = (index: number, maximum: number, minimum = 0) => {
      if (values[index] === undefined) return;
      const value = numeric(values[index]);
      if (value < minimum || value > maximum) fail("#NUM!");
    };
    if (node.name === "REPT" && (numeric(values[1] ?? 0) < 0 || numeric(values[1] ?? 0) > MAX_OUTPUT_LENGTH || textValue(values[0] ?? "").length * numeric(values[1] ?? 0) > MAX_OUTPUT_LENGTH)) return fail("#VALUE!");
    if (node.name === "FACT") limit(0, 170);
    if (node.name === "FACTDOUBLE") limit(0, 300);
    if (["COMBIN", "COMBINA", "PERMUT"].includes(node.name)) { limit(0, 170); limit(1, 170); if (node.name === "COMBINA" && numeric(values[0] ?? 0) + numeric(values[1] ?? 0) > 171) return fail("#NUM!"); }
    if (node.name === "MULTINOMIAL") {
      const numbers = values.flat(2).map(value => numeric(value));
      if (numbers.some(value => value < 0) || numbers.reduce((a, b) => a + b, 0) > 170) return fail("#NUM!");
    }
    if (node.name === "BASE") limit(2, MAX_OUTPUT_LENGTH);
    if (/^(?:BIN|DEC|HEX|OCT)2(?:BIN|DEC|HEX|OCT)$/.test(node.name)) limit(1, 100);
    if (node.name === "ROMAN") limit(0, 3999);
    if (/^BESSEL[IJYK]$/.test(node.name)) limit(1, 1000);
    if (["DB", "DDB"].includes(node.name)) limit(3, 10000);
    if (["CUMIPMT", "CUMPRINC"].includes(node.name)) { limit(3, 10000); limit(4, 10000); }
    if (node.name === "LCM" && values.flat(2).some(value => Math.abs(numeric(value)) > 1000000000)) return fail("#NUM!");
    if (["WORKDAY", "WORKDAY.INTL", "WORKDAYINTL"].includes(node.name)) limit(1, 10000, -10000);
    if (["NETWORKDAYS", "NETWORKDAYS.INTL", "NETWORKDAYSINTL"].includes(node.name)) {
      const serial = (value: FormulaValue) => typeof value === "number" ? value : new Date(textValue(value)).getTime() / 86400000;
      const days = Math.abs(serial(values[1]) - serial(values[0]));
      const holidays = values[node.name === "NETWORKDAYS" ? 2 : 3];
      const holidayCount = Array.isArray(holidays) ? holidays.flat().length : holidays === undefined ? 0 : 1;
      if (days > 100000 || days * (holidayCount + 1) > 1000000) return fail("#NUM!");
    }
    if(runtime.has(node.name)){
      const blanks=node.args.map(arg=>{if(arg.kind==='ref')return (sourceAt(arg.row,arg.column)?.raw??'').trim()==='';if(arg.kind==='range'){const result:boolean[][]=[];for(let r=Math.min(arg.start.row,arg.end.row);r<=Math.max(arg.start.row,arg.end.row);r++){const row:boolean[]=[];for(let c=Math.min(arg.start.column,arg.end.column);c<=Math.max(arg.start.column,arg.end.column);c++)row.push((sourceAt(r,c)?.raw??'').trim()==='');result.push(row);}return result;}return false;});
      const result=runtime.run(node.name,values,blanks);if(result.error)return fail(result.error.code,result.error.message);return formulaResult(result.value);
    }
    // FormulaJS receives only immutable-by-convention scalar/array copies, never source documents or objects.
    try { return formulaResult(implementation(...values)); }
    catch (error) { if (error instanceof FormulaError) throw error; return fail("#ERROR!"); }
  }
  return formulaResult(scalar(evaluate(root)));
}

export interface TableCellEvaluation {
  value:CellValue;
  display:string;
  error?:{code:string;message:string};
}
function legacyEvaluator(rows: string[][], meta: TableCellMetaMap = {},context?:TableEvaluationContext) {
  const runtime=new FunctionRuntime();
  const cache = new Map<string, CellValue>(), visiting = new Set<string>(),errors=new Map<string,FormulaError>();
  const columnCount = Math.max(0, ...rows.map((row) => row.length));
  function read(row: number, column: number): CellValue {
    if(row<0||column<0)return "#REF!";if(row>=rows.length||column>=columnCount)return "";
    const key = cellKey(row, column);
    if (cache.has(key)) return cache.get(key)!;
    if (visiting.has(key)) return "#CYCLE!";
    const raw = rows[row]?.[column] || "";
    if (meta[key]?.type === "text") return raw;
    if (!raw.trimStart().startsWith("=")) return literal(raw);
    visiting.add(key);
    let result: CellValue;
    try { result = parseFormula(raw.trimStart().slice(1),(row,column)=>{
      if(row<0||column<0)return fail('#REF!');if(row>=rows.length||column>=columnCount)return '';
      const key=cellKey(row,column);if(visiting.has(key))return fail('#CYCLE!');
      const value=read(row,column),detail=errors.get(key);
      if(detail)throw detail;
      const raw=rows[row]?.[column]||'';
      // The measured reference coerces a raw error token when that cell is
      // referenced, while quoted formula literals remain ordinary text.
      if(!raw.trimStart().startsWith('=')&&typeof value==='string'&&ERROR.test(value))return fail(value);
      return value;
    }, rows.length, columnCount, row, column,(row,column)=>{
      if(row<0||column<0||row>=rows.length||column>=columnCount)return null;
      const raw=rows[row]?.[column]||'';
      return {raw,isFormula:meta[cellKey(row,column)]?.type!=='text'&&raw.trimStart().startsWith('=')};
    },context,runtime); }
    catch (error) { const issue=error instanceof FormulaError?error:new FormulaError("#ERROR!");errors.set(key,issue);result=issue.message; }
    visiting.delete(key); cache.set(key, result);
    return result;
  }
  function details(row:number,column:number):TableCellEvaluation {
    const value=read(row,column),raw=rows[row]?.[column]||'',style=meta[cellKey(row,column)];
    const isError=style?.type!=='text'&&errors.has(cellKey(row,column));
    const error=isError?{code:String(value),message:errors.get(cellKey(row,column))?.detail??String(value)}:undefined;
    return {value,display:error&&context?.errorDisplay==='blank'?'':formatValue(value,raw,style),...(error?{error}:{})};
  }
  return {read,details,dispose:()=>runtime.dispose()};
}

function evaluator(rows:string[][],meta:TableCellMetaMap={},context?:TableEvaluationContext){
 const legacy=legacyEvaluator(rows,meta,context);
 const expressions=rows.flat().filter(v=>v.trimStart().startsWith('='));
 // Local-only FormulaJS names and existing resource limits keep their compatibility path.
 // Supported native formulas are evaluated as a whole grid to preserve literal/reference argument provenance.
 const fallback=formulaSheetIndex(context)===undefined||expressions.some(v=>/\b(?:WORKDAY(?:\.INTL)?|NETWORKDAYS(?:\.INTL)?)\s*\(/i.test(v)||v.length>8192||/\({65}/.test(v)||/:[A-Z]+[1-9]\d{7,}/i.test(v)||[...v.matchAll(/"(?:[^"\\]|\\.)*"|([A-Z][A-Z0-9_.]*)\s*\(/gi)].some(m=>m[1]&&!supported.has(m[1].toUpperCase())));
 let h:FullRuntime|undefined;
 function details(row:number,column:number):TableCellEvaluation{
  const raw=rows[row]?.[column]||'',style=meta[cellKey(row,column)];
  if(fallback||!raw.trimStart().startsWith('=')||style?.type==='text')return legacy.details(row,column);
  try{const result=(h??=new FullRuntime(rows,meta,context)).read(row,column),value=result.value as CellValue,error=result.error;return{value,display:error&&context?.errorDisplay==='blank'?'':formatValue(value,raw,style),...(error?{error}:{})};}
  catch{return legacy.details(row,column);}
 }
 return{read:(r:number,c:number)=>details(r,c).value,details,dispose(){h?.dispose();legacy.dispose();}};
}

export function evaluateTableCell(rows: string[][], row: number, column: number, meta: TableCellMetaMap = {},context?:TableEvaluationContext): CellValue {
  const engine=evaluator(rows,meta,context);try{return engine.read(row,column);}finally{engine.dispose();}
}
export function evaluateTableCellDetails(rows:string[][],row:number,column:number,meta:TableCellMetaMap={},context?:TableEvaluationContext):TableCellEvaluation {
  const engine=evaluator(rows,meta,context);try{return engine.details(row,column);}finally{engine.dispose();}
}
export function evaluateTableDetails(rows:string[][],meta:TableCellMetaMap={},context?:TableEvaluationContext):TableCellEvaluation[][] {
  const engine=evaluator(rows,meta,context);try{return rows.map((row,ri)=>row.map((_,ci)=>engine.details(ri,ci)));}finally{engine.dispose();}
}
function formatValue(value: CellValue, raw: string, meta?: TableCellMeta): string {
  if (meta?.type === "text") return raw;
  if (typeof value === "string" && ERROR.test(value)) return value;
  if (meta?.type === "checkbox") return value === true || value === 1 || /^\s*(?:true|yes|1|✓|☑)\s*$/i.test(String(value)) ? "☑" : "☐";
  if (value === "") return "";
  if (meta?.type === "date") {
    const iso=/^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/.exec(String(value));
    const date = typeof value === "number" ? new Date(Date.UTC(1899, 11, 30) + value * 86400000)
      : iso ? new Date(Date.UTC(+iso[1],+iso[2]-1,+iso[3],+(iso[4]||0),+(iso[5]||0),+(iso[6]||0))) : new Date(String(value));
    if (Number.isFinite(date.getTime())) {
      const dateFormat=meta.dateFormat||'wordsShort',timeFormat=meta.timeFormat||'none';
      const dateOptions:Intl.DateTimeFormatOptions={timeZone:'UTC',year:'numeric',month:'short',day:'numeric'};
      if(dateFormat==='wordsLong'||dateFormat==='weekday')dateOptions.month='long';
      if(dateFormat==='weekday')dateOptions.weekday='long';
      if(['numericLong','numericShort','numericDashed'].includes(dateFormat))dateOptions.month='numeric';
      if(dateFormat==='numericShort')dateOptions.year='2-digit';
      let formattedDate=dateFormat==='none'?'':date.toLocaleDateString('en-US',dateOptions);
      if(dateFormat==='numericDashed')formattedDate=formattedDate.replace(/\//g,'-');
      const formattedTime=timeFormat==='none'?'':date.toLocaleTimeString('en-US',{timeZone:'UTC',hour:'numeric',minute:'2-digit',...(timeFormat.endsWith('Seconds')?{second:'2-digit'}:{}),hourCycle:timeFormat.startsWith('twelve')?'h12':'h23'});
      return formattedDate&&formattedTime?`${formattedDate} (${formattedTime})`:formattedDate||formattedTime;
    }
  }
  const number = typeof value === "number" ? value : typeof value === "string" && /^[\s$€£+-]*[\d,.]+\s*$/.test(value) ? Number(value.replace(/[$€£,\s]/g, "")) : NaN;
  if (Number.isFinite(number)) {
    const decimals=Number.isInteger(meta?.decimals)&&meta!.decimals!>=0&&meta!.decimals!<=10?meta!.decimals:undefined;
    const options:Intl.NumberFormatOptions={useGrouping:meta?.thousandsSeparator!==false,...(decimals===undefined?{maximumFractionDigits:10}:{minimumFractionDigits:decimals,maximumFractionDigits:decimals})};
    if (meta?.type === "currency") return number.toLocaleString("en-US", { ...options, style: "currency", currency: /^[A-Z]{3}$/.test(meta.currency||'')?meta.currency:'USD', currencyDisplay:meta.currencyDisplay||'symbol',currencySign:meta.accounting?'accounting':'standard',...(decimals===undefined?{minimumFractionDigits:2,maximumFractionDigits:2}:{}) });
    if (meta?.type === "percentage") return `${Number((number * 100).toPrecision(12)).toLocaleString("en-US", options)}%`;
    if (meta?.type === "number") return number.toLocaleString("en-US", {...options,...(decimals===undefined?{maximumFractionDigits:20}:{})});
    if (typeof value === "number") return String(Number(number.toPrecision(12)));
  }
  return typeof value === "boolean" ? value ? "TRUE" : "FALSE" : String(value);
}
export function formatTableCell(rows: string[][], row: number, column: number, meta: TableCellMetaMap = {},context?:TableEvaluationContext): string {
  return evaluateTableCellDetails(rows,row,column,meta,context).display;
}
export function evaluateTable(rows: string[][], meta: TableCellMetaMap = {},context?:TableEvaluationContext): string[][] {
  return evaluateTableDetails(rows,meta,context).map(row=>row.map(cell=>cell.display));
}

function rectangular(rows: string[][]): string[][] {
  const width = Math.max(1, ...rows.map((row) => row.length));
  return (rows.length ? rows : [[]]).map((row) => Array.from({ length: width }, (_, column) => row[column] || ""));
}
function shiftedFormula(raw: string, axis: "row" | "column", index: number, deleting: boolean): string {
  if (!raw.trimStart().startsWith("=")) return raw;
  // Quoted strings are copied verbatim so a label such as "A1" never becomes a reference.
  const rewritten = (token: string, ref: { row: number; column: number }) => {
    const [, columnAbsolute, , rowAbsolute] = /^(\$?)([A-Z]+)(\$?)([1-9]\d*)$/i.exec(token)!;
    return `${columnAbsolute}${columnName(ref.column)}${rowAbsolute}${ref.row + 1}`;
  };
  return raw.replace(/"(?:[^"]|"")*"|\$?[A-Z]+\$?[1-9]\d*(?:\s*:\s*\$?[A-Z]+\$?[1-9]\d*)?/gi, (token, offset: number) => {
    if (token.startsWith('"') || /[\w.]/.test(raw[offset - 1] || "") || /[\w.]/.test(raw[offset + token.length] || "") || /^\s*\(/.test(raw.slice(offset + token.length))) return token;
    if (token.includes(":")) {
      const [firstToken, lastToken] = token.split(":").map((part) => part.trim());
      const first = reference(firstToken)!, last = reference(lastToken)!;
      const low = Math.min(first[axis], last[axis]), high = Math.max(first[axis], last[axis]);
      if (deleting && index >= low && index <= high) {
        if (low === high) return "#REF!";
        // A range keeps the surviving cells when its first or last row is removed.
        if (first[axis] <= last[axis]) {
          if (index < first[axis]) first[axis]--;
          last[axis]--;
        } else {
          first[axis]--;
          if (index < last[axis]) last[axis]--;
        }
      } else {
        if (first[axis] >= index) first[axis] += deleting ? -1 : 1;
        if (last[axis] >= index) last[axis] += deleting ? -1 : 1;
      }
      return `${rewritten(firstToken, first)}:${rewritten(lastToken, last)}`;
    }
    const ref = reference(token);
    if (!ref) return token;
    const coordinate = ref[axis];
    if (deleting && coordinate === index) return "#REF!";
    if (coordinate < index) return token;
    ref[axis] += deleting ? -1 : 1;
    return rewritten(token, ref);
  });
}
function changeStructure(rows: string[][], meta: TableCellMetaMap, axis: "row" | "column", requestedIndex: number, deleting: boolean): TableData {
  const result = rectangular(rows), size = axis === "row" ? result.length : result[0].length;
  const index = Math.max(0, Math.min(deleting ? size - 1 : size, Math.floor(requestedIndex)));
  if (deleting && size === 1) return { rows: result.map((row) => row.map(() => "")), meta: {} };
  if (axis === "row") {
    if (deleting) result.splice(index, 1); else result.splice(index, 0, Array(result[0].length).fill(""));
  } else for (const row of result) { if (deleting) row.splice(index, 1); else row.splice(index, 0, ""); }
  const nextMeta: TableCellMetaMap = {};
  for (const [key, cell] of Object.entries(normalizeTableMeta(meta, rows))) {
    let [row, column] = key.split(":").map(Number);
    const coordinate = axis === "row" ? row : column;
    if (deleting && coordinate === index) continue;
    if (coordinate >= index) { if (axis === "row") row += deleting ? -1 : 1; else column += deleting ? -1 : 1; }
    nextMeta[cellKey(row, column)] = { ...cell };
  }
  return { rows: result.map((row, rowIndex) => row.map((raw, column) => nextMeta[cellKey(rowIndex, column)]?.type === "text" ? raw : shiftedFormula(raw, axis, index, deleting))), meta: nextMeta };
}
export const insertTableRow = (rows: string[][], meta: TableCellMetaMap = {}, index = rows.length): TableData => changeStructure(rows, meta, "row", index, false);
export const deleteTableRow = (rows: string[][], meta: TableCellMetaMap = {}, index = rows.length - 1): TableData => changeStructure(rows, meta, "row", index, true);
export const insertTableColumn = (rows: string[][], meta: TableCellMetaMap = {}, index = rows[0]?.length || 1): TableData => changeStructure(rows, meta, "column", index, false);
export const deleteTableColumn = (rows: string[][], meta: TableCellMetaMap = {}, index = (rows[0]?.length || 1) - 1): TableData => changeStructure(rows, meta, "column", index, true);

/** Move a row/column and retain the cells' formats and reference targets. */
export function moveTableAxis(rows:string[][],meta:TableCellMetaMap,axis:'row'|'column',from:number,to:number):TableData {
  const source=rectangular(rows),size=axis==='row'?source.length:source[0].length;
  const start=Math.max(0,Math.min(size-1,Math.floor(from))),end=Math.max(0,Math.min(size-1,Math.floor(to)));
  if(!Number.isFinite(start)||!Number.isFinite(end)||start===end)return {rows:source,meta:normalizeTableMeta(meta,rows)};
  const order=Array.from({length:size},(_,index)=>index);order.splice(end,0,...order.splice(start,1));
  const remap=new Map(order.map((previous,next)=>[previous,next]));
  const next=axis==='row'?order.map(index=>source[index]):source.map(row=>order.map(index=>row[index]));
  const nextMeta:TableCellMetaMap={};
  for(const [key,value] of Object.entries(normalizeTableMeta(meta,rows))){const [row,column]=key.split(':').map(Number);nextMeta[cellKey(axis==='row'?remap.get(row)!:row,axis==='column'?remap.get(column)!:column)]={...value};}
  function rewrite(raw:string){
    if(!raw.trimStart().startsWith('='))return raw;
    return raw.replace(/"(?:[^"]|"")*"|\$?[A-Z]+\$?[1-9]\d*(?:\s*:\s*\$?[A-Z]+\$?[1-9]\d*)?/gi,(token,offset:number)=>{
      if(token.startsWith('"')||/[\w.]/.test(raw[offset-1]||'')||/[\w.]/.test(raw[offset+token.length]||'')||/^\s*\(/.test(raw.slice(offset+token.length)))return token;
      if(token.includes(':')){
        const [firstToken,lastToken]=token.split(':').map(value=>value.trim()),first=reference(firstToken)!,last=reference(lastToken)!;
        // A partial range behaves as a deletion followed by insertion; a range entirely in the moved row follows it.
        if(first[axis]!==start||last[axis]!==start)return shiftedFormula(shiftedFormula(`=${token}`,axis,start,true),axis,end,false).slice(1);
        first[axis]=end;last[axis]=end;
        const rewrite=(source:string,point:{row:number;column:number})=>{const [,absoluteColumn,,absoluteRow]=/^(\$?)([A-Z]+)(\$?)([1-9]\d*)$/i.exec(source)!;return `${absoluteColumn}${columnName(point.column)}${absoluteRow}${point.row+1}`;};
        return `${rewrite(firstToken,first)}:${rewrite(lastToken,last)}`;
      }
      const point=reference(token);if(!point)return token;
      const coordinate=remap.get(point[axis]);if(coordinate===undefined)return token;point[axis]=coordinate;
      const [,absoluteColumn,,absoluteRow]=/^(\$?)([A-Z]+)(\$?)([1-9]\d*)$/i.exec(token)!;
      return `${absoluteColumn}${columnName(point.column)}${absoluteRow}${point.row+1}`;
    });
  }
  return {rows:next.map((row,ri)=>row.map((raw,ci)=>nextMeta[cellKey(ri,ci)]?.type==='text'?raw:rewrite(raw))),meta:nextMeta};
}
export const moveTableRow=(rows:string[][],meta:TableCellMetaMap,from:number,to:number)=>moveTableAxis(rows,meta,'row',from,to);
export const moveTableColumn=(rows:string[][],meta:TableCellMetaMap,from:number,to:number)=>moveTableAxis(rows,meta,'column',from,to);

/** Grow at the right/bottom and remove trailing cells when the corner is dragged inward. */
export function resizeTableGrid(rows:string[][],meta:TableCellMetaMap,rowCount:number,columnCount:number):TableData {
  const height=Math.max(1,Math.min(1000,Math.floor(rowCount))),width=Math.max(1,Math.min(100,Math.floor(columnCount)));
  if(!Number.isFinite(height)||!Number.isFinite(width))return {rows:rectangular(rows),meta:normalizeTableMeta(meta,rows)};
  let next:TableData={rows:rectangular(rows),meta:normalizeTableMeta(meta,rows)};
  while(next.rows.length<height)next=insertTableRow(next.rows,next.meta);
  while(next.rows.length>height)next=deleteTableRow(next.rows,next.meta);
  while(next.rows[0].length<width)next=insertTableColumn(next.rows,next.meta);
  while(next.rows[0].length>width)next=deleteTableColumn(next.rows,next.meta);
  return next;
}

/** Reads quoted TSV from spreadsheets, including embedded tabs and newlines. */
export function parseTableClipboard(text: string): string[][] {
  const rows: string[][] = [[]];
  let value = "", quoted = false;
  const finish = () => { rows[rows.length - 1].push(value); value = ""; };
  for (let index = 0; index < text.length; index++) {
    const character = text[index];
    if (character === '"') {
      if (quoted && text[index + 1] === '"') { value += '"'; index++; }
      else if (quoted || !value) quoted = !quoted;
      else value += character;
    } else if (!quoted && character === "\t") finish();
    else if (!quoted && (character === "\r" || character === "\n")) {
      if (character === "\r" && text[index + 1] === "\n") index++;
      finish(); rows.push([]);
    } else value += character;
  }
  finish();
  if (rows.length > 1 && rows[rows.length - 1].length === 1 && rows[rows.length - 1][0] === "" && /[\r\n]$/.test(text)) rows.pop();
  return rows;
}
export function pasteTableCells(rows: string[][], meta: TableCellMetaMap = {}, startRow: number, startColumn: number, values: string[][]): TableData {
  const rowStart = Math.max(0, Math.floor(startRow)), columnStart = Math.max(0, Math.floor(startColumn));
  const height = Math.max(1, rows.length, rowStart + values.length);
  const width = Math.max(1, ...rows.map((row) => row.length), columnStart + Math.max(0, ...values.map((row) => row.length)));
  const result = Array.from({ length: height }, (_, row) => Array.from({ length: width }, (_, column) => rows[row]?.[column] || ""));
  values.forEach((row, rowIndex) => row.forEach((value, column) => { result[rowStart + rowIndex][columnStart + column] = value; }));
  return { rows: result, meta: normalizeTableMeta(meta, result) };
}

/** Relocate copied formulas, preserving each absolute axis and quoted strings. */
export function relocateTableFormula(raw: string, rowOffset: number, columnOffset: number): string {
  if (!raw.trimStart().startsWith("=") || (!rowOffset && !columnOffset)) return raw;
  if (!Number.isSafeInteger(rowOffset) || !Number.isSafeInteger(columnOffset)) return "=#REF!";
  return raw.replace(/"(?:[^"]|"")*"|\$?[A-Z]+\$?[1-9]\d*/gi, (token, offset: number) => {
    if (token.startsWith('"') || /[\w.]/.test(raw[offset - 1] || "") || /[\w.]/.test(raw[offset + token.length] || "") || /^\s*\(/.test(raw.slice(offset + token.length))) return token;
    const match = /^(\$?)([A-Z]+)(\$?)([1-9]\d*)$/i.exec(token), ref = reference(token);
    if (!match || !ref) return token;
    const column = ref.column + (match[1] ? 0 : columnOffset), row = ref.row + (match[3] ? 0 : rowOffset);
    if (row < 0 || column < 0 || !Number.isSafeInteger(row) || !Number.isSafeInteger(column)) return "#REF!";
    return `${match[1]}${columnName(column)}${match[3]}${row + 1}`;
  });
}
