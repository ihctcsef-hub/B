export interface LibraryPhoto {
  id:string;
  width:number;
  height:number;
  src:string;
  thumbnail:string;
  alt:string;
  photographer:string;
  photographerUrl:string;
  pageUrl:string;
}
export interface LibrarySearchResult {
  provider:'pexels';
  photos:LibraryPhoto[];
  totalResults:number;
  page:number;
  nextPage:number|null;
}
const safeUrl=(value:unknown,host?:string):string=>{
  if(typeof value!=='string')return '';
  try{const url=new URL(value);return url.protocol==='https:'&&(!host||url.hostname===host)?url.href:'';}catch{return '';}
};

/** Accept only typed photo metadata. API keys and raw third-party response bodies never reach this object. */
export function normalizeLibraryResult(value:unknown):LibrarySearchResult{
  if(!value||typeof value!=='object')throw new Error('Image search returned invalid results.');
  const data=value as Record<string,unknown>;
  if(data.provider!=='pexels'||!Array.isArray(data.photos))throw new Error('Image search returned invalid results.');
  const photos:LibraryPhoto[]=[];
  for(const entry of data.photos){
    if(!entry||typeof entry!=='object')continue;const photo=entry as Record<string,unknown>;
    const src=safeUrl(photo.src,'images.pexels.com'),thumbnail=safeUrl(photo.thumbnail,'images.pexels.com');
    if(!src||!thumbnail||typeof photo.id!=='string'||!photo.id||typeof photo.width!=='number'||typeof photo.height!=='number'||!Number.isFinite(photo.width)||!Number.isFinite(photo.height)||photo.width<=0||photo.height<=0)continue;
    photos.push({id:photo.id,width:photo.width,height:photo.height,src,thumbnail,alt:typeof photo.alt==='string'?photo.alt:'',photographer:typeof photo.photographer==='string'?photo.photographer:'',photographerUrl:safeUrl(photo.photographerUrl),pageUrl:safeUrl(photo.pageUrl)});
  }
  const page=typeof data.page==='number'&&Number.isInteger(data.page)&&data.page>0?data.page:1;
  return {provider:'pexels',photos,page,totalResults:typeof data.totalResults==='number'&&Number.isFinite(data.totalResults)&&data.totalResults>=0?data.totalResults:photos.length,nextPage:typeof data.nextPage==='number'&&Number.isInteger(data.nextPage)&&data.nextPage>page?data.nextPage:null};
}

export async function searchLibraryPhotos(query:string,page=1,signal?:AbortSignal,endpoint='/api/images/search'):Promise<LibrarySearchResult>{
  if(!endpoint.startsWith('/')||endpoint.startsWith('//'))throw new Error('The image search endpoint must be on this site.');
  const parameters=new URLSearchParams({query:query.trim().slice(0,120),page:String(Math.max(1,Math.floor(page)))});
  const response=await fetch(`${endpoint}?${parameters}`,{signal,credentials:'same-origin',headers:{Accept:'application/json'}});
  if(!response.ok)throw new Error(response.status===429?'Image search is busy. Please try again shortly.':'Image search is unavailable right now. Please try again later.');
  return normalizeLibraryResult(await response.json());
}

export const LIBRARY_DRAG_TYPE='application/canvas-library-image';
export function encodeLibraryPhoto(photo:LibraryPhoto):string{return JSON.stringify(photo);}
export function decodeLibraryPhoto(value:string):LibraryPhoto|null{
  try{return normalizeLibraryResult({provider:'pexels',photos:[JSON.parse(value)],page:1}).photos[0]||null;}catch{return null;}
}
