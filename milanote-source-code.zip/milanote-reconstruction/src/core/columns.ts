import type { Board, Card } from "./model";

export const COLUMN_PADDING = 6.4;
export const COLUMN_BOTTOM_PADDING = 6;
export const COLUMN_HEADER_HEIGHT = 62.2;
export const COLUMN_GAP = 6;
export const COLUMN_MIN_WIDTH = 172;
export const COLUMN_MIN_HEIGHT = 126.2;

/** Resolve every selected column, including multiple columns and legacy descendants. */
export function expandSelection(board: Board, ids: string[]): string[] {
  const byId = new Map(board.cards.map((card) => [card.id, card]));
  const expanded = new Set(ids.filter((id) => byId.has(id)));
  let changed = true;
  while (changed) {
    changed = false;
    for (const card of board.cards) {
      if (
        card.parentId &&
        expanded.has(card.parentId) &&
        byId.get(card.parentId)?.type === "column" &&
        !expanded.has(card.id)
      ) {
        expanded.add(card.id);
        changed = true;
      }
    }
  }
  return [...expanded];
}

/** Child y positions persist the order; array position breaks equal-y ties. */
export function columnChildren(board: Board, columnId: string): Card[] {
  const column = board.cards.find((card) => card.id === columnId);
  if (column?.type !== "column") return [];
  return board.cards
    .map((card, index) => ({ card, index }))
    .filter(
      ({ card }) =>
        card.type !== "column" &&
        card.parentId === columnId &&
        (!card.unsorted || column.unsorted),
    )
    .sort((a, b) => a.card.y - b.card.y || a.index - b.index)
    .map(({ card }) => card);
}

/**
 * A column owns its members' geometry, including locked members. A position lock
 * prevents a direct move/reorder; moving or resizing the container still carries
 * its members. Layout preserves the column's existing height and grows to fit.
 */
export function arrangeColumn(
  board: Board,
  columnId: string,
  orderedIds?: string[],
): Board {
  const column = board.cards.find((card) => card.id === columnId);
  if (column?.type !== "column") return board;
  const children = columnChildren(board, columnId);
  const byId = new Map(children.map((card) => [card.id, card]));
  const seen = new Set<string>();
  const ordered = [...(orderedIds ?? []), ...children.map((card) => card.id)]
    .filter((id) => byId.has(id) && !seen.has(id) && !!seen.add(id))
    .map((id) => byId.get(id)!);
  const width = Math.max(COLUMN_MIN_WIDTH, column.width);
  let y = column.y + COLUMN_HEADER_HEIGHT;
  const changes = new Map<string, Card>();
  for (const child of ordered) {
    const x = column.x + COLUMN_PADDING;
    const childWidth = width - COLUMN_PADDING * 2;
    const unsorted = !!column.unsorted;
    if (
      child.x !== x ||
      child.y !== y ||
      child.width !== childWidth ||
      !!child.unsorted !== unsorted
    ) {
      changes.set(child.id, { ...child, x, y, width: childWidth, unsorted });
    }
    y += child.height + COLUMN_GAP;
  }
  const requiredHeight = ordered.length
    ? y - COLUMN_GAP - column.y + COLUMN_BOTTOM_PADDING
    : COLUMN_MIN_HEIGHT;
  const height = Math.max(
    column.autoHeight ? COLUMN_MIN_HEIGHT : column.height,
    COLUMN_MIN_HEIGHT,
    requiredHeight,
  );
  if (column.width !== width || column.height !== height)
    changes.set(column.id, { ...column, width, height });
  return changes.size
    ? {
        ...board,
        cards: board.cards.map((card) => changes.get(card.id) ?? card),
      }
    : board;
}

export function arrangeAllColumns(board: Board, onlyIds?: string[]): Board {
  const requested = onlyIds ? new Set(onlyIds) : null;
  return board.cards
    .filter(
      (card) =>
        card.type === "column" && (!requested || requested.has(card.id)),
    )
    .reduce((next, card) => arrangeColumn(next, card.id), board);
}

/**
 * Insert movable cards into a column. Index addresses the remaining members after
 * removing the incoming cards, so a same-column reorder has unambiguous indices.
 * Columns cannot be members. Direct changes skip locked cards/locked containers.
 */
export function placeInColumn(
  board: Board,
  ids: string[],
  columnId: string,
  index?: number,
): Board {
  const column = board.cards.find((card) => card.id === columnId);
  if (column?.type !== "column" || column.locked) return board;
  const requested = new Set(ids);
  const incoming = board.cards
    .map((card, originalIndex) => ({ card, originalIndex }))
    .filter(
      ({ card }) =>
        requested.has(card.id) && card.type !== "column" && !card.locked,
    )
    .sort((a, b) => a.card.y - b.card.y || a.originalIndex - b.originalIndex)
    .map(({ card }) => card);
  if (!incoming.length) return board;
  const incomingIds = new Set(incoming.map((card) => card.id));
  const remaining = columnChildren(board, columnId).filter(
    (card) => !incomingIds.has(card.id),
  );
  const position =
    index === undefined || !Number.isFinite(index)
      ? remaining.length
      : Math.max(0, Math.min(remaining.length, Math.floor(index)));
  const ordered = [
    ...remaining.slice(0, position),
    ...incoming,
    ...remaining.slice(position),
  ].map((card) => card.id);
  const previousColumns = [
    ...new Set(
      incoming
        .map((card) => card.parentId)
        .filter((id): id is string => !!id && id !== columnId),
    ),
  ];
  const changed = {
    ...board,
    cards: board.cards.map((card) =>
      incomingIds.has(card.id)
        ? {
            ...card,
            parentId: columnId,
            unsorted: !!column.unsorted,
            preColumnWidth: card.preColumnWidth ?? card.width,
          }
        : card,
    ),
  };
  return arrangeAllColumns(
    arrangeColumn(changed, columnId, ordered),
    previousColumns,
  );
}

/** Detach unlocked cards while preserving their canvas positions, then close gaps. */
export function removeFromColumn(board: Board, ids: string[]): Board {
  const requested = new Set(ids);
  const previousColumns = new Set<string>();
  const cards = board.cards.map((card) => {
    if (
      !requested.has(card.id) ||
      !card.parentId ||
      card.locked ||
      card.type === "column"
    )
      return card;
    previousColumns.add(card.parentId);
    return {
      ...card,
      parentId: undefined,
      width: card.preColumnWidth ?? card.width,
      preColumnWidth: undefined,
    };
  });
  if (!previousColumns.size) return board;
  return arrangeAllColumns({ ...board, cards }, [...previousColumns]);
}

/** Explicit resize may reduce empty space; member content remains the lower bound. */
export function resizeColumn(
  board: Board,
  columnId: string,
  width: number,
  height: number,
): Board {
  const column = board.cards.find((card) => card.id === columnId);
  if (column?.type !== "column" || column.locked) return board;
  const resized = {
    ...column,
    autoHeight: false,
    width: Number.isFinite(width)
      ? Math.max(COLUMN_MIN_WIDTH, width)
      : column.width,
    height: Number.isFinite(height)
      ? Math.max(COLUMN_MIN_HEIGHT, height)
      : column.height,
  };
  return arrangeColumn(
    {
      ...board,
      cards: board.cards.map((card) => (card.id === columnId ? resized : card)),
    },
    columnId,
  );
}
