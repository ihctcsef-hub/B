/** Calendar/time masks for TEXT. null delegates numeric and other masks to the numeric formatter. */
export function formulaDateText(value:unknown,format:unknown):string|null {
  if(typeof value!=='number'||!Number.isFinite(value)||typeof format!=='string')return null;
  const parts=format.match(/"[^"]*"|\\.|AM\/PM|A\/P|y{1,4}|m{1,5}|d{1,4}|h{1,2}|s{1,2}|[^a-z"\\]+/gi);
  if(!parts||parts.join('')!==format||!parts.some(part=>/^[ymdhs]+$/i.test(part)))return null;
  const date=new Date(Date.UTC(1899,11,30)+Math.round(value*86400000));
  if(!Number.isFinite(date.getTime()))return null;
  const months=['January','February','March','April','May','June','July','August','September','October','November','December'];
  const weekdays=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const padded=(n:number)=>String(n).padStart(2,'0'),withPeriod=parts.some(part=>/^a(m\/pm|\/p)$/i.test(part));
  let time=false;
  return parts.map((part,index)=>{
    if(part.startsWith('"'))return part.slice(1,-1);
    if(part.startsWith('\\'))return part.slice(1);
    const token=part.toLowerCase(),size=part.length;
    if(token==='am/pm')return date.getUTCHours()<12?'AM':'PM';
    if(token==='a/p')return date.getUTCHours()<12?'A':'P';
    if(/^y+$/.test(token)){time=false;return size<=2?padded(date.getUTCFullYear()%100):String(date.getUTCFullYear());}
    if(/^d+$/.test(token)){time=false;return size===1?String(date.getUTCDate()):size===2?padded(date.getUTCDate()):size===3?weekdays[date.getUTCDay()].slice(0,3):weekdays[date.getUTCDay()];}
    if(/^h+$/.test(token)){time=true;const hour=withPeriod?date.getUTCHours()%12||12:date.getUTCHours();return size===2?padded(hour):String(hour);}
    if(/^s+$/.test(token)){time=true;return size===2?padded(date.getUTCSeconds()):String(date.getUTCSeconds());}
    if(/^m+$/.test(token)){
      const next=parts.slice(index+1).find(part=>/^[ymdhs]+$/i.test(part));
      if(time||/^s+$/i.test(next||''))return size===2?padded(date.getUTCMinutes()):String(date.getUTCMinutes());
      const month=date.getUTCMonth();return size===1?String(month+1):size===2?padded(month+1):size===3?months[month].slice(0,3):size===4?months[month]:months[month][0];
    }
    return part;
  }).join('');
}
