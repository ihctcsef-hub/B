import { uid } from './model';
import type { Board, Card, Workspace } from './model';

export interface WorkspaceLabel { id:string; name:string; color:string }
export type LabelWorkspace=Workspace & { labels?:WorkspaceLabel[] };
export type LabeledCard=Card & { labelIds?:string[] };
export interface LabelUsage { boardId:string; boardTitle:string; cardId:string; cardType:Card['type'] }
export type LabelSelectionState='none'|'some'|'all';

// Primary palette observed in the authenticated Labels → Change color submenu.
export const LABEL_COLORS=['#ffffff','#bbbec3','#62dbc8','#7cd651','#d58558','#ffd14d','#ff8d48','#ff5757','#ff6ed4','#ad6fff','#4ebafd','#5882f8'] as const;
export const LABEL_NAME_LIMIT=30;
const validColor=(value:unknown):value is string=>typeof value==='string'&&/^#[\da-f]{6}$/i.test(value);
const validName=(value:unknown):value is string=>typeof value==='string'&&value.trim().length>0&&value.length<=1000;
const same=(a:readonly string[]|undefined,b:readonly string[])=>!!a&&a.length===b.length&&a.every((value,index)=>value===b[index]);
const unique=(values:readonly string[])=>[...new Set(values)];
const catalog=(workspace:Workspace)=>((workspace as LabelWorkspace).labels||[]);
const touch=(workspace:Workspace,boards:Workspace['boards'],labels:WorkspaceLabel[]):LabelWorkspace=>({...workspace,boards,labels,updatedAt:new Date().toISOString()});

/** Import validation is intentionally strict; label values are text and fixed HEX colors. */
export function isValidWorkspaceLabels(value:unknown):value is WorkspaceLabel[]{
  if(!Array.isArray(value))return false;
  const ids=new Set<string>(),names=new Set<string>();
  return value.every(label=>{
    if(!label||typeof label!=='object'||Array.isArray(label))return false;
    const item=label as Record<string,unknown>;
    if(typeof item.id!=='string'||!item.id||ids.has(item.id)||!validName(item.name)||item.name!==item.name.trim()||names.has(item.name)||!validColor(item.color))return false;
    ids.add(item.id);names.add(item.name);return true;
  });
}

function legacyId(name:string,used:Set<string>):string{
  let hash=2166136261;
  for(const character of name){hash^=character.codePointAt(0)!;hash=Math.imul(hash,16777619);}
  const base=`label-legacy-${(hash>>>0).toString(16)}`;
  let id=base,index=1;while(used.has(id))id=`${base}-${index++}`;return id;
}

/** Older tag strings become stable label IDs once. Existing IDs are authoritative. */
export function migrateLegacyLabels(workspace:Workspace):LabelWorkspace{
  const existing=catalog(workspace),labels=existing.map(label=>({...label}));
  const byName=new Map(labels.map(label=>[label.name,label]));
  const used=new Set(labels.map(label=>label.id));
  let registryChanged=false,boardsChanged=false;
  const boards={...workspace.boards};
  for(const [boardId,board] of Object.entries(boards)){
    let changed=false;
    const cards=board.cards.map(raw=>{
      const card=raw as LabeledCard;
      if(card.labelIds===undefined&&!card.tags?.length)return raw;
      let ids:string[];
      if(card.labelIds!==undefined)ids=unique(card.labelIds.filter(id=>used.has(id)));
      else ids=unique((card.tags||[]).filter(validName).map(tag=>{
        const name=tag.trim();let label=byName.get(name);
        if(!label){label={id:legacyId(name,used),name,color:LABEL_COLORS[(labels.length+8)%LABEL_COLORS.length]};labels.push(label);used.add(label.id);byName.set(name,label);registryChanged=true;}
        return label.id;
      }));
      const names=ids.map(id=>labels.find(label=>label.id===id)!.name);
      if(same(card.labelIds,ids)&&same(card.tags,names))return raw;
      changed=true;return {...raw,labelIds:ids,tags:names} as LabeledCard;
    });
    if(changed){boardsChanged=true;boards[boardId]={...board,cards};}
  }
  return registryChanged||boardsChanged?touch(workspace,boards,labels):workspace;
}

export function labelsForCard(workspace:Workspace,card:Card):WorkspaceLabel[]{
  const byId=new Map(catalog(workspace).map(label=>[label.id,label]));
  return unique((card as LabeledCard).labelIds||[]).flatMap(id=>{const label=byId.get(id);return label?[label]:[];});
}

function withRegistry(workspace:Workspace,labels:WorkspaceLabel[],map?:(card:LabeledCard,boardId:string)=>string[]|undefined):LabelWorkspace{
  const byId=new Map(labels.map(label=>[label.id,label]));let changed=false;
  const boards={...workspace.boards};
  for(const [boardId,board] of Object.entries(boards)){
    let boardChanged=false;
    const cards=board.cards.map(raw=>{
      const card=raw as LabeledCard,requested=map?.(card,boardId);
      if(requested===undefined&&card.labelIds===undefined)return raw;
      const ids=unique((requested??card.labelIds??[]).filter(id=>byId.has(id))),tags=ids.map(id=>byId.get(id)!.name);
      if(same(card.labelIds,ids)&&same(card.tags,tags))return raw;
      boardChanged=true;return {...raw,labelIds:ids,tags} as LabeledCard;
    });
    if(boardChanged){changed=true;boards[boardId]={...board,cards};}
  }
  const old=catalog(workspace),registryChanged=old.length!==labels.length||old.some((label,index)=>label.id!==labels[index]?.id||label.name!==labels[index]?.name||label.color!==labels[index]?.color);
  return changed||registryChanged?touch(workspace,boards,labels):workspace;
}

/** Creating an existing exact name reuses that global label. */
export function createWorkspaceLabel(workspace:Workspace,name:string,assignment?:{boardId:string;cardIds:string[]},color?:string):{workspace:LabelWorkspace;label?:WorkspaceLabel}{
  if(!validName(name)||name.trim().length>LABEL_NAME_LIMIT||color!==undefined&&!validColor(color))return {workspace};
  const base=migrateLegacyLabels(workspace),text=name.trim(),old=catalog(base);
  const existing=old.find(label=>label.name===text),label=existing||{id:uid(),name:text,color:color?.toLowerCase()||LABEL_COLORS[(old.length+8)%LABEL_COLORS.length]};
  let next=existing?base:withRegistry(base,[...old,label]);
  if(assignment)next=setLabelAssignment(next,assignment.boardId,assignment.cardIds,label.id,true);
  return {workspace:next,label};
}

export function renameWorkspaceLabel(workspace:Workspace,id:string,name:string):LabelWorkspace{
  if(!validName(name)||name.trim().length>LABEL_NAME_LIMIT)return workspace;
  const base=migrateLegacyLabels(workspace),text=name.trim(),labels=catalog(base);
  if(!labels.some(label=>label.id===id)||labels.some(label=>label.id!==id&&label.name===text))return base;
  return withRegistry(base,labels.map(label=>label.id===id?{...label,name:text}:label));
}
export function recolorWorkspaceLabel(workspace:Workspace,id:string,color:string):LabelWorkspace{
  if(!validColor(color))return workspace;
  const base=migrateLegacyLabels(workspace);
  return withRegistry(base,catalog(base).map(label=>label.id===id?{...label,color:color.toLowerCase()}:label));
}
export function deleteWorkspaceLabel(workspace:Workspace,id:string):LabelWorkspace{
  const base=migrateLegacyLabels(workspace);
  return withRegistry(base,catalog(base).filter(label=>label.id!==id));
}
export function setLabelAssignment(workspace:Workspace,boardId:string,cardIds:string[],id:string,assigned:boolean):LabelWorkspace{
  const base=migrateLegacyLabels(workspace),labels=catalog(base),ids=new Set(cardIds);
  if(!base.boards[boardId]||!labels.some(label=>label.id===id)||!ids.size)return base;
  return withRegistry(base,labels,(card,currentBoard)=>currentBoard===boardId&&ids.has(card.id)?assigned?unique([...(card.labelIds||[]),id]):(card.labelIds||[]).filter(value=>value!==id):undefined);
}
export function labelSelectionState(workspace:Workspace,boardId:string,cardIds:string[],id:string):LabelSelectionState{
  const wanted=new Set(cardIds),cards=(workspace.boards[boardId]?.cards||[]).filter(card=>wanted.has(card.id));
  if(!cards.length)return 'none';
  const count=cards.filter(card=>(card as LabeledCard).labelIds?.includes(id)).length;
  return !count?'none':count===cards.length?'all':'some';
}
export function labelUsages(workspace:Workspace,id:string):LabelUsage[]{
  return Object.values(workspace.boards).flatMap(board=>board.cards.filter(card=>(card as LabeledCard).labelIds?.includes(id)).map(card=>({boardId:board.id,boardTitle:board.title,cardId:card.id,cardType:card.type})));
}
export function searchWorkspaceLabels(workspace:Workspace,query:string):WorkspaceLabel[]{
  const value=query.trim().toLowerCase();return catalog(workspace).filter(label=>label.name.toLowerCase().includes(value));
}
export function labelMatchesQuery(workspace:Workspace,card:Card,query:string):boolean{
  const value=query.trim().toLowerCase();return !!value&&labelsForCard(workspace,card).some(label=>label.name.toLowerCase().includes(value));
}

/**
 * A clipboard may come from an older workspace snapshot or another workspace.
 * Reconcile its global labels before inserting copied cards/nested boards.
 * Target definitions win on an existing name so a stale clipboard never undoes
 * a label's current global color. Conflicting IDs receive fresh IDs.
 */
export function reconcileCopiedLabels(
  source:Workspace,
  target:Workspace,
  cards:Card[],
  newBoards:Record<string,Board>={},
):{labels:WorkspaceLabel[];cards:Card[];boards:Record<string,Board>}{
  const sourceLabels=catalog(migrateLegacyLabels(source));
  const labels=catalog(migrateLegacyLabels(target)).map(label=>({...label}));
  const sourceById=new Map(sourceLabels.map(label=>[label.id,label]));
  const sourceByName=new Map(sourceLabels.map(label=>[label.name,label]));
  const targetById=new Map(labels.map(label=>[label.id,label]));
  const targetByName=new Map(labels.map(label=>[label.name,label]));
  const remap=new Map<string,string>();
  function resolve(label:WorkspaceLabel):string{
    const cached=remap.get(label.id);if(cached)return cached;
    const byId=targetById.get(label.id);
    let match=byId?.name===label.name&&byId.color===label.color?byId:targetByName.get(label.name);
    if(!match){
      let id=label.id;
      if(targetById.has(id)){do{id=uid();}while(targetById.has(id));}
      match={...label,id};labels.push(match);targetById.set(id,match);targetByName.set(match.name,match);
    }
    remap.set(label.id,match.id);return match.id;
  }
  function reconcile(raw:Card):Card{
    const card=raw as LabeledCard;
    const definitions=card.labelIds!==undefined
      ?card.labelIds.flatMap(id=>{const label=sourceById.get(id);return label?[label]:[];})
      :(card.tags||[]).flatMap(name=>{const label=sourceByName.get(name.trim());return label?[label]:[];});
    if(card.labelIds===undefined&&!definitions.length)return raw;
    const labelIds=unique(definitions.map(resolve));
    const tags=labelIds.map(id=>targetById.get(id)!.name);
    if(same(card.labelIds,labelIds)&&same(card.tags,tags))return raw;
    return {...raw,labelIds,tags} as LabeledCard;
  }
  const copied=cards.map(reconcile);
  const boards=Object.fromEntries(Object.entries(newBoards).map(([id,board])=>[id,{...board,cards:board.cards.map(reconcile)}]));
  return {labels,cards:copied,boards};
}
