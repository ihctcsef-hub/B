import type { Card, Point, Workspace } from './model';
import { moveCardsToBoard } from './boardActions';

export const BOARD_HOVER_OPEN_MS = 1000;
export interface BoardDragViewport { x:number; y:number; zoom:number }
export interface BoardDragStage { left:number; top:number }

/** The pointer stays at the same logical point in the selected group after a board opens. */
export function boardDragAnchor(client:Point,stage:BoardDragStage,viewport:BoardDragViewport,grab:Point):Point {
  return {x:(client.x-stage.left-viewport.x)/viewport.zoom-grab.x,y:(client.y-stage.top-viewport.y)/viewport.zoom-grab.y};
}
export function boardDragGrab(cards:Card[],pointer:Point):Point {
  return {x:pointer.x-Math.min(...cards.map(card=>card.x)),y:pointer.y-Math.min(...cards.map(card=>card.y))};
}
/** Use the same ownership/ID checks as the actual transaction, without mutating the workspace. */
export function canMoveDragToBoard(workspace:Workspace,sourceId:string,targetId:string,ids:string[]):boolean {
  return moveCardsToBoard(workspace,sourceId,targetId,ids)!==workspace;
}

