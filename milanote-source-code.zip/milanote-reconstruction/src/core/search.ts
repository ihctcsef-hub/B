import type { Board, Card, Workspace } from './model';
import { noteContentHtml, richHtmlToPlainText } from './richText';
import { workspaceBoard } from './shortcuts';

export type SearchSort = 'viewed' | 'modified' | 'relevance';
export interface SearchBoardResult { board: Board; titleMatch: boolean; hits: Card[]; score: number }
const renderedText=new WeakMap<Card,{text:string;html?:string;plain:string}>();
function visibleCardText(card:Card,text:string,html?:string):string {
  const previous=renderedText.get(card);
  if(previous?.text===text&&previous.html===html)return previous.plain;
  const plain=richHtmlToPlainText(noteContentHtml(text,html));
  renderedText.set(card,{text,html,plain});return plain;
}
const normalize = (value: string) => value.normalize('NFKC').toLocaleLowerCase().replace(/\s+/g, ' ').trim();
const time = (value?: string) => value !== undefined && Number.isFinite(Date.parse(value)) ? Date.parse(value) : Number.NEGATIVE_INFINITY;
const stamp = (now: Date | string | number) => new Date(now).toISOString();
const graphemes = new Intl.Segmenter(undefined, { granularity: 'grapheme' });
function textBoundaries(text: string): number[] {
  return [0, ...Array.from(graphemes.segment(text), part => part.index + part.segment.length)];
}
export interface SearchMatchRange { start: number; end: number }
/** Map a normalized match back to whole original graphemes, including expansions
 * such as a ligature or capital dotted I. Whole-prefix normalization preserves
 * the same case-context and whitespace rules used by the actual search. */
function matchRange(text: string, query: string, boundaries?: number[]): SearchMatchRange | null {
  const needle = normalize(query);
  if (!needle) return null;
  const normalized = normalize(text), at = normalized.indexOf(needle);
  if (at < 0) return null;
  const edges = boundaries || textBoundaries(text), lengths = new Map<number, number>([[0, 0], [edges.length - 1, normalized.length]]);
  const prefixLength = (index: number) => {
    let length = lengths.get(index);
    if (length === undefined) { length = normalize(text.slice(0, edges[index])).length; lengths.set(index, length); }
    return length;
  };
  let low = 0, high = edges.length - 1;
  while (low < high) { const mid = Math.ceil((low + high) / 2); if (prefixLength(mid) <= at) low = mid; else high = mid - 1; }
  const start = edges[low];
  low = 0; high = edges.length - 1;
  while (low < high) { const mid = Math.floor((low + high) / 2); if (prefixLength(mid) >= at + needle.length) high = mid; else low = mid + 1; }
  return { start, end: edges[low] };
}
export function searchMatchRange(text: string, query: string): SearchMatchRange | null { return matchRange(text, query); }

/** Read-only visits deliberately do not create an undo transaction or change modifiedAt. */
export function markBoardViewed(workspace: Workspace, boardId: string, now: Date | string | number = Date.now()): Workspace {
  if (!workspaceBoard(workspace, boardId)) return workspace;
  const viewedAt = stamp(now), activity = workspace.boardActivity?.[boardId];
  if (activity?.viewedAt === viewedAt) return workspace;
  return { ...workspace, boardActivity: { ...workspace.boardActivity, [boardId]: { ...activity, viewedAt } } };
}
function equalData(left: unknown, right: unknown): boolean {
  if (left === right) return true;
  if (!left || !right || typeof left !== 'object' || typeof right !== 'object') return false;
  if (Array.isArray(left) || Array.isArray(right)) return Array.isArray(left) && Array.isArray(right) && left.length === right.length && left.every((value, index) => equalData(value, right[index]));
  const a = left as Record<string, unknown>, b = right as Record<string, unknown>;
  return [...new Set([...Object.keys(a), ...Object.keys(b)])].every(key => equalData(a[key], b[key]));
}
export function sameBoardContent(left: Board, right: Board): boolean {
  if (left === right) return true;
  const a = left as unknown as Record<string, unknown>, b = right as unknown as Record<string, unknown>;
  return [...new Set([...Object.keys(a), ...Object.keys(b)])].filter(key => key !== 'viewport').every(key => equalData(a[key], b[key]));
}
/** Detect semantic edits without serializing image bytes, and preserve a newer live-edit stamp. */
export function stampBoardModifications(previous: Workspace, next: Workspace, now: Date | string | number = Date.now()): Workspace {
  let activity = next.boardActivity;
  const modifiedAt = stamp(now);
  for (const [id, board] of Object.entries(next.boards)) {
    const before = workspaceBoard(previous, id);
    if (before && sameBoardContent(before, board)) continue;
    const current = activity?.[id], old = previous.boardActivity?.[id];
    if (current?.modifiedAt && current.modifiedAt !== old?.modifiedAt && time(current.modifiedAt) >= time(old?.modifiedAt)) continue;
    activity = { ...activity, [id]: { ...current, modifiedAt } };
  }
  return activity === next.boardActivity ? next : { ...next, boardActivity: activity };
}
/** Undo/redo restores document content, while previously viewed boards remain in recent history. */
export function retainBoardActivity(snapshot: Workspace, current: Workspace): Workspace {
  if (snapshot.id!==current.id||(!snapshot.boardActivity && !current.boardActivity)) return snapshot;
  const entries = new Map(Object.entries(snapshot.boardActivity || {}));
  for (const [id, activity] of Object.entries(current.boardActivity || {})) entries.set(id, { ...entries.get(id), ...activity });
  return { ...snapshot, boardActivity: Object.fromEntries(entries) };
}
export function searchableCardText(card: Card): string {
  switch (card.type) {
    case 'note': return [card.title, visibleCardText(card,card.text,card.html)].filter(Boolean).join('\n');
    case 'image': return visibleCardText(card,card.caption,card.captionHtml);
    case 'link': return [card.title, card.url, card.description, visibleCardText(card,card.caption||'',card.captionHtml)].filter(Boolean).join('\n');
    case 'todo': return [card.title, ...card.items.map(item => item.text)].join('\n');
    case 'table': return [card.title, ...card.rows.map(row => row.join('\t'))].join('\n');
    case 'board': case 'column': return card.title;
    case 'file': return card.name;
    case 'label': return card.text;
    case 'swatch': return [visibleCardText(card,card.label,card.captionHtml), card.value].join('\n');
    case 'sketch': return '';
  }
}
export function searchSnippet(card: Card, query: string, workspace?: Workspace): string {
  const names = workspace?.labels?.filter(label => card.labelIds?.includes(label.id)).map(label => label.name) || card.tags || [];
  const text = [searchableCardText(card), ...names].filter(Boolean).join(' · ').replace(/\s+/g, ' ').trim();
  const boundaries = textBoundaries(text), match = matchRange(text, query, boundaries), targetStart = match && match.start > 45 ? match.start - 35 : 0;
  let start = 0;
  for (const boundary of boundaries) { if (boundary > targetStart) break; start = boundary; }
  const targetEnd = Math.max(start + 140, match?.end || 0), end = boundaries.find(boundary => boundary >= targetEnd) ?? text.length;
  return `${start ? '…' : ''}${text.slice(start, end)}${text.length > end ? '…' : ''}` || 'Untitled item';
}
export function searchWorkspace(workspace: Workspace, query: string, sort: SearchSort = 'viewed', labelId?: string | null): SearchBoardResult[] {
  const needle = normalize(query);
  const results = Object.values(workspace.boards).flatMap(board => {
    if (!needle && !labelId) return Number.isFinite(time(workspace.boardActivity?.[board.id]?.viewedAt)) ? [{ board, titleMatch: false, hits: [], score: 0 }] : [];
    const title = normalize(board.title), titleMatch = !labelId && !!needle && title.includes(needle);
    const hits = board.cards.filter(card => {
      if (labelId) return card.labelIds?.includes(labelId);
      const labels = workspace.labels?.filter(label => card.labelIds?.includes(label.id)).map(label => label.name) || card.tags || [];
      // A live target is already returned by its own title, but a tile's labels
      // (and a broken shortcut's remaining title) still belong to this board.
      const content = card.type==='board' && workspaceBoard(workspace,card.boardId) ? '' : searchableCardText(card);
      return normalize([content, ...labels].join('\n')).includes(needle);
    });
    if (!titleMatch && !hits.length) return [];
    const score = (title === needle ? 100 : title.startsWith(needle) ? 60 : titleMatch ? 40 : 0) + Math.min(20, hits.length);
    return [{ board, titleMatch, hits, score }];
  });
  return results.sort((a, b) => {
    const activityA = workspace.boardActivity?.[a.board.id], activityB = workspace.boardActivity?.[b.board.id];
    const primary = sort === 'relevance' && needle ? b.score - a.score : time(sort === 'modified' ? activityB?.modifiedAt : activityB?.viewedAt) - time(sort === 'modified' ? activityA?.modifiedAt : activityA?.viewedAt);
    return primary || b.score - a.score || a.board.title.localeCompare(b.board.title) || a.board.id.localeCompare(b.board.id);
  });
}
export function searchBoardAncestors(workspace: Workspace, board: Board): string[] {
  const names: string[] = [], seen = new Set([board.id]);let parent = board.parentBoardId;
  while (parent && !seen.has(parent)) { const owner=workspaceBoard(workspace,parent);if(!owner)break;seen.add(parent);names.unshift(parent===workspace.rootBoardId?'Home':owner.title);parent=owner.parentBoardId; }
  return names.length ? names : board.id === workspace.rootBoardId ? ['Home'] : [];
}
