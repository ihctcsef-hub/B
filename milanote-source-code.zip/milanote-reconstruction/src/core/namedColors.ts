import names from './namedColorData.json';
import {hexToRgb, rgbToHex} from './colors';

// Name that Color's public data is CC BY 2.5, Chirag Mehta.
// See docs/licenses/NameThatColor-CC-BY-2.5.txt for attribution and provenance.
// This small independent lookup keeps the public RGB/HSL distance rule.
function coordinates(value:string):number[]|null {
  const color=hexToRgb(value);if(!color)return null;
  const channels=[color.r,color.g,color.b].map(channel=>channel/255);
  const [r,g,b]=channels,min=Math.min(...channels),max=Math.max(...channels),delta=max-min,l=(min+max)/2;
  const hue=!delta?0:max===r?(g-b)/delta:max===g?2+(b-r)/delta:4+(r-g)/delta;
  const saturation=delta/(l<.5?2*l:2-2*l)||0;
  return [color.r,color.g,color.b,Math.trunc(hue/6*255),Math.trunc(saturation*255),Math.trunc(l*255)];
}
const palette=names.map(([hex,name])=>({color:`#${hex.toLowerCase()}`,name,point:coordinates(hex)!}));
export interface NamedColor {color:string;name:string;exact:boolean}
export function nearestNamedColor(value:string):NamedColor|null {
  const rgb=hexToRgb(value),point=coordinates(value);if(!rgb||!point)return null;
  const canonical=rgbToHex(rgb);let best=palette[0],score=Infinity;
  for(const candidate of palette){
    if(candidate.color===canonical)return {color:canonical,name:candidate.name,exact:true};
    const distance=point.reduce((total,coordinate,index)=>total+(coordinate-candidate.point[index])**2*(index<3?1:2),0);
    if(distance<score){score=distance;best=candidate;}
  }
  return {color:best.color,name:best.name,exact:false};
}
