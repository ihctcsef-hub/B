import type { Board, Card, Point } from './model';

export const IMAGE_GRID_STEP = 288;
export const IMAGE_GRID_GAP = 18;
const snap = (value:number) => Math.round(value/8)*8;

/** Observed upload sizing: a 270px default image uses an eight-pixel
 * envelope with a two-pixel inset; smaller originals are not enlarged. */
export function droppedImageSize(naturalWidth:number,naturalHeight:number):{width:number;height:number} {
  if(!Number.isFinite(naturalWidth)||!Number.isFinite(naturalHeight)||naturalWidth<=0||naturalHeight<=0)return {width:270,height:220};
  const width=Math.max(6,snap(Math.min(270,naturalWidth*.8))-2);
  const defaultHeight=Math.max(6,snap(270*naturalHeight/naturalWidth)-2);
  return {width,height:Math.min(1_000_000,width*defaultHeight/270)};
}

/** Keep columns and mixed file batches on their existing insertion path.
 * An empty board's image batch starts at 16/16; otherwise it starts at the
 * snapped drop point. Each next image uses the leftmost shortest column. */
export function layoutDroppedImages(board:Board,items:Card[],at:Point,availableWidth:number):Card[] {
  if(!items.length||items.some(item=>item.type!=='image'))return items;
  const inColumn=board.cards.some(card=>card.type==='column'&&!card.collapsed&&!card.locked&&!card.unsorted&&at.x>card.x&&at.x<card.x+card.width&&at.y>card.y+38&&at.y<card.y+card.height);
  if(inColumn)return items;
  const empty=!board.cards.some(card=>!card.unsorted)&&!board.connections.length;
  const origin=empty&&items.length>1?{x:16,y:16}:{x:snap(at.x),y:snap(at.y)};
  const columns=Math.min(items.length,Math.max(1,Math.floor((Number.isFinite(availableWidth)&&availableWidth>0?availableWidth:IMAGE_GRID_STEP)/IMAGE_GRID_STEP)));
  const bottoms=Array<number>(columns).fill(origin.y);
  return items.map(item=>{
    let column=0;
    for(let index=1;index<columns;index++)if(bottoms[index]<bottoms[column])column=index;
    const placed={...item,x:origin.x+column*IMAGE_GRID_STEP,y:bottoms[column]};
    bottoms[column]=snap(placed.y+placed.height+IMAGE_GRID_GAP);
    return placed;
  });
}
