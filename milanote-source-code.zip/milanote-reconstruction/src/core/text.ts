/** The note renderer deliberately supports only these text formatting primitives.
 * Source text is escaped first; the only HTML emitted is our fixed markup below.
 * It never accepts HTML, URLs, attributes, or user-defined tag names.
 */
const escapeHtml = (value: string): string =>
  value.replace(
    /[&<>"']/g,
    (character) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        character
      ]!,
  );

type InlineMarker = "**" | "__" | "*" | "_" | "~~" | "++";
const inlineTags: Record<InlineMarker, string> = {
  "**": "strong",
  __: "strong",
  "*": "em",
  _: "em",
  "~~": "s",
  "++": "u",
};

/** A delimiter stack keeps rendering linear and emits only fixed, balanced tags.
 * Unclosed delimiters remain text; inline code is always opaque.
 */
function inline(text: string, html: boolean): string {
  const output: string[] = [];
  const frames: { marker: InlineMarker; index: number; start: number }[] = [];
  const append = (value: string) => output.push(value);
  for (let index = 0; index < text.length; ) {
    const character = text[index]!;
    if (character === "\\" && /[\\*_`~+]/.test(text[index + 1] ?? "")) {
      append(text[index + 1]!);
      index += 2;
      continue;
    }

    if (character === "`") {
      const end = text.indexOf("`", index + 1);
      if (end > index + 1) {
        const content = text.slice(index + 1, end);
        append(html ? `<code>${content}</code>` : content);
        index = end + 1;
        continue;
      }
    }

    const top = frames[frames.length - 1];
    const canClose = index > 0 && !/\s/.test(text[index - 1]!);
    // A double delimiter can open strong emphasis inside single emphasis.
    const opensStrong =
      (top?.marker === "*" || top?.marker === "_") &&
      text.startsWith(top.marker.repeat(2), index) &&
      text[index + 2] !== top.marker &&
      !!text[index + 2] &&
      !/\s/.test(text[index + 2]!);
    if (
      top &&
      text.startsWith(top.marker, index) &&
      index > top.start &&
      canClose &&
      !opensStrong
    ) {
      frames.pop();
      const tag = inlineTags[top.marker];
      output[top.index] = html ? `<${tag}>` : "";
      append(html ? `</${tag}>` : "");
      index += top.marker.length;
      continue;
    }

    const marker: InlineMarker | undefined = text.startsWith("**", index)
      ? "**"
      : text.startsWith("__", index)
        ? "__"
        : text.startsWith("~~", index)
          ? "~~"
          : text.startsWith("++", index)
            ? "++"
            : character === "*" || character === "_"
              ? character
              : undefined;
    // Underscores inside a word remain ordinary text (for example file_name).
    const inWord =
      marker?.includes("_") && /[\p{L}\p{N}]/u.test(text[index - 1] ?? "");
    if (
      marker &&
      !inWord &&
      !!text[index + marker.length] &&
      !/\s/.test(text[index + marker.length]!)
    ) {
      frames.push({
        marker,
        index: output.length,
        start: index + marker.length,
      });
      append(marker);
      index += marker.length;
      continue;
    }
    append(character);
    index++;
  }
  return output.join("");
}

/** Safe, intentionally small Markdown subset for board notes. */
export function renderNoteHtml(text: string): string {
  const lines = escapeHtml(String(text ?? ""))
    .replace(/\r\n?/g, "\n")
    .split("\n");
  const output: string[] = [];
  let paragraph: string[] = [];
  let list: "ul" | "ol" | undefined;
  const closeParagraph = () => {
    if (paragraph.length)
      output.push(
        `<p>${paragraph.map((line) => inline(line, true)).join("<br/>")}</p>`,
      );
    paragraph = [];
  };
  const closeList = () => {
    if (list) output.push(`</${list}>`);
    list = undefined;
  };
  for (const line of lines) {
    if (!line.trim()) {
      closeParagraph();
      closeList();
      continue;
    }
    const heading = /^ {0,3}(#{1,6})[ \t]+(.+?)(?:[ \t]+#+)?[ \t]*$/.exec(line);
    const item = /^ {0,3}([-+*]|\d+[.)])\s+(.+)$/.exec(line);
    if (heading) {
      closeParagraph();
      closeList();
      output.push(
        `<h${heading[1]!.length}>${inline(heading[2]!, true)}</h${heading[1]!.length}>`,
      );
    } else if (item) {
      closeParagraph();
      const kind = /^\d/.test(item[1]!) ? "ol" : "ul";
      if (list !== kind) {
        closeList();
        list = kind;
        const start = kind === "ol" ? Number.parseInt(item[1]!, 10) : 1;
        output.push(
          kind === "ol" && Number.isSafeInteger(start) && start !== 1
            ? `<ol start="${start}">`
            : `<${kind}>`,
        );
      }
      output.push(`<li>${inline(item[2]!, true)}</li>`);
    } else {
      closeList();
      paragraph.push(line);
    }
  }
  closeParagraph();
  closeList();
  return output.join("");
}

/** Plain text corresponding to the supported note formatting. */
export function exportNotePlainText(text: string): string {
  return String(text ?? "")
    .replace(/\r\n?/g, "\n")
    .split("\n")
    .map((line) => {
      const heading = /^ {0,3}#{1,6}[ \t]+(.+?)(?:[ \t]+#+)?[ \t]*$/.exec(line);
      const item = /^ {0,3}([-+*]|\d+[.)])\s+(.+)$/.exec(line);
      if (heading) return inline(heading[1]!, false);
      if (item)
        return `${/^\d/.test(item[1]!) ? `${Number.parseInt(item[1]!, 10)}.` : "•"} ${inline(item[2]!, false)}`;
      return inline(line, false);
    })
    .join("\n");
}
