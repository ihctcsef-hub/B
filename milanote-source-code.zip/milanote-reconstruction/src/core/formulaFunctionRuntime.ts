/** Independent calculation adapter. HyperFormula retains its GPLv3 license; see docs/THIRD-PARTY.md. */
import {HyperFormula} from 'hyperformula';
type Value=string|number|boolean|Error;type Argument=Value|Value[][];type Blank=boolean|boolean[][];
const supported=new Set(HyperFormula.getRegisteredFunctionNames('enGB'));
function column(index:number){let result='';for(let n=index+1;n;n=Math.floor((n-1)/26))result=String.fromCharCode(65+(n-1)%26)+result;return result;}
export class FunctionRuntime {
 private engine?:HyperFormula;
 has(name:string){return supported.has(name);}
 run(name:string,values:Argument[],blanks:Blank[]){
  const h=this.engine??=HyperFormula.buildFromArray([],{licenseKey:'gpl-v3',precisionRounding:17,smartRounding:false,dateFormats:['YYYY-MM-DD','MM/DD/YYYY','DD/MM/YYYY'],language:'enGB',useArrayArithmetic:false});
  const data:(string|number|boolean|null)[][]=[],args:string[]=[];let offset=0;
  values.forEach((value,i)=>{const matrix=Array.isArray(value)?value:[[value]],flags=Array.isArray(blanks[i])?blanks[i] as boolean[][]:[[blanks[i]===true]],width=Math.max(1,...matrix.map(row=>row.length));for(let r=0;r<matrix.length;r++){data[r]??=[];for(let c=0;c<width;c++){const item=matrix[r][c];data[r][offset+c]=flags[r]?.[c]?null:item instanceof Error?item.message:typeof item==='string'?"'"+item:item??null;}}args.push(`${column(offset)}1`+(Array.isArray(value)?`:${column(offset+width-1)}${matrix.length}`:''));offset+=width;});
  h.setSheetContent(0,data);const result=h.calculateFormula(`=${name}(${args.join(',')})`,0);if(result&&typeof result==='object'&&'type'in result)return{error:{code:result.value,message:(result.message|| (result.type==='DIV_BY_ZERO'?"Numbers can't be divided by zero":result.value)).replace(/\.$/,'')}};return{value:result};
 }
 dispose(){this.engine?.destroy();}
}
