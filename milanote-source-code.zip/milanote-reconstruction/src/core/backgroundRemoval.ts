import type { InferenceSession } from 'onnxruntime-web';

export interface BackgroundRemovalProgress {
  stage:'loading-image'|'loading-model'|'segmenting'|'compositing';
  progress:number;
}
export interface BackgroundRemovalResult {
  src:string;
  width:number;
  height:number;
  model:'u2netp';
  alpha:{transparent:number;opaque:number;partial:number};
}
export interface BackgroundRemovalOptions {
  signal?:AbortSignal;
  onProgress?:(progress:BackgroundRemovalProgress)=>void;
  modelUrl?:string;
  runtimeUrl?:string;
}
const INPUT_SIZE=320;
let sessionPromise:Promise<InferenceSession>|undefined;
let sessionModel='';
function checkAbort(signal?:AbortSignal){if(signal?.aborted)throw new DOMException('Background removal was cancelled.','AbortError');}

/** U²-Net/rembg input normalization: RGB divided by image maximum, then ImageNet channel normalization. */
export function normalizeSegmentationInput(pixels:Uint8ClampedArray):Float32Array{
  if(pixels.length!==INPUT_SIZE*INPUT_SIZE*4)throw new Error('The segmentation input must be 320×320 RGBA.');
  let maximum=0;for(let index=0;index<pixels.length;index+=4)maximum=Math.max(maximum,pixels[index],pixels[index+1],pixels[index+2]);
  if(maximum===0)maximum=255;
  const means=[.485,.456,.406],deviations=[.229,.224,.225],plane=INPUT_SIZE*INPUT_SIZE,result=new Float32Array(plane*3);
  for(let index=0;index<plane;index++)for(let channel=0;channel<3;channel++)result[channel*plane+index]=(pixels[index*4+channel]/maximum-means[channel])/deviations[channel];
  return result;
}

/** Convert the model's probability tensor to an 8-bit soft alpha matte. */
export function segmentationMask(values:ArrayLike<number>):Uint8ClampedArray{
  if(values.length!==INPUT_SIZE*INPUT_SIZE)throw new Error('The segmentation model returned an unexpected mask.');
  let minimum=Infinity,maximum=-Infinity;
  for(let index=0;index<values.length;index++){const value=values[index];if(!Number.isFinite(value))throw new Error('The segmentation model returned invalid probabilities.');minimum=Math.min(minimum,value);maximum=Math.max(maximum,value);}
  const span=maximum-minimum,result=new Uint8ClampedArray(values.length);
  if(span<1e-8){result.fill(maximum>.5?255:0);return result;}
  for(let index=0;index<values.length;index++)result[index]=Math.round((values[index]-minimum)/span*255);
  return result;
}

function canvas(width:number,height:number){const value=document.createElement('canvas');value.width=width;value.height=height;return value;}
async function loadImage(src:string,signal?:AbortSignal):Promise<HTMLImageElement>{
  return new Promise((resolve,reject)=>{
    const image=new Image();image.crossOrigin='anonymous';
    const abort=()=>{image.src='';reject(new DOMException('Background removal was cancelled.','AbortError'));};
    signal?.addEventListener('abort',abort,{once:true});
    function cleanup(){signal?.removeEventListener('abort',abort);image.onload=null;image.onerror=null;}
    image.onload=()=>{cleanup();resolve(image);};image.onerror=()=>{cleanup();reject(new Error('The image could not be loaded for background removal.'));};
    if(signal?.aborted){abort();return;}image.src=src;
  });
}

async function getSession(options:BackgroundRemovalOptions):Promise<InferenceSession>{
  const modelUrl=options.modelUrl||'/models/u2netp.onnx';
  if(!sessionPromise||sessionModel!==modelUrl){
    sessionModel=modelUrl;
    sessionPromise=(async()=>{
      const ort=await import('onnxruntime-web/wasm');
      // A single local WASM thread works without cross-origin-isolation and keeps images on-device.
      ort.env.wasm.numThreads=1;ort.env.wasm.proxy=false;
      ort.env.wasm.wasmPaths={wasm:options.runtimeUrl||'/runtime/ort-wasm-simd-threaded.wasm'};
      return ort.InferenceSession.create(modelUrl,{executionProviders:['wasm'],graphOptimizationLevel:'all',executionMode:'sequential'});
    })().catch(error=>{sessionPromise=undefined;throw error;});
  }
  return sessionPromise;
}

/** Real local model inference. The supplied source is never modified or uploaded. */
export async function removeImageBackground(src:string,options:BackgroundRemovalOptions={}):Promise<BackgroundRemovalResult>{
  const {signal,onProgress}=options;checkAbort(signal);onProgress?.({stage:'loading-image',progress:.05});
  const image=await loadImage(src,signal);checkAbort(signal);
  const width=image.naturalWidth,height=image.naturalHeight;
  if(!width||!height||width*height>32000000)throw new Error('This image is too large for local background removal. Use an image below 32 megapixels.');
  const input=canvas(INPUT_SIZE,INPUT_SIZE),inputContext=input.getContext('2d',{willReadFrequently:true});
  if(!inputContext)throw new Error('This browser cannot process image pixels.');
  inputContext.imageSmoothingEnabled=true;inputContext.imageSmoothingQuality='high';inputContext.drawImage(image,0,0,INPUT_SIZE,INPUT_SIZE);
  let pixels:Uint8ClampedArray;
  try{pixels=inputContext.getImageData(0,0,INPUT_SIZE,INPUT_SIZE).data;}catch{throw new Error('This image host does not allow local editing. Download and upload the image first.');}
  onProgress?.({stage:'loading-model',progress:.15});const session=await getSession(options);checkAbort(signal);
  const ort=await import('onnxruntime-web/wasm');
  const tensor=new ort.Tensor('float32',normalizeSegmentationInput(pixels),[1,3,INPUT_SIZE,INPUT_SIZE]);
  onProgress?.({stage:'segmenting',progress:.35});
  // Yield once so the progress state paints before synchronous WASM inference starts.
  await new Promise<void>(resolve=>requestAnimationFrame(()=>resolve()));checkAbort(signal);
  const outputs=await session.run({[session.inputNames[0]]:tensor});tensor.dispose();checkAbort(signal);
  const prediction=outputs[session.outputNames[0]];
  if(!prediction)throw new Error('The segmentation model did not produce a foreground mask.');
  const mask=segmentationMask(prediction.data as Float32Array);
  for(const output of Object.values(outputs))output.dispose();
  onProgress?.({stage:'compositing',progress:.85});
  const maskCanvas=canvas(INPUT_SIZE,INPUT_SIZE),maskContext=maskCanvas.getContext('2d')!;
  const maskPixels=maskContext.createImageData(INPUT_SIZE,INPUT_SIZE);
  for(let index=0;index<mask.length;index++){maskPixels.data[index*4]=255;maskPixels.data[index*4+1]=255;maskPixels.data[index*4+2]=255;maskPixels.data[index*4+3]=mask[index];}
  maskContext.putImageData(maskPixels,0,0);
  const fullMask=canvas(width,height),fullMaskContext=fullMask.getContext('2d',{willReadFrequently:true})!;
  fullMaskContext.imageSmoothingEnabled=true;fullMaskContext.imageSmoothingQuality='high';fullMaskContext.drawImage(maskCanvas,0,0,width,height);
  const output=canvas(width,height),outputContext=output.getContext('2d',{willReadFrequently:true})!;
  outputContext.drawImage(image,0,0);const originalPixels=outputContext.getImageData(0,0,width,height),alphaPixels=fullMaskContext.getImageData(0,0,width,height);
  const alpha={transparent:0,opaque:0,partial:0};
  for(let index=3;index<originalPixels.data.length;index+=4){const value=Math.round(originalPixels.data[index]*alphaPixels.data[index]/255);originalPixels.data[index]=value;if(value<=5)alpha.transparent++;else if(value>=250)alpha.opaque++;else alpha.partial++;}
  checkAbort(signal);outputContext.putImageData(originalPixels,0,0);onProgress?.({stage:'compositing',progress:1});
  return {src:output.toDataURL('image/png'),width,height,model:'u2netp',alpha};
}
