/** Independent compatibility corrections for measured reference results.
 * These adapters use the public FormulaJS implementation for mathematical
 * primitives. They do not imply exhaustive compatibility for each function.
 */
type SpreadsheetFunction = (...args: unknown[]) => unknown;
const failure = (code: '#VALUE!' | '#NUM!' | '#DIV/0!' | '#N/A') => new Error(code);

function number(value: unknown): number | Error {
  if (value instanceof Error) return value;
  if (value === undefined || value === null) return 0;
  if (typeof value === 'boolean') return Number(value);
  if ((typeof value !== 'number' && typeof value !== 'string') || value === '') return failure('#VALUE!');
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : failure('#VALUE!');
}
function text(value: unknown): string | Error {
  if (value instanceof Error) return value;
  if (Array.isArray(value) || (typeof value === 'object' && value !== null)) return failure('#VALUE!');
  if (typeof value === 'boolean') return value ? 'TRUE' : 'FALSE';
  return value === undefined || value === null ? '' : String(value);
}

export function installFormulaCompatibility(functions: Map<string, SpreadsheetFunction>): void {
  const erf = functions.get('ERF');
  if (erf) functions.set('ERF', (lower, upper) => {
    const low = number(lower); if (low instanceof Error) return low;
    if (upper === undefined) return erf(low);
    const high = number(upper); if (high instanceof Error) return high;
    const start = erf(low), end = erf(high);
    return start instanceof Error ? start : end instanceof Error ? end : Number(end) - Number(start);
  });

  functions.set('ATAN2', (x, y) => {
    const a = number(x), b = number(y);
    if (a instanceof Error) return a;
    if (b instanceof Error) return b;
    return a === 0 && b === 0 ? failure('#DIV/0!') : Math.atan2(b, a);
  });

  const base = functions.get('BASE');
  if (base) functions.set('BASE', (...args) => {
    const result = base(...args);
    return typeof result === 'string' ? result.toUpperCase() : result;
  });

  // The legacy functions use the right-hand tail (and two tails for TINV),
  // whereas the identically named FormulaJS aliases point at other variants.
  for (const [alias, target] of Object.entries({
    CHIDIST: 'CHISQ.DIST.RT', CHIINV: 'CHISQ.INV.RT',
    FDIST: 'F.DIST.RT', FINV: 'F.INV.RT', TINV: 'T.INV.2T',
  })) {
    const implementation = functions.get(target);
    if (implementation) functions.set(alias, implementation);
  }

  const rightTail = functions.get('T.DIST.RT'), logGamma = functions.get('GAMMALN');
  if (rightTail && logGamma) functions.set('T.DIST', (x, freedom, cumulative) => {
    const value = number(x), rawDegrees = number(freedom);
    if (value instanceof Error) return value;
    if (rawDegrees instanceof Error) return rawDegrees;
    const degrees = Math.trunc(rawDegrees);
    if (degrees < 1) return failure('#NUM!');
    let integral: boolean;
    if (typeof cumulative === 'boolean') integral = cumulative;
    else {
      const flag = number(cumulative); if (flag instanceof Error) return flag;
      integral = flag !== 0;
    }
    if (integral) {
      const tail = rightTail(Math.abs(value), degrees);
      return tail instanceof Error ? tail : value < 0 ? Number(tail) : 1 - Number(tail);
    }
    const upper = logGamma((degrees + 1) / 2), lower = logGamma(degrees / 2);
    if (upper instanceof Error) return upper;
    if (lower instanceof Error) return lower;
    return Math.exp(Number(upper) - Number(lower) - .5 * Math.log(degrees * Math.PI)
      - ((degrees + 1) / 2) * Math.log1p(value * value / degrees));
  });

  const timeValue = functions.get('TIMEVALUE');
  if (timeValue) functions.set('TIMEVALUE', value => {
    if (typeof value !== 'string') return timeValue(value);
    // Parse a time independently of the current date/time zone. Browser Date
    // parsers reject time-only strings, which caused the measured 12:00 error.
    const match = /^\s*(\d{1,2}):(\d{2})(?::(\d{2}(?:\.\d+)?))?\s*(AM|PM)?\s*$/i.exec(value);
    if (!match) return timeValue(value);
    let hour = Number(match[1]);
    const minute = Number(match[2]), second = Number(match[3] || 0), meridiem = match[4]?.toUpperCase();
    if (minute > 59 || second >= 60 || (meridiem ? hour < 1 || hour > 12 : hour > 23)) return failure('#VALUE!');
    if (meridiem) hour = hour % 12 + (meridiem === 'PM' ? 12 : 0);
    return (hour * 3600 + minute * 60 + second) / 86400;
  });

  functions.set('SUBSTITUTE', (...args) => {
    if (args.length < 3) return failure('#N/A');
    const source = text(args[0]), search = text(args[1]), replacement = text(args[2]);
    if (source instanceof Error) return source;
    if (search instanceof Error) return search;
    if (replacement instanceof Error) return replacement;
    if (!search) return source;
    if (args[3] === undefined) return source.split(search).join(replacement);
    const rawInstance = number(args[3]); if (rawInstance instanceof Error) return rawInstance;
    const instance = Math.trunc(rawInstance); if (instance < 1) return failure('#VALUE!');
    let offset = 0;
    for (let occurrence = 1; occurrence <= instance; occurrence++) {
      const index = source.indexOf(search, offset);
      if (index < 0) return source;
      if (occurrence === instance) return source.slice(0, index) + replacement + source.slice(index + search.length);
      offset = index + search.length;
    }
    return source;
  });
}
