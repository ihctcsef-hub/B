import { arrangeAllColumns, expandSelection } from "./columns";
import { createCard, uid } from "./model";
import type { Board, Card, Connection, Point, Workspace } from "./model";
import { workspaceBoard } from "./shortcuts";

const finitePoint = (point: Point) => Number.isFinite(point.x) && Number.isFinite(point.y);
const translatedPoint = (point: Point | undefined, offset: Point) => point ? { x: point.x + offset.x, y: point.y + offset.y } : undefined;

/** Ownership traversal also checks parent metadata, so an inconsistent graph cannot create a cycle. */
function descendantBoards(workspace: Workspace, root: string): Set<string> {
  const found = new Set<string>(), pending = [root];
  while (pending.length) {
    const id = pending.pop()!;
    const board = workspaceBoard(workspace, id);
    if (found.has(id) || !board) continue;
    found.add(id);
    for (const card of board.cards) if (card.type === "board" && !card.isShortcut) pending.push(card.boardId);
    for (const board of Object.values(workspace.boards)) if (board.parentBoardId === id) pending.push(board.id);
  }
  return found;
}
function translateConnection(connection: Connection, offset: Point): Connection {
  const result = structuredClone(connection);
  if (result.start) result.start = translatedPoint(result.start, offset);
  if (result.end) result.end = translatedPoint(result.end, offset);
  if (result.control) result.control = translatedPoint(result.control, offset);
  return result;
}

/**
 * Move content atomically between boards, retaining card IDs and synced-note groups.
 * `at` anchors the moved group's top-left; omitting it retains canvas coordinates.
 * Explicit placement removes Unsorted status. Otherwise that status is retained.
 * Selected columns carry all members. A member moved alone detaches and restores
 * its standalone width. Only lines with both attached endpoints in the selection
 * move with it. Lines crossing the selection boundary are removed; unrelated free
 * lines remain on their source board. Invalid targets/cycles return the input.
 */
export function moveCardsToBoard(
  workspace: Workspace,
  sourceId: string,
  targetId: string,
  ids: string[],
  at?: Point,
): Workspace {
  const source = workspaceBoard(workspace, sourceId), target = workspaceBoard(workspace, targetId);
  if (!source || !target || sourceId === targetId || (at && !finitePoint(at))) return workspace;
  const selected = new Set(expandSelection(source, ids));
  const incoming = source.cards.filter(card => selected.has(card.id));
  if (!incoming.length) return workspace;
  const targetIds = new Set(target.cards.map(card => card.id));
  if (incoming.some(card => targetIds.has(card.id))) return workspace;
  for (const card of incoming) {
    if (card.type !== "board" || card.isShortcut) continue;
    if (!workspaceBoard(workspace, card.boardId) || card.boardId === workspace.rootBoardId || descendantBoards(workspace, card.boardId).has(targetId)) return workspace;
  }
  const internal = source.connections.filter(line => !!line.from && !!line.to && selected.has(line.from) && selected.has(line.to));
  const targetLines = new Set(target.connections.map(line => line.id));
  if (internal.some(line => targetLines.has(line.id))) return workspace;
  const offset = at ? { x: at.x - Math.min(...incoming.map(card => card.x)), y: at.y - Math.min(...incoming.map(card => card.y)) } : { x: 0, y: 0 };
  const previousColumns = [...new Set(incoming.flatMap(card => card.parentId && !selected.has(card.parentId) ? [card.parentId] : []))];
  const moved = incoming.map(card => {
    const copy = structuredClone(card);
    copy.x += offset.x; copy.y += offset.y;
    if (at) copy.unsorted = false;
    if (copy.parentId && !selected.has(copy.parentId)) {
      copy.parentId = undefined;
      copy.width = copy.preColumnWidth ?? copy.width;
      copy.preColumnWidth = undefined;
    }
    return copy;
  });
  const nextSource = arrangeAllColumns({
    ...source,
    cards: source.cards.filter(card => !selected.has(card.id)),
    connections: source.connections.filter(line => !selected.has(line.from) && !selected.has(line.to)),
  }, previousColumns);
  const nextTarget = arrangeAllColumns({
    ...target,
    cards: [...target.cards, ...moved],
    connections: [...target.connections, ...internal.map(line => translateConnection(line, offset))],
  }, moved.filter(card => card.type === "column").map(card => card.id));
  const boards = { ...workspace.boards, [sourceId]: nextSource, [targetId]: nextTarget };
  for (const card of moved) if (card.type === "board" && !card.isShortcut) boards[card.boardId] = { ...workspaceBoard(workspace, card.boardId)!, parentBoardId: targetId };
  return { ...workspace, boards, updatedAt: new Date().toISOString() };
}

/**
 * Replace a column with a board tile using the same card ID and canvas position.
 * Its members become standalone cards in the new board with a 40px margin; their
 * IDs, note sync groups, internal connections and nested board trees survive.
 * Connections from the former column to outside cards stay attached to the tile.
 * Connections from its members to cards outside the column are removed.
 */
export function convertColumnToBoard(
  workspace: Workspace,
  boardId: string,
  columnId: string,
): { workspace: Workspace; boardId?: string } {
  const source = workspaceBoard(workspace, boardId);
  const column = source?.cards.find(card => card.id === columnId);
  if (!source || column?.type !== "column") return { workspace };
  const seed = uid();
  let childId = seed, suffix = 1;
  while (workspaceBoard(workspace, childId)) childId = `${seed}-${suffix++}`;
  const memberIds = expandSelection(source, [columnId]).filter(id => id !== columnId);
  const tile: Card = {
    ...createCard("board", column.x, column.y), type: "board", id: column.id,
    title: column.title || "Untitled board", boardId: childId, z: column.z,
    color: column.color, locked: column.locked, unsorted: column.unsorted,
    tags: column.tags ? [...column.tags] : undefined,
    labelIds: column.labelIds ? [...column.labelIds] : undefined,
  };
  const child: Board = {
    id: childId, title: tile.title, parentBoardId: boardId, cards: [], connections: [],
    viewport: { x: 0, y: 0, zoom: 1 }, background: source.background, grid: source.grid,
  };
  const next: Workspace = {
    ...workspace, updatedAt: new Date().toISOString(), boards: {
      ...workspace.boards,
      [boardId]: { ...source, cards: source.cards.map(card => card.id === columnId ? tile : card) },
      [childId]: child,
    },
  };
  if (!memberIds.length) return { workspace: next, boardId: childId };
  const moved = moveCardsToBoard(next, boardId, childId, memberIds, { x: 40, y: 40 });
  // A malformed nested board tree must not leave a partially converted column.
  return moved === next ? { workspace } : { workspace: moved, boardId: childId };
}
