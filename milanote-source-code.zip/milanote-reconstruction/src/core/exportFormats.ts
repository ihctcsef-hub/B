/// <reference types="vite/client" />
import { parseFragment } from "parse5";
import interFontUrl from "@fontsource-variable/inter/files/inter-latin-wght-normal.woff2?url";
import type { Board, Card } from "./model";
import type { Paragraph, ParagraphChild, Table, IRunPropertiesOptions, IParagraphOptions } from "docx";
import { noteContentHtml, richHtmlToMarkdown, richHtmlToPlainText, safeNoteLink } from "./richText";
import { evaluateTable, cellKey, normalizeTableMeta,createFormulaWorkbook,reconcileFormulaWorkbook,formulaContextForTable } from "./spreadsheet";
import { taskIndent } from "./todo";
import { displayColor, swatchInk } from "./colors";
import { boardExportBounds, boardsForLinearExport, cardsInReadingOrder, exportBoardHtml, exportCardLabels, exportIconImageSource, exportLabelInk, prepareBoardForExport, visibleCards, type LinearExportOptions, type VisualExportOptions } from "../export";
import { collectPdfVectorText, type PdfVectorOverlay } from './vectorPdf';
import { embedPdfFonts, pdfFontFileForText, canPaintPdfText, paintPdfText, type PdfFontFile } from './pdfFonts';

export interface RasterExportOptions extends VisualExportOptions {
  /** 1 is 96dpi, 2 is 192dpi. The output never silently rescales itself. */
  scale?: number;
  background?: "board" | "white" | "transparent";
  includeTitle?: boolean;
  /** Pass the current .world element to capture the actual rendered editor styles. */
  sourceElement?: HTMLElement;
}
export interface PdfExportOptions extends RasterExportOptions {
  /** Supported non-overlapping text is visibly painted as PDF glyphs. Complex
   * overlap, clipping or unsupported scripts remain raster. Defaults to true. */
  vectorText?: boolean;
  /** 'large' selects high quality, rather than changing the paper dimensions. */
  format?: "standard" | "large";
  /** Board-sized output uses 0.75 PDF points per CSS pixel; paper sizes opt into a fitted page. */
  pageSize?: "board" | "a4" | "a3" | "letter" | "legal";
  orientation?: "auto" | "portrait" | "landscape";
  pagination?: "fit" | "tile";
}
interface HtmlNode {
  nodeName: string;
  tagName?: string;
  value?: string;
  attrs?: { name: string; value: string }[];
  childNodes?: HtmlNode[];
}
type Docx = typeof import("docx");
const blobOf = (bytes: Uint8Array, type: string) => new Blob([new Uint8Array(bytes)], { type });
const abortSignal = () => AbortSignal.timeout(30_000);
const ownText = (node: HtmlNode): string => node.nodeName === "#text" ? node.value || "" : (node.childNodes || []).map(ownText).join("");
const attr = (node: HtmlNode, name: string) => node.attrs?.find(item => item.name === name)?.value || "";
const rtl = (text: string): boolean => /[\u0590-\u08ff]/.test(text.match(/[a-z\u0590-\u08ff]/i)?.[0] || "");
const hex = (color?: string) => /^#[\da-f]{6}$/i.test(color || "") ? color!.slice(1).toUpperCase() : /^#[\da-f]{3}$/i.test(color || "") ? color!.slice(1).split("").map(char => char + char).join("").toUpperCase() : undefined;

function validatedScale(scale = 2): number {
  if (!Number.isFinite(scale) || scale < 0.25 || scale > 4) throw new Error("Export scale must be between 0.25 and 4.");
  return scale;
}
function captureOptions(options: RasterExportOptions): RasterExportOptions {
  return { ...options, bounds: options.bounds ?? "content", includeTitle: options.includeTitle ?? false, background: options.background ?? "white" };
}
export function rasterDimensions(board: Board, options: RasterExportOptions = {}): { width: number; height: number; pixelWidth: number; pixelHeight: number } {
  options = captureOptions(options);
  const area = boardExportBounds(board, options), scale = validatedScale(options.scale);
  const width = Math.ceil(area.width), height = Math.ceil(area.height + (options.includeTitle === false ? 0 : 70));
  const pixelWidth = Math.ceil(width * scale), pixelHeight = Math.ceil(height * scale);
  if (pixelWidth > 32767 || pixelHeight > 32767 || pixelWidth * pixelHeight > 160_000_000)
    throw new Error("This board is too large for the requested raster scale. Choose a smaller scale or export a smaller board.");
  return { width, height, pixelWidth, pixelHeight };
}

async function imageReady(image: HTMLImageElement): Promise<void> {
  if (image.complete && image.naturalWidth) return;
  if (image.complete) throw new Error("An export image could not be loaded.");
  await new Promise<void>((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error("An export image timed out.")), 20_000);
    image.onload = () => { clearTimeout(timeout); resolve(); };
    image.onerror = () => { clearTimeout(timeout); reject(new Error("An export image could not be loaded.")); };
  });
}
async function bytesDataUrl(bytes: Uint8Array, mime: string): Promise<string> {
  let binary = "";
  for (let index = 0; index < bytes.length; index += 8192) binary += String.fromCharCode(...bytes.subarray(index, index + 8192));
  return `data:${mime};base64,${btoa(binary)}`;
}
async function bounded<T>(operation: PromiseLike<T>, milliseconds: number, message: string): Promise<T> {
  let timeout: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([operation, new Promise<never>((_, reject) => { timeout = setTimeout(() => reject(new Error(message)), milliseconds); })]);
  } finally { if (timeout !== undefined) clearTimeout(timeout); }
}
/** WebKit does not fire load events for detached SVG <image> nodes. Embed their
 * resources before html-to-image clones the surface, so its embedder can skip
 * those nodes. Fetch failures stay explicit instead of producing blank images. */
async function embedCaptureImages(element: HTMLElement): Promise<void> {
  const resources = new Map<string, Promise<string>>();
  await Promise.all([...element.querySelectorAll<HTMLImageElement | SVGImageElement>("img,svg image")].map(async node => {
    const htmlImage = node.tagName.toLowerCase() === "img" ? node as HTMLImageElement : undefined;
    const source = htmlImage ? htmlImage.currentSrc || htmlImage.src : (node as SVGImageElement).href.baseVal;
    if (!source) throw new Error("An export image has no resource URL.");
    const url = new URL(source, element.ownerDocument.baseURI).href;
    let resource = resources.get(url);
    if (!resource) {
      resource = (async () => {
        const data = /^data:/i.test(url) ? url : await (async () => { const { bytes, mime } = await fetchBytes(url); return bytesDataUrl(bytes, mime); })();
        const image = new Image(); image.src = data; await imageReady(image);
        return data;
      })();
      resources.set(url, resource);
    }
    const data = await resource;
    if (htmlImage) { htmlImage.loading = "eager"; htmlImage.srcset = ""; htmlImage.src = data; await imageReady(htmlImage); }
    else (node as SVGImageElement).href.baseVal = data;
  }));
}
let fontCssPromise: Promise<string> | undefined;
async function exportFontCss(): Promise<string> {
  fontCssPromise ||= (async () => {
    const response = await fetch(interFontUrl, { signal: abortSignal() });
    if (!response.ok) throw new Error("The bundled export font could not be loaded.");
    const data = await bytesDataUrl(new Uint8Array(await response.arrayBuffer()), "font/woff2");
    return `@font-face{font-family:Inter;font-style:normal;font-weight:100 900;src:url('${data}') format('woff2')}`;
  })().catch(error => { fontCssPromise = undefined; throw error; });
  return fontCssPromise;
}
function exportBackground(board: Board, option: RasterExportOptions["background"]): string {
  return option === "white" ? "#ffffff" : option === "transparent" ? "transparent" : /^#[\da-f]{3}(?:[\da-f]{3})?$/i.test(board.background || "") ? board.background! : "#ebedee";
}
const excludedControl = ".resize-handle,.connector-handle,.table-move-handle,.tableGrid-columnHeaders,.tableGrid-rowHeaders,.column-drop-hint,.column-insertion,.marquee,.draw-overlay,.captionEditor-tools,.captionEditor-link,.todoEditor-add,.todoEditor-more,.todoEditor-dragHandle,.connection-handle,.lock-indicator,.note-editor-loading,.synced-note-indicator";

async function surfaceForBoard(board: Board, options: RasterExportOptions): Promise<{ element: HTMLElement; cleanup: () => void; width: number; height: number }> {
  const dimensions = rasterDimensions(board, options), fontCss = await exportFontCss();
  if (options.sourceElement) {
    const area = boardExportBounds(board, options), titleHeight = options.includeTitle === false ? 0 : 70;
    const element = document.createElement("div");
    element.className = "app reference-layout export-capture";
    element.setAttribute("aria-hidden", "true");
    Object.assign(element.style, { position: "fixed", left: "-100000px", top: "0", display: "block", width: `${dimensions.width}px`, height: `${dimensions.height}px`, minHeight: "0", overflow: "hidden", background: exportBackground(board, options.background), pointerEvents: "none", zIndex: "-1000", color: "#323b4a", font: "11.2px/16px Inter,Arial,sans-serif" });
    const fonts = document.createElement("style"); fonts.textContent = fontCss; element.append(fonts);
    if (titleHeight) {
      const title = document.createElement("div"); title.textContent = board.title; title.dir = "auto";
      Object.assign(title.style, { position: "absolute", left: "32px", top: "20px", height: "36px", font: "600 18px/28px Inter,Arial,sans-serif" }); element.append(title);
      const iconSource = exportIconImageSource(board.icon);
      if (iconSource) {
        const icon = new Image(); icon.src = iconSource; icon.alt = "";
        Object.assign(icon.style, { width: "24px", height: "24px", objectFit: "contain", verticalAlign: "middle", marginInlineEnd: "8px" }); title.prepend(icon);
      } else if (board.icon && !/^(?:data:|https?:|\/)/i.test(board.icon)) title.prepend(`${board.icon} `);
    }
    const clone = options.sourceElement.cloneNode(true) as HTMLElement;
    clone.querySelectorAll(excludedControl).forEach(node => node.remove());
    clone.querySelectorAll(".selected,.selected-line,.tableGrid-cell-active,.tableGrid-cell-selected,.tableGrid-hasSelection,.todoEditor-selected").forEach(node => node.classList.remove("selected", "selected-line", "tableGrid-cell-active", "tableGrid-cell-selected", "tableGrid-hasSelection", "todoEditor-selected"));
    clone.querySelectorAll("[contenteditable]").forEach(node => node.setAttribute("contenteditable", "false"));
    clone.querySelectorAll("[data-card-id],[data-connection-id]").forEach(node => { node.removeAttribute("data-card-id"); node.removeAttribute("data-connection-id"); });
    Object.assign(clone.style, { position: "absolute", left: "0", top: `${titleHeight}px`, width: `${dimensions.width}px`, height: `${dimensions.height - titleHeight}px`, transform: `translate(${-area.x}px,${-area.y}px)`, transformOrigin: "0 0", margin: "0" });
    element.append(clone); document.body.append(element);
    try {
      await bounded(document.fonts.ready, 20_000, "The export font timed out.");
      await embedCaptureImages(element);
      return { element, cleanup: () => element.remove(), ...dimensions };
    } catch (error) { element.remove(); throw error; }
  }
  const prepared = await prepareBoardForExport({ ...board, cards: visibleCards(board) }, { strictResources: true });
  const frame = document.createElement("iframe"); frame.setAttribute("aria-hidden", "true"); frame.tabIndex = -1;
  Object.assign(frame.style, { position: "fixed", left: "-100000px", top: "0", width: `${dimensions.width}px`, height: `${dimensions.height}px`, border: "0", pointerEvents: "none" });
  const loaded = new Promise<void>(resolve => frame.onload = () => resolve());
  frame.srcdoc = exportBoardHtml(prepared, options).replace("</head>", `<style>${fontCss}.sheet{padding:0;width:${dimensions.width}px;height:${dimensions.height}px}.sheet>h1{box-sizing:border-box;height:70px;margin:0;padding:20px 32px;font:600 18px/28px Inter,Arial,sans-serif}body{background:${exportBackground(board, options.background)}}html{background:transparent}</style></head>`);
  document.body.append(frame);
  try {
    await bounded(loaded, 20_000, "The export document timed out.");
    const doc = frame.contentDocument; if (!doc) throw new Error("The export document could not be created.");
    if (options.includeTitle === false) doc.querySelector(".sheet>h1")?.remove();
    await bounded(doc.fonts.ready, 20_000, "The export font timed out.");
    const element = doc.querySelector<HTMLElement>(".sheet"); if (!element) throw new Error("The export surface is missing.");
    await embedCaptureImages(element);
    return { element, cleanup: () => frame.remove(), ...dimensions };
  } catch (error) { frame.remove(); throw error; }
}

async function renderBoardCanvas(board: Board, options: RasterExportOptions = {}, onSurface?: (element:HTMLElement)=>void|Promise<void>): Promise<HTMLCanvasElement> {
  if (typeof document === "undefined") throw new Error("Image and PDF exports require a browser.");
  options = captureOptions(options);
  const surface = await surfaceForBoard(board, options);
  try {
    await onSurface?.(surface.element);
    const { toCanvas } = await import("html-to-image");
    return await bounded(toCanvas(surface.element, { width: surface.width, height: surface.height, pixelRatio: validatedScale(options.scale), backgroundColor: exportBackground(board, options.background), skipAutoScale: true, fontEmbedCSS: await exportFontCss(), cacheBust: false, style: { position: "relative", inset: "auto", insetBlock: "auto", insetInline: "auto", left: "0", top: "0", zIndex: "auto" } }), 30_000, "The board image renderer timed out. Please try again.");
  } finally { surface.cleanup(); }
}
function canvasBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error("The image could not be encoded as PNG.")), "image/png"));
}
export async function exportBoardPng(board: Board, options: RasterExportOptions = {}): Promise<Blob> {
  return canvasBlob(await renderBoardCanvas(board, options));
}
export function pdfPageDimensions(options: PdfExportOptions, width: number, height: number): [number, number] {
  if (!options.pageSize || options.pageSize === "board") {
    if ([width,height].some(value => !Number.isFinite(value) || value <= 0)) throw new Error("PDF board dimensions must be finite and positive.");
    // Observed PNG/PDF pairs share this extra CSS pixel and .24pt paper grid.
    // Content itself retains the measured 0.75pt/CSSpx drawing scale.
    const pageEdge = (value: number) => Number((Math.floor((value + 1) * 25 / 8) * .24).toFixed(2));
    const dimensions: [number, number] = [pageEdge(width), pageEdge(height)];
    if (dimensions.some(value => value > 14400)) throw new Error("This board exceeds the PDF page size limit. Choose an explicit paper size or export a smaller board.");
    return dimensions;
  }
  const sizes = { a4: [595.28, 841.89], a3: [841.89, 1190.55], letter: [612, 792], legal: [612, 1008] } as const;
  const source = sizes[options.pageSize];
  const landscape = options.orientation === "landscape" || (options.orientation !== "portrait" && width > height);
  return landscape ? [source[1], source[0]] : [source[0], source[1]];
}
async function canvasToPdf(canvas: HTMLCanvasElement, title: string, options: PdfExportOptions, logicalSize?: { width: number; height: number }, vector?: {pdf:import('pdf-lib').PDFDocument; overlay:PdfVectorOverlay}): Promise<Blob> {
  const { PDFDocument } = await import("pdf-lib"), pdf = vector?.pdf ?? await PDFDocument.create();
  pdf.setTitle(title); pdf.setCreator("Canvas workspace"); pdf.setProducer("Canvas workspace");
  const scale = validatedScale(options.scale), logicalWidth = logicalSize?.width ?? canvas.width / scale, logicalHeight = logicalSize?.height ?? canvas.height / scale;
  const boardSize = !options.pageSize || options.pageSize === "board";
  const pageSize = pdfPageDimensions(options, logicalWidth, logicalHeight), margin = boardSize ? 0 : 24;
  const availableWidth = pageSize[0] - margin * 2, availableHeight = pageSize[1] - margin * 2;
  const overlay=async(page:import('pdf-lib').PDFPage,x:number,top:number,sx:number,sy:number,clip:{x:number;y:number;width:number;height:number})=>{
    if(!vector?.overlay.texts.length)return;
    const {pushGraphicsState,popGraphicsState,rectangle,clip:clipPath,endPath,PDFString}=await import('pdf-lib');
    page.pushOperators(pushGraphicsState(),rectangle(clip.x,clip.y,clip.width,clip.height),clipPath(),endPath());
    try{for(const run of vector.overlay.texts){
      const y=top-run.baseline*sy,left=x+run.x*sx,size=run.fontSize*sy,width=run.width*sx;
      if(y+size<clip.y||y-size>clip.y+clip.height)continue;
      const painted=paintPdfText(pdf,page,{...run,x:left,y,fontSize:size,width,letterSpacing:(run.letterSpacing??0)*sx});
      if(!painted)throw new Error('A measured PDF text run could not be encoded.');
      if(run.href){
        const box=[Math.max(clip.x,left),Math.max(clip.y,y-size*.25),Math.min(clip.x+clip.width,left+width),Math.min(clip.y+clip.height,y+size)];
        if(box[2]>box[0]&&box[3]>box[1])page.node.addAnnot(pdf.context.register(pdf.context.obj({Type:'Annot',Subtype:'Link',Rect:box,Border:[0,0,0],A:{Type:'Action',S:'URI',URI:PDFString.of(run.href)}})));
      }
    }}finally{page.pushOperators(popGraphicsState());}
  };
  if (boardSize) {
    const image = await pdf.embedPng(await (await canvasBlob(canvas)).arrayBuffer()), page = pdf.addPage(pageSize);
    page.drawImage(image, { x: 0, y: pageSize[1] - logicalHeight * .75, width: logicalWidth * .75, height: logicalHeight * .75 });
    await overlay(page,0,pageSize[1],.75,.75,{x:0,y:pageSize[1]-logicalHeight*.75,width:logicalWidth*.75,height:logicalHeight*.75});
  } else if (options.pagination === "tile") {
    const cropHeight = Math.max(1, Math.floor(canvas.width * availableHeight / availableWidth));
    for (let top = 0; top < canvas.height; top += cropHeight) {
      const segment = document.createElement("canvas"); segment.width = canvas.width; segment.height = Math.min(cropHeight, canvas.height - top);
      const context = segment.getContext("2d"); if (!context) throw new Error("PDF rendering is unavailable.");
      context.drawImage(canvas, 0, top, segment.width, segment.height, 0, 0, segment.width, segment.height);
      const image = await pdf.embedPng(await (await canvasBlob(segment)).arrayBuffer()), page = pdf.addPage(pageSize);
      const drawHeight = availableWidth * segment.height / segment.width;
      page.drawImage(image, { x: margin, y: pageSize[1] - margin - drawHeight, width: availableWidth, height: drawHeight });
      const pixelFactor=availableWidth/canvas.width;
      await overlay(page,margin,pageSize[1]-margin+top*pixelFactor,availableWidth/logicalWidth,pixelFactor*canvas.height/logicalHeight,{x:margin,y:pageSize[1]-margin-availableHeight,width:availableWidth,height:availableHeight});
    }
  } else {
    const image = await pdf.embedPng(await (await canvasBlob(canvas)).arrayBuffer()), page = pdf.addPage(pageSize);
    const factor = Math.min(availableWidth / image.width, availableHeight / image.height);
    const width = image.width * factor, height = image.height * factor;
    page.drawImage(image, { x: (pageSize[0] - width) / 2, y: (pageSize[1] - height) / 2, width, height });
    await overlay(page,(pageSize[0]-width)/2,(pageSize[1]+height)/2,width/logicalWidth,height/logicalHeight,{x:(pageSize[0]-width)/2,y:(pageSize[1]-height)/2,width,height});
  }
  return blobOf(await pdf.save(), "application/pdf");
}
export async function exportBoardPdf(board: Board, options: PdfExportOptions = {}): Promise<Blob> {
  const settings: PdfExportOptions = { ...options, includeTitle: options.includeTitle ?? false, background: options.background ?? "white", scale: options.scale ?? (options.format === "large" ? 3 : 1.5) };
  const dimensions = rasterDimensions(board, settings);
  pdfPageDimensions(settings, dimensions.width, dimensions.height);
  if(settings.vectorText===false)return canvasToPdf(await renderBoardCanvas(board, settings), board.title, settings, dimensions);
  const {PDFDocument}=await import('pdf-lib'),pdf=await PDFDocument.create();
  let overlay:PdfVectorOverlay={texts:[],rasterFallbackNodes:0,overlappingCards:0};
  const canvas=await renderBoardCanvas(board,settings,async element=>{overlay=await pdfOverlayForSurface(pdf,element);});
  return canvasToPdf(canvas,board.title,settings,dimensions,{pdf,overlay});
}
async function pdfOverlayForSurface(pdf:import('pdf-lib').PDFDocument,element:HTMLElement):Promise<PdfVectorOverlay>{
  const files=new Set<PdfFontFile>(),doc=element.ownerDocument,walker=doc.createTreeWalker(element,NodeFilter.SHOW_TEXT);let node:Node|null;
  while((node=walker.nextNode())){
    const parent=node.parentElement;if(!parent||!node.textContent?.length||parent.closest('style,script,svg,textarea,select,option'))continue;
    const style=doc.defaultView!.getComputedStyle(parent),file=pdfFontFileForText(node.textContent,{weight:Number(style.fontWeight)||400,italic:style.fontStyle!=='normal'});
    if(file)files.add(file);
  }
  const fonts=await embedPdfFonts(pdf,{fontFiles:[...files]});
  return collectPdfVectorText(element,(text,weight,italic,width,fontSize,letterSpacing)=>canPaintPdfText(fonts,{text,weight,italic,width,fontSize,letterSpacing}));
}

function runStyles(node: HtmlNode, inherited: IRunPropertiesOptions = {}): IRunPropertiesOptions {
  const styles = { ...inherited }, tag = node.tagName;
  if (tag === "strong") styles.bold = styles.boldComplexScript = true;
  if (tag === "em") styles.italics = styles.italicsComplexScript = true;
  if (tag === "u") styles.underline = { type: "single" };
  if (tag === "s") styles.strike = true;
  if (tag === "code" || tag === "pre") styles.font = "Consolas";
  for (const declaration of attr(node, "style").split(";")) {
    const [name, ...parts] = declaration.split(":"), value = parts.join(":").trim();
    if (name.trim() === "color" && hex(value)) styles.color = hex(value);
    if (name.trim() === "background-color" && hex(value)) styles.shading = { fill: hex(value) };
    if (name.trim() === "font-size" && ["9.6px", "10px"].includes(value)) styles.size = styles.sizeComplexScript = value === "9.6px" ? 14 : 15;
  }
  return styles;
}
function richParagraphs(html: string, dx: Docx): Paragraph[] {
  const parsed = parseFragment(noteContentHtml("", html)) as unknown as HtmlNode;
  let listInstance = 0;
  const inline = (node: HtmlNode, inherited: IRunPropertiesOptions = {}): ParagraphChild[] => {
    if (node.nodeName === "#text") return [new dx.TextRun({ text: node.value || "", rightToLeft: rtl(node.value || ""), ...inherited })];
    if (node.tagName === "br") return [new dx.TextRun({ text: "", break: 1, ...inherited })];
    const styles = runStyles(node, inherited), children = (node.childNodes || []).flatMap(child => inline(child, styles));
    const link = node.tagName === "a" ? safeNoteLink(attr(node, "href")) : undefined;
    return link ? [new dx.ExternalHyperlink({ link, children })] : children;
  };
  const paragraph = (node: HtmlNode, options: IParagraphOptions = {}) => {
    const text = ownText(node), align = /text-align:\s*(left|right|center)/.exec(attr(node, "style"))?.[1];
    const heading = /^h([1-6])$/.exec(node.tagName || "")?.[1];
    return new dx.Paragraph({ children: inline(node), bidirectional: rtl(text), alignment: align === "center" ? dx.AlignmentType.CENTER : align === "right" || (!align && rtl(text)) ? dx.AlignmentType.RIGHT : dx.AlignmentType.LEFT, spacing: { after: 120, line: 240 }, heading: heading ? dx.HeadingLevel[`HEADING_${heading}` as keyof typeof dx.HeadingLevel] : undefined, ...options });
  };
  const blocks = (node: HtmlNode, depth = 0, inherited: IParagraphOptions = {}): Paragraph[] => {
    const tag = node.tagName;
    if (tag === "ul" || tag === "ol") {
      const instance = listInstance++;
      return (node.childNodes || []).flatMap(child => {
        if (child.tagName !== "li") return [];
        const content = { ...child, childNodes: (child.childNodes || []).filter(part => part.tagName !== "ul" && part.tagName !== "ol") };
        const list = tag === "ul" ? { bullet: { level: Math.min(8, depth) } } : { numbering: { reference: "ordered", level: Math.min(8, depth), instance } };
        return [paragraph(content, { ...inherited, ...list }), ...(child.childNodes || []).filter(part => part.tagName === "ul" || part.tagName === "ol").flatMap(part => blocks(part, depth + 1, inherited))];
      });
    }
    if (tag === "blockquote" || tag === "aside") return (node.childNodes || []).flatMap(child => blocks(child, depth, { ...inherited, indent: { left: 240 }, border: { left: { style: dx.BorderStyle.SINGLE, size: 12, color: tag === "aside" ? "7696CD" : "A4B1C5", space: 8 } }, ...(tag === "aside" ? { shading: { fill: "EEF2F8" } } : {}) }));
    if (tag && ["p", "pre", "h1", "h2", "h3", "h4", "h5", "h6"].includes(tag)) return [paragraph(node, inherited)];
    if (node.nodeName === "#text") return node.value?.trim() ? [paragraph(node, inherited)] : [];
    return (node.childNodes || []).flatMap(child => blocks(child, depth, inherited));
  };
  return blocks(parsed);
}
async function fetchBytes(source: string): Promise<{ bytes: Uint8Array; mime: string }> {
  if (!/^(?:https?:\/\/|\/(?!\/)|blob:|data:)/i.test(source)) throw new Error("The resource URL is unsupported.");
  const response = await fetch(source, { credentials: "same-origin", signal: abortSignal() });
  if (!response.ok) throw new Error(`The resource could not be downloaded (${response.status}).`);
  return { bytes: new Uint8Array(await response.arrayBuffer()), mime: (response.headers.get("content-type") || "application/octet-stream").split(";")[0].trim() };
}
async function wordImage(source: string, width: number, height: number, title: string, dx: Docx): Promise<Paragraph> {
  const resource = await fetchBytes(source);
  let bytes = resource.bytes, type: "png" | "jpg" | "gif" | "bmp";
  if (resource.mime === "image/png") type = "png";
  else if (resource.mime === "image/jpeg") type = "jpg";
  else if (resource.mime === "image/gif") type = "gif";
  else if (resource.mime === "image/bmp") type = "bmp";
  else {
    if (typeof document === "undefined") throw new Error(`Word export cannot decode ${resource.mime} outside a browser.`);
    const url = URL.createObjectURL(new Blob([new Uint8Array(bytes)], { type: resource.mime }));
    try {
      const image = new Image(); image.src = url; await imageReady(image);
      const canvas = document.createElement("canvas"); canvas.width = image.naturalWidth; canvas.height = image.naturalHeight;
      const context = canvas.getContext("2d"); if (!context) throw new Error("Image conversion is unavailable.");
      context.drawImage(image, 0, 0); bytes = new Uint8Array(await (await canvasBlob(canvas)).arrayBuffer()); type = "png";
    } finally { URL.revokeObjectURL(url); }
  }
  const factor = Math.min(1, 620 / Math.max(1, width), 820 / Math.max(1, height));
  return new dx.Paragraph({ children: [new dx.ImageRun({ type, data: bytes, transformation: { width: Math.max(1, Math.round(width * factor)), height: Math.max(1, Math.round(height * factor)) }, altText: { name: title, description: title, title } })], spacing: { after: 160 } });
}
async function wordChildren(board: Board, dx: Docx, options: LinearExportOptions = {}): Promise<(Paragraph | Table)[]> {
  const imageIcon = exportIconImageSource(board.icon), textIcon = board.icon && !/^(?:data:|https?:|\/)/i.test(board.icon) ? `${board.icon} ` : "";
  const output: (Paragraph | Table)[] = [new dx.Paragraph({ text: `${textIcon}${board.title}`, heading: dx.HeadingLevel.TITLE, bidirectional: rtl(board.title) })];
  if (imageIcon) output.unshift(await wordImage(imageIcon, 32, 32, "Board icon", dx));
  const text = (value: string, props: IParagraphOptions = {}) => new dx.Paragraph({ children: [new dx.TextRun({ text: value, rightToLeft: rtl(value) })], bidirectional: rtl(value), spacing: { after: 120 }, ...props });
  for (const { card, depth } of cardsInReadingOrder(board)) {
    switch (card.type) {
      case "note":
        if (card.isDocument && card.title) output.push(text(card.title, { heading: dx.HeadingLevel.HEADING_1 }));
        output.push(...richParagraphs(noteContentHtml(card.text, card.html), dx)); break;
      case "column": output.push(text(card.title, { heading: depth ? dx.HeadingLevel.HEADING_2 : dx.HeadingLevel.HEADING_1 })); break;
      case "label": output.push(text(card.text, { heading: dx.HeadingLevel.HEADING_2 })); break;
      case "image":
        if (card.src) output.push(await wordImage(card.src, card.width, Math.max(1, card.height - (card.showCaption === false ? 0 : card.captionHeight || 35)), card.caption || "Image", dx));
        if (card.caption || card.captionHtml) output.push(...richParagraphs(noteContentHtml(card.caption, card.captionHtml), dx)); break;
      case "link": {
        const link = safeNoteLink(card.url);
        output.push(new dx.Paragraph({ children: link ? [new dx.ExternalHyperlink({ link, children: [new dx.TextRun({ text: card.title || card.url, color: "4D78CC", underline: { type: dx.UnderlineType.SINGLE } })] })] : [new dx.TextRun(card.title || card.url)] }));
        if (card.description) output.push(text(card.description));
        if (card.caption || card.captionHtml) output.push(...richParagraphs(noteContentHtml(card.caption || "", card.captionHtml), dx)); break;
      }
      case "todo":
        if (card.title) output.push(text(card.title, { heading: dx.HeadingLevel.HEADING_2 }));
        for (const task of card.items) output.push(new dx.Paragraph({ children: [new dx.TextRun({ text: `${task.done ? "☑" : "☐"} ${task.text}`, strike: task.done }), ...(task.dueDate ? [new dx.TextRun({ text: `  (${task.dueDate}${task.reminderTime ? ` ${task.reminderTime}` : ""})`, color: "7D8797", size: 18 })] : [])], indent: { left: taskIndent(task) * 280 }, bidirectional: rtl(task.text), spacing: { after: 80 } })); break;
      case "table": {
        if (card.title) output.push(text(card.title, { heading: dx.HeadingLevel.HEADING_2 }));
        const meta = normalizeTableMeta(card.cellMeta, card.rows), rows = evaluateTable(card.rows, meta,formulaContextForTable(options.formulaWorkbook?reconcileFormulaWorkbook(options.formulaWorkbook,board.cards.filter(item=>item.type==='table')):createFormulaWorkbook(board.cards.filter(item=>item.type==='table')),card.id,{errorDisplay:'codes'}));
        const columns = Math.max(1, ...rows.map(row => row.length)), widths = card.columnWidths?.length === columns ? card.columnWidths : Array(columns).fill(90), total = widths.reduce((sum, value) => sum + value, 0);
        output.push(new dx.Table({ width: { size: 100, type: dx.WidthType.PERCENTAGE }, columnWidths: widths.map(width => Math.round(width / total * 9360)), rows: rows.map((row, rowIndex) => new dx.TableRow({ children: Array.from({ length: columns }, (_, column) => {
          const style = meta[cellKey(rowIndex, column)] || {};
          return new dx.TableCell({ children: [new dx.Paragraph({ children: [new dx.TextRun({ text: row[column] || "", bold: style.bold, italics: style.italic, rightToLeft: rtl(row[column] || "") })], alignment: style.align === "center" ? dx.AlignmentType.CENTER : style.align === "right" ? dx.AlignmentType.RIGHT : dx.AlignmentType.LEFT })], width: { size: widths[column] / total * 100, type: dx.WidthType.PERCENTAGE }, shading: hex(style.color) ? { fill: hex(style.color) } : undefined, verticalAlign: style.verticalAlign === "bottom" ? dx.VerticalAlign.BOTTOM : style.verticalAlign === "middle" ? dx.VerticalAlign.CENTER : dx.VerticalAlign.TOP });
        }) })) })); output.push(text("")); break;
      }
      case "file": output.push(text(`${card.name} (${card.mime || "File"}, ${card.size} bytes)`)); break;
      case "board": {
        const icon = options.workspace?.boards[card.boardId]?.icon, image = exportIconImageSource(icon);
        if (image) output.push(await wordImage(image, 32, 32, "Board icon", dx));
        output.push(text(`${icon && !/^(?:data:|https?:|\/)/i.test(icon) ? `${icon} ` : ""}${card.title}`, { heading: dx.HeadingLevel.HEADING_2 })); break;
      }
      case "swatch":
        output.push(new dx.Paragraph({ children: [new dx.TextRun({ text: card.showValue === false ? "\u00a0" : displayColor(card.value, card.colorSpace), color: swatchInk(card.value).slice(1).toUpperCase() })], shading: { fill: hex(card.value) || "FFFFFF" }, spacing: { after: 160 } }));
        if (card.showCaption !== false && (card.label || card.captionHtml)) output.push(...richParagraphs(noteContentHtml(card.label, card.captionHtml), dx));
        break;
      case "sketch": {
        if (typeof document !== "undefined") {
          // A drawing is exported at its own bounds, without the board's minimum canvas area.
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.ceil(card.width * 2)); canvas.height = Math.max(1, Math.ceil(card.height * 2));
          const context = canvas.getContext("2d"); if (!context) throw new Error("Drawing export is unavailable.");
          context.scale(2, 2);
          if (card.background !== "transparent") {
            context.fillStyle = /^#[\da-f]{3}(?:[\da-f]{3})?$/i.test(card.background || "") ? card.background! : "#ffffff";
            context.fillRect(0, 0, card.width, card.height);
          }
          for (const path of card.paths) {
            context.strokeStyle = /^#[\da-f]{3}(?:[\da-f]{3})?$/i.test(path.color) ? path.color : "#333333";
            context.lineWidth = path.width; context.lineCap = context.lineJoin = "round";
            context.beginPath(); path.points.forEach((point, index) => index ? context.lineTo(point.x, point.y) : context.moveTo(point.x, point.y)); context.stroke();
          }
          output.push(await wordImage(await bytesDataUrl(new Uint8Array(await (await canvasBlob(canvas)).arrayBuffer()), "image/png"), card.width, card.height, "Sketch", dx));
        } else throw new Error("Word export of sketches requires a browser renderer.");
        break;
      }
    }
    const labels = exportCardLabels(card, options);
    if (labels.length) output.push(new dx.Paragraph({ children: [new dx.TextRun("Labels: "), ...labels.flatMap((label, index) => [new dx.TextRun({ text: label.name, ...(label.color ? { shading: { fill: hex(label.color) }, color: hex(exportLabelInk(label.color)) } : {}) }), ...(index < labels.length - 1 ? [new dx.TextRun(", ")] : [])])], spacing: { after: 160 } }));
  }
  return output;
}
export async function exportBoardWord(board: Board, options: LinearExportOptions = {}): Promise<Blob> {
  const boards = boardsForLinearExport(board, options), dx = await import("docx");
  const children: (Paragraph | Table)[] = [];
  for (let index = 0; index < boards.length; index++) {
    const prepared = await prepareBoardForExport({ ...boards[index], cards: visibleCards(boards[index]) }, { strictResources: true });
    if (index) children.push(new dx.Paragraph({ children: [new dx.PageBreak()] }));
    children.push(...await wordChildren(prepared, dx, options));
  }
  const document = new dx.Document({
    title: board.title, creator: "Canvas workspace", description: "Editable board content",
    styles: { default: { document: {
      run: { font: { ascii: "Inter", hAnsi: "Inter", cs: "Arial" }, size: 22, sizeComplexScript: 22 },
      paragraph: { spacing: { after: 120, line: 240 } },
    } } },
    numbering: { config: [{ reference: "ordered", levels: Array.from({ length: 9 }, (_, level) => ({
      level, format: dx.LevelFormat.DECIMAL, text: `%${level + 1}.`, alignment: dx.AlignmentType.LEFT,
      style: { paragraph: { indent: { left: (level + 1) * 360, hanging: 240 } } },
    })) }] },
    sections: [{ properties: { page: {
      size: { width: 11906, height: 16838 }, margin: { top: 1134, right: 1134, bottom: 1134, left: 1134 },
    } }, children }],
  });
  return blobOf(new Uint8Array(await dx.Packer.toArrayBuffer(document)), "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
}

export function safeAttachmentName(name: string, fallback: string): string {
  const leaf = name.replace(/\\/g, "/").split("/").at(-1) || "";
  const cleaned = leaf.normalize("NFC").replace(/[\u0000-\u001f\u007f<>:"|?*]/g, "_").replace(/^\.+|[. ]+$/g, "").trim();
  const safe = Object.getOwnPropertyNames(Object.prototype).some(name=>name.toLowerCase()===cleaned.toLowerCase()) ? `file-${cleaned}` : cleaned;
  return (safe || fallback).slice(0, 180);
}
function uniqueAttachmentName(candidate: string, used: Set<string>): string {
  let result = candidate, index = 2;
  const match = /^(.*?)(\.[^.]+)?$/.exec(candidate)!, base = match[1], extension = match[2] || "";
  while (used.has(result.toLowerCase())) result = `${base} (${index++})${extension}`;
  used.add(result.toLowerCase()); return result;
}
export async function exportBoardAttachmentsZip(board: Board): Promise<Blob> {
  const { zipSync } = await import("fflate"), entries: Record<string, Uint8Array> = Object.create(null), used = new Set<string>();
  for (const card of visibleCards(board)) {
    if (card.type !== "image" && card.type !== "file") continue;
    const source = card.type === "image" ? card.src : card.dataUrl;
    if (!source) continue;
    const resource = await fetchBytes(source);
    const extensions: Record<string, string> = { "image/png": "png", "image/jpeg": "jpg", "image/gif": "gif", "image/webp": "webp", "image/avif": "avif", "image/svg+xml": "svg", "application/pdf": "pdf", "audio/mpeg": "mp3", "video/mp4": "mp4", "text/plain": "txt" };
    const fallback = `${card.type}-${card.id.replace(/[^a-z0-9_-]/gi, "_")}.${extensions[resource.mime] || "bin"}`;
    const imageName = card.type === "image" ? (card as typeof card & { originalName?: string }).originalName || (/\.[a-z0-9]{2,8}$/i.test(card.caption) ? card.caption : "") : "";
    const filename = uniqueAttachmentName(safeAttachmentName(card.type === "file" ? card.name : imageName, fallback), used);
    entries[filename] = resource.bytes;
  }
  if (!Object.keys(entries).length) throw new Error("This board has no downloadable files or images.");
  return blobOf(zipSync(entries, { level: 6 }), "application/zip");
}

async function renderDocumentCanvas(card: Extract<Card, { type: "note" }>, onSurface?:(element:HTMLElement)=>void|Promise<void>): Promise<HTMLCanvasElement> {
  const surface = document.createElement("div"); surface.dir = "auto";
  surface.setAttribute("aria-hidden", "true");
  Object.assign(surface.style, { position: "fixed", left: "-100000px", top: "0", width: "794px", padding: "48px", boxSizing: "border-box", background: "#fff", color: "#323b4a", font: "14px/22px Inter,Arial,sans-serif", overflowWrap: "anywhere" });
  const style = document.createElement("style"); style.textContent = `${await exportFontCss()}.export-document p{margin:0 0 10px}.export-document h1{font-size:28px;line-height:36px}.export-document h2{font-size:22px;line-height:28px}.export-document h3{font-size:18px}.export-document aside{background:#eef2f8;border-left:3px solid #7696cd;padding:12px 14px}.export-document blockquote{border-left:3px solid #a4b1c5;padding-left:12px}.export-document pre{white-space:pre-wrap;background:#f1f3f5;padding:10px}.export-document a{color:#4d78cc}`;
  surface.append(style); surface.className = "export-document";
  const title = document.createElement("h1"); title.textContent = card.title || "Untitled document"; surface.append(title);
  const content = document.createElement("div"); content.innerHTML = noteContentHtml(card.text, card.html); surface.append(content); document.body.append(surface);
  try {
    await bounded(document.fonts.ready, 20_000, "The export font timed out."); await embedCaptureImages(surface);
    const height = Math.ceil(surface.getBoundingClientRect().height);
    if (height * 794 * 4 > 160_000_000) throw new Error("This document is too long for the PDF renderer.");
    await onSurface?.(surface);
    const { toCanvas } = await import("html-to-image");
    return await bounded(toCanvas(surface, { width: 794, height, pixelRatio: 2, backgroundColor: "#ffffff", fontEmbedCSS: await exportFontCss(), skipAutoScale: true, style: { position: "relative", inset: "auto", insetBlock: "auto", insetInline: "auto", left: "0", top: "0" } }), 30_000, "The document image renderer timed out. Please try again.");
  } finally { surface.remove(); }
}
export async function exportDocumentFile(card: Extract<Card, { type: "note" }>, format: "pdf" | "word" | "markdown" | "text"): Promise<Blob> {
  const title = card.title || "Untitled document", html = noteContentHtml(card.text, card.html);
  if (format === "markdown") return new Blob([`# ${title.replace(/[\\`*_[\]<>#]/g, "\\$&")}\n\n${richHtmlToMarkdown(html)}\n`], { type: "text/markdown;charset=utf-8" });
  if (format === "text") return new Blob([`${title}\n\n${richHtmlToPlainText(html)}\n`], { type: "text/plain;charset=utf-8" });
  if (format === "word") return exportBoardWord({ id: "document-export", title, cards: [{ ...card, isDocument: false, parentId: undefined, unsorted: false }], connections: [], viewport: { x: 0, y: 0, zoom: 1 } });
  if (typeof document === "undefined") throw new Error("PDF document export requires a browser.");
  const {PDFDocument}=await import('pdf-lib'),pdf=await PDFDocument.create();
  let overlay:PdfVectorOverlay={texts:[],rasterFallbackNodes:0,overlappingCards:0};
  const canvas=await renderDocumentCanvas(card,async element=>{overlay=await pdfOverlayForSurface(pdf,element);});
  return canvasToPdf(canvas, title, { format: "standard", pageSize: "a4", orientation: "portrait", pagination: "tile", scale: 2 },undefined,{pdf,overlay});
}
