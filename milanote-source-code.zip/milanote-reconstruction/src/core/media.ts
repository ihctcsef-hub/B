/** Known media providers only; arbitrary supplied HTML is never embedded.
 * Conversions are local: no redirect/oEmbed lookup or provider request occurs. */
export function mediaEmbedUrl(source: string): string | null {
  if (typeof source !== 'string' || source.length > 4096 || /[\u0000-\u001f\u007f]/.test(source)) return null;
  let url: URL;
  try { url = new URL(source.trim()); } catch { return null; }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.port) return null;
  const host = url.hostname.toLowerCase().replace(/^www\./, '');
  if (['youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtube-nocookie.com', 'youtu.be'].includes(host)) {
    const short = /^\/([\w-]{11})\/?$/.exec(url.pathname);
    const player = /^\/(?:shorts|embed|live)\/([\w-]{11})\/?$/.exec(url.pathname);
    const id = host === 'youtu.be' ? short?.[1] : url.pathname === '/watch' ? url.searchParams.get('v') : player?.[1];
    return id && /^[\w-]{11}$/.test(id) ? `https://www.youtube-nocookie.com/embed/${id}` : null;
  }
  if (host === 'vimeo.com' || host === 'player.vimeo.com') {
    const path = host === 'player.vimeo.com' ? /^\/video\/(\d+)\/?$/.exec(url.pathname) : /^(?:\/(\d+)(?:\/([a-zA-Z0-9]+))?\/?|\/channels\/[^/]+\/(\d+)\/?|\/groups\/[^/]+\/videos\/(\d+)\/?|\/showcase\/\d+\/video\/(\d+)\/?)$/.exec(url.pathname);
    if (!path) return null;
    const id = path[1] || path[3] || path[4] || path[5], hash = path[2] || url.searchParams.get('h');
    if (hash && !/^[a-zA-Z0-9]{1,64}$/.test(hash)) return null;
    return `https://player.vimeo.com/video/${id}${hash ? `?h=${hash}` : ''}`;
  }
  if (host === 'ted.com' || host === 'embed.ted.com') {
    const talk = /^\/talks\/(?:lang\/[a-z]{2}(?:-[a-z]{2})?\/)?([a-z0-9_]+)\/?$/i.exec(url.pathname);
    return talk ? `https://embed.ted.com/talks/${talk[1]}` : null;
  }
  if (host === 'open.spotify.com') {
    const path = /^\/(?:intl-[a-z]{2}\/)?(?:embed\/)?(track|album|playlist|episode|show|artist)\/([a-zA-Z0-9]{1,128})\/?$/.exec(url.pathname);
    return path ? `https://open.spotify.com/embed/${path[1]}/${path[2]}` : null;
  }
  if (host === 'soundcloud.com' || host === 'm.soundcloud.com') {
    const path = /^\/([a-zA-Z0-9_-]+)\/(?:(sets)\/)?([a-zA-Z0-9_-]+)\/?$/.exec(url.pathname);
    if (!path || (!path[2] && ['tracks', 'sets', 'albums', 'popular-tracks', 'reposts', 'likes'].includes(path[3]))) return null;
    const canonical = `https://soundcloud.com/${path[1]}/${path[2] ? 'sets/' : ''}${path[3]}`;
    return `https://w.soundcloud.com/player/?url=${encodeURIComponent(canonical)}&auto_play=false`;
  }
  if (host === 'mixcloud.com') {
    const path = /^\/([a-zA-Z0-9_-]+)\/([a-zA-Z0-9_-]+)\/?$/.exec(url.pathname);
    if (!path || ['uploads', 'favorites', 'playlists', 'stream'].includes(path[2])) return null;
    return `https://www.mixcloud.com/widget/iframe/?hide_cover=1&feed=${encodeURIComponent(`/${path[1]}/${path[2]}/`)}`;
  }
  if (host === 'music.apple.com' || host === 'embed.music.apple.com') {
    const path = /^\/([a-z]{2})\/(album|song|playlist)\/([^/]+)\/(\d+|pl\.[a-zA-Z0-9-]+)\/?$/.exec(url.pathname);
    if (!path || (path[2] === 'playlist' ? !path[4].startsWith('pl.') : !/^\d+$/.test(path[4]))) return null;
    const track = url.searchParams.get('i');
    if (track && !/^\d+$/.test(track)) return null;
    return `https://embed.music.apple.com/${path[1]}/${path[2]}/${path[3]}/${path[4]}${track && path[2] === 'album' ? `?i=${track}` : ''}`;
  }
  if (host === 'deezer.com' || host === 'widget.deezer.com') {
    const path = host === 'widget.deezer.com' ? /^\/widget\/(?:dark|light|auto)\/(track|album|playlist)\/(\d+)\/?$/.exec(url.pathname) : /^\/(?:[a-z]{2}\/)?(track|album|playlist)\/(\d+)\/?$/.exec(url.pathname);
    return path ? `https://widget.deezer.com/widget/dark/${path[1]}/${path[2]}` : null;
  }
  if (host === 'codepen.io') {
    const path = /^\/([a-zA-Z0-9_-]{1,64})\/(?:pen|full|embed)\/([a-zA-Z0-9]{1,32})\/?$/.exec(url.pathname);
    return path ? `https://codepen.io/${path[1]}/embed/${path[2]}?default-tab=result` : null;
  }
  if (host === 'airtable.com') {
    // Classic shared-view URLs expose a public share ID; workspace/app URLs do not.
    const path = /^\/(?:embed\/)?(shr[a-zA-Z0-9]{14})\/?$/.exec(url.pathname);
    return path ? `https://airtable.com/embed/${path[1]}` : null;
  }
  if (['maps.google.com', 'google.com'].includes(host) && (host === 'maps.google.com' || /^\/maps(?:\/|$)/.test(url.pathname))) {
    const query = url.searchParams.get('q');
    if (query) return `https://maps.google.com/maps?q=${encodeURIComponent(query)}&output=embed`;
    const place = /\/maps\/place\/([^/]+)/.exec(url.pathname)?.[1];
    if (!place) return null;
    try { return `https://maps.google.com/maps?q=${encodeURIComponent(decodeURIComponent(place.replace(/\+/g, ' ')))}&output=embed`; } catch { return null; }
  }
  return null;
}
