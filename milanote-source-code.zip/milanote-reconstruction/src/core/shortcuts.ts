import { createCard, uid, updateBoard } from './model';
import type { Board, Card, Point, Workspace } from './model';

export type BoardShortcut = Extract<Card, { type: 'board' }> & { isShortcut: true };
/** A registry lookup must not treat Object.prototype names as saved boards. */
export function workspaceBoard(workspace: Pick<Workspace,'boards'>, boardId: string): Board | undefined {
  return Object.hasOwn(workspace.boards, boardId) ? workspace.boards[boardId] : undefined;
}
export function isBoardShortcut(card: Card): card is BoardShortcut {
  return card.type === 'board' && (card as BoardShortcut).isShortcut === true;
}

/** A shortcut is a reference, never an owner and never an independently cloned board. */
export function createBoardShortcut(
  workspace: Workspace, targetBoardId: string, destinationBoardId: string,
  at: Point = { x: 40, y: 40 },
): { workspace: Workspace; id?: string } {
  const target = workspaceBoard(workspace, targetBoardId), destination = workspaceBoard(workspace, destinationBoardId);
  if (!target || !destination || !Number.isFinite(at.x) || !Number.isFinite(at.y)) return { workspace };
  const id = uid();
  const card: BoardShortcut = { ...createCard('board', at.x, at.y), type: 'board', id,
    title: target.title, boardId: targetBoardId, isShortcut: true };
  return { workspace: updateBoard(workspace, destinationBoardId, board => ({ ...board, cards: [...board.cards, card] })), id };
}

export function shortcutTarget(workspace: Workspace, card: Card): Board | undefined {
  return card.type === 'board' ? workspaceBoard(workspace, card.boardId) : undefined;
}

/** Local share/navigation URLs are deliberately independent of Milanote's private IDs. */
export function boardLocalUrl(boardId: string, base = typeof location === 'undefined' ? 'http://localhost/' : location.href): string {
  const url = new URL(base);
  url.hash = `board/${encodeURIComponent(boardId)}`;
  return url.href;
}

/** Only local URLs belonging to a board already in this workspace become shortcuts. */
export function localBoardIdFromUrl(workspace: Workspace, source: string, base = typeof location === 'undefined' ? 'http://localhost/' : location.href): string | null {
  try {
    const origin = new URL(base), url = new URL(source, base);
    if (url.origin !== origin.origin || url.pathname !== origin.pathname || !/^#board\//.test(url.hash)) return null;
    const id = decodeURIComponent(url.hash.slice(7));
    return workspaceBoard(workspace, id) ? id : null;
  } catch { return null; }
}

/** Follow owning tiles only: an alias cycle must not keep deleted boards alive. */
export function ownedBoardDescendants(workspace: Workspace, rootIds: string[]): Set<string> {
  const found = new Set<string>(), pending = [...rootIds];
  while (pending.length) {
    const id = pending.pop()!;
    const board = workspaceBoard(workspace, id);
    if (found.has(id) || !board) continue;
    found.add(id);
    for (const card of board.cards) if (card.type === 'board' && !isBoardShortcut(card)) pending.push(card.boardId);
  }
  return found;
}
