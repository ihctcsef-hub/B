import type { Card } from './model';
export interface LinkMetadata { url: string; title?: string; description?: string; image?: string }
type LinkCard=Extract<Card,{type:'link'}>;
export function normalizeLinkUrl(source:string):string|null {
  if(typeof source!=='string'||source.length>4096)return null;
  try{const url=new URL(source.trim());if(!['http:','https:'].includes(url.protocol)||url.username||url.password)return null;return url.href.length<=4096?url.href:null;}catch{return null;}
}
const plain=(value:unknown,max:number)=>typeof value==='string'?value.replace(/<[^>]*>/g,' ').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g,'').replace(/\s+/g,' ').trim().slice(0,max):'';
export async function fetchLinkMetadata(source:string,{signal,endpoint='/api/links/metadata'}:{signal?:AbortSignal;endpoint?:string}={}):Promise<LinkMetadata>{
  const url=normalizeLinkUrl(source);if(!url)throw new Error('Enter a valid website URL.');
  let response:Response;
  try{response=await fetch(`${endpoint}?url=${encodeURIComponent(url)}`,{signal,credentials:'omit',headers:{Accept:'application/json'}});}catch(error){if(signal?.aborted)throw error;throw new Error('This link preview is unavailable. You can edit its details.');}
  if(!response.ok)throw new Error('This link preview is unavailable. You can edit its details.');
  let data:unknown;try{data=await response.json();}catch{throw new Error('This link preview is unavailable. You can edit its details.');}if(!data||typeof data!=='object')throw new Error('This link preview is unavailable.');
  const value=data as Record<string,unknown>,finalUrl=typeof value.url==='string'?normalizeLinkUrl(value.url):null;if(!finalUrl)throw new Error('This link preview is unavailable.');
  const result:LinkMetadata={url:finalUrl},title=plain(value.title,512),description=plain(value.description,2048),image=typeof value.image==='string'?normalizeLinkUrl(value.image):null;
  if(title)result.title=title;if(description)result.description=description;if(image)result.image=image;return result;
}
/** Fetched provenance permits automatic refresh without replacing custom details. */
export function linkMetadataPatch(current:LinkCard,baseline:LinkCard,metadata:LinkMetadata):Partial<LinkCard>{
  if(current.locked||current.id!==baseline.id||current.url!==baseline.url)return {};
  const patch:Partial<LinkCard>={linkMetadata:{...baseline.linkMetadata,...metadata}};
  const mappings=[['title','title'],['description','description'],['previewSrc','image']] as const;
  for(const [field,source] of mappings){
    const value=metadata[source];if(!value||current[field]!==baseline[field])continue;
    let eligible=!baseline[field]||baseline[field]===baseline.linkMetadata?.[source];
    if(field==='title'){try{eligible ||= baseline.title===baseline.url||baseline.title===new URL(baseline.url).hostname;}catch{/* Invalid legacy URLs have no automatic hostname. */}}
    if(eligible)Object.assign(patch,{[field]:value});
  }
  return patch;
}
