import { parseFragment } from "parse5";
import { renderNoteHtml } from "./text";

interface HtmlNode {
  nodeName: string;
  tagName?: string;
  value?: string;
  attrs?: { name: string; value: string }[];
  childNodes?: HtmlNode[];
}

const escapeHtml = (value: string): string =>
  value.replace(/[&<>"']/g, (character) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]!,
  );
const parse = (html: string): HtmlNode =>
  parseFragment(String(html ?? "")) as unknown as HtmlNode;
const allowedTags = new Set([
  "p", "h1", "h2", "h3", "h4", "h5", "h6", "strong", "em", "s", "u",
  "ul", "ol", "li", "br", "hr", "code", "pre", "blockquote", "a", "span", "mark", "aside",
]);
const discardedTags = new Set([
  "script", "style", "iframe", "object", "embed", "svg", "math", "template",
  "noscript", "xmp", "plaintext", "textarea", "title", "head",
]);
const tagAliases: Record<string, string> = { b: "strong", i: "em", del: "s", strike: "s" };
const blockTags = new Set(["p", "h1", "h2", "h3", "h4", "h5", "h6", "li", "pre", "blockquote", "aside"]);

export function safeNoteColor(value: string): string | undefined {
  return /^#(?:[\da-f]{3}|[\da-f]{6})$/i.test(value) ? value.toLowerCase() : undefined;
}

/** A callout icon is one text grapheme, never HTML, a URL or a CSS value. */
export function safeCalloutIcon(value: unknown): string | undefined {
  if(typeof value!=='string'||!value||value.length>32||/[\u0000-\u0020\u007f-\u009f\u2028\u2029<>]/u.test(value))return undefined;
  const segments=[...new Intl.Segmenter(undefined,{granularity:'grapheme'}).segment(value)];
  return segments.length===1?value:undefined;
}

// Browsers normalize a hex color to rgb() when an existing style is edited.
// Accept only integer RGB channels here, and always store the fixed hex form.
function cssColor(value: string): string | undefined {
  const hex = safeNoteColor(value.trim());
  if (hex) return hex;
  const rgb = /^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$/i.exec(value.trim());
  if (!rgb) return undefined;
  const channels = rgb.slice(1).map(Number);
  return channels.every((channel) => channel <= 255)
    ? `#${channels.map((channel) => channel.toString(16).padStart(2, "0")).join("")}`
    : undefined;
}

/** Links are deliberately limited to web URLs; control characters cannot hide a scheme. */
export function safeNoteLink(value: string): string | undefined {
  const href = String(value ?? "").trim();
  if (!/^https?:\/\//i.test(href) || /[\u0000-\u0020\u007f]/.test(href)) return undefined;
  try {
    const parsed = new URL(href);
    if (!["http:", "https:"].includes(parsed.protocol) || !parsed.hostname) return undefined;
    return parsed.href;
  } catch {
    return undefined;
  }
}

/**
 * Parse HTML with an HTML5 parser, then emit only the note schema. No browser DOM,
 * user-defined tag, style value, event handler, or resource is copied through.
 */
export function sanitizeNoteHtml(html: string): string {
  const visit = (node: HtmlNode): string => {
    if (node.nodeName === "#text") return escapeHtml(node.value ?? "");
    if (node.nodeName === "#comment") return "";
    const originalTag = node.tagName?.toLowerCase();
    if (originalTag && discardedTags.has(originalTag)) return "";
    const children = (node.childNodes ?? []).map(visit).join("");
    if (!originalTag) return children;
    const tag = tagAliases[originalTag] ?? originalTag;
    if (!allowedTags.has(tag)) return children;
    const attr = (name: string) => node.attrs?.find((attribute) => attribute.name === name)?.value;
    let attributes = "";
    if (tag === "aside") {
      if (attr("data-note-callout") !== "true") return children;
      attributes = ' data-note-callout="true"';
      const icon=safeCalloutIcon(attr('data-note-callout-icon'));
      if(icon)attributes+=` data-note-callout-icon="${escapeHtml(icon)}"`;
    }
    if (tag === "a") {
      const href = safeNoteLink(attr("href") ?? "");
      if (!href) return children;
      attributes = ` href="${escapeHtml(href)}" target="_blank" rel="noopener noreferrer"`;
    }
    if (tag === "ol") {
      const start = attr("start") ?? "";
      if (/^[1-9]\d{0,8}$/.test(start) && Number(start) !== 1) attributes += ` start="${Number(start)}"`;
    }
    if (tag === "span" || tag === "mark") {
      const styles = new Map<string, string>();
      for (const declaration of (attr("style") ?? "").split(";")) {
        const colon = declaration.indexOf(":");
        if (colon < 0) continue;
        const name = declaration.slice(0, colon).trim().toLowerCase();
        const value = declaration.slice(colon + 1).trim();
        if ((tag === "span" && name === "color") || (tag === "mark" && name === "background-color")) {
          const color = cssColor(value);
          if (color) styles.set(name, color);
        }
        if (tag === "span" && name === "font-size" && ["9.6px", "10px"].includes(value)) styles.set("font-size", value);
      }
      if (styles.size) attributes += ` style="${[...styles.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([name, value]) => `${name}: ${value}`).join("; ")}"`;
      if (tag === "span" && !styles.size) return children;
    }
    if (blockTags.has(tag)) {
      const declarations = (attr("style") ?? "").split(";");
      const align = declarations.map((declaration) => /^\s*text-align\s*:\s*(left|center|right)\s*$/i.exec(declaration)).find(Boolean)?.[1]?.toLowerCase();
      if (align) attributes += ` style="text-align: ${align}"`;
    }
    return tag === "br"||tag==='hr' ? `<${tag}>` : `<${tag}${attributes}>${children}</${tag}>`;
  };
  return visit(parse(html));
}

/** Old notes contain our small Markdown subset; rich notes store sanitized HTML. */
export function noteContentHtml(text: string, html?: string): string {
  return typeof html === "string" ? sanitizeNoteHtml(html) : renderNoteHtml(text);
}

/** A text export keeps paragraph breaks and list structure while dropping marks. */
export function richHtmlToPlainText(html: string): string {
  const visit = (node: HtmlNode, depth = 0): string => {
    if (node.nodeName === "#text") return node.value ?? "";
    const tag = node.tagName;
    if (tag === "br") return "\n";
    if (tag === "hr") return "\n\n";
    if (tag === "ul" || tag === "ol") {
      let index = Number(node.attrs?.find((attribute) => attribute.name === "start")?.value ?? 1);
      return (node.childNodes ?? []).map((child) => {
        if (child.tagName !== "li") return visit(child, depth);
        const content = (child.childNodes ?? []).map((part) => visit(part, depth + 1)).join("").trim();
        const prefix = `${"  ".repeat(depth)}${tag === "ol" ? `${index++}.` : "•"} `;
        return `${prefix}${content}\n`;
      }).join("") + "\n";
    }
    const content = (node.childNodes ?? []).map((child) => visit(child, depth)).join("");
    return tag && blockTags.has(tag) ? `${content}\n` : content;
  };
  return visit(parse(sanitizeNoteHtml(html))).replace(/\n{3,}/g, "\n\n").trim();
}

const escapeMarkdown = (value: string) => value.replace(/([\\`*_[\]{}<>#+~|])/g, "\\$1");

/** Markdown export mirrors the legacy note renderer, including its ++underline++ mark. */
export function richHtmlToMarkdown(html: string): string {
  const rawText = (node: HtmlNode): string => node.nodeName === "#text"
    ? node.value ?? ""
    : (node.childNodes ?? []).map(rawText).join("");
  const visit = (node: HtmlNode, depth = 0): string => {
    if (node.nodeName === "#text") return escapeMarkdown(node.value ?? "");
    const tag = node.tagName;
    if (tag === "br") return "  \n";
    if (tag === "hr") return "\n---\n\n";
    if (tag === "code" || tag === "pre") {
      const content = rawText(node);
      const longest = Math.max(0, ...(content.match(/`+/g) ?? []).map((run) => run.length));
      const fence = "`".repeat(Math.max(tag === "pre" ? 3 : 1, longest + 1));
      return tag === "pre" ? `${fence}\n${content}\n${fence}\n\n` : `${fence}${content}${fence}`;
    }
    if (tag === "ul" || tag === "ol") {
      let index = Number(node.attrs?.find((attribute) => attribute.name === "start")?.value ?? 1);
      return (node.childNodes ?? []).map((child) => {
        if (child.tagName !== "li") return visit(child, depth);
        const parts = child.childNodes ?? [];
        const body = parts.filter((part) => part.tagName !== "ul" && part.tagName !== "ol").map((part) => visit(part, depth)).join("").trim();
        const nested = parts.filter((part) => part.tagName === "ul" || part.tagName === "ol").map((part) => visit(part, depth + 1)).join("");
        const prefix = `${"  ".repeat(depth)}${tag === "ol" ? `${index++}.` : "-"} `;
        return `${prefix}${body.replace(/\n\n/g, "\n")}\n${nested}`;
      }).join("") + (depth === 0 ? "\n" : "");
    }
    const content = (node.childNodes ?? []).map((child) => visit(child, depth)).join("");
    if (tag === "strong") return `**${content}**`;
    if (tag === "em") return `*${content}*`;
    if (tag === "s") return `~~${content}~~`;
    if (tag === "u") return `++${content}++`;
    if (tag === "a") {
      const href = node.attrs?.find((attribute) => attribute.name === "href")?.value ?? "";
      return `[${content}](${href.replace(/\(/g, "%28").replace(/\)/g, "%29")})`;
    }
    if (tag && /^h[1-6]$/.test(tag)) return `${"#".repeat(Number(tag[1]))} ${content}\n\n`;
    if (tag === "blockquote") return content.trim().split("\n").map((line) => `> ${line}`).join("\n") + "\n\n";
    if (tag === "aside") return "> [!NOTE]\n" + content.trim().split("\n").map((line) => `> ${line}`).join("\n") + "\n\n";
    return tag === "p" ? `${content}\n\n` : content;
  };
  return visit(parse(sanitizeNoteHtml(html))).replace(/\n{3,}/g, "\n\n").trim();
}
