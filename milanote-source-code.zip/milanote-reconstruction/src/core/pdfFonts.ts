/// <reference types="vite/client" />
import fontkit from '@pdf-lib/fontkit';
import type { Font, GlyphRun } from '@pdf-lib/fontkit';
import {
  PDFDict, PDFDocument, PDFFont, PDFHexString, PDFName, PDFOperator, PDFOperatorNames,
  beginText, endText, popGraphicsState, pushGraphicsState, setFillingRgbColor,
  setFontAndSize, setTextMatrix, showText,
} from 'pdf-lib';
import type { PDFPage } from 'pdf-lib';

export const PDF_FONT_FILES = ['Inter-Regular.ttf','Inter-Bold.ttf','Inter-Italic.ttf','Inter-BoldItalic.ttf','NotoSansArabic-Regular.ttf','NotoSansArabic-Bold.ttf'] as const;
export type PdfFontFile = typeof PDF_FONT_FILES[number];
export interface PdfFontHandle { file: PdfFontFile; font: PDFFont; parsed: Font }
export type PdfFontSet = ReadonlyMap<PdfFontFile,PdfFontHandle>;
export interface PdfFontStyle { weight?: number; italic?: boolean }
export interface PdfTextMeasure extends PdfFontStyle {
  text: string;
  fontSize: number;
  /** Browser-measured visual run width, expressed in PDF points. */
  width: number;
  /** CSS letter spacing, in the same point units as width. */
  letterSpacing?: number;
}
export interface PdfTextRun extends PdfTextMeasure {
  /** PDF-space baseline and leftmost visual glyph position. */
  x: number;
  y: number;
  color: readonly [number,number,number];
}
const fontBytes = new Map<PdfFontFile,Promise<Uint8Array>>();
const documentFonts = new WeakMap<PDFDocument,Promise<PdfFontSet>>();
const loadedFonts = new WeakMap<PDFDocument,PdfFontSet>();
const pageResources = new WeakMap<PDFPage,Map<PDFFont,PDFName>>();
const actualTextCounts = new WeakMap<PDFPage,number>();
async function bundledFont(file:PdfFontFile):Promise<Uint8Array> {
  let request=fontBytes.get(file);
  if(!request){
    request=(async()=>{
      const root=import.meta.env.BASE_URL || '/';
      const response=await fetch(`${root}fonts/pdf/${file}`,{signal:AbortSignal.timeout(20000),credentials:'omit'});
      if(!response.ok)throw new Error('A bundled PDF font could not be loaded.');
      const data=new Uint8Array(await response.arrayBuffer());
      if(!data.length||data.length>4*1024*1024)throw new Error('A bundled PDF font is invalid.');
      return data;
    })();
    fontBytes.set(file,request);
    request.catch(()=>{if(fontBytes.get(file)===request)fontBytes.delete(file);});
  }
  return request;
}
/** Embeds openly licensed fonts. Full embedding avoids fontkit's Inter subset
 * outline loss; only genuine visible text creates page text operators. */
export function embedPdfFonts(pdf:PDFDocument,options:{loadFont?:(file:PdfFontFile)=>Promise<Uint8Array>;fontFiles?:readonly PdfFontFile[]}={}):Promise<PdfFontSet> {
  const previous=documentFonts.get(pdf);if(previous)return previous;
  const request=(async()=>{
    pdf.registerFontkit(fontkit);
    const files=[...new Set(options.fontFiles??PDF_FONT_FILES)];
    if(files.some(file=>!PDF_FONT_FILES.includes(file)))throw new Error('Unknown PDF font.');
    const entries=await Promise.all(files.map(async file=>{
      const bytes=await(options.loadFont||bundledFont)(file),parsed=fontkit.create(bytes);
      const font=await pdf.embedFont(bytes,{subset:false});
      return [file,{file,font,parsed}] as const;
    }));
    const fonts:PdfFontSet=new Map(entries);loadedFonts.set(pdf,fonts);return fonts;
  })();
  documentFonts.set(pdf,request);request.catch(()=>documentFonts.delete(pdf));return request;
}
/** Mixed bidi text needs a complete bidi layout pass; keep its existing raster
 * rendering rather than reversing numbers/Latin text or dropping glyphs. */
export function pdfFontFileForText(text:string,style:PdfFontStyle={}):PdfFontFile|null {
  if(!text||/[\r\n\t\u0000-\u0008\u000b\u000c\u000e-\u001f\u202a-\u202e\u2066-\u2069]/u.test(text))return null;
  const arabic=/\p{Script=Arabic}/u.test(text);
  if(arabic&&(/\p{N}/u.test(text)||Array.from(text).some(char=>/\p{L}/u.test(char)&&!/\p{Script=Arabic}/u.test(char))))return null;
  if(arabic&&style.italic)return null;
  const bold=(style.weight??400)>=600;
  return arabic?(bold?'NotoSansArabic-Bold.ttf':'NotoSansArabic-Regular.ttf'):(style.italic?(bold?'Inter-BoldItalic.ttf':'Inter-Italic.ttf'):(bold?'Inter-Bold.ttf':'Inter-Regular.ttf'));
}
export function selectPdfFont(fonts:PdfFontSet,text:string,style:PdfFontStyle={}):PdfFontHandle|null {
  const file=pdfFontFileForText(text,style);if(!file)return null;
  const handle=fonts.get(file);if(!handle)return null;
  // Explicit missing-glyph detection precedes any raster text removal.
  return Array.from(text).every(char=>handle.parsed.hasGlyphForCodePoint(char.codePointAt(0)!))?handle:null;
}
function beginActualText(pdf:PDFDocument,page:PDFPage,text:string):PDFOperator {
  let resources=page.node.Resources();
  if(!resources){resources=pdf.context.obj({});page.node.set(PDFName.of('Resources'),resources);}
  let properties=resources.lookupMaybe(PDFName.of('Properties'),PDFDict);
  if(!properties){properties=pdf.context.obj({});resources.set(PDFName.of('Properties'),properties);}
  let index=actualTextCounts.get(page)||0,name:PDFName;
  do{name=PDFName.of(`CanvasActualText${++index}`);}while(properties.has(name));
  actualTextCounts.set(page,index);
  properties.set(name,pdf.context.register(pdf.context.obj({ActualText:PDFHexString.fromText(text)})));
  return PDFOperator.of(PDFOperatorNames.BeginMarkedContentSequence,[PDFName.of('Span'),name]);
}
function fontResource(page:PDFPage,font:PDFFont):PDFName {
  let fonts=pageResources.get(page);if(!fonts){fonts=new Map();pageResources.set(page,fonts);}
  let name=fonts.get(font);if(!name){name=page.node.newFontDictionary(font.name,font.ref);fonts.set(font,name);}return name;
}
function prepareText(fonts:PdfFontSet,run:PdfTextMeasure):{handle:PdfFontHandle;layout:GlyphRun;encoded:string[];glyphScale:number;stretch:number;letterSpacing:number}|null {
  const handle=selectPdfFont(fonts,run.text,run);if(!handle)return null;
  if(![run.fontSize,run.width].every(Number.isFinite)||run.fontSize<=0||run.width<=0)return null;
  const layout:GlyphRun=handle.parsed.layout(run.text),encoded=handle.font.encodeText(run.text).asString().match(/.{4}/g)||[];
  if(encoded.length!==layout.glyphs.length||layout.positions.length!==encoded.length||layout.glyphs.some(glyph=>glyph.id===0))return null;
  if(layout.positions.some(position=>![position.xAdvance,position.yAdvance,position.xOffset,position.yOffset].every(Number.isFinite)))return null;
  const glyphScale=run.fontSize/handle.parsed.unitsPerEm,total=layout.positions.reduce((sum,position)=>sum+position.xAdvance,0)*glyphScale;
  if(!Number.isFinite(total)||total<=0)return null;
  const letterSpacing=run.letterSpacing??0;
  if(!Number.isFinite(letterSpacing))return null;
  // Spaced runs need one independently positioned glyph per grapheme. Keep
  // cursive shaping, combining marks and ligature clusters raster unless their
  // browser cluster positions can be represented without changing glyph ink.
  if(letterSpacing!==0&&(handle.file.startsWith('Noto')||layout.glyphs.length!==Array.from(run.text).length||layout.glyphs.some(glyph=>glyph.codePoints.length!==1)||/\p{M}/u.test(run.text)))return null;
  const stretch=(run.width-letterSpacing*layout.glyphs.length)/total;if(!Number.isFinite(stretch)||stretch<.25||stretch>4)return null;
  return {handle,layout,encoded,glyphScale,stretch,letterSpacing};
}
/** The collector uses this same shaping/geometry check before removing any
 * visible raster text. Encoding preflight does not paint hidden text. */
export function canPaintPdfText(fonts:PdfFontSet,run:PdfTextMeasure):boolean { return prepareText(fonts,run)!==null; }
/** Paints shaped glyphs as visible PDF text operators, with the original logical
 * Unicode string attached to the same visible marked-content span. Returnsfalse
 * before writing any operators when a sound vector replacement is unavailable. */
export function paintPdfText(pdf:PDFDocument,page:PDFPage,run:PdfTextRun):boolean {
  const fonts=loadedFonts.get(pdf);if(!fonts)throw new Error('PDF fonts have not been loaded.');
  if(![run.x,run.y,...run.color].every(Number.isFinite)||run.color.length!==3||run.color.some(value=>value<0||value>1))return false;
  const prepared=prepareText(fonts,run);if(!prepared)return false;
  const {handle,layout,encoded,glyphScale,stretch,letterSpacing}=prepared;
  const operators:PDFOperator[]=[pushGraphicsState(),beginActualText(pdf,page,run.text),beginText(),setFontAndSize(fontResource(page,handle.font),run.fontSize),setFillingRgbColor(...run.color)];
  let x=run.x,y=run.y;
  for(let index=0;index<encoded.length;index++){
    const position=layout.positions[index];
    operators.push(setTextMatrix(stretch,0,0,1,x+position.xOffset*glyphScale*stretch,y+position.yOffset*glyphScale),showText(PDFHexString.of(encoded[index])));
    x+=position.xAdvance*glyphScale*stretch+letterSpacing;y+=position.yAdvance*glyphScale;
  }
  operators.push(endText(),PDFOperator.of(PDFOperatorNames.EndMarkedContent),popGraphicsState());
  page.pushOperators(...operators);return true;
}
