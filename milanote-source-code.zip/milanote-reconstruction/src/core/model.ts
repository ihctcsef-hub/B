import { reconcileCopiedLabels } from "./labels";
import type { WorkspaceLabel } from "./labels";
import type { TrashEntry } from "./trash";
import type { TableCellMeta } from "./spreadsheet";
import type { ImageEdits } from "./imageEditing";
export type CardType =
  | "note"
  | "image"
  | "link"
  | "todo"
  | "column"
  | "board"
  | "file"
  | "swatch"
  | "sketch"
  | "table"
  | "label";
export interface Point {
  x: number;
  y: number;
}
export interface SketchPath {
  points: Point[];
  color: string;
  width: number;
}
export interface TodoItem {
  id: string;
  text: string;
  done: boolean;
  indent?: number;
  dueDate?: string;
  reminderTime?: string;
}
export interface CardBase {
  id: string;
  type: CardType;
  x: number;
  y: number;
  width: number;
  height: number;
  z: number;
  color?: string;
  /** Retained source value when the captured value is invalid CSS. */
  sourceColor?: string;
  stripColor?: string;
  parentId?: string;
  collapsed?: boolean;
  locked?: boolean;
  unsorted?: boolean;
  align?: "left" | "center" | "right";
  autoHeight?: boolean;
  preColumnWidth?: number;
  tags?: string[];
  labelIds?: string[];
}
export type Card =
  | (CardBase & { type: "note"; text: string; html?: string; title?: string; isDocument?: boolean; syncedId?: string })
  | (CardBase & { type: "image"; src: string; originalName?: string; cutoutSrc?: string; useCutout?: boolean; caption: string; captionHtml?: string; captionHeight?: number; showCaption?: boolean; imageEdits?: ImageEdits })
  | (CardBase & {
      type: "link";
      url: string;
      title: string;
      description: string;
      previewSrc?: string;
      previewWidth?: number;
      previewHeight?: number;
      faviconSrc?: string;
      /** Last fetched values distinguish automatic details from user edits. */
      linkMetadata?: { url: string; title?: string; description?: string; image?: string };
      showPreview?: boolean;
      showMedia?: boolean;
      showInfo?: boolean;
      showCaption?: boolean;
      caption?: string;
      captionHtml?: string;
    })
  | (CardBase & { type: "todo"; title: string; items: TodoItem[] })
  | (CardBase & { type: "column"; title: string })
  | (CardBase & { type: "board"; title: string; boardId: string; isShortcut?: boolean })
  | (CardBase & {
      type: "file";
      name: string;
      mime: string;
      dataUrl?: string;
      /** Public attachment URL, separate from an uploaded local data URL. */
      sourceUrl?: string;
      size: number;
      autoplay?: boolean;
      loop?: boolean;
      poster?: string;
      showPreview?: boolean;
      showFileInfo?: boolean;
      showCaption?: boolean;
      caption?: string;
      captionHtml?: string;
      captionHeight?: number;
      previewSrc?: string;
      previewWidth?: number;
      previewHeight?: number;
      pageCount?: number;
      previewDigest?: string;
      detailWidth?: number;
      detailHeight?: number;
      detailAutoHeight?: boolean;
    })
  | (CardBase & { type: "swatch"; value: string; label: string; captionHtml?: string; captionHeight?: number; showCaption?: boolean; showValue?: boolean; colorSpace?: "hex" | "rgb" | "hsl" })
  | (CardBase & { type: "sketch"; paths: SketchPath[]; background?: string })
  | (CardBase & { type: "table"; title: string; rows: string[][]; columnWidths?: number[]; cellMeta?: Record<string,TableCellMeta> })
  | (CardBase & { type: "label"; text: string });
export interface Connection {
  id: string;
  from: string;
  to: string;
  color: string;
  label?: string;
  style: "solid" | "dashed";
  bend?: number;
  width?: number;
  startArrow?: boolean;
  endArrow?: boolean;
  start?: Point;
  end?: Point;
  control?: Point;
  /** Normalized positions on the attached card; omitted endpoints use automatic edge anchors. */
  fromAnchor?: Point;
  toAnchor?: Point;
}
export interface Viewport {
  x: number;
  y: number;
  zoom: number;
}
export interface Board {
  id: string;
  title: string;
  parentBoardId?: string;
  cards: Card[];
  connections: Connection[];
  viewport: Viewport;
  background?: string;
  grid?: boolean;
  icon?: string;
  /** Factual reference catalog identity; image rendering is resolved separately. */
  sourceIconId?: string;
  /** A locally captured dependency reached through an external board shortcut. */
  isExternalReference?: boolean;
  isTemplate?: boolean;
}
export interface Workspace {
  version: 1;
  id: string;
  title: string;
  boards: Record<string, Board>;
  rootBoardId: string;
  updatedAt: string;
  labels?: WorkspaceLabel[];
  customColors?: string[];
  trash?: TrashEntry[];
  /** Local navigation/content activity; viewport changes are not content edits. */
  boardActivity?: Record<string, { viewedAt?: string; modifiedAt?: string }>;
}
export function uid(): string {
  return (
    globalThis.crypto?.randomUUID?.() ??
    `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`
  );
}
export function createCard(type: CardType, x = 0, y = 0): Card {
  const base = { id: uid(), x, y, width: 270, height: 96, z: Date.now() };
  switch (type) {
    case "note":
      return { ...base, type, height: 56, text: "", color: "#ffffff" };
    case "image":
      return { ...base, type, height: 220, src: "", caption: "" };
    case "link":
      return {
        ...base,
        type,
        height: 58,
        url: "",
        title: "",
        description: "",
      };
    case "todo":
      return {
        ...base,
        type,
        height: 54,
        title: "",
        items: [{ id: uid(), text: "", done: false }],
      };
    case "column":
      return {
        ...base,
        type,
        width: 270,
        height: 126.2,
        autoHeight: true,
        title: "Untitled column",
        z: 0,
      };
    case "board":
      return {
        ...base,
        type,
        width: 160,
        height: 160,
        title: "Untitled board",
        boardId: "",
      };
    case "file":
      return {
        ...base,
        type,
        height: 160,
        name: "Untitled file",
        mime: "",
        size: 0,
      };
    case "swatch":
      return {
        ...base,
        type,
        width: 134,
        height: 142,
        value: "#b7c3a5",
        label: "Sage",
      };
    case "sketch":
      return {
        ...base,
        type,
        width: 320,
        height: 230,
        paths: [],
        background: "#ffffff",
      };
    case "table":
      return {...base,type,width:270,height:94,title:'',rows:Array.from({length:4},()=>['','',''])};
    case "label":
      return { ...base, type, width: 260, height: 60, text: "A new direction" };
  }
}
export function createWorkspace(): Workspace {
  const rootId = uid(),
    nestedId = uid();
  const note = {
    ...createCard("note", 120, 180),
    type: "note" as const,
    text: "A little room for big ideas.\n\nA warm, thoughtful studio. Natural materials, quiet details, and space to create.",
    height: 205,
    color: "#fff4cc",
  };
  const image = {
    ...createCard("image", 405, 180),
    type: "image" as const,
    width: 285,
    height: 310,
    src: "/assets/studio-objects.jpg",
    caption: "Objects with a little character.",
  };
  const image2 = {
    ...createCard("image", 735, 180),
    type: "image" as const,
    width: 285,
    height: 265,
    src: "/assets/studio-light.jpg",
    caption: "Let the light in.",
  };
  const todo = {
    ...createCard("todo", 120, 450),
    type: "todo" as const,
    title: "Make space to create",
    height: 230,
    items: [
      { id: uid(), text: "Gather a few ideas", done: true },
      { id: uid(), text: "Find a visual direction", done: false },
      { id: uid(), text: "Connect the dots", done: false },
    ],
  };
  const link = {
    ...createCard("link", 405, 550),
    type: "link" as const,
    url: "https://milanote.com/",
    title: "A visual way to think",
    description: "Your inspiration, organized in one place.",
    height: 220,
    width: 285,
  };
  const nested = {
    ...createCard("board", 120, 745),
    type: "board" as const,
    title: "Explore the details",
    boardId: nestedId,
    color: "#e8eddd",
  };
  const swatch = {
    ...createCard("swatch", 735, 510),
    type: "swatch" as const,
    value: "#b7c3a5",
    label: "Quiet green",
    width: 125,
  };
  const swatch2 = {
    ...createCard("swatch", 895, 510),
    type: "swatch" as const,
    value: "#e8c6ad",
    label: "Warm clay",
    width: 125,
  };
  const label = {
    ...createCard("label", 120, 90),
    type: "label" as const,
    text: "A fresh perspective",
    width: 500,
  };
  return {
    version: 1,
    id: uid(),
    title: "My creative workspace",
    rootBoardId: rootId,
    updatedAt: new Date().toISOString(),
    boards: {
      [rootId]: {
        id: rootId,
        title: "A fresh perspective",
        cards: [
          label,
          note,
          image,
          image2,
          todo,
          link,
          nested,
          swatch,
          swatch2,
        ],
        connections: [
          {
            id: uid(),
            from: note.id,
            to: image.id,
            color: "#8b9582",
            style: "solid",
          },
        ],
        viewport: { x: 0, y: 0, zoom: 1 },
      },
      [nestedId]: {
        id: nestedId,
        title: "Explore the details",
        parentBoardId: rootId,
        cards: [
          {
            ...createCard("note", 100, 100),
            type: "note",
            text: "Start a new thread of ideas here.\n\nDouble-click a note to edit it.",
            color: "#ffffff",
          },
        ],
        connections: [],
        viewport: { x: 0, y: 0, zoom: 1 },
      },
    },
  };
}
export function updateBoard(
  workspace: Workspace,
  boardId: string,
  fn: (board: Board) => Board,
): Workspace {
  const board = workspace.boards[boardId];
  if (!board) return workspace;
  return {
    ...workspace,
    updatedAt: new Date().toISOString(),
    boards: { ...workspace.boards, [boardId]: fn(board) },
  };
}
export function addCards(
  workspace: Workspace,
  boardId: string,
  cards: Card[],
): Workspace {
  return updateBoard(workspace, boardId, (b) => ({
    ...b,
    cards: [...b.cards, ...cards],
  }));
}
export type CardPatch = Partial<Card> | ((card: Card) => Card);
export function patchCards(
  workspace: Workspace,
  boardId: string,
  ids: string[],
  patch: CardPatch,
): Workspace {
  const selected = new Set(ids);
  return updateBoard(workspace, boardId, (b) => ({
    ...b,
    cards: b.cards.map((c) =>
      selected.has(c.id)
        ? typeof patch === "function"
          ? patch(c)
          : ({ ...c, ...patch, id: c.id, type: c.type } as Card)
        : c,
    ),
  }));
}
export function deleteCards(
  workspace: Workspace,
  boardId: string,
  ids: string[],
): Workspace {
  const board = workspace.boards[boardId];
  if (!board) return workspace;
  const removed = new Set(ids);
  // A column owns its children, so deletion never leaves dangling containment references.
  let changed = true;
  while (changed) {
    changed = false;
    for (const c of board.cards)
      if (c.parentId && removed.has(c.parentId) && !removed.has(c.id)) {
        removed.add(c.id);
        changed = true;
      }
  }
  const next = updateBoard(workspace, boardId, (b) => ({
    ...b,
    cards: b.cards.filter((c) => !removed.has(c.id)),
    connections: b.connections.filter(
      (c) => !removed.has(c.from) && !removed.has(c.to),
    ),
  }));
  const reachable = new Set<string>(),
    pending = [next.rootBoardId, ...Object.values(next.boards).filter(board=>board.isTemplate).map(board=>board.id)];
  while (pending.length) {
    const id = pending.pop()!;
    if (reachable.has(id)) continue;
    reachable.add(id);
    for (const c of next.boards[id]?.cards ?? [])
      if (c.type === "board" && !c.isShortcut) pending.push(c.boardId);
  }
  return {
    ...next,
    boards: Object.fromEntries(
      Object.entries(next.boards).filter(([id]) => reachable.has(id)),
    ),
  };
}
export function duplicateCards(
  workspace: Workspace,
  boardId: string,
  ids: string[],
  offset: Point = { x: 32, y: 32 },
): { workspace: Workspace; ids: string[] } {
  const board = workspace.boards[boardId];
  if (!board) return { workspace, ids: [] };
  const selected = new Set(ids);
  let expanded = true;
  while (expanded) {
    expanded = false;
    for (const c of board.cards)
      if (c.parentId && selected.has(c.parentId) && !selected.has(c.id)) {
        selected.add(c.id);
        expanded = true;
      }
  }
  const remap = new Map(
    board.cards.filter((c) => selected.has(c.id)).map((c) => [c.id, uid()]),
  );
  const boards = { ...workspace.boards };
  function cloneBoard(
    sourceId: string,
    parentId: string,
    ancestors: Set<string>,
  ): string {
    const source = workspace.boards[sourceId];
    if (!source || ancestors.has(sourceId)) return sourceId;
    const id = uid(),
      cardIds = new Map(source.cards.map((c) => [c.id, uid()])),
      path = new Set([...ancestors, sourceId]);
    const cards = source.cards.map((c) => {
      const copy = {
        ...structuredClone(c),
        id: cardIds.get(c.id)!,
        parentId: c.parentId ? cardIds.get(c.parentId) : undefined,
      };
      if (copy.type === "board" && !copy.isShortcut)
        copy.boardId = cloneBoard(copy.boardId, id, path);
      return copy;
    });
    boards[id] = {
      ...structuredClone(source),
      id,
      parentBoardId: parentId,
      cards,
      connections: source.connections.map((c) => ({
        ...c,
        id: uid(),
        from: cardIds.get(c.from) ?? "",
        to: cardIds.get(c.to) ?? "",
      })),
    };
    return id;
  }
  const copies = board.cards
    .filter((c) => selected.has(c.id))
    .map((c) => {
      const copy = {
        ...structuredClone(c),
        id: remap.get(c.id)!,
        x: c.x + offset.x,
        y: c.y + offset.y,
        parentId: c.parentId
          ? (remap.get(c.parentId) ?? c.parentId)
          : undefined,
        z: c.z + 1,
      };
      if (copy.type === "board" && !copy.isShortcut)
        copy.boardId = cloneBoard(copy.boardId, boardId, new Set([boardId]));
      return copy;
    });
  const connections = board.connections
    .filter((c) => remap.has(c.from) && remap.has(c.to))
    .map((c) => ({
      ...c,
      id: uid(),
      from: remap.get(c.from)!,
      to: remap.get(c.to)!,
    }));
  const next = updateBoard({ ...workspace, boards }, boardId, (b) => ({
    ...b,
    cards: [...b.cards, ...copies],
    connections: [...b.connections, ...connections],
  }));
  return { workspace: next, ids: copies.map((c) => c.id) };
}
/** Copy from a clipboard snapshot, including contained cards, internal lines and nested boards. */
export function copyCardsToBoard(
  source: Workspace,
  sourceBoardId: string,
  ids: string[],
  target: Workspace,
  targetBoardId: string,
  offset: Point = { x: 32, y: 32 },
): { workspace: Workspace; ids: string[] } {
  if (!source.boards[sourceBoardId] || !target.boards[targetBoardId])
    return { workspace: target, ids: [] };
  const cloned = duplicateCards(source, sourceBoardId, ids, offset),
    newIds = new Set(cloned.ids);
  const sourceBoard = cloned.workspace.boards[sourceBoardId];
  const cards = sourceBoard.cards
    .filter((c) => newIds.has(c.id))
    .map((c) => ({
      ...c,
      parentId: c.parentId && newIds.has(c.parentId) ? c.parentId : undefined,
    }));
  const connections = sourceBoard.connections.filter(
    (c) => newIds.has(c.from) && newIds.has(c.to),
  );
  const newBoards = Object.fromEntries(
    Object.entries(cloned.workspace.boards)
      .filter(([id]) => !Object.hasOwn(source.boards, id))
      .map(([id, b]) => [
        id,
        {
          ...b,
          parentBoardId:
            b.parentBoardId === sourceBoardId ? targetBoardId : b.parentBoardId,
        },
      ]),
  );
  const reconciled=reconcileCopiedLabels(source,target,cards,newBoards);
  const next = updateBoard(
    { ...target, labels:reconciled.labels, boards: { ...target.boards, ...reconciled.boards } },
    targetBoardId,
    (b) => ({
      ...b,
      cards: [...b.cards, ...reconciled.cards],
      connections: [...b.connections, ...connections],
    }),
  );
  return { workspace: next, ids: cloned.ids };
}
export function addConnection(
  workspace: Workspace,
  boardId: string,
  from: string,
  to: string,
  color = "#697569",
): Workspace {
  const b = workspace.boards[boardId];
  if (
    !b ||
    from === to ||
    !b.cards.some((c) => c.id === from) ||
    !b.cards.some((c) => c.id === to)
  )
    return workspace;
  if (b.connections.some((c) => c.from === from && c.to === to))
    return workspace;
  return updateBoard(workspace, boardId, (b) => ({
    ...b,
    connections: [
      ...b.connections,
      { id: uid(), from, to, color, style: "solid" },
    ],
  }));
}
export function createNestedBoard(
  workspace: Workspace,
  parentBoardId: string,
  x = 0,
  y = 0,
  title = "Untitled board",
): {
  workspace: Workspace;
  card: Extract<Card, { type: "board" }>;
  boardId: string;
} {
  const boardId = uid();
  const card = {
    ...createCard("board", x, y),
    type: "board" as const,
    title,
    boardId,
  };
  const next = addCards(
    {
      ...workspace,
      boards: {
        ...workspace.boards,
        [boardId]: {
          id: boardId,
          title,
          parentBoardId,
          cards: [],
          connections: [],
          viewport: { x: 0, y: 0, zoom: 1 },
        },
      },
    },
    parentBoardId,
    [card],
  );
  return { workspace: next, card, boardId };
}
