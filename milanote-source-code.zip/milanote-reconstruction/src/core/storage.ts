import { isValidWorkspaceLabels } from "./labels";
import { isValidTrashEntry, trashEntryValidationWorkspace } from "./trash";
import { isValidTodoMetadata } from "./todo";
import { isValidTableMeta } from "./spreadsheet";
import { isValidImageEdits } from "./imageEditing";
import { sanitizeNoteHtml } from "./richText";
import type { Workspace, Card, CardType } from "./model";

const DB_NAME = "visual-workspace";
const STORE = "documents";
const KEY = "workspace";
const FALLBACK_KEY = "visual-workspace-backup-v1";
const types: CardType[] = [
  "note",
  "image",
  "link",
  "todo",
  "column",
  "board",
  "file",
  "swatch",
  "sketch",
  "table",
  "label",
];
type UnknownRecord = Record<string, unknown>;
function record(value: unknown): value is UnknownRecord {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function require(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(`Invalid workspace: ${message}`);
}
function string(value: unknown): value is string {
  return typeof value === "string";
}
function finite(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}
function safeColor(value:unknown):value is string {
  return string(value)&&/^(?:#(?:[\da-f]{3}|[\da-f]{4}|[\da-f]{6}|[\da-f]{8})|[a-z]{1,24}|(?:rgba?|hsla?)\([\d\s.,%/+\-]+\))$/i.test(value);
}
function validCard(value: unknown): value is Card {
  require(record(value), "card must be an object");
  require(string(value.id) && value.id.length > 0, "card ID is missing");
  require(types.includes(value.type as CardType), "unknown card type");
  require(finite(value.x) &&
    finite(value.y) &&
    finite(value.z), "invalid card position");
  require(finite(value.width) &&
    value.width > 0 &&
    finite(value.height) &&
    value.height > 0, "invalid card size");
  for (const k of ["parentId"])
    require(value[k] === undefined || string(value[k]), `invalid card ${k}`);
  require(value.color===undefined||safeColor(value.color),"invalid card color");
  require(value.sourceColor===undefined||string(value.sourceColor),"invalid source color metadata");
  require(value.stripColor===undefined||(string(value.stripColor)&&/^#[\da-f]{6}$/i.test(value.stripColor)),"invalid card color strip");
  for (const k of ["collapsed", "locked", "unsorted", "autoHeight"])
    require(value[k] === undefined ||
      typeof value[k] === "boolean", `invalid card ${k}`);
  require(value.align === undefined ||
    ["left", "center", "right"].includes(
      value.align as string,
    ), "invalid alignment");
  require(value.preColumnWidth === undefined ||
    (finite(value.preColumnWidth) &&
      value.preColumnWidth > 0), "invalid previous card width");
  require(value.captionHeight === undefined || (finite(value.captionHeight) && value.captionHeight >= 16 && value.captionHeight <= 2400), "invalid caption height");
  require(value.captionHtml === undefined || string(value.captionHtml), "invalid rich caption");
  require(value.labelIds===undefined||(Array.isArray(value.labelIds)&&value.labelIds.every(string)&&new Set(value.labelIds).size===value.labelIds.length), "invalid label assignments");
  require(value.tags === undefined || (Array.isArray(value.tags) && value.tags.every(string)), "invalid labels");
  require(value.showCaption === undefined || typeof value.showCaption === "boolean", "invalid caption visibility");
  switch (value.type) {
    case "note":
      require(string(value.text), "text must be a string");
      require(value.html===undefined||string(value.html),"invalid rich text");
      require(value.isDocument === undefined || typeof value.isDocument === "boolean", "invalid document");
      for(const field of ["title", "syncedId"]) require(value[field] === undefined || string(value[field]), "invalid note metadata");
      break;
    case "label":
      require(string(value.text), "text must be a string");
      break;
    case "image":
      require(value.originalName===undefined||string(value.originalName),"invalid original image name");
      require(value.useCutout===undefined||typeof value.useCutout==='boolean',"invalid cutout state");
      require(value.cutoutSrc===undefined||(string(value.cutoutSrc)&&/^data:image\/png;base64,[a-z\d+/=\s]+$/i.test(value.cutoutSrc)),"invalid cutout image");
      require(string(value.src) && string(value.caption), "invalid image");
      require(value.imageEdits===undefined||isValidImageEdits(value.imageEdits),"invalid image edits");
      require(value.src === "" ||
        /^(?:https?:\/\/|\/(?!\/)|data:image\/[a-z0-9.+-]+[;,])/i.test(
          value.src,
        ), "unsupported image source");
      break;
    case "link":
      if (value.linkMetadata !== undefined) {
        const metadata=value.linkMetadata;
        require(record(metadata), "invalid link metadata");
        const webUrl=(value:unknown)=>{if(!string(value)||value.length>4096)return false;try{const url=new URL(value);return ['http:','https:'].includes(url.protocol)&&!url.username&&!url.password;}catch{return false;}};
        require(webUrl(metadata.url), "invalid link metadata URL");
        for(const field of ['title','description']) require(metadata[field]===undefined||(string(metadata[field])&&metadata[field].length<=4096), "invalid link metadata text");
        require(metadata.image===undefined||webUrl(metadata.image), "invalid link metadata image");
      }
      for (const field of ["showPreview", "showInfo", "showMedia"]) require(value[field] === undefined || typeof value[field] === "boolean", "invalid link visibility");
      for (const field of ["previewSrc", "caption"]) require(value[field] === undefined || string(value[field]), "invalid link preview");
      require(value.faviconSrc === undefined || string(value.faviconSrc), 'invalid link favicon');
      for (const field of ['previewWidth','previewHeight']) require(value[field] === undefined || (finite(value[field]) && value[field] > 0), 'invalid link preview dimensions');
      require(string(value.url) &&
        string(value.title) &&
        string(value.description), "invalid link");
      break;
    case "column":
      require(string(value.title), "invalid column");
      break;
    case "board":
      require(value.isShortcut === undefined || typeof value.isShortcut === "boolean", "invalid shortcut");
      require(string(value.title) &&
        string(value.boardId), "invalid board card");
      break;
    case "todo":
      require(string(value.title) &&
        Array.isArray(value.items), "invalid to-do list");
      require(value.items.every(
        (i) =>
          record(i) &&
          string(i.id) &&
          string(i.text) &&
          typeof i.done === "boolean" && isValidTodoMetadata(i),
      ), "invalid to-do item");
      require(new Set(value.items.map((i) => (i as UnknownRecord).id)).size ===
        value.items.length, "duplicate to-do IDs");
      break;
    case "file":
      for (const field of ["autoplay", "loop", "showPreview", "showFileInfo", "detailAutoHeight"]) require(value[field] === undefined || typeof value[field] === "boolean", "invalid media preference");
      require(value.poster === undefined || string(value.poster), "invalid media poster");
      for (const field of ["caption", "previewSrc"]) require(value[field] === undefined || string(value[field]), "invalid file preview text");
      for (const field of ["previewWidth", "previewHeight", "pageCount", "detailWidth", "detailHeight"]) require(value[field] === undefined || (finite(value[field]) && value[field] > 0), "invalid file preview dimensions");
      require(value.previewDigest === undefined || (string(value.previewDigest) && /^[a-f\d]{64}$/.test(value.previewDigest)), "invalid file preview digest");
      if (value.sourceUrl !== undefined) {
        let valid=false;
        if(string(value.sourceUrl))try{const url=new URL(value.sourceUrl);valid=['https:','http:'].includes(url.protocol)&&!url.username&&!url.password;}catch{/* Invalid public attachment URL. */}
        require(valid,"invalid file source URL");
      }
      require(string(value.name) &&
        string(value.mime) &&
        finite(value.size) &&
        value.size >= 0 &&
        (value.dataUrl === undefined || string(value.dataUrl)), "invalid file");
      require(value.dataUrl === undefined ||
        /^data:[^,]*,/i.test(value.dataUrl), "invalid file data URL");
      break;
    case "swatch":
      require(value.showValue === undefined || typeof value.showValue === "boolean", "invalid swatch code visibility");
      require(value.colorSpace === undefined || ["hex", "rgb", "hsl"].includes(value.colorSpace as string), "invalid swatch format");
      require(string(value.value) &&
        /^#[0-9a-f]{6}$/i.test(value.value) &&
        string(value.label), "invalid color swatch");
      break;
    case "sketch":
      require(Array.isArray(value.paths) &&
        (value.background === undefined ||
          safeColor(value.background)), "invalid sketch");
      require(value.paths.every(
        (p) =>
          record(p) &&
          safeColor(p.color) &&
          finite(p.width) &&
          p.width > 0 &&
          Array.isArray(p.points) &&
          p.points.every((pt) => record(pt) && finite(pt.x) && finite(pt.y)),
      ), "invalid sketch path");
      break;
    case "table":
      require(string(value.title) &&
        Array.isArray(value.rows) &&
        value.rows.every(
          (r) => Array.isArray(r) && r.every(string),
        ), "invalid table");
      require(value.columnWidths===undefined || (Array.isArray(value.columnWidths) && value.columnWidths.length===Math.max(1,...(value.rows as string[][]).map(row=>row.length)) && value.columnWidths.every(width=>finite(width)&&width>=40&&width<=2400)), "invalid table column widths");
      require(value.cellMeta===undefined||isValidTableMeta(value.cellMeta,value.rows as string[][]),"invalid table cell metadata");
      break;
  }
  return true;
}

/** Validate the complete graph before replacing the current document. */
export function validateWorkspace(value: unknown, options:{skipTrash?:boolean;allowUnknownLabels?:boolean}={}): Workspace {
  require(record(value), "document must be an object");
  require(value.version === 1, "unsupported file version");
  require(string(value.id) &&
    string(value.title) &&
    string(value.rootBoardId), "missing document metadata");
  require(string(value.updatedAt) &&
    Number.isFinite(Date.parse(value.updatedAt)), "invalid update time");
  require(record(value.boards) &&
    Object.hasOwn(
      value.boards,
      value.rootBoardId,
    ), "root board does not exist");
  require(value.labels===undefined||isValidWorkspaceLabels(value.labels), "invalid global labels");
  require(value.customColors===undefined||(Array.isArray(value.customColors)&&value.customColors.length<=7&&value.customColors.every(color=>string(color)&&/^#[\da-f]{6}$/i.test(color))&&new Set(value.customColors).size===value.customColors.length),"invalid custom colors");
  require(value.boardActivity===undefined||(record(value.boardActivity)&&Object.values(value.boardActivity).every(activity=>record(activity)&&['viewedAt','modifiedAt'].every(field=>activity[field]===undefined||(string(activity[field])&&Number.isFinite(Date.parse(activity[field])))))),"invalid board activity");
  const labelIds=new Set((value.labels as Array<{id:string}>|undefined||[]).map(label=>label.id));
  const boards = value.boards;
  const boardOwners = new Map<string, string>();
  for (const [id, b] of Object.entries(boards)) {
    require(record(b) &&
      b.id === id &&
      string(b.title), "invalid board metadata");
    require(b.grid === undefined ||
      typeof b.grid === "boolean", "invalid board grid");
    require(b.background === undefined ||
      (string(b.background) &&
        /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i.test(
          b.background,
        )), "invalid board background");
    require(b.parentBoardId === undefined ||
      (string(b.parentBoardId) &&
        Object.hasOwn(boards, b.parentBoardId)), "board parent does not exist");
    require(record(b.viewport) &&
      finite(b.viewport.x) &&
      finite(b.viewport.y) &&
      finite(b.viewport.zoom) &&
      b.viewport.zoom > 0, "invalid viewport");
    require(Array.isArray(b.cards) &&
      b.cards.every(validCard), "invalid card list");
    const cards = b.cards as Card[],
      ids = new Set(cards.map((c) => c.id));
    require(ids.size === cards.length, "duplicate card IDs");
    const byId = new Map(cards.map((c) => [c.id, c]));
    for (const card of cards) {
      require(options.allowUnknownLabels || !card.labelIds?.some(label=>!labelIds.has(label)), "unknown label assignment");
      if (card.type === "board" && !card.isShortcut) {
        require(Object.hasOwn(
          boards,
          card.boardId,
        ), "nested board does not exist");
        require(card.boardId !==
          value.rootBoardId, "root board cannot be nested");
        require(!boardOwners.has(
          card.boardId,
        ), "nested board has multiple owners");
        const nested = boards[card.boardId];
        require(record(nested) &&
          nested.parentBoardId ===
            id, "nested board parent does not match its containing board");
        boardOwners.set(card.boardId, id);
      }
      if (card.parentId) {
        require(byId.get(card.parentId)?.type ===
          "column", "card parent is not a column");
        const visited = new Set([card.id]);
        let current: Card | undefined = card;
        while (current?.parentId) {
          require(!visited.has(current.parentId), "cyclic column containment");
          visited.add(current.parentId);
          current = byId.get(current.parentId);
        }
        require(card.type !== "column", "columns cannot contain columns");
      }
    }
    require(b.icon === undefined || string(b.icon), "invalid board icon");
    require(b.sourceIconId === undefined || string(b.sourceIconId), "invalid board icon identity");
    require(b.isExternalReference === undefined || typeof b.isExternalReference === 'boolean', 'invalid external reference state');
    require(b.isTemplate === undefined || typeof b.isTemplate === "boolean", "invalid board template");
    require(Array.isArray(b.connections), "invalid connection list");
    const connectionIds = new Set<string>();
    for (const c of b.connections) {
      require(record(c) &&
        string(c.id) &&
        string(c.from) &&
        string(c.to) &&
        (ids.has(c.from) || (c.from==='' && record(c.start) && finite(c.start.x) && finite(c.start.y))) &&
        (ids.has(c.to) || (c.to==='' && record(c.end) && finite(c.end.x) && finite(c.end.y))) &&
        (c.from==='' || c.from !== c.to), "connection endpoint does not exist");
      require(!connectionIds.has(c.id), "duplicate connection IDs");
      connectionIds.add(c.id);
      require(safeColor(c.color) &&
        (c.style === "solid" || c.style === "dashed") &&
        (c.label === undefined || string(c.label)), "invalid connection");
      for(const field of ["start", "end", "control"]) require(c[field]===undefined || (record(c[field]) && finite((c[field] as UnknownRecord).x) && finite((c[field] as UnknownRecord).y)), "invalid line point");
      for(const field of ["fromAnchor", "toAnchor"]) {
        const anchor=c[field];
        require(anchor===undefined || (record(anchor) && finite(anchor.x) && finite(anchor.y) && anchor.x>=0 && anchor.x<=1 && anchor.y>=0 && anchor.y<=1), "invalid line anchor");
      }
      for (const field of ["startArrow", "endArrow"]) require(c[field] === undefined || typeof c[field] === "boolean", "invalid line arrow");
      require(c.bend === undefined ||
        finite(c.bend), "invalid connection bend");
      require(c.width === undefined ||
        (finite(c.width) && c.width > 0), "invalid connection width");
    }
    const seen = new Set([id]);
    let parent: unknown = b.parentBoardId;
    while (string(parent)) {
      require(!seen.has(parent), "cyclic board hierarchy");
      seen.add(parent);
      const next = boards[parent];
      parent = record(next) ? next.parentBoardId : undefined;
    }
  }
  const root = boards[value.rootBoardId];
  require(record(root) &&
    root.parentBoardId === undefined, "root board cannot have a parent");
  for (const id of Object.keys(boards))
    if (id !== value.rootBoardId) {
      const candidate=boards[id] as UnknownRecord;
      if(candidate.isExternalReference===true && !boardOwners.has(id)) {
        require(candidate.parentBoardId===undefined,'external reference root cannot have a parent');
        require(Object.values(boards).some(board=>record(board)&&Array.isArray(board.cards)&&board.cards.some(card=>record(card)&&card.type==='board'&&card.isShortcut===true&&card.boardId===id)), 'external reference is not reachable through a shortcut');
      }
      else if(candidate.isTemplate===true && !boardOwners.has(id)) require(candidate.parentBoardId===undefined,"template root cannot have a parent");
      else require(boardOwners.has(id), "nested board is not reachable from its owner");
    }
  if(!options.skipTrash&&value.trash!==undefined){
    require(Array.isArray(value.trash),"invalid trash");const trashIds=new Set<string>();
    for(const entry of value.trash){require(isValidTrashEntry(entry)&&!trashIds.has(entry.id),"invalid trash entry");trashIds.add(entry.id);require(!Object.hasOwn(entry.boards,entry.sourceBoardId),"invalid deleted board ownership");validateWorkspace(trashEntryValidationWorkspace(entry),{skipTrash:true,allowUnknownLabels:true});}
  }
  return value as unknown as Workspace;
}
export function importWorkspace(json: string): Workspace {
  let value: unknown;
  try {
    value = JSON.parse(json);
  } catch {
    throw new Error("This file is not valid JSON.");
  }
  return sanitizeWorkspaceHtml(validateWorkspace(value));
}
/** Normalize imported rich text before it is persisted or copied into another backup. */
function sanitizeWorkspaceHtml(workspace: Workspace): Workspace {
  const cleanCard=(card:Card):Card=>{
    const values:Partial<Card>={};
    if(card.type==='note'&&card.html!==undefined)Object.assign(values,{html:sanitizeNoteHtml(card.html)});
    if('captionHtml' in card&&card.captionHtml!==undefined)Object.assign(values,{captionHtml:sanitizeNoteHtml(card.captionHtml)});
    return Object.keys(values).length?{...card,...values} as Card:card;
  };
  const cleanBoards=(boards:Workspace['boards'])=>Object.fromEntries(Object.entries(boards).map(([id,board])=>[id,{...board,cards:board.cards.map(cleanCard)}]));
  return {...workspace,boards:cleanBoards(workspace.boards),...(workspace.trash?{trash:workspace.trash.map(entry=>({...entry,cards:entry.cards.map(cleanCard),boards:cleanBoards(entry.boards)}))}:{})};
}
export function exportWorkspace(workspace: Workspace): string {
  return JSON.stringify(workspace, null, 2);
}

interface Stored {
  workspace: Workspace;
  savedAt: number;
}
let database: Promise<IDBDatabase> | undefined;
function openDatabase(): Promise<IDBDatabase> {
  if (!database)
    database = new Promise<IDBDatabase>((resolve, reject) => {
      if (!globalThis.indexedDB) {
        reject(new Error("IndexedDB is unavailable"));
        return;
      }
      const request = indexedDB.open(DB_NAME, 1);
      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains(STORE))
          request.result.createObjectStore(STORE);
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () =>
        reject(request.error ?? new Error("Could not open local database"));
      request.onblocked = () =>
        reject(new Error("Local database is blocked by another tab"));
    }).catch((error) => {
      database = undefined;
      throw error;
    });
  return database;
}
function stored(value: unknown): Stored | null {
  if (value === undefined || value === null) return null;
  require(record(value) && finite(value.savedAt), "invalid saved document");
  return {
    workspace: sanitizeWorkspaceHtml(validateWorkspace(value.workspace)),
    savedAt: value.savedAt,
  };
}
export async function loadWorkspace(): Promise<Workspace | null> {
  let fallback: Stored | null = null,
    primary: Stored | null = null,
    fallbackError: unknown;
  try {
    const raw = globalThis.localStorage?.getItem(FALLBACK_KEY);
    if (raw) fallback = stored(JSON.parse(raw));
  } catch (error) {
    fallbackError = error;
  }
  try {
    const db = await openDatabase();
    const value = await new Promise<unknown>((resolve, reject) => {
      const req = db.transaction(STORE, "readonly").objectStore(STORE).get(KEY);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    primary = stored(value);
  } catch (error) {
    if (
      !fallback &&
      error instanceof Error &&
      error.message.startsWith("Invalid workspace:")
    )
      throw error;
  }
  if (!primary && !fallback && fallbackError)
    throw new Error(
      "The saved local backup could not be read. Keep an exported copy before resetting this browser.",
    );
  return fallback && (!primary || fallback.savedAt > primary.savedAt)
    ? fallback.workspace
    : (primary?.workspace ?? null);
}
/** Resolves only after the storage transaction commits; callers can show true save status. */
export async function saveWorkspace(
  workspace: Workspace,
): Promise<"indexeddb" | "localstorage"> {
  const snapshot: Stored = {
    workspace: structuredClone(workspace),
    savedAt: Date.now(),
  };
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).put(snapshot, KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error ?? new Error("Save was interrupted"));
    });
    try {
      globalThis.localStorage?.removeItem(FALLBACK_KEY);
    } catch {
      /* Database save has succeeded. */
    }
    return "indexeddb";
  } catch {
    if (!globalThis.localStorage)
      throw new Error(
        "Local storage is unavailable. Export your board to keep a copy.",
      );
    globalThis.localStorage.setItem(FALLBACK_KEY, JSON.stringify(snapshot));
    return "localstorage";
  }
}
