import { updateBoard } from './model';
import type { Card,Workspace } from './model';
import { arrangeAllColumns } from './columns';

export const CARD_COLORS=['#ffffff','#bbbec3','#62dbc8','#7cd651','#d58558','#ffd14d','#ff8d48','#ff5757','#ff6ed4','#ad6fff','#4ebafd','#5882f8'] as const;
const hex=(value:string)=>/^#[\da-f]{6}$/i.test(value);
export const canUseColorStrip=(card:Card)=>['note','image','link','todo','file'].includes(card.type);
export function updateCardAppearance(workspace:Workspace,boardId:string,ids:string[],value:{background?:string;strip?:string|null;remember?:string}):Workspace{
  const board=workspace.boards[boardId];if(!board)return workspace;
  if(value.background!==undefined&&value.background!=='transparent'&&!hex(value.background))return workspace;
  if(value.strip!==undefined&&value.strip!==null&&!hex(value.strip))return workspace;
  const targets=new Set(ids);let changed=false;
  let next=updateBoard(workspace,boardId,board=>arrangeAllColumns({...board,cards:board.cards.map(card=>{
    if(!targets.has(card.id))return card;
    const strip=value.strip!==undefined&&canUseColorStrip(card)?value.strip||undefined:card.stripColor;
    const color=value.background??card.color;
    if(color===card.color&&strip===card.stripColor)return card;
    changed=true;return {...card,color,stripColor:strip,height:card.height+(strip?4:0)-(card.stripColor?4:0)};
  })}));
  const remembered=value.remember&&hex(value.remember)?value.remember.toLowerCase():undefined;
  if(remembered&&!CARD_COLORS.includes(remembered as typeof CARD_COLORS[number])){
    const colors=[...(workspace.customColors||[]).filter(color=>color!==remembered),remembered].slice(-7);
    if(JSON.stringify(colors)!==JSON.stringify(workspace.customColors||[])){changed=true;next={...next,customColors:colors};}
  }
  return changed?next:workspace;
}
