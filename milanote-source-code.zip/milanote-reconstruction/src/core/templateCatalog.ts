import catalogJson from '../data/templateCatalog.json?raw';
import {createCard,deleteCards,uid} from './model';
import {boardIconSvgUrl} from './boardIcons';
import type {Board,Card,Point,Workspace} from './model';

export interface CatalogTemplate {
  id:string;
  title:string;
  keywords:string;
  boardId:string;
  forceClear:boolean;
  emptyBoardId:string;
  publicUrls:string[];
}
export interface CatalogCategory {id:string;title:string;entries:{id:string;displayName:string}[]}
export interface CatalogBoard extends Board {sourceIconId?:string;sourceTemplateLinkId?:string}
export interface TemplateCatalogData {
  schemaVersion:number;
  observedAt:string;
  categories:CatalogCategory[];
  entries:CatalogTemplate[];
  boards:Record<string,CatalogBoard>;
  /** Public boards reached by an observed shortcut, separate from owned content. */
  externalBoards:Record<string,CatalogBoard>;
  externalBoardErrors:Record<string,{code:string;status:number;observedAt:string}>;
  coverage:Record<string,unknown>;
}
export interface CatalogTemplateOptions {includeExampleContent?:boolean}
export interface CatalogPreview {rootBoardId:string;boards:Record<string,Board>;templateId:string;includesExampleContent:boolean}
const catalog=JSON.parse(catalogJson) as TemplateCatalogData;
const entries=new Map(catalog.entries.map(entry=>[entry.id,entry]));
const categories=new Map(catalog.categories.map(category=>[category.id,category]));
const fold=(value:string)=>value.normalize('NFKD').replace(/\p{M}/gu,'').toLocaleLowerCase().trim();

/** Public template metadata is factual inventory. Returned values are detached
 * from the shared catalog so a consumer cannot change later instances. */
export function getTemplateCatalog():CatalogTemplate[]{return structuredClone(catalog.entries);}
export function getTemplateCategories():CatalogCategory[]{return structuredClone(catalog.categories);}
export function getTemplateCatalogCoverage():Record<string,unknown>{return structuredClone(catalog.coverage);}
export function getCatalogTemplate(templateId:string):CatalogTemplate|undefined {
  const entry=entries.get(templateId);return entry?structuredClone(entry):undefined;
}
export function searchTemplateCatalog({query='',categoryId}:{query?:string;categoryId?:string}={}):(CatalogTemplate&{displayName:string})[]{
  const queryWords=fold(query).split(/\s+/).filter(Boolean),category=categoryId?categories.get(categoryId):undefined;
  if(categoryId&&!category)return [];
  const items=category?category.entries:catalog.entries.map(entry=>({id:entry.id,displayName:entry.title}));
  return items.flatMap(item=>{
    const entry=entries.get(item.id);if(!entry)return [];
    const text=fold([entry.title,item.displayName,entry.keywords].join(' '));
    return queryWords.every(word=>text.includes(word))?[{...structuredClone(entry),displayName:item.displayName}]:[];
  });
}
function selectedRoot(entry:CatalogTemplate,options:CatalogTemplateOptions):{id:string;examples:boolean}{
  const examples=options.includeExampleContent===true&&!entry.forceClear;
  const example=catalog.boards[entry.boardId];
  if(!example)throw new Error(`The template structure is unavailable: ${entry.id}`);
  const id=examples?entry.boardId:example.sourceTemplateLinkId;
  if(!id||!catalog.boards[id])throw new Error(`The empty template structure is unavailable: ${entry.id}`);
  return {id,examples};
}
function templateBoards(rootId:string):CatalogBoard[]{
  const found=new Set<string>(),pending=[rootId],ordered:CatalogBoard[]=[];
  while(pending.length){
    const id=pending.pop()!;if(found.has(id))continue;
    const board=catalog.boards[id]||catalog.externalBoards[id];if(!board)throw new Error(`A nested template board is unavailable: ${id}`);
    found.add(id);ordered.push(board);
    for(const card of board.cards)if(card.type==='board'&&(!card.isShortcut||catalog.externalBoards[card.boardId]))pending.push(card.boardId);
  }
  return ordered;
}
function cloneTemplate(entry:CatalogTemplate,options:CatalogTemplateOptions,rootId?:string,parentId?:string):CatalogPreview{
  const selected=selectedRoot(entry,options),sourceBoards=templateBoards(selected.id),boardIds=new Map<string,string>();
  for(const board of sourceBoards)boardIds.set(board.id,board.id===selected.id&&rootId?rootId:uid());
  // Source location.parentId can name a column. Ownership belongs to the board
  // containing its non-shortcut tile, just as in an ordinary workspace.
  const owners=new Map<string,string>();
  for(const board of sourceBoards)for(const card of board.cards)if(card.type==='board'&&!card.isShortcut){
    const previous=owners.get(card.boardId);
    if(previous&&previous!==board.id)throw new Error(`The template board has multiple owners: ${card.boardId}`);
    owners.set(card.boardId,board.id);
  }
  const cardIds=new Map<string,string>();for(const board of sourceBoards)for(const card of board.cards)cardIds.set(card.id,uid());
  const boards:Record<string,Board>={};
  for(const source of sourceBoards){
    const id=boardIds.get(source.id)!,{sourceTemplateLinkId:_templatePeer,...plain}=structuredClone(source);
    const cards:Card[]=source.cards.map(original=>{
      const card={...structuredClone(original),id:cardIds.get(original.id)!} as Card;
      if(card.parentId)card.parentId=cardIds.get(card.parentId);
      if(card.type==='board')card.boardId=boardIds.get(card.boardId)||card.boardId;
      if(card.type==='todo')card.items=card.items.map(item=>({...item,id:uid()}));
      if(card.type==='note')delete card.syncedId;
      return card;
    });
    boards[id]={...plain,icon:source.id===selected.id?undefined:source.icon||(source.sourceIconId?boardIconSvgUrl(source.sourceIconId,{color:'#323b4a'}):undefined),id,title:source.id===selected.id?entry.title:source.title,
      parentBoardId:source.id===selected.id?parentId:boardIds.get(owners.get(source.id)||''),
      ...(source.id!==selected.id&&!owners.has(source.id)&&catalog.externalBoards[source.id]?{isExternalReference:true}:{}),
      isTemplate:undefined,cards,
      connections:source.connections.map(line=>({...structuredClone(line),id:uid(),from:cardIds.get(line.from)||'',to:cardIds.get(line.to)||''})),
    };
  }
  return {rootBoardId:boardIds.get(selected.id)!,boards,templateId:entry.id,includesExampleContent:selected.examples};
}
/** A detached, editable preview. It never touches the caller's workspace or
 * autosave/history; the host decides when Continue commits the transaction. */
export function getCatalogPreview(templateId:string,options:CatalogTemplateOptions={}):CatalogPreview|undefined {
  if(templateId==='empty-board'){const root=uid();return {rootBoardId:root,boards:{[root]:{id:root,title:'New Board',cards:[],connections:[],viewport:{x:16,y:16,zoom:1},background:'#ebedee',grid:true}},templateId,includesExampleContent:false};}
  const entry=entries.get(templateId);return entry?cloneTemplate(entry,options):undefined;
}
/** Instantiate the actual captured branch, including every nested board and
 * column membership. Keep-example-off selects its separately captured peer;
 * it does not discard arbitrary cards from the example version. */
export function instantiateCatalogTemplate(workspace:Workspace,templateId:string,parentId:string,at:Point,options:CatalogTemplateOptions={}):{workspace:Workspace;boardId?:string}{
  const parent=workspace.boards[parentId];if(!parent)return {workspace};
  if(templateId==='empty-board'){const id=uid(),tile={...createCard('board',at.x,at.y),type:'board' as const,boardId:id,title:'New Board'};return {workspace:{...workspace,updatedAt:new Date().toISOString(),boards:{...workspace.boards,[id]:{id,title:'New Board',parentBoardId:parentId,cards:[],connections:[],viewport:{x:16,y:16,zoom:1}},[parentId]:{...parent,cards:[...parent.cards,tile]}}},boardId:id};}
  const entry=entries.get(templateId);if(!entry)return {workspace};
  const preview=cloneTemplate(entry,options,undefined,parentId),root=preview.boards[preview.rootBoardId];
  const tile={...createCard('board',at.x,at.y),type:'board' as const,boardId:root.id,title:entry.title};
  return {workspace:{...workspace,updatedAt:new Date().toISOString(),boards:{...workspace.boards,...preview.boards,[parentId]:{...parent,cards:[...parent.cards,tile]}}},boardId:root.id};
}
/** Apply to an existing board in one host Undo transaction. Identity, incoming
 * shortcuts and the owning tile remain; old owned descendants are removed by
 * the same ownership rule used for ordinary board content deletion. */
export function applyCatalogTemplateToBoard(workspace:Workspace,templateId:string,targetId:string,options:CatalogTemplateOptions={}):{workspace:Workspace;boardId?:string}{
  const target=workspace.boards[targetId];if(!target)return {workspace};
  if(templateId==='empty-board'){const next=deleteCards(workspace,targetId,target.cards.map(card=>card.id));return {workspace:{...next,updatedAt:new Date().toISOString(),boards:{...next.boards,[targetId]:{...next.boards[targetId],connections:[]}}},boardId:targetId};}
  const entry=entries.get(templateId);if(!entry)return {workspace};
  const preview=cloneTemplate(entry,options,targetId,target.parentBoardId);
  const emptied=deleteCards(workspace,targetId,target.cards.map(card=>card.id));
  const root={...preview.boards[targetId],title:target.title,icon:target.icon};
  return {workspace:{...emptied,updatedAt:new Date().toISOString(),boards:{...emptied.boards,...preview.boards,[targetId]:root}},boardId:targetId};
}
