import http from 'node:http';
import https from 'node:https';
import tls from 'node:tls';
import { isIP } from 'node:net';
import { lookup as dnsLookup } from 'node:dns/promises';
import { parse } from 'parse5';

const MAX_BYTES=1024*1024;
export function normalizeMetadataUrl(value,base){
  if(typeof value!=='string'||value.length>4096)return null;
  try{const url=new URL(value.trim(),base);if(!['http:','https:'].includes(url.protocol)||url.username||url.password||(url.port&&url.port!==(url.protocol==='https:'?'443':'80')))return null;url.hash='';return url.href.length<=4096?url:null;}catch{return null;}
}
export function isPublicAddress(address){
  const kind=isIP(address);
  if(kind===4){const [a,b,c]=address.split('.').map(Number);return !(a===0||a===10||a===127||a>=224||(a===100&&b>=64&&b<=127)||(a===169&&b===254)||(a===172&&b>=16&&b<=31)||(a===192&&((b===0&&(c===0||c===2))||b===168||(b===88&&c===99)))||(a===198&&(b===18||b===19||(b===51&&c===100)))||(a===203&&b===0&&c===113));}
  if(kind!==6||address.includes('.'))return false;
  const groups=address.toLowerCase().split(':');const first=parseInt(groups[0]||'0',16),second=parseInt(groups[1]||'0',16);
  return first>=0x2000&&first<=0x3fff&&first!==0x2002&&!(first===0x2001&&(second<=0x1ff||second===0xdb8))&&!(first===0x3fff&&second<0x1000);
}
function aborted(signal){if(signal?.aborted)throw signal.reason||new Error('Aborted');}
async function bounded(operation,signal){aborted(signal);let onAbort;try{return await Promise.race([operation,new Promise((_,reject)=>{onAbort=()=>reject(signal.reason||new Error('Aborted'));signal.addEventListener('abort',onAbort,{once:true});})]);}finally{if(onAbort)signal.removeEventListener('abort',onAbort);}}
export async function resolvePublicTarget(url,{lookup=dnsLookup,signal=AbortSignal.timeout(10000)}={}){
  if(!normalizeMetadataUrl(url.href))throw new Error('Unsupported URL');
  const host=url.hostname.replace(/^\[|\]$/g,'').toLowerCase();
  if(!host.includes('.')&&!isIP(host)||/\.(?:localhost|local|internal|home|lan|invalid)$/.test(host)||host==='localhost')throw new Error('Private destination');
  const answers=isIP(host)?[{address:host,family:isIP(host)}]:await bounded(lookup(host,{all:true,verbatim:true}),signal);
  if(!Array.isArray(answers)||!answers.length||answers.length>64||answers.some(answer=>!isPublicAddress(answer.address)))throw new Error('Private destination');
  aborted(signal);return {address:answers[0].address,family:isIP(answers[0].address),hostname:host,port:Number(url.port||(url.protocol==='https:'?443:80))};
}
function configuredProxy(url){
  const raw=url.protocol==='https:'?(process.env.HTTPS_PROXY||process.env.https_proxy||process.env.HTTP_PROXY||process.env.http_proxy):(process.env.HTTP_PROXY||process.env.http_proxy);
  if(!raw)return null;
  const proxy=new URL(raw);if(!['http:','https:'].includes(proxy.protocol))throw new Error('Unsupported proxy');return proxy;
}
async function proxyTunnel(proxy,target,signal){
  return new Promise((resolve,reject)=>{
    const authority=`${target.family===6?'['+target.address+']':target.address}:${target.port}`;
    const headers={Host:authority};if(proxy.username||proxy.password)headers['Proxy-Authorization']='Basic '+Buffer.from(decodeURIComponent(proxy.username)+':'+decodeURIComponent(proxy.password)).toString('base64');
    const request=(proxy.protocol==='https:'?https:http).request({hostname:proxy.hostname,port:proxy.port||undefined,method:'CONNECT',path:authority,headers,signal,agent:false});
    request.once('connect',(response,socket,head)=>{if(response.statusCode!==200){socket.destroy();reject(new Error('Proxy tunnel unavailable'));return;}if(head.length)socket.unshift(head);resolve(socket);});
    request.once('response',response=>{response.destroy();reject(new Error('Proxy tunnel unavailable'));});request.once('error',reject);request.end();
  });
}
/** The requested address is pinned after public-DNS validation. Proxy tunnels
 * also target that numeric address; neither transport re-resolves the origin. */
export async function requestPublicPage(url,target,{signal=AbortSignal.timeout(10000),maxBytes=MAX_BYTES,proxy=configuredProxy(url)}={}){
  let agent,socket;
  try{
    if(proxy){socket=await proxyTunnel(proxy,target,signal);agent=url.protocol==='https:'?new https.Agent({keepAlive:false}):new http.Agent({keepAlive:false});agent.createConnection=()=>url.protocol==='https:'?tls.connect({socket,host:target.hostname,servername:isIP(target.hostname)?undefined:target.hostname,rejectUnauthorized:true}):socket;}
    return await new Promise((resolve,reject)=>{
      const request=(url.protocol==='https:'?https:http).request({protocol:url.protocol,hostname:target.hostname,port:target.port,path:url.pathname+url.search,method:'GET',headers:{Host:url.host,Accept:'text/html, application/xhtml+xml','Accept-Encoding':'identity','User-Agent':'Canvas-Link-Preview/1.0'},signal,agent:agent||false,lookup:(_host,options,callback)=>{const answer={address:target.address,family:target.family};if(options?.all)callback(null,[answer]);else callback(null,answer.address,answer.family);}},response=>{
        const headers=response.headers,status=response.statusCode||0;
        if(status>=300&&status<400){response.destroy();resolve({status,headers,body:''});return;}
        const type=String(headers['content-type']||'').toLowerCase(),encoding=String(headers['content-encoding']||'identity').toLowerCase();
        if(status!==200||!/^\s*(?:text\/html|application\/xhtml\+xml)(?:;|$)/.test(type)||encoding!=='identity'||Number(headers['content-length']||0)>maxBytes){response.destroy();reject(new Error('Unsupported preview response'));return;}
        let size=0;const chunks=[];
        response.on('data',chunk=>{size+=chunk.length;if(size>maxBytes){const error=new Error('Preview is too large');reject(error);response.destroy(error);return;}chunks.push(chunk);});
        response.once('end',()=>{
          const bytes=Buffer.concat(chunks),declared=/charset\s*=\s*["']?([a-z\d._-]+)/i.exec(type)?.[1]||/<meta\b[^>]*\bcharset\s*=\s*["']?([a-z\d._-]+)/i.exec(bytes.subarray(0,2048).toString('ascii'))?.[1]||'utf-8';
          try{resolve({status,headers,body:new TextDecoder(declared).decode(bytes)});}catch{reject(new Error('Unsupported preview encoding'));}
        });response.once('error',reject);response.once('aborted',()=>reject(new Error('Preview interrupted')));
      });
      request.once('error',reject);request.end();
    });
  }finally{agent?.destroy();socket?.destroy();}
}
const attrs=node=>Object.fromEntries((node.attrs||[]).map(attr=>[attr.name.toLowerCase(),attr.value]));
function nodeText(node){if(['script','style','noscript'].includes(node.tagName))return '';return node.nodeName==='#text'?node.value||'':(node.childNodes||[]).map(nodeText).join(' ');}
const text=(value,max=4096)=>typeof value==='string'?value.replace(/<[^>]*>/g,' ').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g,'').replace(/\s+/g,' ').trim().slice(0,max):'';
export function parseLinkMetadata(html,pageUrl){
  const document=parse(html),values=new Map();let title='',base;
  const visit=node=>{const properties=attrs(node);if(node.tagName==='title'&&!title)title=text(nodeText(node),512);if(node.tagName==='meta'){const key=(properties.property||properties.name||'').toLowerCase();if(key&&!values.has(key)&&text(properties.content))values.set(key,properties.content);}if(node.tagName==='base'&&!base)base=normalizeMetadataUrl(properties.href,pageUrl)?.href;for(const child of node.childNodes||[])visit(child);};visit(document);
  const result={url:pageUrl};const name=text(values.get('og:title')||values.get('twitter:title')||title,512),description=text(values.get('og:description')||values.get('twitter:description')||values.get('description'),2048),image=normalizeMetadataUrl(values.get('og:image:secure_url')||values.get('og:image')||values.get('twitter:image'),base||pageUrl);
  if(name)result.title=name;if(description)result.description=description;if(image)result.image=image.href;return result;
}
export async function getLinkMetadata(source,{lookup=dnsLookup,request=requestPublicPage,signal=AbortSignal.timeout(10000),maxBytes=MAX_BYTES}={}){
  let url=normalizeMetadataUrl(source);if(!url)throw new Error('Unsupported URL');
  const visited=new Set();
  for(let redirects=0;redirects<=4;redirects++){
    if(visited.has(url.href))throw new Error('Redirect loop');visited.add(url.href);
    const target=await resolvePublicTarget(url,{lookup,signal});const response=await bounded(request(url,target,{signal,maxBytes}),signal);aborted(signal);
    if([301,302,303,307,308].includes(response.status)){if(redirects===4)throw new Error('Too many redirects');url=normalizeMetadataUrl(response.headers.location,url.href);if(!url)throw new Error('Unsupported redirect');continue;}
    if(response.status!==200||typeof response.body!=='string'||Buffer.byteLength(response.body)>maxBytes)throw new Error('Unsupported response');
    const result=parseLinkMetadata(response.body,url.href);
    if(result.image){try{await resolvePublicTarget(new URL(result.image),{lookup,signal});}catch{delete result.image;}}
    return result;
  }
  throw new Error('Too many redirects');
}
function send(response,status,value){response.statusCode=status;response.setHeader('Content-Type','application/json; charset=utf-8');response.setHeader('Cache-Control','no-store');response.setHeader('X-Content-Type-Options','nosniff');response.end(JSON.stringify(value));}
export function createLinkMetadataMiddleware({path='/api/links/metadata',lookup=dnsLookup,request=requestPublicPage,timeoutMs=10000}={}){
  let active=0;const cache=new Map();
  return async(req,res,next=()=>{})=>{
    let endpoint;try{endpoint=new URL(req.url||'/','http://localhost');}catch{return next();}if(endpoint.pathname!==path)return next();
    if(req.method!=='GET'){res.setHeader('Allow','GET');send(res,405,{error:'Only GET is supported.'});return;}
    const url=normalizeMetadataUrl(endpoint.searchParams.get('url'));if(!url){send(res,400,{error:'Enter a valid public website URL.'});return;}
    const cached=cache.get(url.href);if(cached?.expires>Date.now()){send(res,200,cached.value);return;}if(active>=8){send(res,429,{error:'Link previews are busy. Please try again.'});return;}
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(new Error('Preview timed out')),timeoutMs),closed=()=>controller.abort(new Error('Request closed'));req.once?.('aborted',closed);res.once?.('close',closed);active++;
    try{const value=await getLinkMetadata(url.href,{lookup,request,signal:controller.signal});if(cache.size>=100)cache.delete(cache.keys().next().value);cache.set(url.href,{expires:Date.now()+300000,value});send(res,200,value);}
    catch{if(!res.destroyed)send(res,503,{error:'This link preview is unavailable. You can edit its details.'});}
    finally{active--;clearTimeout(timer);req.off?.('aborted',closed);res.off?.('close',closed);}
  };
}
