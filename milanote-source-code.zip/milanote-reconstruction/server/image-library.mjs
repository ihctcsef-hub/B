/** Official Pexels API adapter. The provider credential remains in the local server environment. */
const send=(response,status,value)=>{response.statusCode=status;response.setHeader('Content-Type','application/json; charset=utf-8');response.setHeader('Cache-Control','private, max-age=60');response.end(JSON.stringify(value));};
const validPhotoUrl=value=>{try{const url=new URL(value);return url.protocol==='https:'&&url.hostname==='images.pexels.com'?url.href:'';}catch{return '';}};
const publicUrl=value=>{try{const url=new URL(value);return url.protocol==='https:'?url.href:'';}catch{return '';}};
export function normalizePexelsResponse(value,page){
  const data=value&&typeof value==='object'?value:{};
  const photos=Array.isArray(data.photos)?data.photos.flatMap(photo=>{
    const src=validPhotoUrl(photo.src?.original),thumbnail=validPhotoUrl(photo.src?.medium||photo.src?.large);
    return src&&thumbnail&&Number.isFinite(photo.width)&&photo.width>0&&Number.isFinite(photo.height)&&photo.height>0?[{id:String(photo.id),width:photo.width,height:photo.height,src,thumbnail,alt:typeof photo.alt==='string'?photo.alt:'',photographer:typeof photo.photographer==='string'?photo.photographer:'',photographerUrl:publicUrl(photo.photographer_url),pageUrl:publicUrl(photo.url)}]:[];
  }):[];
  return {provider:'pexels',photos,page,totalResults:Number.isFinite(data.total_results)?data.total_results:photos.length,nextPage:data.next_page&&photos.length?page+1:null};
}

export function createImageLibraryMiddleware({apiKey=process.env.PEXELS_API_KEY,fetchImpl=globalThis.fetch,path='/api/images/search'}={}){
  const cache=new Map();
  return async(request,response,next=()=>{})=>{
    let url;try{url=new URL(request.url||'/','http://localhost');}catch{return next();}
    if(url.pathname!==path)return next();
    if(request.method!=='GET'){response.setHeader('Allow','GET');send(response,405,{error:'Only GET is supported.'});return;}
    if(!apiKey){send(response,503,{error:'Image search is unavailable right now.'});return;}
    const query=(url.searchParams.get('query')||'').trim().slice(0,120),page=Number(url.searchParams.get('page')||1);
    if(!Number.isInteger(page)||page<1||page>1000){send(response,400,{error:'Invalid image-search page.'});return;}
    const key=JSON.stringify([query,page]),cached=cache.get(key);if(cached&&cached.expires>Date.now()){send(response,200,cached.value);return;}
    const upstream=new URL(query?'https://api.pexels.com/v1/search':'https://api.pexels.com/v1/curated');upstream.searchParams.set('per_page','30');upstream.searchParams.set('page',String(page));if(query)upstream.searchParams.set('query',query);
    try{
      const result=await fetchImpl(upstream,{headers:{Authorization:apiKey,Accept:'application/json'},signal:AbortSignal.timeout(20000)});
      if(!result.ok){send(response,result.status===429?429:503,{error:result.status===429?'Image search is busy. Please try again shortly.':'Image search is unavailable right now.'});return;}
      const value=normalizePexelsResponse(await result.json(),page);if(cache.size>=100)cache.delete(cache.keys().next().value);cache.set(key,{expires:Date.now()+5*60*1000,value});send(response,200,value);
    }catch{send(response,503,{error:'Image search is unavailable right now.'});}
  };
}
